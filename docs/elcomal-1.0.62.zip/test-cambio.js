// Headless assertions for the Cambio pendiente (saldo a favor) flow.
// Mirrors the real formulas from data.js/screens.js so a regression in the
// arithmetic is caught without a browser.
const rows = [];
const sign = r => (r.kind === 'applied' ? -1 : 1);
const get = id => rows.filter(r => r.customerId === id).reduce((s, r) => s + sign(r) * r.amount, 0);
function push(customerId, amount, kind) {
  if (!(amount > 0)) return null;
  rows.push({ customerId, amount, kind });
  return { amount, kind };
}
const record = (c, a) => push(c, a, 'owed');
const apply = (c, a) => push(c, Math.max(0, Math.min(a, get(c))), 'applied');

let pass = 0, fail = 0;
function eq(label, actual, expected) {
  const ok = Math.abs(actual - expected) < 0.005;
  if (ok) { pass++; }
  else { fail++; console.log(`  FAIL ${label}: got ${actual}, expected ${expected}`); }
}
function section(t) { console.log('\n' + t); }

section('Ledger sign convention');
eq('balance starts at 0', get('c1'), 0);
record('c1', 2);
eq('after recording 2 owed', get('c1'), 2);
apply('c1', 2);
eq('after applying 2, balance is 0 not 4', get('c1'), 0);

section('The regression this replaces');
rows.length = 0;
record('c2', 2); apply('c2', 2);
eq('owed+applied nets to zero', get('c2'), 0);

section('Over-application is clamped, not negative');
rows.length = 0;
record('c3', 2);
apply('c3', 50);
eq('applying 50 against a 2 balance consumes only 2', get('c3'), 0);

section('Partial application');
rows.length = 0;
record('c4', 10);
apply('c4', 4);
eq('4 applied leaves 6 owed', get('c4'), 6);
apply('c4', 6);
eq('remaining 6 applied leaves 0', get('c4'), 0);

section('Multiple cycles accumulate');
rows.length = 0;
record('c5', 2); record('c5', 3); apply('c5', 2);
eq('2+3 owed, 2 applied => 3 remaining', get('c5'), 3);
record('c5', 1);
eq('a further 1 owed => 4', get('c5'), 4);

section('Day 1: sale 48, a 50 typed is a typo and is rejected');
{
  const price = 24, qty = 2, neto = qty * price;
  eq('sale value', neto, 48);
  const cash = 50;
  // The "No tengo cambio" opt-in was removed: there is no way to declare an
  // unbreakable bill, so a surplus is always refused rather than booked as a
  // liability. The driver re-types the exact amount.
  const rejected = cash > neto + 0.01;
  eq('surplus is rejected', rejected ? 1 : 0, 1);
  const cashApplied = Math.min(cash, neto);
  eq('cash applied to the sale', cashApplied, 48);
  eq('surplus is dropped, not booked as change owed', Math.max(0, cash - cashApplied), 2); // never booked
  const todayCredit = Math.max(0, neto - cashApplied);
  eq('no receivable created', todayCredit, 0);
  // report
  const brutoValue = neto, recompraValue = 0, streetTotal = 0, devValue = 0, totalCredited = 0;
  const routeGross = brutoValue - recompraValue - streetTotal;
  const routeCash = routeGross - devValue - totalCredited;
  const totalCashCollected = routeCash + recompraValue + streetTotal;
  const totalCash = 48;
  const changeOwedAgg = 0, owedAppliedAgg = 0;
  const rawGap = totalCash - totalCashCollected + streetTotal;
  const abonos = Math.max(0, rawGap - changeOwedAgg);
  const totalCashReal = totalCashCollected + abonos + changeOwedAgg - owedAppliedAgg;
  eq('no change is reported as abonos', abonos, 0);
  eq('report total cash equals physical cash', totalCashReal, 48);
  eq('route cash matches the sale', routeCash, 48);
}

section('Day 2: sale 30, 2 owed applied, driver collects 28');
{
  rows.length = 0;
  record('c6', 2);
  const price = 24, qty = 1.25, neto = 30;
  eq('sale value', neto, 30);
  const owedBal = get('c6');
  eq('app owes the customer', owedBal, 2);
  const base = Math.max(0, neto);
  const owedApplied = Math.min(Math.max(0, owedBal), base);
  eq('auto-applied this stop', owedApplied, 2);
  const owedBase = Math.max(0, base - owedApplied);
  eq('remaining to charge in cash', owedBase, 28);
  const cash = 28;
  const cashApplied = Math.min(cash, owedBase);
  eq('cash applied', cashApplied, 28);
  eq('nothing is owed back', Math.max(0, cash - cashApplied), 0);
  const todayCredit = Math.max(0, owedBase - cashApplied);
  eq('no receivable', todayCredit, 0);
  apply('c6', owedApplied);
  eq('liability cleared after the sale', get('c6'), 0);
  // report
  const brutoValue = 30, routeGross = 30, routeCash = 30, totalCashCollected = 30;
  const totalCash = 28, changeOwedAgg = 0, owedAppliedAgg = 2;
  const rawGap = totalCash - totalCashCollected;
  eq('no phantom abonos when cash is low', Math.max(0, rawGap - changeOwedAgg), 0);
  const totalCashReal = totalCashCollected + 0 + changeOwedAgg - owedAppliedAgg;
  eq('report total cash equals physical cash', totalCashReal, 28);
}

section('A 50 typed against a 48 sale is always rejected (the opt-in is gone)');
{
  // One rule, no chip: cash may never exceed what the sale is worth. A stale
  // `noChange` from an old caller must not be able to reopen the liability path.
  for (const stale of [false, true, undefined]) {
    const neto = 48, cash = 50;
    const rejected = cash > neto + 0.01;
    eq(`rejected (stale noChange=${String(stale)})`, rejected ? 1 : 0, 1);
  }
}

section('Owed can never exceed the sale it is applied to');
{
  rows.length = 0;
  record('c7', 50);
  const neto = 10;
  const owedApplied = Math.min(get('c7'), Math.max(0, neto));
  eq('applied capped at the sale value', owedApplied, 10);
  eq('excess stays owed for the next order', get('c7') - owedApplied, 40);
}

section('Change + old debt collected in one stop');
{
  rows.length = 0;
  // NOTE: the old receivable lives in `customer.balance` (a separate account),
  // so it must NOT be seeded into the owed ledger or the two get conflated.
  const pending = 5;           // getCustomerBalance — customer owes us
  record('c8', 3);             // saldo a favor — we owe them
  eq('owed ledger holds only the change', get('c8'), 3);
  const neto = 48;
  const owedBal = get('c8');
  const chipOn = true;
  const owedApplied = Math.min(owedBal, neto);
  eq('auto-applied the 3', owedApplied, 3);
  const owedBase = neto - owedApplied;
  const sugerido = owedBase + pending;
  eq('sugerido includes old debt after applying owed', sugerido, 50);
  const cash = 50;
  const cashApplied = Math.min(cash, sugerido);
  eq('cash applied', cashApplied, 50);
  eq('nothing is change owed', Math.max(0, cash - cashApplied), 0);
  const oldDebtPaid = Math.min(pending, Math.max(0, cash - owedBase));
  eq('old debt fully collected', oldDebtPaid, 5);
  const todayCredit = Math.max(0, owedBase - cashApplied);
  eq('no new receivable', todayCredit, 0);
  apply('c8', owedApplied);
  eq('liability cleared', get('c8'), 0);
}

section('Report must reconcile with the cash physically in hand');
{
  // Mirrors _renderSettlementTab in screens.js. `totalCashCollected` is what
  // the route formula derives from the sale, and the driver reports the notes
  // actually held. Everything between the two has to be explained.
  function reconcile({ neto, credited = 0, cash, changeOwed = 0, owedApplied = 0 }) {
    const totalCashCollected = neto - credited;
    const rawGap = cash - totalCashCollected;
    const abonos = Math.max(0, rawGap - changeOwed + owedApplied);
    return {
      abonos,
      total: totalCashCollected + abonos + changeOwed - owedApplied,
    };
  }

  // LEGACY ONLY. Change owed can no longer be created (the opt-in is gone), but
  // stops booked before the removal still carry it, and the report must keep
  // reconciling them instead of treating the unbroken bill as an abono.
  //
  // Day 1 (historical): 48 sale, unbroken 50 handed over.
  let r = reconcile({ neto: 48, cash: 50, changeOwed: 2 });
  eq('day 1 change is not an abono', r.abonos, 0);
  eq('day 1 total equals cash in hand', r.total, 50);

  // What a fresh stop looks like now: no changeOwed, cash == sale.
  r = reconcile({ neto: 48, cash: 48 });
  eq('a fresh stop owes no abono', r.abonos, 0);
  eq('a fresh stop total equals cash in hand', r.total, 48);

  // Day 2: 30 sale, 2 owed applied, driver collects 28.
  r = reconcile({ neto: 30, cash: 28, owedApplied: 2 });
  eq('day 2 owes no abono', r.abonos, 0);
  eq('day 2 total equals cash in hand', r.total, 28);

  // The regression: 88 sale, 3 owed applied, 5 old deuda, driver collects 90.
  // The 3 came out of the cash in hand but settled the LIABILITY, not the sale.
  // Without +owedApplied in the plug the 3 is subtracted twice and the
  // liquidation reports 87 for 90 of real cash.
  r = reconcile({ neto: 88, cash: 90, owedApplied: 3 });
  eq('old-deuda collection is recovered as abono', r.abonos, 5);
  eq('combined case total equals cash in hand', r.total, 90);

  // Guard: the +owedApplied term must not invent an abono when the sale is
  // fully settled BY the liability. 50 sale, 2 owed applied, 48 collected.
  r = reconcile({ neto: 50, cash: 48, owedApplied: 2 });
  eq('sale settled by liability => no abono', r.abonos, 0);
  eq('sale settled by liability => total is the cash', r.total, 48);

  // And when cash exceeds the route total, the plug must explain it rather
  // than let the total drift: 50 sale, 50 collected, 2 owed applied means 2
  // of that cash settled the liability and still has to be labelled.
  r = reconcile({ neto: 50, cash: 50, owedApplied: 2 });
  eq('unexplained cash is surfaced', r.abonos, 2);
  eq('unexplained cash still reconciles', r.total, 50);
}

section('Statement running balances stay independent');
{
  rows.length = 0;
  let saldo = 0, saldoFavor = 0;
  const mvs = [
    { type: 'credit', amount: 30 },
    { type: 'owed', amount: 2 },
    { type: 'payment', amount: 10 },
    { type: 'owedApplied', amount: 2 },
  ];
  mvs.forEach(m => {
    if (m.type === 'credit') saldo += m.amount;
    else if (m.type === 'payment') saldo = Math.max(0, saldo - m.amount);
    else if (m.type === 'owed') saldoFavor += m.amount;
    else if (m.type === 'owedApplied') saldoFavor = Math.max(0, saldoFavor - m.amount);
    m.saldo_actual = saldo; m.saldo_favor = (m.type === 'owed' || m.type === 'owedApplied') ? saldoFavor : null;
  });
  eq('receivable ends at 20', saldo, 20);
  eq('liability ends at 0', saldoFavor, 0);
  eq('credit row has no favor column', mvs[0].saldo_favor === null, true);
  eq('owed row carries favor 2', mvs[1].saldo_favor, 2);
  eq('owed row does not move the receivable', mvs[1].saldo_actual, 30);
}

section('Zero / residue handling');
{
  rows.length = 0;
  eq('recording 0 is a no-op', record('c9', 0) === null, true);
  eq('applying 0 is a no-op', apply('c9', 0) === null, true);
  record('c9', 0.01); apply('c9', 0.01);
  eq('a 1-cent residue clears exactly', get('c9'), 0);
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
