// Headless tests for CORRECTING A COMPLETED ORDER (reopen + audit trail).
//
// Unlike test-cambio.js (which mirrors the formulas), this file LOADS the real
// data.js and drives the real revertStopBooking / applyStopBooking /
// computeStopSettlement / addAmendment code. A correction that reverses money
// in five places is exactly the kind of logic a formula mirror cannot vouch
// for — the risk lives in the wiring, not the arithmetic.
//
//   node www/test-amend.js
const fs = require('fs');
const path = require('path');
const vm = require('vm');

// ─── Minimal browser + app stubs ──────────────────────────────────────
const store = () => {
  const d = {};
  return {
    _d: d,
    getItem: k => (k in d ? d[k] : null),
    setItem: (k, v) => { d[k] = String(v); },
    removeItem: k => { delete d[k]; },
    // Enumeration, so code that walks keys (e.g. the route-day session scan in
    // getStatementCashForDay) behaves here like it does in a real browser.
    get length() { return Object.keys(d).length; },
    key: i => Object.keys(d)[i],
  };
};

const toasts = [];
const sandbox = {
  console,
  localStorage: store(),
  sessionStorage: store(),
  document: {
    getElementById: () => null,
    querySelector: () => null,
    querySelectorAll: () => [],
    addEventListener: () => {},
    body: {},
  },
  navigator: { onLine: true },
  setTimeout, clearTimeout,
  Date, Math, JSON, Number, String, Array, Object, isNaN, parseFloat, parseInt,
  formatCurrency: n => '$' + (Math.round((Number(n) || 0) * 100) / 100).toFixed(2),
  showToast: m => toasts.push(m),
  App: { goBack() {}, navigate() {} },
  Auth: {
    _user: { id: 'u1', name: 'Admin Uno', role: 'admin' },
    currentUser() { return this._user; },
    isAdmin() { return this._user && this._user.role === 'admin'; },
    isDriver() { return this._user && this._user.role === 'driver'; },
  },
  AppState: {
    driver: { id: 'D1', name: 'Chofer Uno' },
    collections: [], extraSales: [], trips: [], params: {},
  },
  DB: {
    Storage: { _d: {}, get(k, d) { return (k in this._d) ? this._d[k] : d; }, set(k, v) { this._d[k] = v; }, del(k) { delete this._d[k]; } },
    Session: { _d: {}, save(k, v) { this._d[k] = v; }, load(k) { return this._d[k] || { routeName: '', date: '', extraSales: [], collections: [] }; } },
    Street: { _a: [], append(r) { this._a.push(r); }, byDate() { return this._a; } },
    Prices: { _d: null, load() { return this._d; }, save(v) { this._d = v; } },
    FutureOrders: { _d: null, load() { return this._d; }, save(v) { this._d = v; } },
    User: { _d: null, load() { return this._d; } },
    SettlementHistory: { _a: [], load() { return this._a; }, save(a) { this._a = a; }, getByDate(d) { return this._a.filter(s => s.date === d); }, getRange(lo, hi) { return this._a.filter(s => s.date >= lo && s.date <= hi); }, addSnapshot(s) { const i = this._a.findIndex(x => x.date === s.date && x.routeName === s.routeName); if (i >= 0) this._a[i] = s; else this._a.push(s); } },
  },
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;

vm.createContext(sandbox);
const src = fs.readFileSync(path.join(__dirname, 'js', 'data.js'), 'utf8');

// `let` bindings at the top level of a vm script are script-scoped, not global
// properties, so they are invisible to the test. Several data.js functions
// REASSIGN these (cleanup filters them, reset clears them), so a one-time
// reference would go stale. Accessors close over the live binding instead.
const EPILOGUE = `
;globalThis.__live = {
  get CLIENTES() { return CLIENTES; }, set CLIENTES(v) { CLIENTES = v; },
  get PAYMENTS() { return PAYMENTS; }, set PAYMENTS(v) { PAYMENTS = v; },
  get CUSTOMER_OWED() { return CUSTOMER_OWED; }, set CUSTOMER_OWED(v) { CUSTOMER_OWED = v; },
  get AMENDMENTS() { return AMENDMENTS; }, set AMENDMENTS(v) { AMENDMENTS = v; },
  get advanceOrders() { return advanceOrders; }, set advanceOrders(v) { advanceOrders = v; },
  get ROUTES() { return ROUTES; },
  get AppState() { return AppState; },
};
`;
vm.runInContext(src + EPILOGUE, sandbox, { filename: 'data.js' });

// data.js declares its own `const AppState`, so the sandbox copy above is
// ignored — read the real one through the accessor, not off the sandbox.
const S = sandbox;
const L = S.__live;
const ST = L.AppState;

// Build the route the way the app does, then take the route/day it actually
// chose. Hardcoding a date would let the closed-day guard pass for the wrong
// reason (or fail to fire at all).
S.initRoute();
const RT = ST.routeName;
const RD = ST.routeDate;
const {
  computeStopSettlement, applyStopBooking, revertStopBooking,
  addAmendment, getAmendmentsForOrder, getAmendmentsInRange, currentActor,
  isRouteDayOpen, fieldDiff, genId, CUSTOMER_OWED_KEY, getStatementCashForDay,
  recordChangeOwed,
} = S;

// ─── tiny assert harness ──────────────────────────────────────────────
let pass = 0, fail = 0;
const fails = [];
function ok(label, cond, extra) {
  if (cond) pass++;
  else { fail++; fails.push(label + (extra !== undefined ? ` (${extra})` : '')); }
}
function eq(label, actual, expected) {
  ok(label, Math.abs((Number(actual) || 0) - (Number(expected) || 0)) < 0.005, `got ${actual}, want ${expected}`);
}
function section(t) { console.log('\n' + t); }

// ─── fixtures ────────────────────────────────────────────────────────
function resetWorld() {
  L.CUSTOMER_OWED.length = 0;
  S.saveCustomerOwed();
  L.PAYMENTS.length = 0;
  S.savePayments();
  L.CLIENTES.length = 0;
  L.CLIENTES.push({ id: 'C1', name: 'Cliente Uno', balance: 0, creditLimit: 0 });
  S.saveClients();
  ST.collections.length = 0;
  ST.trips.length = 0;
  L.AMENDMENTS.length = 0;
  S.saveAmendments();
  L.advanceOrders.length = 0;
  S.saveAdvanceOrders();
  S.DB.SettlementHistory._a.length = 0;
  S.rebuildRouteStops();
}

// Create an order inside a driver-owned trip so rebuildRouteStops() produces
// the real stop object — same path production takes, no hand-built fixture.
function makeOrder(over) {
  const o = Object.assign({
    id: 'AO-' + (makeOrder.n = (makeOrder.n || 0) + 1), customerId: 'C1', customerName: 'Cliente Uno',
    productId: 'P1', qty: 4, price: 22, status: 'pending', devolucionKg: 0, recompraKg: 0,
  }, over || {});
  L.advanceOrders.push(o);
  S.saveAdvanceOrders();
  if (!ST.trips.length) {
    ST.trips.push({
      id: 'T1', driverId: ST.driver.id, driverName: ST.driver.name,
      date: RD, routeName: RT, routes: [RT], orderIds: [], kilosLoaded: 100, status: 'active',
    });
  }
  ST.trips[0].orderIds.push(o.id);
  S.saveTrips();
  S.rebuildRouteStops();
  const stop = ST.route.stops.find(s => s.orderId === o.id);
  if (!stop) throw new Error('rebuildRouteStops did not produce a stop for ' + o.id);
  return { order: o, stop };
}

// Book a stop exactly the way confirmStop does, via the shared math.
function book(stop, s, ctx) {
  return applyStopBooking(stop, s, ctx);
}

function settle(opts) {
  return computeStopSettlement(Object.assign({
    neto: 0, yaCobrado: 0, cash: 0, creditAmount: 0, owedApplied: 0,
    pending: 0, oldDebtChipOn: false, creditLimit: 0,
    recompraKg: 0, recompraPrice: 8,
  }, opts));
}

const balance = () => S.getCustomerBalance('C1');
const owed = () => S.getCustomerOwed('C1');
const cashTotal = () => ST.collections.reduce((t, c) => t + (c.cash || 0), 0);
const payTotal = () => L.PAYMENTS.reduce((t, p) => t + (p.amount || 0), 0);

// ══════════════════════════════════════════════════════════════════════
section('computeStopSettlement — the rules a correction must respect');
{
  // The "No tengo cambio" opt-in was removed, so an unbreakable bill can no
  // longer be declared: cash above the sale is always a typo and is rejected.
  // A noChange passed in by a stale caller must not reopen the old path.
  const bad = settle({ neto: 88, cash: 90, noChange: true });
  ok('overpayment is rejected (the opt-in is gone)', !bad.ok && bad.error === 'no-change');

  const atTotal = settle({ neto: 88, cash: 88 });
  ok('paying exactly the total is fine', atTotal.ok);
  eq('nothing is change owed', atTotal.changeOwed, 0);
  eq('all of the cash settles the sale', atTotal.cashApplied, 88);

  const unbal = settle({ neto: 88, cash: 50, creditAmount: 10 });
  ok('cash+credit must equal the total', !unbal.ok && unbal.error === 'unbalanced');

  const allCredit = settle({ neto: 88, cash: 0, creditAmount: 88 });
  eq('no cash means the whole sale is credited', allCredit.todayCredit, 88);
  eq('and nothing is collected', allCredit.cashApplied, 0);

  const owedUse = settle({ neto: 88, owedApplied: 8, cash: 80 });
  eq('owed applied reduces what cash must cover', owedUse.todayCredit, 0);
  eq('owed applied is not counted as collected', owedUse.cashApplied, 80);

  const capped = settle({ neto: 88, cash: 10, creditAmount: 78, creditLimit: 50 });
  ok('credit limit is enforced', !capped.ok && capped.error === 'credit-limit');

  // The correction editor derives the credit from the cash, which means it
  // needs `sugerido` back from a probe that was rejected as unbalanced. If the
  // rejection swallowed it, "I wrote cash but it was really credit" becomes
  // impossible to save.
  const short = settle({ neto: 88, cash: 20, creditAmount: 0 });
  ok('a short payment is rejected', !short.ok && short.error === 'unbalanced');
  eq('but still reports the target', short.sugerido, 88);
  const derived = settle({ neto: 88, cash: 20, creditAmount: round2To(short.sugerido - 20) });
  ok('and the derived credit then settles it', derived.ok, derived.error);
  eq('with the balance as credit', derived.todayCredit, 68);
  ok('over the chip also reports the target', settle({ neto: 88, cash: 200 }).sugerido === 88);
}
function round2To(n) { return Math.round(n * 100) / 100; }

// ══════════════════════════════════════════════════════════════════════
section('The reported case: cash recorded, it was really credit');
resetWorld();
let { order: o1, stop: s1 } = makeOrder({ id: 'AO-CASH', qty: 4, price: 22 }); // 88
{
  const s = settle({ neto: 88, cash: 88 });
  book(s1, s, { qty: 4, devKg: 0, recKg: 0 });
  eq('sale booked as fully collected', balance(), 0);
  eq('nothing owed to the customer', owed(), 0);
  eq('driver cash recorded', cashTotal(), 88);
  eq('order shows 88 collected', o1.creditPaidAmount, 88);

  // ── the correction ──
  const before = {};
  o1 && ['creditAmount', 'creditPaidAmount', 'changeOwed', 'owedApplied', 'oldDebtPaid', 'deliveredKg']
    .forEach(f => { before[f] = o1[f]; });
  revertStopBooking(s1);
  eq('revert removes the collection from the day', cashTotal(), 0);
  eq('revert returns the order to pending', o1.status, 'pending');
  eq('revert leaves no phantom cash on the order', o1.creditPaidAmount, 0);

  const s2 = settle({ neto: 88, cash: 0, creditAmount: 88 });
  book(s1, s2, { qty: 4, devKg: 0, recKg: 0 });
  eq('now nothing is in the driver\'s pocket', cashTotal(), 0);
  eq('the sale became a receivable', balance(), 88);
  eq('order records the credit', o1.creditAmount, 88);
  eq('order records zero cash collected', o1.creditPaidAmount, 0);
  eq('still no change owed', owed(), 0);

  const entry = addAmendment({
    kind: 'order.corrected', orderId: o1.id, stopId: s1.stopId,
    routeName: RT, date: RD,
    reason: 'Se registró efectivo y era crédito',
    by: 'u1', byName: 'Admin Uno', byRole: 'admin',
    before, after: { creditAmount: 88, creditPaidAmount: 0 },
    changes: fieldDiff(before, { creditAmount: 88, creditPaidAmount: 0 },
      ['creditAmount', 'creditPaidAmount', 'changeOwed', 'owedApplied', 'oldDebtPaid', 'deliveredKg']),
  });
  ok('an audit row is written', !!entry.id);
  eq('the audit trail records exactly one edit', getAmendmentsForOrder(o1.id).length, 1);
  const ch = entry.changes.find(c => c.field === 'creditPaidAmount');
  ok('the audit shows cash going 88 -> 0', ch && ch.from === 88 && ch.to === 0, JSON.stringify(ch));
  const ch2 = entry.changes.find(c => c.field === 'creditAmount');
  ok('the audit shows credit going 0 -> 88', ch2 && ch2.from === 0 && ch2.to === 88, JSON.stringify(ch2));
}

// ══════════════════════════════════════════════════════════════════════
section('The reverse correction: credit recorded, they actually paid cash');
resetWorld();
{
  const { order, stop } = makeOrder({ id: 'AO-CR', qty: 2, price: 24 }); // 48
  const s = settle({ neto: 48, cash: 0, creditAmount: 48 });
  book(stop, s, { qty: 2, devKg: 0, recKg: 0 });
  eq('starts as 48 receivable', balance(), 48);

  revertStopBooking(stop);
  eq('revert clears the receivable', balance(), 0);

  const s2 = settle({ neto: 48, cash: 48 });
  book(stop, s2, { qty: 2, devKg: 0, recKg: 0 });
  eq('now it is collected', balance(), 0);
  eq('cash is in the day total', cashTotal(), 48);
  eq('order records 48 cash', order.creditPaidAmount, 48);
  eq('order records no credit', order.creditAmount, 0);
}

// ══════════════════════════════════════════════════════════════════════
section('Correcting an old-debt collection does not double-apply the payment');
resetWorld();
{
  L.CLIENTES[0].balance = 30;  // customer owes 30 from before
  S.saveClients();
  const { order, stop } = makeOrder({ id: 'AO-DEBT', qty: 2, price: 24 }); // 48
  // The chip pulls the old debt into the equation: 48 sale + 30 old = 78.
  const s = settle({ neto: 48, cash: 78, pending: 30, oldDebtChipOn: true });
  ok('chip lets cash cover sale + old debt', s.ok, s.error);
  eq('suggested total includes the old debt', s.sugerido, 78);
  eq('old debt collected', s.oldDebtPaid, 30);
  book(stop, s, { qty: 2, devKg: 0, recKg: 0 });
  eq('old debt is now cleared', balance(), 0);
  eq('a payment row exists', payTotal(), 30);
  eq('day cash is 78', cashTotal(), 78);

  // Correct: they never paid the old debt after all, so the chip comes off
  // and only the 48 sale was collected.
  revertStopBooking(stop);
  eq('revert restores the receivable', balance(), 30);
  eq('revert removes the payment row', payTotal(), 0);
  eq('revert removes the day cash', cashTotal(), 0);

  const s2 = settle({ neto: 48, cash: 48, pending: 30, oldDebtChipOn: false });
  book(stop, s2, { qty: 2, devKg: 0, recKg: 0 });
  eq('the 30 stays owed', balance(), 30);
  eq('no payment row this time', payTotal(), 0);
  eq('day cash is 48', cashTotal(), 48);
}

// ══════════════════════════════════════════════════════════════════════
section('Correcting a stop booked back when change owed still existed');
resetWorld();
{
  // Stops booked while the "No tengo cambio" opt-in existed carry a real
  // liability row and a changeOwed on the order. computeStopSettlement can no
  // longer produce that state, so it is written the way the old code wrote it:
  // a cash collection of the unbroken bill plus an 'owed' ledger row. The
  // invariant under test is that correcting such a stop still clears the
  // liability instead of leaving (or doubling) it.
  const { order, stop } = makeOrder({ id: 'AO-CHG', qty: 4, price: 22 }); // 88
  // Backfill the change-owed state the old opt-in would have produced: one cash
  // collection of the FULL unbroken 90 (change owed is included in the driver's
  // pocket and must reach the day's cash), plus the liability row.
  const legacy = {
    ok: true, cash: 90, cashApplied: 88, creditAmount: 0, todayCredit: 0,
    oldDebtPaid: 0, changeOwed: 2, owedApplied: 0, recompraCollected: 0,
    yaCobrado: 0, neto: 88, base: 88, owedBase: 88, sugerido: 88,
  };
  book(stop, legacy, { qty: 4, devKg: 0, recKg: 0 });
  recordChangeOwed(stop.customerId, 2, { orderId: order.id, stopId: stop.stopId, kg: 4, reason: 'Sin cambio' });
  eq('2 owed to the customer', owed(), 2);
  eq('the unbroken 90 is still driver cash', cashTotal(), 90);
  eq('the order records the change owed', order.changeOwed, 2);

  // Correct: they should have got their change.
  revertStopBooking(stop);
  eq('the liability is gone, not doubled', owed(), 0);
  eq('the cash is gone', cashTotal(), 0);
  eq('changeOwed is cleared on the stop', stop.changeOwed, 0);

  const s2 = settle({ neto: 88, cash: 88 });
  book(stop, s2, { qty: 4, devKg: 0, recKg: 0 });
  eq('nothing owed', owed(), 0);
  eq('cash is 88', cashTotal(), 88);
  eq('order has no changeOwed', order.changeOwed, 0);
}

// ══════════════════════════════════════════════════════════════════════
section('A stop cannot declare change owed any more');
resetWorld();
{
  const { stop } = makeOrder({ id: 'AO-NOCHG', qty: 4, price: 22 }); // 88
  const s = settle({ neto: 88, cash: 90 });
  ok('an unbreakable bill is rejected', !s.ok && s.error === 'no-change');
  // Both production callers bail on !s.ok before booking, so nothing is written.
  // (applyStopBooking trusts its caller — booking a rejected settlement is the
  // caller's bug, not something it guards against.)
  eq('the rejected result carries no liability figure', s.changeOwed, undefined);
  eq('no liability is created', owed(), 0);
  eq('no cash is collected', cashTotal(), 0);
}

// ══════════════════════════════════════════════════════════════════════
section('Repeated corrections are stable (no drift)');
resetWorld();
{
  const { order, stop } = makeOrder({ id: 'AO-REP', qty: 3, price: 20 }); // 60
  const s = settle({ neto: 60, cash: 60 });
  book(stop, s, { qty: 3, devKg: 0, recKg: 0 });
  eq('baseline cash', cashTotal(), 60);

  for (let i = 0; i < 5; i++) {
    revertStopBooking(stop);
    const again = settle({ neto: 60, cash: 60 });
    book(stop, again, { qty: 3, devKg: 0, recKg: 0 });
  }
  eq('cash identical after 5 corrections', cashTotal(), 60);
  eq('no receivable drift', balance(), 0);
  eq('no liability drift', owed(), 0);
  eq('collection rows are not duplicated', ST.collections.length, 1);
  eq('no orphaned payment rows', L.PAYMENTS.length, 0);
}

// ══════════════════════════════════════════════════════════════════════
section('A kg correction re-books revenue too');
resetWorld();
{
  const { order, stop } = makeOrder({ id: 'AO-KG', qty: 4, price: 22 }); // 88
  const s = settle({ neto: 88, cash: 88 });
  book(stop, s, { qty: 4, devKg: 0, recKg: 0 });
  eq('starts at 88', cashTotal(), 88);

  revertStopBooking(stop);
  // 3 kg were actually delivered -> 66
  const s2 = settle({ neto: 66, cash: 66 });
  book(stop, s2, { qty: 3, devKg: 0, recKg: 0 });
  eq('cash follows the corrected kg', cashTotal(), 66);
  eq('order kg is corrected', order.deliveredKg, 3);
  eq('no residual receivable', balance(), 0);
}

// ══════════════════════════════════════════════════════════════════════
section('Closed route-day cannot be corrected');
resetWorld();
{
  ok('the day starts open', isRouteDayOpen(RT, RD) === true);
  S.DB.SettlementHistory.addSnapshot({ date: RD, routeName: RT });
  ok('a closed day is refused', isRouteDayOpen(RT, RD) === false);
  ok('a different route on the same date is unaffected', isRouteDayOpen('OTRA RUTA', RD) === true);
}

// ══════════════════════════════════════════════════════════════════════
section('Audit trail');
resetWorld();
{
  const { order, stop } = makeOrder({ id: 'AO-AUD', qty: 4, price: 22 });
  book(stop, settle({ neto: 88, cash: 88 }), { qty: 4, devKg: 0, recKg: 0 });

  S.Auth._user = { id: 'u9', name: 'Admin Dos', role: 'admin' };
  const a1 = addAmendment({ kind: 'order.corrected', orderId: order.id, stopId: stop.stopId, date: RD, routeName: RT, reason: 'Monto mal capturado', byRole: 'admin' });
  S.Auth._user = { id: 'u9', name: 'Admin Dos', role: 'admin' };
  const a2 = addAmendment({ kind: 'order.corrected', orderId: order.id, stopId: stop.stopId, date: RD, routeName: RT, reason: 'Otra correccion', byRole: 'admin' });

  ok('each correction appends a row', getAmendmentsForOrder(order.id).length === 2);
  ok('rows are append-only and distinct', a1.id !== a2.id);
  ok('newest first in the list', getAmendmentsInRange('0000', '9999')[0].id === a2.id);
  eq('the trail is queryable by date', getAmendmentsInRange(RD, RD).length, 2);
  eq('and excludes other dates', getAmendmentsInRange('2026-01-01', '2026-01-02').length, 0);

  // the actor is the authenticated user, not the driver on the route
  S.Auth._user = { id: 'd1', name: 'Chofer Uno', role: 'driver' };
  const actor = currentActor();
  eq('a driver session reports the driver role', actor.role, 'driver');
  eq('and the driver id', actor.id, 'd1');
  S.Auth._user = null;
  const fallback = currentActor();
  eq('with no session it falls back to the route driver', fallback.id, 'D1');
}

section('fieldDiff reports only real changes');
{
  const d = fieldDiff({ a: 1, b: 2, c: 0 }, { a: 1, b: 5, c: 0 }, ['a', 'b', 'c', 'd']);
  eq('only the changed field is listed', d.length, 1);
  ok('and it carries both sides', d[0].field === 'b' && d[0].from === 2 && d[0].to === 5, JSON.stringify(d));
  const rounded = fieldDiff({ x: 1.005 }, { x: 1.006 }, ['x']);
  ok('sub-cent float noise is not a change', rounded.length === 0, JSON.stringify(rounded));
}

section('an abono on the statement is real cash on the rutas dashboard');
{
  resetWorld();
  ST.driver = { id: 'D1', name: 'Chofer Uno' };
  const day = ST.routeDate;
  const key = 'elcomal_session_' + RT + '_' + day;
  // The real DB.Storage is backed by localStorage and hands back a parsed
  // object; the harness stub is a plain map that keeps what it is given. Seed
  // the object into Storage and the serialised form into localStorage, which is
  // what a key scan expects to find.
  const put = collections => {
    const sess = { routeName: RT, date: day, collections };
    S.DB.Storage.set(key, sess);
    S.localStorage.setItem(key, JSON.stringify(sess));
  };
  const clear = () => { S.DB.Storage.del(key); S.localStorage.removeItem(key); };

  put([{ id: 'c1', customerId: 'C1', cash: 200, card: 0, source: 'statement-payment', driverId: 'D1' },
       { id: 'c2', customerId: 'C2', cash: 50, card: 0 }]);
  eq('the tagged abono is counted', getStatementCashForDay(day, 'D1'), 200);
  ok('an untagged stop handoff is not double counted', getStatementCashForDay(day, 'D1') === 200);

  put([{ id: 'c1', cash: 200, source: 'statement-payment', driverId: 'D1' },
       { id: 'c3', cash: 75, source: 'statement-payment', driverId: 'D2' }]);
  eq('another driver’s abono is not in my pocket', getStatementCashForDay(day, 'D1'), 200);
  eq('and is in theirs', getStatementCashForDay(day, 'D2'), 75);

  put([]);
  eq('no abonos means no extra cash', getStatementCashForDay(day, 'D1'), 0);
  eq('and another date is not confused with this one', getStatementCashForDay('2020-01-01', 'D1'), 0);
  clear();
}

// ══════════════════════════════════════════════════════════════════════
section('Settlement marks corrected orders');
resetWorld();
{
  // The marker lives in screens.js, not data.js, and it is the whole point of
  // the feature: cash totals net out the reversal + re-booking, so a corrected
  // stop is otherwise indistinguishable from an untouched one. Assert against
  // the REAL renderer — a formula mirror would not catch a wrong date filter or
  // a marker that never reaches the DOM.
  const screensSrc = fs.readFileSync(path.join(__dirname, 'js', 'screens.js'), 'utf8');
  vm.runInContext(screensSrc, sandbox, { filename: 'screens.js' });

  // The tab renders an empty state until the day has some activity, so the
  // fixture needs real totals — a correction never happens on a day with no
  // money in it, and the marker sits below the cash breakdown.
  const base = {
    date: RD, routeName: RT,
    totalDelivered: 88, brutoValue: 88, streetTotal: 0, devValue: 0,
    totalCredited: 0, totalCollected: 88, totalCash: 88, totalCard: 0,
    recompraValue: 0, totalRecompra: 0, totalRecompraCollected: 0,
    totalChangeOwed: 0, totalOwedApplied: 0,
  };
  const renderMarker = (data) =>
    String(S._renderSettlementTab(Object.assign({}, base, data), 22, 11, RD, true));

  ok('the fixture renders the cash breakdown', renderMarker({}).includes('Efectivo'), 'empty state leaked in');

  const clean = renderMarker({});
  ok('no corrections means no marker', !clean.includes('CORREGIDAS'), clean.slice(0, 120));

  const { order } = makeOrder({ id: 'AO-MK', qty: 4, price: 22 });
  addAmendment({ kind: 'order.corrected', orderId: order.id, stopId: 'S-' + order.id, date: RD, routeName: 'Pueblo Nuevo', reason: 'monto' });
  const one = renderMarker({});
  ok('a correction on the day is marked', one.includes('CORREGIDAS'), one.slice(0, 120));
  ok('and the count is the order', /CORREGIDAS[\s\S]{0,200}?>1</.test(one), one.slice(0, 200));

  // Correcting the SAME order again is still one corrected order; the label
  // counts orders, so it must not drift to 2 while saying "ORDENES".
  addAmendment({ kind: 'order.corrected', orderId: order.id, stopId: 'S-' + order.id, date: RD, routeName: 'Pueblo Nuevo', reason: 'otra vez' });
  const two = renderMarker({});
  ok('repeat corrections do not inflate the order count', /CORREGIDAS[\s\S]{0,200}?>1</.test(two), two.slice(0, 200));

// The whole point of the marker is that it STANDS OUT — the cash totals
  // already net out the reversal, so an unmarked correction is invisible. An
  // undefined CSS custom property does not fail loudly in a template string:
  // var(--amber-600) silently falls back to the inherited text colour, which
  // made the marker render as ordinary body text. Cross-check every var() the
  // marker uses against the real stylesheet.
  const css = fs.readFileSync(path.join(__dirname, 'css', 'styles.css'), 'utf8');
  const declared = new Set((css.match(/--[a-z0-9-]+\s*:/g) || []).map(s => s.replace(/\s*:\s*$/, '').trim()));
  const markerHtml = renderMarker({});
  const used = new Set((markerHtml.match(/var\(\s*(--[a-z0-9-]+)\s*\)/g) || [])
    .map(v => v.replace(/^var\(\s*/, '').replace(/\s*\)$/, '').trim()));
  const missing = [...used].filter(v => !declared.has(v));
  // NB: use ok(), not eq() — eq() coerces via Number(), so two different
  // strings both become 0 and the comparison always passes.
  ok('every CSS var the settlement marker uses is declared', missing.length === 0, 'undeclared: ' + missing.join(', '));
  ok('the marker is styled amber, not inherited text',
    markerHtml.includes('--amber-400'), markerHtml.slice(markerHtml.indexOf('CORREGIDAS') - 80, markerHtml.indexOf('CORREGIDAS')));

  // Repo-wide: the marker was not the only casualty. --red-600 and --amber-500
  // were missing too, affecting ~35 report cells, and each one painted as
  // ordinary body text with no error anywhere. Sweep every var() referenced
  // from www/ so the next typo fails here instead of silently in the UI.
  const srcFiles = [];
  (function walk(dir) {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) walk(p);
      else if (/\.(js|html)$/.test(e.name) && !/__tests__/.test(p)) srcFiles.push(p);
    }
  })(__dirname);
  const orphans = {};
  for (const f of srcFiles) {
    const src = fs.readFileSync(f, 'utf8');
    // This file mentions --amber-600 on purpose as a negative control for the
    // check above; it is not a real reference.
    if (f === __filename) continue;
    const refs = new Set((src.match(/var\(\s*(--[a-z0-9-]+)\s*\)/g) || [])
      .map(v => v.replace(/^var\(\s*/, '').replace(/\s*\)$/, '').trim()));
    for (const v of refs) if (!declared.has(v)) (orphans[v] = orphans[v] || []).push(path.basename(f));
  }
  const orphanList = Object.keys(orphans).sort();
  ok('no var() in www/ points at an undeclared custom property',
    orphanList.length === 0,
    orphanList.map(v => v + ' in ' + [...new Set(orphans[v])].join(',')).join('; '));

  // A correction on a DIFFERENT day must not mark this day's settlement.
  L.AMENDMENTS.length = 0;
  S.saveAmendments();
  addAmendment({ kind: 'order.corrected', orderId: order.id, stopId: 'S-' + order.id, date: '2020-01-01', routeName: RT, reason: 'viejo' });
  ok('another date is not marked here', !renderMarker({}).includes('CORREGIDAS'));

  // An audit row of a different kind on the same day is not a correction.
  L.AMENDMENTS.length = 0;
  S.saveAmendments();
  addAmendment({ kind: 'order.cancelled', orderId: order.id, stopId: 'S-' + order.id, date: RD, routeName: RT, reason: 'no' });
  ok('a non-correction audit row is not marked', !renderMarker({}).includes('CORREGIDAS'));

  L.AMENDMENTS.length = 0;
  S.saveAmendments();
}

// ─── report ──────────────────────────────────────────────────────────
console.log(`\n${pass} passed, ${fail} failed`);
if (fail) { fails.forEach(f => console.log('  FAIL ' + f)); process.exit(1); }
