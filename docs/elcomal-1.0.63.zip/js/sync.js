// ─── FIREBASE SYNC LAYER ─────────────────────────────────
// Loaded FIRST (before persistence.js). Responsibilities:
//   1. Per-record sync for contended data (orders, trips,
//      settlements): each record is its own Firestore doc, so
//      two drivers editing different records never clobber each
//      other. Real-time onSnapshot pushes changes live (~1s).
//   2. Whole-array sync for low-contention data (clients, users,
//      prices, future orders, payments, street sales, opening
//      debts): one doc per localStorage key, merged in-place.
//   3. Transactional order claim on trip creation, so two drivers
//      can't grab the same order.
//   4. Write interception: every localStorage elcomal_* write is
//      timestamped; a debounced push uploads changed records.
//      Works offline (queued locally, synced on next success).
//
// If Firebase config is missing or offline, the app runs exactly
// as before (localStorage only).

// ─── Environment isolation ────────────────────────────────
// The Capacitor app (phone) is production: it owns the real cloud
// data in collection `kv`. A local browser sandbox must NEVER touch
// that collection — it writes to `kv_dev` instead, with its own meta
// key, so sandbox test data can't sync to the phone (or vice versa).
const IS_NATIVE = typeof window !== 'undefined' && window.Capacitor &&
  (window.Capacitor.Plugins || window.Capacitor.nativePromise);

const SYNC_COLLECTION = IS_NATIVE ? 'kv' : 'kv_dev';
const META_KEY = IS_NATIVE ? 'elcomal_sync_meta' : 'elcomal_sync_meta_dev'; // { key: lastPushedTimestamp }
const V2_FLAG = 'elcomal_sync_v2';

// Keys that are NEVER synced (device-local).
const SKIP_KEYS = [
  'elcomal_sync_meta', 'elcomal_sync_meta_dev',
  'elcomal_schema_ver', 'elcomal_sync_reconciled',
  'elcomal_session',
  // Update lane + banner dismissal are per phone. 'elcomal_update_channel'
  // (1.0.60-1.0.61) leaked through sync, so it is ignored in both directions.
  'elcomal_update_channel', 'elcomal_update_ack',
];
// Prefixes that are NEVER synced (device-local working state).
// Anything named elcomal_device_* stays on the phone that set it.
const SKIP_PREFIXES = ['elcomal_stops_', 'elcomal_session_', 'elcomal_device_'];

// Record collections: each record is its own Firestore doc.
//   docPrefix  -> Firestore doc id prefix
//   localKey   -> localStorage array key
//   idField    -> record's unique id field
//   updatedAt  -> record's updatedAt field (for conflict resolution)
// NOTE: `elcomal_clientes` is a PER-RECORD collection (customer__ prefix),
// NOT a whole-array doc. Whole-array LWW sync is exactly how customers
// were clobbered (a reinstall's 20-row DEFAULT_CLIENTES overwrote the
// 30-row cloud list while per-record orders survived). Per-record means
// a missing customer on one device can never delete it on another.
const RECORD_COLLECTIONS = [
  { docPrefix: 'order__',       localKey: 'elcomal_orders',       idField: 'id',   updatedAt: 'updatedAt' },
  { docPrefix: 'trip__',        localKey: 'elcomal_trips',        idField: 'id',   updatedAt: 'updatedAt' },
  { docPrefix: 'settlement__',  localKey: 'elcomal_settlements',  idField: 'date', updatedAt: 'timestamp' },
  { docPrefix: 'user__',        localKey: 'elcomal_users',        idField: 'id',   updatedAt: 'updatedAt' },
  { docPrefix: 'customer__',    localKey: 'elcomal_clientes',     idField: 'id',   updatedAt: 'updatedAt' },
  { docPrefix: 'event__',       localKey: 'elcomal_outbox',       idField: 'id',   updatedAt: 'updatedAt' },
  { docPrefix: 'erpmap__',      localKey: 'elcomal_erp_map',      idField: 'id',   updatedAt: 'updatedAt' },
  // The amendment trail is the fraud evidence. Per-record so one device can
  // never overwrite the whole history; it is only ever appended to.
  { docPrefix: 'amendment__',   localKey: 'elcomal_amendments',   idField: 'id',   updatedAt: 'at' },
];
// Whole-array keys (one doc per localStorage key).
const ARRAY_KEYS = [
  'elcomal_productCatalog', 'elcomal_productPrices',
  'elcomal_futureOrders', 'elcomal_payments', 'elcomal_streetSales',
  'elcomal_openingDebts',
];

function isRecordDocId(id) { return RECORD_COLLECTIONS.some(c => id.indexOf(c.docPrefix) === 0); }
function isSkippedKey(k) {
  if (SKIP_KEYS.includes(k)) return true;
  return SKIP_PREFIXES.some(p => k.indexOf(p) === 0);
}
function isSkippedDocId(id) {
  if (isSkippedKey(id)) return true;
  // Legacy whole-array docs for record collections must be ignored —
  // real data now lives in per-record docs (user__, order__, trip__,
  // settlement__). Old devices may still push these; don't let them
  // clobber the per-record state.
  if (RECORD_COLLECTIONS.some(c => c.localKey === id)) return true;
  if (ARRAY_KEYS.includes(id)) return false;
  if (isRecordDocId(id)) return false;
  // Unknown doc id — treat as array key (legacy whole-array docs).
  return false;
}

// ─── Development flag: local Firebase emulator ───────────
// Open the app in a browser as http://localhost:5173/?emulator to use the
// Firebase emulator running on this laptop (fake project "demo-elcomal")
// instead of any real Firebase project. Ignored inside the phone app.
const USE_EMULATOR = !IS_NATIVE && typeof location !== 'undefined' &&
  new URLSearchParams(location.search).has('emulator');
const EMULATOR_CONFIG = {
  apiKey: 'demo-key',
  authDomain: 'demo-elcomal.firebaseapp.com',
  projectId: 'demo-elcomal',
  appId: 'demo-elcomal',
};

// Allow runtime override (used in tests) — window.__FIREBASE_CONFIG wins
const FIREBASE_CONFIG = USE_EMULATOR ? EMULATOR_CONFIG
  : (typeof window !== 'undefined' && window.__FIREBASE_CONFIG)
  ? window.__FIREBASE_CONFIG
  : {
      apiKey: 'AIzaSyDfz4r-C9SWzhjkatEk4ngGZk2Ogli1Jxc',
      authDomain: 'delivery-app-49eab.firebaseapp.com',
      projectId: 'delivery-app-49eab',
      appId: '1:1005979978877:web:8c5b9f7a0e3d1c4b',
    };

// ─── Write interception (installed synchronously) ─────────
(function installInterception() {
  const orig = Storage.prototype.setItem;
  Storage.prototype.setItem = function (key, value) {
    const res = orig.call(this, key, value);
    try {
      if (typeof key === 'string' && key.indexOf('elcomal_') === 0 && !isSkippedKey(key)) {
        if (ARRAY_KEYS.includes(key)) {
          const m = getMeta();
          if (m[key + '__h']) { delete m[key + '__h']; setMeta(m); }
        }
        schedulePush();
      }
    } catch (e) {}
    return res;
  };
})();

// ─── State ────────────────────────────────────────────────
let firebase = null;          // { app, auth, db }
let pushTimer = null;
let unsubSnapshot = null;
let online = typeof navigator !== 'undefined' && navigator.onLine;

function getMeta() {
  try { return JSON.parse(localStorage.getItem(META_KEY) || '{}'); } catch (e) { return {}; }
}
function setMeta(m) {
  try { localStorage.setItem(META_KEY, JSON.stringify(m)); } catch (e) {}
}

// ─── Firebase init (lazy, CDN import with timeout) ────────
async function initFirebase() {
  if (firebase) return firebase;
  if (!FIREBASE_CONFIG.apiKey || !FIREBASE_CONFIG.projectId) return null;
  try {
    const base = 'https://www.gstatic.com/firebasejs/10.12.0';
    const [{ initializeApp }, { getAuth, signInAnonymously, connectAuthEmulator }, { getFirestore, connectFirestoreEmulator }] = await Promise.all([
      import(base + '/firebase-app.js'),
      import(base + '/firebase-auth.js'),
      import(base + '/firebase-firestore.js'),
    ]);
    const app = initializeApp(FIREBASE_CONFIG);
    const auth = getAuth(app);
    if (USE_EMULATOR) connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
    await signInAnonymously(auth);
    const db = getFirestore(app);
    if (USE_EMULATOR) {
      connectFirestoreEmulator(db, '127.0.0.1', 8080);
      console.info('sync: using the local Firebase emulator (project demo-elcomal)');
    }
    firebase = { app, auth, db };
    return firebase;
  } catch (e) {
    console.error('sync: Firebase init failed', e);
    return null;
  }
}

// ─── Record helpers ───────────────────────────────────────
function _readLocalArray(key) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : [];
  } catch (e) { return []; }
}
function _writeLocalArray(key, arr) {
  try { localStorage.setItem(key, JSON.stringify(arr)); } catch (e) {}
}
function _recordUpdatedAt(rec, col) {
  const v = rec && rec[col.updatedAt || 'updatedAt'];
  return Number(new Date(v).getTime()) || 0;
}

// FNV-1a hash used to skip re-pushing unchanged whole-array docs.
function _hashStr(s) {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(36);
}

// V2 migration already ran on this device?
function v2Done() {
  try { return localStorage.getItem(V2_FLAG) === '2'; } catch (e) { return false; }
}

// ─── Migration: fan out local records to per-record docs ──
// On first launch after upgrade, push every local order/trip/
// settlement/customer as its own doc, then delete stale whole
// array docs so pull() can't restore them.
async function migrateToRecords() {
  if (v2Done()) return;
  await _migrateFanOut();
}

async function _migrateFanOut() {
  const fb = await initFirebase();
  if (!fb) return;
  const { doc, setDoc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  try {
    for (const col of RECORD_COLLECTIONS) {
      const arr = _readLocalArray(col.localKey);
      for (const rec of arr) {
        const id = rec[col.idField];
        if (!id || rec.builtIn) continue; // built-in samples never upload
        try {
          await setDoc(doc(fb.db, SYNC_COLLECTION, col.docPrefix + id), {
            data: JSON.stringify(rec),
            updatedAt: _recordUpdatedAt(rec, col), // no date = 0 (oldest), never "now"
          });
        } catch (e) {}
      }
      try { await deleteDoc(doc(fb.db, SYNC_COLLECTION, col.localKey)); } catch (e) {}
    }
    try { localStorage.setItem(V2_FLAG, '2'); } catch (e) {}
  } catch (e) {
    console.error('sync: migration failed', e);
  }
}

// Drop the legacy whole-array `elcomal_clientes` doc on every startup.
// Customers were once a whole-array doc; LWW clobbering is what deleted
// Irma. The app now stores them as customer__ records and ignores the
// legacy doc on pull (mergeArrayDoc + isSkippedDocId), but never let a
// stale copy survive in the cloud.
async function dropLegacyCustomerDoc() {
  if (v2Done()) return;
  const fb = await initFirebase();
  if (!fb) return;
  const { doc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  try { await deleteDoc(doc(fb.db, SYNC_COLLECTION, 'elcomal_clientes')); } catch (e) {}
}

// ─── Shadow diff push ─────────────────────────────────────
// Persist a shadow of each record collection in meta. On setItem
// of a record key, diff old vs new by record id → push changed
// records as their own docs; deleteDoc removed records.
function _shadowKey(col) { return 'shadow_' + col.localKey; }

function _loadShadow(col) {
  const s = getMeta()[_shadowKey(col)];
  try { return s ? JSON.parse(s) : []; } catch (e) { return []; }
}
function _saveShadow(col, arr) {
  const m = getMeta();
  m[_shadowKey(col)] = JSON.stringify(arr);
  setMeta(m);
}

// UI-only state must not ride the sync layer: `expanded` on trips is
// per-device view state, and pushing it bumps updatedAt so a card
// expand could revert a concurrent ownership transfer (LWW).
function stripTripUiState(rec) {
  if (!rec || rec.expanded === undefined) return rec;
  const copy = { ...rec };
  delete copy.expanded;
  return copy;
}

async function pushRecordCollection(col) {
  const fb = await initFirebase();
  if (!fb) return;
  const { doc, setDoc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  const current = _readLocalArray(col.localKey);
  const shadow = _loadShadow(col);
  const shadowById = new Map(shadow.map(r => [r[col.idField], r]));
  const currentById = new Map(current.map(r => [r[col.idField], r]));
  // Each await below can last minutes (no signal, app in the background)
  // while merges keep arriving. So: re-read each record just before it is
  // uploaded, and at the end touch only the shadow entries of the records
  // this push actually handled.
  const latest = _latestReader(col);
  const done = new Map(); // id -> record now in the cloud (null = deleted)
  // Settlements keep one snapshot per route but sync under one id per date,
  // so their ids repeat. Such a collection keeps the old path (upload the
  // snapshot, save it as the shadow) until its ids are fixed.
  const uniqueIds = currentById.size === current.length;

  // Removed records → delete remote doc.
  for (const [id] of shadowById) {
    if (!currentById.has(id)) {
      try { await deleteDoc(doc(fb.db, SYNC_COLLECTION, col.docPrefix + id)); } catch (e) {}
      done.set(id, null);
    }
  }
  // Added / changed records → push.
  for (const first of current) {
    const id = first[col.idField];
    if (!id) continue;
    const old = shadowById.get(id);
    const isNew = !old;
    const changed = old && JSON.stringify(stripTripUiState(old)) !== JSON.stringify(stripTripUiState(first));
    if (isNew || changed) {
      const now = uniqueIds ? latest(id) : { rec: first, shadow: old };
      if (!now) continue; // removed meanwhile: the next push deletes it
      const rec = col.docPrefix === 'trip__' ? stripTripUiState(now.rec) : now.rec;
      // A merge that arrived during an earlier wait may already match it.
      if (now.shadow && JSON.stringify(stripTripUiState(now.shadow)) === JSON.stringify(rec)) continue;
      if (rec.builtIn) continue; // built-in sample customers never upload (Bug 2)
      try {
        await setDoc(doc(fb.db, SYNC_COLLECTION, col.docPrefix + id), {
          data: JSON.stringify(rec),
          // No date counts as 0 (oldest), never "now": an old copy uploaded
          // late must not look like the newest one.
          updatedAt: _recordUpdatedAt(rec, col),
        });
      } catch (e) {
        console.error('sync: push failed for ' + col.docPrefix + id, e);
      }
      done.set(id, rec);
    }
  }
  // After the waits: re-read the shadow, change only this push's records.
  if (!uniqueIds) _saveShadow(col, current);
  else if (done.size) {
    const byId = new Map(_loadShadow(col).map(r => [r[col.idField], r]));
    for (const [id, rec] of done) { if (rec) byId.set(id, rec); else byId.delete(id); }
    _saveShadow(col, [...byId.values()]);
  }
}

// Reads a record and its shadow entry as they are NOW in localStorage.
// Re-parses only when the array or the sync notes were written since.
function _latestReader(col) {
  let raw, byId, metaRaw, shadowById;
  return (id) => {
    const r = localStorage.getItem(col.localKey);
    if (r !== raw) { raw = r; byId = new Map(_readLocalArray(col.localKey).map(x => [x[col.idField], x])); }
    const m = localStorage.getItem(META_KEY);
    if (m !== metaRaw) { metaRaw = m; shadowById = new Map(_loadShadow(col).map(x => [x[col.idField], x])); }
    const rec = byId.get(id);
    return rec ? { rec, shadow: shadowById.get(id) } : null;
  };
}

// ─── Whole-array push ─────────────────────────────────────
async function pushArrayKey(k) {
  const fb = await initFirebase();
  if (!fb) return;
  const val = localStorage.getItem(k);
  if (val === null) return;
  const h = _hashStr(val);
  if (getMeta()[k + '__h'] === h) return; // unchanged since last push — skip the write
  const { doc, setDoc } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  try {
    await setDoc(doc(fb.db, SYNC_COLLECTION, k), {
      data: val,
      updatedAt: Date.now(),
    });
    // Re-read the sync notes AFTER the wait: merges saved shadows meanwhile.
    const meta = getMeta();
    meta[k] = Date.now();
    meta[k + '__h'] = h;
    setMeta(meta);
  } catch (e) {
    console.error('sync: push failed for ' + k, e);
  }
}

// ─── Pull (one-shot, used at startup / visibility) ────────
async function pull() {
  const fb = await initFirebase();
  if (!fb) return false;
  const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  try {
    const snap = await getDocs(collection(fb.db, SYNC_COLLECTION));
    let changed = false;
    snap.docs.forEach(doc => {
      const id = doc.id;
      if (isSkippedDocId(id)) return;
      const docData = doc.data() || {};
      const remoteTs = Number(docData.updatedAt) || 0;
      if (isRecordDocId(id)) {
        changed = mergeRecordDoc(id, docData.data, remoteTs) || changed;
      } else {
        changed = mergeArrayDoc(id, docData.data, remoteTs) || changed;
      }
    });
    if (changed) {
      selfHealTrips();
      notifyChanged();
    }
    return changed;
  } catch (e) {
    console.error('sync: pull failed', e);
    return false;
  }
}

function mergeArrayDoc(key, dataStr, remoteTs) {
  if (typeof dataStr !== 'string') return false;
  // Per-record collections (customers, users, orders...) are now merged
  // per-row by id. A legacy whole-array doc for one of these keys must NOT
  // wholesale-replace the local list — that is exactly what deleted Irma.
  if (RECORD_COLLECTIONS.some(c => c.localKey === key)) return false;
  const meta = getMeta();
  const localTs = Number(meta[key]) || 0;
  if (remoteTs <= localTs) return false;
  try {
    localStorage.setItem(key, dataStr);
    meta[key] = remoteTs;
    meta[key + '__h'] = _hashStr(dataStr); // local == merged remote; skip re-push
    setMeta(meta);
    return true;
  } catch (e) { return false; }
}

function mergeRecordDoc(id, dataStr, remoteTs) {
  if (typeof dataStr !== 'string') return false;
  const col = RECORD_COLLECTIONS.find(c => id.indexOf(c.docPrefix) === 0);
  if (!col) return false;
  let rec;
  try { rec = JSON.parse(dataStr); } catch (e) { return false; }
  const recId = rec && rec[col.idField];
  if (!recId) return false;
  const arr = _readLocalArray(col.localKey);
  const idx = arr.findIndex(r => r[col.idField] === recId);
  if (idx >= 0) {
    const localTs = _recordUpdatedAt(arr[idx], col);
    if (remoteTs <= localTs) return false;
    // Preserve per-device UI state on trips.
    if (col.docPrefix === 'trip__' && arr[idx].expanded !== undefined) {
      rec.expanded = arr[idx].expanded;
    }
    arr[idx] = rec;
  } else {
    arr.push(rec);
  }
  _writeLocalArray(col.localKey, arr);
  // Keep shadow in sync so we don't re-push what we just merged.
  const shadow = _loadShadow(col);
  const sIdx = shadow.findIndex(r => r[col.idField] === recId);
  if (sIdx >= 0) shadow[sIdx] = rec; else shadow.push(rec);
  _saveShadow(col, shadow);
  return true;
}

// ─── Trip membership sync ─────────────────────────────────
// Trip orderIds are authoritative. Membership changes are made only by
// explicit trip/order transactions, never by a partial local cache.
function selfHealTrips() {
  return false;
}

// ─── Notify the app that data changed (no reload) ─────────
function notifyChanged() {
  try {
    if (typeof App !== 'undefined' && App.reloadData) App.reloadData();
  } catch (e) {}
}

// Batch-apply record==>doc changes within a snapshot. Instead of re-reading
// and re-writing the whole localStorage array once per doc (the O(n^2) cost
// of mergeRecordDoc in a loop over the initial snapshot), load each collection
// once, apply every change in one pass, and write once.
function applyRecordBatch(entriesByCol) {
  let changed = false;
  for (const [ix, col] of RECORD_COLLECTIONS.entries()) {
    const entries = entriesByCol[ix];
    if (!entries || entries.length === 0) continue;
    const arr = _readLocalArray(col.localKey);
    const shadow = _loadShadow(col);
    let colChanged = false;
    for (const e of entries) {
      const { id, type, dataStr, remoteTs } = e;
      if (type === 'removed') {
        const recId = id.slice(col.docPrefix.length);
        const next = arr.filter(r => r[col.idField] !== recId);
        if (next.length !== arr.length) {
          arr.length = 0; arr.push(...next);
          const si = shadow.findIndex(r => r[col.idField] === recId);
          if (si >= 0) shadow.splice(si, 1);
          colChanged = true;
        }
        continue;
      }
      let rec;
      try { rec = JSON.parse(dataStr); } catch (err) { continue; }
      if (!rec || !rec[col.idField]) continue;
      const idx = arr.findIndex(r => r[col.idField] === rec[col.idField]);
      if (idx >= 0) {
        const localTs = _recordUpdatedAt(arr[idx], col);
        if (remoteTs <= localTs) continue;
        if (col.docPrefix === 'trip__' && arr[idx].expanded !== undefined) {
          rec.expanded = arr[idx].expanded;
        }
        arr[idx] = rec;
      } else {
        arr.push(rec);
      }
      const sIdx = shadow.findIndex(r => r[col.idField] === rec[col.idField]);
      if (sIdx >= 0) shadow[sIdx] = rec; else shadow.push(rec);
      colChanged = true;
    }
    if (colChanged) {
      _writeLocalArray(col.localKey, arr);
      _saveShadow(col, shadow);
      changed = true;
    }
  }
  return changed;
}

// ─── Real-time subscription ───────────────────────────────
// The first onSnapshot delivers the ENTIRE collection (same data pull()
// would fetch), so a subscriber awaiting the first snapshot replaces the
// separate startup pull() — one full read per launch instead of two.
async function subscribe() {
  const fb = await initFirebase();
  if (!fb) return;
  const { collection, onSnapshot } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  if (unsubSnapshot) return;
  let resolveFirst;
  const firstSnapshot = new Promise(r => { resolveFirst = r; });
  unsubSnapshot = onSnapshot(collection(fb.db, SYNC_COLLECTION), (snap) => {
    let changed = false;
    const batchEntries = RECORD_COLLECTIONS.map(() => []);
    snap.docChanges().forEach(change => {
      const doc = change.doc;
      const id = doc.id;
      if (isSkippedDocId(id)) return;
      const docData = doc.data() || {};
      const remoteTs = Number(docData.updatedAt) || 0;
      if (isRecordDocId(id)) {
        const colIx = RECORD_COLLECTIONS.findIndex(c => id.indexOf(c.docPrefix) === 0);
        batchEntries[colIx].push({ id, type: change.type, dataStr: docData.data, remoteTs });
      } else if (change.type === 'removed') {
        changed = removeArrayDoc(id) || changed;
      } else {
        changed = mergeArrayDoc(id, docData.data, remoteTs) || changed;
      }
    });
    // Batch-merge record collections: one localStorage read/write per
    // collection per snapshot (not one per document). LWW per record is
    // enforced inside applyRecordBatch via updatedAt.
    changed = applyRecordBatch(batchEntries) || changed;
    if (changed) {
      selfHealTrips();
      notifyChanged();
    }
    if (resolveFirst) { const r = resolveFirst; resolveFirst = null; r(); }
  }, (err) => {
    console.error('sync: onSnapshot error', err);
    if (resolveFirst) { const r = resolveFirst; resolveFirst = null; r(); }
  });
  await firstSnapshot;
}

function removeRecordDoc(id) {
  const col = RECORD_COLLECTIONS.find(c => id.indexOf(c.docPrefix) === 0);
  if (!col) return false;
  const recId = id.slice(col.docPrefix.length);
  const arr = _readLocalArray(col.localKey);
  const before = arr.length;
  const next = arr.filter(r => r[col.idField] !== recId);
  if (next.length === before) return false;
  _writeLocalArray(col.localKey, next);
  const shadow = _loadShadow(col).filter(r => r[col.idField] !== recId);
  _saveShadow(col, shadow);
  return true;
}

function removeArrayDoc(id) {
  if (!ARRAY_KEYS.includes(id)) return false;
  const meta = getMeta();
  delete meta[id];
  delete meta[id + '__h'];
  setMeta(meta);
  try {
    localStorage.removeItem(id);
    return true;
  } catch (e) { return false; }
}

// ─── Push ─────────────────────────────────────────────────
// One push at a time. A push asked for while one is running (3 s timer,
// app to background, startup) only sets a flag; the running push then goes
// round once more, so nothing is left un-uploaded and pushes never overlap.
let pushRunning = null;
let pushAgain = false;
function push() {
  if (pushRunning) { pushAgain = true; return pushRunning; }
  pushRunning = (async () => {
    try {
      do { pushAgain = false; await pushOnce(); } while (pushAgain);
    } finally { pushRunning = null; }
  })();
  return pushRunning;
}

async function pushOnce() {
  const fb = await initFirebase();
  if (!fb) return;
  // Record collections → per-record diff push.
  for (const col of RECORD_COLLECTIONS) {
    try { await pushRecordCollection(col); } catch (e) {}
  }
  // Whole-array keys → whole-doc push.
  for (const k of ARRAY_KEYS) {
    try { await pushArrayKey(k); } catch (e) {}
  }
  // Any other elcomal_* keys not in records/arrays → whole-doc push.
  const meta = getMeta();
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (!k || k.indexOf('elcomal_') !== 0 || isSkippedKey(k)) continue;
    if (RECORD_COLLECTIONS.some(c => c.localKey === k)) continue;
    if (ARRAY_KEYS.includes(k)) continue;
    try { await pushArrayKey(k); } catch (e) {}
  }
  void meta;
}

function schedulePush() {
  if (pushTimer) clearTimeout(pushTimer);
  pushTimer = setTimeout(() => { pushTimer = null; push(); }, 3000);
}

// ─── Transactional order claim ────────────────────────────
// Atomically claim orders for a new trip. Returns the claimed
// order ids; throws with the taken order ids if any are already
// claimed/completed.
async function claimOrders(orderIds, tripId, driverId, driverName) {
  const fb = await initFirebase();
  if (!fb) return orderIds; // offline → claim locally (deferred)
  const { doc, runTransaction } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  const taken = [];
  let txError = null;
  try {
    await runTransaction(fb.db, async (tx) => {
      for (const oid of orderIds) {
        const ref = doc(fb.db, SYNC_COLLECTION, 'order__' + oid);
        const snap = await tx.get(ref);
        if (snap.exists()) {
          const rec = JSON.parse(snap.data().data || '{}');
          if (rec.status !== 'pending' || rec.tripId) { taken.push(oid); continue; }
          rec.tripId = tripId;
          rec.claimedBy = driverId;
          rec.claimedByName = driverName;
          rec.claimedAt = new Date().toISOString();
          rec.updatedAt = new Date().toISOString();
          tx.set(ref, { data: JSON.stringify(rec), updatedAt: Date.now() });
        } else {
          // Doc doesn't exist in Firestore → unclaimed; write the claim.
          // If the order is unknown locally too, treat as taken to avoid orphans.
          const o = advanceOrders.find(x => x.id === oid);
          if (o) {
            const rec = { ...o, tripId, claimedBy: driverId, claimedByName: driverName,
                          claimedAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
            tx.set(ref, { data: JSON.stringify(rec), updatedAt: Date.now() });
          } else {
            taken.push(oid);
          }
        }
      }
    });
  } catch (e) {
    txError = e;
  }
  if (txError) {
    const err = new Error('claim_failed');
    err.cause = txError;
    err.taken = taken;
    throw err;
  }
  if (taken.length > 0) {
    const err = new Error('orders_taken');
    err.taken = taken;
    throw err;
  }
  return orderIds;
}

// ─── Transactional order transfer (takeover) ──────────────
// Moves pending orders from one trip to another atomically, so two
// drivers taking the same order race-resolve instead of clobbering.
// Returns { conflicts: [orderIds] } — empty on success.
async function transferOrders(orderIds, fromTripId, toTripId, driverId, driverName) {
  const fb = await initFirebase();
  if (!fb) return { conflicts: [] }; // offline → local change is authoritative
  const { doc, runTransaction } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  const conflicts = [];
  let txError = null;
  try {
    await runTransaction(fb.db, async (tx) => {
      const orderRefs = {};
      const recs = {};
      for (const oid of orderIds) {
        const ref = doc(fb.db, SYNC_COLLECTION, 'order__' + oid);
        orderRefs[oid] = ref;
        const snap = await tx.get(ref);
        if (!snap.exists()) { conflicts.push(oid); continue; }
        const rec = JSON.parse(snap.data().data || '{}');
        if (rec.status !== 'pending') { conflicts.push(oid); continue; }
        if (rec.tripId && rec.tripId !== fromTripId && rec.tripId !== toTripId) { conflicts.push(oid); continue; }
        recs[oid] = rec;
      }
      if (conflicts.length) return;
      const now = Date.now();
      const fromRef = fromTripId ? doc(fb.db, SYNC_COLLECTION, 'trip__' + fromTripId) : null;
      const toRef = doc(fb.db, SYNC_COLLECTION, 'trip__' + toTripId);
      let fromRec = null, toRec = null;
      if (fromRef) {
        const fs = await tx.get(fromRef);
        if (fs.exists()) fromRec = JSON.parse(fs.data().data || '{}');
      }
      const ts = await tx.get(toRef);
      if (ts.exists()) toRec = JSON.parse(ts.data().data || '{}');
      for (const oid of orderIds) {
        const rec = recs[oid];
        rec.tripId = toTripId;
        rec.claimedBy = driverId;
        rec.claimedByName = driverName;
        rec.claimedAt = new Date().toISOString();
        rec.updatedAt = new Date().toISOString();
        tx.set(orderRefs[oid], { data: JSON.stringify(rec), updatedAt: now });
        if (fromRec) fromRec.orderIds = [...new Set((fromRec.orderIds || []).filter(x => x !== oid))];
        if (toRec) toRec.orderIds = [...new Set([...(toRec.orderIds || []), oid])];
      }
      if (fromRec) tx.set(fromRef, { data: JSON.stringify(fromRec), updatedAt: now });
      if (toRec) tx.set(toRef, { data: JSON.stringify(toRec), updatedAt: now });
    });
  } catch (e) {
    txError = e;
  }
  if (txError) return { conflicts: [], error: txError };
  return { conflicts };
}

// ─── Clear remote keys (cleanup) ──────────────────────────
async function clearRemoteKeys(keys) {
  const meta = getMeta();
  for (const k of keys) meta[k] = Date.now();
  setMeta(meta);
  try {
    const fb = await initFirebase();
    if (fb) {
      const { doc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
      for (const k of keys) {
        try { await deleteDoc(doc(fb.db, SYNC_COLLECTION, k)); } catch (e) {}
      }
    }
  } catch (e) {}
}

// ─── One-time production reconcile ────────────────────────
const RECONCILE_FLAG = 'elcomal_sync_reconciled';
async function reconcileLocal() {
  if (!IS_NATIVE) return false;
  try { if (localStorage.getItem(RECONCILE_FLAG) === '1') return false; } catch (e) {}
  const fb = await initFirebase();
  if (!fb) return false;
  const { collection, getDocs, doc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  try {
    const snap = await getDocs(collection(fb.db, SYNC_COLLECTION));
    const ids = snap.docs.map(d => d.id).filter(id => !isSkippedDocId(id));
    for (const id of ids) {
      try { await deleteDoc(doc(fb.db, SYNC_COLLECTION, id)); } catch (e) {}
    }
    try { localStorage.setItem(RECONCILE_FLAG, '1'); } catch (e) {}
    await push();
    return true;
  } catch (e) {
    console.error('sync: reconcile failed', e);
    return false;
  }
}

// ─── Events ───────────────────────────────────────────────
if (typeof document !== 'undefined') {
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      if (pushTimer) { clearTimeout(pushTimer); pushTimer = null; }
      push();
    } else if (document.visibilityState === 'visible') {
      // The live subscription (subscribe) already reconnects and delivers
      // missed changes; a full collection pull on every foreground is the
      // O(collection) read that made reopening slow. Just refresh connectivity.
      online = navigator.onLine;
    }
  });
  window.addEventListener('online', () => { online = true; pull().then(() => {}); });
  window.addEventListener('offline', () => { online = false; });
}

// ─── Startup ──────────────────────────────────────────────
// Returning devices (users already in localStorage) render the login screen
// INSTANTLY from local cache; the full collection read + live subscription
// happen in the background and merge via notifyChanged → reloadData. Only a
// genuinely fresh device (no local users) must await the first snapshot so the
// create-account vs login decision sees the instance's existing users first.
// The outbound push runs later, non-blocking; dropLegacyCustomerDoc is a
// one-time migration step.
if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    window.__syncReady = (async () => {
      await migrateToRecords();
      const returning = typeof Auth !== 'undefined' && Auth.isFirstRun && !Auth.isFirstRun();
      if (returning) {
        // Returning device: do not block first paint on the Cloud read.
        void subscribe();
      } else {
        await subscribe();
      }
      if (!v2Done()) { try { await dropLegacyCustomerDoc(); } catch (e) {} }
    })();
    setTimeout(() => { void push(); }, 1500);
  });
}

// ─── Test hooks (harmless in production) ──────────────────
window.SyncDebug = {
  pull, push, getMeta, setMeta, initFirebase, clearRemoteKeys, reconcileLocal,
  claimOrders, transferOrders, subscribe, migrateToRecords, isSkippedKey,
};