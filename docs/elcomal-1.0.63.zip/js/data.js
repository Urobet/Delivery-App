// ─── STATE ─────────────────────────────────────────────
const AppState = {
  driver: (() => {
    const s = Auth.currentUser();
    if (s) return { name: s.name, id: s.userId, role: s.role };
    const u = DB.User.load();
    return { name: (u && u.name) || 'Usuario', id: (u && u.id) || 'USR000', role: 'driver' };
  })(),
  screen: 'login',
  params: {},
  history: [],
  route: null,
  routeName: null,
  routeFilter: null,
  creditModal: null,
  extraSales: [],
  streetExpanded: false,
  streetModal: false,
  streetLines: null,
  streetDescription: '',
  collections: [],
  futureOrders: DB.FutureOrders.load(),
  counterSales: [],
  currentStop: null,
  collapsedCompleted: true,
  toast: null,
  toastMs: 0,
  reportTab: 'ventas.liquidacion',
  reportDate: today(),
  reportFrom: today(),
  reportTo: today(),
  reportDrill: null,
  reportDrillDay: null,
  friosTrendView: 'pct',
  friosSort: 'pct',
  friosCustomer: null,
  routeSubTab: 'today',
  sheetCustomerId: null,
  paymentEntry: false,
  statementModal: null,
  openingDebtModal: null,
  statementFilter: 'all',
  showRouteFilter: false,
  routeDate: today(),
  calendarOpen: false,
  calendarMonth: today().slice(0, 7),
  customersSortBy: 'name',
  customersSortDir: 'asc',
  customersPage: 1,
  customersPerPage: 8,
  customerFormId: null,
  selectedCustomers: [],
  editingOrderId: null,
  selectedOrders: [],
  productEditId: null,
  showOrderForm: false,
  orderRecurrence: null,
  trips: [],
  routeCreationModal: false,
  skipReasonModal: null,
  signatureSheet: null,
  showNewUserForm: false,
  nuName: '',
  nuUsername: '',
  nuPassword: '',
  nuRole: 'driver',
  editUserId: null,
  userMenuId: null,
  euName: '',
  euUsername: '',
  loginUsername: '',
  loginPassword: '',
  loginName: '',
  loginPassword2: '',
  loginRemember: true,
};

// ─── HELPERS ───────────────────────────────────────────
function genId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function today() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
}
function formatDate(d) {
  const date = new Date(d + 'T12:00:00');
  return date.toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long' });
}
function formatCurrency(n) { return '$' + Number(n).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); }
function formatDateShort(d) {
  const date = new Date(d + 'T12:00:00');
  return date.toLocaleDateString('es-MX', { day: 'numeric', month: 'short' });
}
function formatStmtDate(d) {
  const date = new Date(d + 'T12:00:00');
  const mon = date.toLocaleDateString('es-MX', { month: 'short' }).replace('.', '');
  return String(date.getDate()).padStart(2, '0') + '/' + mon.charAt(0).toUpperCase() + mon.slice(1);
}
function formatDateNumeric(d) {
  if (!d) return '';
  const date = new Date(d + 'T12:00:00');
  return String(date.getDate()).padStart(2, '0') + '/' + String(date.getMonth() + 1).padStart(2, '0') + '/' + date.getFullYear();
}
function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

// ─── PERSISTENCE ────────────────────────────────────────
const STORAGE_KEY_CLIENTS = 'elcomal_clientes';
const STORAGE_KEY_ORDERS = 'elcomal_orders';
const STORAGE_KEY_STOPS = 'elcomal_stops';
const STORAGE_KEY_TRIPS = 'elcomal_trips';

// ─── CUSTOMERS ─────────────────────────────────────────
const DEFAULT_CLIENTES = [
  { id: 'C15', name: 'Juanito', contact: '', phone: '', direccion: 'Pueblo Nuevo', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 22.5,
    recurrence: { preset: 'weekly', frequencyValue: 1, frequencyUnit: 'weeks', daysOfWeek: [1], endType: 'never', endDate: '', endOccurrences: 10 } },
  { id: 'C16', name: 'Lupe', contact: '', phone: '', direccion: 'Pueblo Nuevo', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0 },
  { id: 'C17', name: 'Santos', contact: '', phone: '', direccion: 'Dolores', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 21 },
  { id: 'C18', name: 'Pepe', contact: '', phone: '', direccion: 'La Perla', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 22 },
  { id: 'C19', name: 'Jorge', contact: '', phone: '', direccion: 'La Perla', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 22 },
  { id: 'C20', name: 'Chuy', contact: '', phone: '', direccion: 'La Perla', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 22 },
  { id: 'C21', name: 'Eliza', contact: '', phone: '', direccion: 'Melgar', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C22', name: 'Molino', contact: '', phone: '', direccion: 'Melgar', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C23', name: 'Cona 25', contact: '', phone: '', direccion: '25 de Diciembre', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 23, recurrence: null },
  { id: 'C24', name: 'Hugo', contact: '', phone: '', direccion: '25 de Diciembre', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C25', name: 'Mundo', contact: '', phone: '', direccion: 'El Paso', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C26', name: 'Paco', contact: '', phone: '', direccion: 'El Paso', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C27', name: 'Chata', contact: '', phone: '', direccion: 'El Paso', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C28', name: 'Milenio', contact: '', phone: '', direccion: 'El Paso', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C29', name: 'Fermina', contact: '', phone: '', direccion: 'El Paso', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C30', name: 'Casas', contact: '', phone: '', direccion: '25 de Diciembre', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 24, recurrence: null },
  { id: 'C31', name: 'Chuy la flor', contact: '', phone: '', direccion: 'La Flor', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C32', name: 'susana', contact: '', phone: '', direccion: 'La Flor', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C33', name: 'tienda la flor', contact: '', phone: '', direccion: 'La Flor', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C34', name: 'lupita', contact: '', phone: '', direccion: 'La Flor', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
];

function loadClients() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_CLIENTS);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  // Built-in samples (ids C15–C34, the same ids as real customers in the
  // cloud): marked builtIn and left with no date, so they count as the
  // oldest and the cloud's real customers replace them. sync.js never
  // uploads a customer still marked builtIn (Bug 2).
  return JSON.parse(JSON.stringify(DEFAULT_CLIENTES)).map(c => ({ ...c, builtIn: true }));
}

// A balance change is a real edit: date it so it reaches the other phones
// (an undated customer counts as 0 there). Built-in samples stay undated.
function touchCustomer(c) {
  if (!c.builtIn) c.updatedAt = new Date().toISOString();
}

function saveClients() {
  try { localStorage.setItem(STORAGE_KEY_CLIENTS, JSON.stringify(CLIENTES)); } catch (e) {}
}

let CLIENTES = loadClients();
backfillCustomerBalances();

// ─── CUSTOMER PAYMENTS / CUENTA (kilos fiados) ─────────
const PAYMENTS_KEY = 'elcomal_payments';
let PAYMENTS = loadPayments();

function loadPayments() {
  try {
    const saved = localStorage.getItem(PAYMENTS_KEY);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return [];
}

function savePayments() {
  try { localStorage.setItem(PAYMENTS_KEY, JSON.stringify(PAYMENTS)); } catch (e) {}
}

// One-time migration: seed each customer's balance from historical
// settlement snapshots (sum of all credited kilos per stop).
function backfillCustomerBalances() {
  let changed = false;
  const snapshots = DB.SettlementHistory.load();
  CLIENTES.forEach(c => {
    if (typeof c.balance !== 'number') {
      let total = 0;
      snapshots.forEach(snap => {
        (snap.stops || []).forEach(st => {
          if (st.customerId === c.id) total += (Number(st.creditAmount) || 0);
        });
      });
      c.balance = total;
      changed = true;
    }
  });
  if (changed) saveClients();
}

function recordCustomerCredit(customerId, amount) {
  const amt = Number(amount) || 0;
  if (amt <= 0) return;
  const c = getCustomerSafe(customerId, { label: 'Cliente' });
  if (c) {
    c.balance = (c.balance || 0) + amt;
    touchCustomer(c);
    saveClients();
  }
}

// ─── ERP BOUNDARY HELPERS (additive; app math never uses these) ──
// Round money to 2 decimals — ONLY for ERP outbox serialization.
function round2(n) { return Math.round((Number(n) + Number.EPSILON) * 100) / 100; }

// Derive a customer's balance from the synced ledger rows, mirroring the
// mutation semantics exactly:
//   + opening debts (addOpeningDebt → recordCustomerCredit)
//   + completed order credits (confirmStop → recordCustomerCredit == o.creditAmount)
//   − payment ledger rows (addPayment / recordDebtPayment)
// Mutations clamp decreases at 0 (Math.max), so a negative raw sum is a
// valid match for a stored 0. Diagnostic only — never writes balance.
function computeBalanceFromLedger(customerId) {
  const opening = OPENING_DEBTS.filter(d => d.customerId === customerId)
    .reduce((s, d) => s + (Number(d.amount) || 0), 0);
  const credits = advanceOrders.filter(o =>
      o.customerId === customerId && o.status === 'completed')
    .reduce((s, o) => s + (Number(o.creditAmount) || 0), 0);
  const paid = PAYMENTS.filter(p => p.customerId === customerId)
    .reduce((s, p) => s + (Number(p.amount) || 0), 0);
  return opening + credits - paid;
}

// True when the stored balance drifts from the ledger derivation.
// Tolerance 0.01 (float money); stored 0 with negative raw is the clamp.
function balanceDrift(customerId) {
  const c = getCustomer(customerId);
  if (!c) return false;
  const derived = computeBalanceFromLedger(customerId);
  const stored = Number(c.balance) || 0;
  if (derived < 0 && stored === 0) return false; // clamp effect
  return Math.abs(stored - derived) > 0.01;
}

function getCustomerPayments(customerId) {
  return PAYMENTS.filter(p => p.customerId === customerId)
    .sort((a, b) => (a.timestamp || '').localeCompare(b.timestamp || ''));
}

function getTotalPayments(customerId) {
  return getCustomerPayments(customerId).reduce((s, p) => s + (Number(p.amount) || 0), 0);
}

function getPaymentsTotalForDate(dateStr) {
  const d = dateStr || today();
  return PAYMENTS.filter(p => (p.timestamp || '').slice(0, 10) === d)
    .reduce((s, p) => s + (Number(p.amount) || 0), 0);
}

// ─── OPENING DEBTS (deuda previa / saldo inicial) ───────
const OPENING_DEBTS_KEY = 'elcomal_openingDebts';
let OPENING_DEBTS = loadOpeningDebts();

function loadOpeningDebts() {
  try {
    const saved = localStorage.getItem(OPENING_DEBTS_KEY);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return [];
}

function saveOpeningDebts() {
  try { localStorage.setItem(OPENING_DEBTS_KEY, JSON.stringify(OPENING_DEBTS)); } catch (e) {}
}

// Registers debt the customer already owed before using the app.
// Bumps c.balance (drives the stop highlight) AND persists a row so
// the ledger/statement shows where the debt came from.
function addOpeningDebt(customerId, amount, date) {
  const amt = Number(amount) || 0;
  if (amt <= 0) return null;
  const entry = {
    id: genId(),
    customerId,
    amount: amt,
    date: date || today(),
    note: 'Deuda previa / Saldo inicial',
    operator: (AppState.driver && AppState.driver.name) || '—',
    timestamp: new Date().toISOString(),
  };
  OPENING_DEBTS.push(entry);
  saveOpeningDebts();
  recordCustomerCredit(customerId, amt);
  return entry;
}

function getOpeningDebts(customerId) {
  return OPENING_DEBTS.filter(d => d.customerId === customerId);
}

// ─── CHANGE OWED (cambio pendiente) ─────────────────────
// A liability the app owes the CUSTOMER — the mirror image of the credit
// ledger. Arises when the driver cannot break the customer's bill: they hand
// over more than the sale is worth, and the surplus is owed back on a later
// visit, applied against the next order.
//
// Deliberately NOT a field on the customer. `balance` is a pure receivable and
// is clamped at 0 by BOTH addPayment (Math.max(0, ...)) and getCustomerBalance
// (Math.max(0, ...)), so a negative balance there is unreachable — and every
// comparison that reads it (payment cap, old-debt chip, credit-limit guard)
// would silently invert if it became reachable. Two accounts, one per side.
//
// Balance is the plain UNCLAMPED sum of these rows: owed rows add, applied
// rows subtract. Never rounded, never forced to 0 — a 0.02 residue is real
// money still owed, and hiding it would be exactly the manual bookkeeping
// this ledger exists to replace.
const CUSTOMER_OWED_KEY = 'elcomal_customerOwed';
let CUSTOMER_OWED = loadCustomerOwed();

function loadCustomerOwed() {
  try {
    const saved = localStorage.getItem(CUSTOMER_OWED_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {}
  return [];
}

function saveCustomerOwed() {
  try { localStorage.setItem(CUSTOMER_OWED_KEY, JSON.stringify(CUSTOMER_OWED)); } catch (e) {}
}

function getCustomerOwedRows(customerId) {
  return CUSTOMER_OWED.filter(r => r.customerId === customerId)
    .sort((a, b) => (a.timestamp || '').localeCompare(b.timestamp || ''));
}

// What the app currently owes this customer. Positive = we owe them.
// Not clamped: this is a liability, so a residue IS an outstanding obligation.
//
// The sign lives here and ONLY here. `amount` is stored positive on every row
// (an audit log of magnitudes); 'applied' rows move the balance DOWN. Summing
// the raw amount column regardless of kind is the bug this comment exists to
// prevent: it would make applying $2 ADD $2 to what we owe, so the next order
// would consume $2 from a $4 phantom balance and the customer would never get
// their change back.
function customerOwedSign(row) {
  return row.kind === 'applied' ? -1 : 1;
}

function getCustomerOwed(customerId) {
  return getCustomerOwedRows(customerId)
    .reduce((s, r) => s + customerOwedSign(r) * (Number(r.amount) || 0), 0);
}

// Net movement on a day: change owed raised MINUS change already returned.
// Net-negative means the day handed back more unbroken change than it took in,
// which is legitimate (a customer paying back an old balance) and must not be
// clamped to 0 or the day's figure contradicts the statement.
function getCustomerOwedTotalForDate(dateStr) {
  const d = dateStr || today();
  return CUSTOMER_OWED.filter(r => (r.timestamp || '').slice(0, 10) === d)
    .reduce((s, r) => s + customerOwedSign(r) * (Number(r.amount) || 0), 0);
}

// kind 'owed' → the driver took more cash than the sale was worth and cannot
// break the bill. kind 'applied' → a later order consumed that surplus.
// Both carry orderId so the statement can prove WHICH order absorbed it.
function pushCustomerOwedRow(customerId, amount, kind, meta) {
  const amt = Number(amount) || 0;
  if (amt <= 0) return null;
  const m = meta || {};
  const row = {
    id: genId(),
    customerId,
    amount: amt,
    kind,
    orderId: m.orderId || null,
    stopId: m.stopId || null,
    routeName: m.routeName || AppState.routeName || null,
    kg: Number(m.kg) || 0,
    reason: m.reason || (kind === 'owed' ? 'Sin cambio' : 'Aplicado a pedido'),
    operator: m.operator || (AppState.driver && AppState.driver.name) || '—',
    timestamp: new Date().toISOString(),
  };
  CUSTOMER_OWED.push(row);
  saveCustomerOwed();
  return row;
}

function recordChangeOwed(customerId, amount, meta) {
  return pushCustomerOwedRow(customerId, amount, 'owed', meta);
}

// Consumes up to `amount` of what we owe. Callers pass min(balance, need);
// re-clamping here is a cheap guard against a double-apply leaving the
// balance negative (which would flip the sign and start paying the customer).
function applyCustomerOwed(customerId, amount, meta) {
  const amt = Math.max(0, Math.min(Number(amount) || 0, getCustomerOwed(customerId)));
  return pushCustomerOwedRow(customerId, amt, 'applied', meta);
}

// Drops every ledger row booked for one delivery leg so it can be re-booked
// from scratch. A partial delivery is a draft the driver can revise (wrong kg,
// wrong cash, chip flipped), and the ledger rows are append-only, so without
// this a re-commit would leave the first attempt's rows stranded beside the
// corrected ones and the balance would carry both. Matching is scoped to the
// leg's own stopId so other stops of the same order are untouched.
function clearCustomerOwedForLeg(customerId, stopId) {
  const before = CUSTOMER_OWED.length;
  CUSTOMER_OWED = CUSTOMER_OWED.filter(
    r => !(r.customerId === customerId && r.stopId && r.stopId === stopId)
  );
  if (CUSTOMER_OWED.length !== before) saveCustomerOwed();
  return before - CUSTOMER_OWED.length;
}

// ─── AMENDMENTS (append-only audit of post-completion edits) ───────
//
// A completed stop is a financial fact, not a draft. When one has to be
// corrected we do NOT overwrite it quietly: we reverse its bookings, re-run the
// normal settlement math with the corrected figures, and write an immutable
// record of who did it, when, and why.
//
// Why this is append-only and never edited or deleted: the whole point is to
// catch a driver marking collected money as cash when it was never collected.
// A log that the same actor can rewrite proves nothing. Rows are only ever
// ADDED; a correction to an edit is itself another edit.
//
// Synced PER-RECORD (amendment__ docs, not a whole-array key) on purpose —
// whole-array LWW would let one device's push erase the audit trail wholesale.
const AMENDMENTS_KEY = 'elcomal_amendments';
let AMENDMENTS = loadAmendments();
// Two corrections in the same millisecond produce the same `at`, and a
// timestamp alone cannot order them. `seq` is a monotonic counter that breaks
// the tie so the trail always reads newest-last / newest-first consistently —
// an audit whose order wobbles is worthless as evidence. It resumes from the
// highest seq already on record, so it keeps counting up across reloads and
// after rows arrive from another device.
let _amendSeq = AMENDMENTS.reduce((m, a) => Math.max(m, Number(a.seq) || 0), 0);

function loadAmendments() {
  try {
    const saved = localStorage.getItem(AMENDMENTS_KEY);
    if (saved) { const parsed = JSON.parse(saved); if (Array.isArray(parsed)) return parsed; }
  } catch (e) {}
  return [];
}
function saveAmendments() {
  try { localStorage.setItem(AMENDMENTS_KEY, JSON.stringify(AMENDMENTS)); } catch (e) {}
}

// Who is acting. The authenticated user is the accountable party; the driver
// on the route is recorded separately because they are the one who first
// entered the figure being corrected. Never trust one to speak for the other.
function currentActor() {
  let u = null;
  try { if (typeof Auth !== 'undefined') u = Auth.currentUser(); } catch (e) {}
  if (u) {
    return {
      id: u.id || u.username || 'usr?',
      name: u.name || u.username || 'Admin',
      role: u.role === 'admin' ? 'admin' : 'driver',
    };
  }
  const d = AppState.driver || {};
  return { id: d.id || 'driver?', name: d.name || '—', role: 'driver' };
}

// fieldDiff reports only what actually changed, so the audit shows the
// correction and not a wall of identical numbers.
function fieldDiff(before, after, fields) {
  const out = [];
  fields.forEach(f => {
    const b = before ? before[f] : undefined;
    const a = after ? after[f] : undefined;
    const nb = typeof b === 'number' ? round2(b) : b;
    const na = typeof a === 'number' ? round2(a) : a;
    if (JSON.stringify(nb) !== JSON.stringify(na)) out.push({ field: f, from: b, to: a });
  });
  return out;
}

function addAmendment(entry) {
  const row = Object.assign({
    id: 'AM-' + genId(),
    at: new Date().toISOString(),
    seq: ++_amendSeq,
  }, entry);
  AMENDMENTS.push(row);
  saveAmendments();
  return row;
}

function getAmendmentsForOrder(orderId) {
  return AMENDMENTS.filter(a => a.orderId === orderId)
    .sort((x, y) => (String(x.at).localeCompare(String(y.at)) || ((Number(x.seq) || 0) - (Number(y.seq) || 0))));
}
function getAmendmentsForStop(stopId) {
  return AMENDMENTS.filter(a => a.stopId === stopId)
    .sort((x, y) => String(x.at).localeCompare(String(y.at)));
}
function getAmendmentsInRange(from, to) {
  return AMENDMENTS.filter(a => a.date >= from && a.date <= to)
    .sort((x, y) => (String(y.at).localeCompare(String(x.at)) || ((Number(y.seq) || 0) - (Number(x.seq) || 0)))) // newest first
}

// ─── STOP BOOKING RECEIPT (what a completion wrote, so it can be undone) ──
// confirmStop fans money out across FIVE places: the order doc, the stop
// itself, AppState.collections + its session doc, the CUSTOMER_OWED ledger,
// the PAYMENTS ledger, and customer.balance. A reopen has to be able to put
// all five back exactly, so the completion records what it did. Nothing here
// is ever overwritten in place — it is the "before" side of the audit.
const STOP_BOOKING_FIELDS = [
  'deliveredKg', 'devolucionKg', 'recompraKg', 'recompraCollected',
  'creditAmount', 'creditPaidType', 'creditPaidAmount',
  'oldDebtPaid', 'changeOwed', 'owedApplied',
  'completedAt', 'completedBy', 'completedByName',
];

// Records which sink-rows a completion created. Ids are captured at booking
// time; `inferred` covers stops completed before this feature existed, matched
// by customer + amount + the completion timestamp.
function recordStopBooking(order, stop, booking) {
  if (!order) return null;
  order.booking = Object.assign({
    stopId: stop.stopId,
    at: new Date().toISOString(),
    by: currentActor().id,
    byName: currentActor().name,
  }, booking);
  return order.booking;
}

function getStopBooking(order) {
  return (order && order.booking && typeof order.booking === 'object') ? order.booking : null;
}

// Same stop, same customer, created at the moment the stop was completed.
// Used only to recover rows for bookings made before receipts existed.
function inferRowsForStop(rows, order, field, amount) {
  if (!order || !amount) return [];
  const at = order.completedAt ? new Date(order.completedAt).getTime() : 0;
  return rows.filter(r => {
    if (r.customerId !== order.customerId) return false;
    if (Math.abs((Number(r[field]) || 0) - (Number(amount) || 0)) > 0.005) return false;
    if (order.booking && order.booking.stopId && r.stopId && r.stopId === order.booking.stopId) return true;
    if (!at || !r.timestamp) return false;
    return Math.abs(new Date(r.timestamp).getTime() - at) < 10 * 60 * 1000;
  });
}

function removeCollectionRow(collectionId, order) {
  let removed = [];
  if (collectionId) {
    removed = AppState.collections.filter(c => c.id === collectionId);
    if (removed.length) {
      AppState.collections = AppState.collections.filter(c => c.id !== collectionId);
    }
  } else if (order) {
    const cash = getStopBooking(order)?.cash;
    if (cash > 0) {
      const matches = inferRowsForStop(AppState.collections, order, 'cash', cash);
      if (matches.length === 1) {
        removed = matches;
        AppState.collections = AppState.collections.filter(c => c.id !== matches[0].id);
      }
    }
  }
  const rn = AppState.routeName, rd = AppState.routeDate || today();
  if (removed.length && rn) {
    DB.Session.save(rn, rd, { routeName: rn, date: rd, extraSales: AppState.extraSales, collections: AppState.collections });
  }
  return removed.reduce((s, c) => s + (Number(c.cash) || 0), 0);
}

function removePaymentRows(paymentIds, order) {
  let ids = paymentIds;
  if ((!ids || !ids.length) && order) {
    const oldDebt = getStopBooking(order)?.oldDebtPaid || order.oldDebtPaid;
    if (oldDebt > 0) {
      const matches = inferRowsForStop(PAYMENTS, order, 'amount', oldDebt);
      if (matches.length === 1) ids = [matches[0].id];
    }
  }
  if (!ids || !ids.length) return 0;
  const set = new Set(ids);
  const before = PAYMENTS.length;
  PAYMENTS = PAYMENTS.filter(p => !set.has(p.id));
  if (PAYMENTS.length !== before) savePayments();
  return before - PAYMENTS.length;
}

// Reverse every booking a stop completion made. Returns a receipt of what was
// undone so the caller can show an honest summary, and so tests can assert the
// ledgers came back to where they were.
//
// Deliberately ledger-row DELETION, not negative rows: these are corrections to
// a figure that was never real, and leaving compensating entries would make
// the statement show a sale that was withdrawn. The audit trail is where that
// history belongs, and it is append-only.
function revertStopBooking(stop) {
  const order = stop.orderId ? getAdvanceOrder(stop.orderId) : null;
  const b = getStopBooking(order) || (order || stop);
  const customerId = stop.customerId;
  const undid = {
    cash: 0, credit: 0, oldDebt: 0, owedCleared: 0, payments: 0, inferred: !getStopBooking(order),
  };

  undid.owedCleared = clearCustomerOwedForLeg(customerId, stop.stopId);
  undid.payments = removePaymentRows(b.paymentIds, order);
  undid.cash = removeCollectionRow(b.collectionId, order);

  // Balance: undo the two deltas the completion applied, by the SAME amounts.
  const todayCredit = Number(b.creditAmount) || 0;
  const oldDebtPaid = Number(b.oldDebtPaid) || 0;
  undid.credit = todayCredit;
  undid.oldDebt = oldDebtPaid;
  const c = getCustomerSafe(customerId, { label: 'Cliente' });
  if (c) {
    c.balance = (Number(c.balance) || 0) - todayCredit + oldDebtPaid;
    if (c.balance < 0) c.balance = 0;
    touchCustomer(c);
    saveClients();
  }

  if (order) {
    STOP_BOOKING_FIELDS.forEach(f => { if (order[f] !== undefined) order[f] = null; });
    order.status = 'pending';
    order.booking = null;
    order.updatedAt = new Date().toISOString();
    saveAdvanceOrders();
  }

  // Back to editable: same shape the stop had before it was ever confirmed.
  stop.status = 'pending';
  stop.creditAmount = 0;
  stop.creditPaidType = null;
  stop.creditPaidAmount = 0;
  stop.changeOwed = 0;
  stop.owedApplied = 0;
  stop.oldDebtPaid = 0;
  stop.recompraCollected = 0;
  stop.deliveryDraft = null;
  saveStopProgress(AppState.routeName, AppState.route.stops);
  return undid;
}

// Reopening can silently orphan a trip that auto-completed on its last stop.
// If no order is pending any more, the trip is genuinely done again.
function reopenTripIfUndone(order) {
  if (!order) return;
  const trip = (AppState.trips || []).find(t => (t.orderIds || []).includes(order.id));
  if (!trip || trip.status !== 'completed') return;
  const allDone = trip.orderIds.every(oid => {
    const ord = advanceOrders.find(x => x.id === oid);
    return !ord || ord.status === 'completed' || ord.status === 'skipped';
  });
  if (!allDone && trip.completedBy === order.completedBy) {
    trip.status = 'pending';
    delete trip.completedBy;
    delete trip.completedByName;
    delete trip.completedAt;
    trip.updatedAt = new Date().toISOString();
    saveTrips();
  }
}

// A route-day that has been closed with Finalizar is frozen. Reopening after
// that point would leave the closed snapshot, the reports and the ERP
// settlement disagreeing with the ledger, so it is refused outright.
function isRouteDayOpen(routeName, date) {
  const rn = routeName || AppState.routeName;
  if (!rn) return true;
  const d = date || AppState.routeDate || today();
  const snaps = (DB.SettlementHistory.getByDate(d) || []);
  return !snaps.some(s => s.routeName === rn);
}

// ─── CREDIT LEDGER (fiado) ─────────────────────────────
function getCreditMovements(customerId) {
  const rows = [];
  const seen = new Set();
  const liveDate = AppState.routeDate || today();
  const hasLiveRoute = !!AppState.route && AppState.route.stops.length > 0;
  const push = r => {
    const key = r.orderId || r.stopId || (r.date + '|' + r.ref);
    if (seen.has(key)) return;
    seen.add(key);
    rows.push(r);
  };
  advanceOrders.forEach(o => {
    if (o.customerId === customerId && o.status === 'completed' && (Number(o.creditAmount) || 0) > 0) {
      push({
        type: 'credit',
        date: o.date,
        amount: Number(o.creditAmount) || 0,
        kg: (o.deliveredKg !== undefined ? o.deliveredKg : o.qty) || 0,
        ref: o.id,
        stopId: 'S-' + o.id,
        orderId: o.id,
        routeName: o.route || null,
        operator: '—',
        source: 'sale',
        isOpeningBalance: false,
        dateKnown: !!o.date,
      });
    }
  });
  OPENING_DEBTS.forEach(d => {
    if (d.customerId === customerId && (Number(d.amount) || 0) > 0) {
      push({
        type: 'credit',
        // Undated opening debt keeps missing-date semantics (real debt,
        // unknown age) — never invent today() as its age.
        date: d.date || null,
        amount: Number(d.amount) || 0,
        kg: 0,
        ref: 'SALDO-' + d.id,
        stopId: null,
        orderId: null,
        routeName: null,
        operator: d.operator || '—',
        note: d.note || 'Deuda previa / Saldo inicial',
        source: 'opening',
        isOpeningBalance: true,
        dateKnown: !!d.date,
      });
    }
  });
  DB.SettlementHistory.load().forEach(snap => {
    if (hasLiveRoute && snap.date === liveDate) return;
    (snap.stops || []).forEach(st => {
      // No receivables from cancelled/pending stops; missing status stays
      // eligible (records predating the status field).
      if (st.status && st.status !== 'completed') return;
      if (st.customerId === customerId && (Number(st.creditAmount) || 0) > 0) {
        push({
          type: 'credit',
          date: snap.date,
          amount: Number(st.creditAmount) || 0,
          kg: (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0,
          ref: st.orderId || st.stopId || 'INV',
          stopId: st.stopId || null,
          orderId: st.orderId || null,
          routeName: snap.routeName || null,
          operator: snap.driverName || '—',
          source: 'sale',
          isOpeningBalance: false,
          dateKnown: !!snap.date,
        });
      }
    });
  });
  if (AppState.route) {
    AppState.route.stops.forEach(st => {
      if (st.customerId === customerId && st.status === 'completed' && (Number(st.creditAmount) || 0) > 0) {
        push({
          type: 'credit',
          date: liveDate,
          amount: Number(st.creditAmount) || 0,
          kg: (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0,
          ref: st.orderId || st.stopId || 'INV',
          stopId: st.stopId || null,
          orderId: st.orderId || null,
          routeName: AppState.routeName || null,
          operator: (AppState.driver && AppState.driver.name) || '—',
          source: 'sale',
          isOpeningBalance: false,
          dateKnown: !!liveDate,
        });
      }
    });
  }
  return rows;
}

// Unified credits + payments, FIFO-covered (payments settle oldest
// credit first). Returns newest-first rows for display.
function getUnifiedLedger(customerId) {
  const movements = [];
  getCreditMovements(customerId).forEach(m => movements.push({
    type: 'credit', date: m.date, amount: m.amount, kg: m.kg, ref: m.ref,
    status: 'pendiente', remaining: m.amount, method: null,
  }));
  getCustomerPayments(customerId).forEach(p => movements.push({
    type: 'payment', date: (p.timestamp || '').slice(0, 10), amount: Number(p.amount) || 0,
    method: p.method, ref: p.id, status: 'abono', remaining: 0, kg: 0,
  }));

  movements.sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? -1 : 1;
    if (a.type === 'credit' && b.type !== 'credit') return -1;
    if (b.type === 'credit' && a.type !== 'credit') return 1;
    return 0;
  });

  const open = [];
  movements.forEach(m => {
    if (m.type === 'credit') { open.push(m); return; }
    let rem = m.amount;
    while (rem > 0.001 && open.length > 0) {
      const head = open[0];
      const take = Math.min(head.remaining, rem);
      head.remaining -= take;
      rem -= take;
      if (head.remaining <= 0.001) open.shift();
    }
  });
  movements.forEach(m => {
    if (m.type === 'credit' && m.remaining <= 0.001) m.status = 'saldado';
  });

  return movements.slice().reverse();
}

// True when the customer has a payment recurrence configured
// (e.g. "pays every Monday"). Such customers collect old debt on
// their scheduled day, not at the delivery stop.
function hasPaymentRecurrence(c) {
  return !!(c && c.recurrence && c.recurrence.preset && c.recurrence.preset !== 'none');
}

// ─── CANONICAL CREDIT LEDGER REPLAY (Cobranza) ─────────
// Single FIFO implementation for all Cobranza analytics. Undated opening
// balances predate app sales; same-day credits precede same-day payments.
function _creditEventSort(a, b) {
  const aUndated = !!a.isOpeningBalance && !a.dateKnown;
  const bUndated = !!b.isOpeningBalance && !b.dateKnown;
  if (aUndated && !bUndated) return -1;
  if (bUndated && !aUndated) return 1;
  const ad = a.date || '', bd = b.date || '';
  if (ad !== bd) return ad < bd ? -1 : 1;
  if (a.type === 'credit' && b.type === 'payment') return -1;
  if (a.type === 'payment' && b.type === 'credit') return 1;
  return 0;
}

function _daysBetween(a, b) {
  if (!a || !b) return null;
  return Math.max(0, Math.round((new Date(b + 'T12:00:00') - new Date(a + 'T12:00:00')) / 86400000));
}

// Pure FIFO replay over pre-built {credits, payments} arrays (no DB reads,
// no mutation of inputs) so ledger semantics are unit-testable. A payment
// only ever touches credits already outstanding at its date — future credits
// are unreachable by construction.
function _replayLedgerEvents(credits, payments) {
  const cs = (credits || []).map(c => ({
    ref: c.ref, date: c.date || null,
    // Explicit dateKnown wins (guarded by date presence); otherwise a dated
    // credit is known and a dateless one is not.
    dateKnown: c.dateKnown !== undefined ? (!!c.dateKnown && !!c.date) : !!c.date,
    source: c.source || (c.isOpeningBalance ? 'opening' : 'sale'),
    isOpeningBalance: !!c.isOpeningBalance,
    kg: Number(c.kg) || 0,
    stopId: c.stopId || null, orderId: c.orderId || null, routeName: c.routeName || null,
    originalAmount: Number(c.amount) || 0, remaining: Number(c.amount) || 0,
    settled: false, settledDate: null, daysToSettle: null, allocations: [],
  })).filter(c => c.originalAmount > 0.001);
  const ps = (payments || [])
    .map(p => ({ id: p.id || p.ref || null, date: p.date || ((p.timestamp || '').slice(0, 10)) || null, amount: Number(p.amount) || 0 }))
    .filter(p => p.date && p.amount > 0.001);
  const events = [...cs.map(c => ({ kind: 'credit', c })), ...ps.map(p => ({ kind: 'payment', p }))];
  events.sort((x, y) => _creditEventSort(
    x.kind === 'credit' ? { ...x.c, type: 'credit' } : { ...x.p, type: 'payment', isOpeningBalance: false, dateKnown: !!x.p.date },
    y.kind === 'credit' ? { ...y.c, type: 'credit' } : { ...y.p, type: 'payment', isOpeningBalance: false, dateKnown: !!y.p.date }
  ));
  const queue = [];
  const unappliedPayments = [];
  events.forEach(ev => {
    if (ev.kind === 'credit') { queue.push(ev.c); return; }
    let remainingPayment = ev.p.amount;
    while (remainingPayment > 0.001 && queue.length > 0) {
      const credit = queue[0];
      const allocated = Math.min(credit.remaining, remainingPayment);
      credit.remaining -= allocated;
      remainingPayment -= allocated;
      credit.allocations.push({
        paymentId: ev.p.id, paymentDate: ev.p.date, amount: allocated,
        daysFromCredit: credit.dateKnown ? _daysBetween(credit.date, ev.p.date) : null,
      });
      if (credit.remaining <= 0.001) {
        credit.remaining = 0;
        credit.settled = true;
        credit.settledDate = ev.p.date;
        if (credit.dateKnown) credit.daysToSettle = _daysBetween(credit.date, ev.p.date);
        queue.shift();
      }
    }
    if (remainingPayment > 0.001) {
      unappliedPayments.push({ paymentId: ev.p.id, date: ev.p.date, amount: remainingPayment });
    }
  });
  const openCredits = cs.filter(c => !c.settled);
  const settledCredits = cs.filter(c => c.settled);
  return {
    credits: cs, payments: ps, openCredits, settledCredits, unappliedPayments,
    totalOriginalCredit: cs.reduce((s, c) => s + c.originalAmount, 0),
    totalOpen: openCredits.reduce((s, c) => s + c.remaining, 0),
  };
}

const _cobWarned = new Set();
function _cobWarnOnce(key, ...args) {
  if (_cobWarned.has(key)) return;
  _cobWarned.add(key);
  console.warn(...args);
}

// DB-backed wrapper: loads movements, replays, and surfaces unapplied
// payments as data-quality warnings (deduped; console only, never UI).
function _replayCustomerCreditLedger(customerId) {
  const replay = _replayLedgerEvents(getCreditMovements(customerId), getCustomerPayments(customerId));
  replay.unappliedPayments.forEach(u => {
    _cobWarnOnce('unapplied@' + customerId + '@' + (u.paymentId || u.date + '|' + u.amount),
      '[COBRANZA UNAPPLIED]', { customerId, paymentId: u.paymentId, date: u.date, amount: u.amount });
  });
  return replay;
}

// Open (unpaid) credits via the canonical replay, oldest first. Shape stays
// compatible with statement-screen callers (ref/kg/date/remaining/ids).
function getOpenCredits(customerId) {
  return _replayCustomerCreditLedger(customerId).openCredits.map(c => ({
    ref: c.ref, kg: c.kg, date: c.date, dateKnown: c.dateKnown,
    remaining: c.remaining, stopId: c.stopId, orderId: c.orderId,
    routeName: c.routeName, isOpeningBalance: c.isOpeningBalance,
  }));
}

function getOldestPendingCredit(customerId) {
  const open = getOpenCredits(customerId);
  if (open.length === 0) return null;
  return open[0];
}

function getRecentPendingCredit(customerId) {
  const open = getOpenCredits(customerId);
  if (open.length === 0) return null;
  return open[open.length - 1];
}

// ─── CUSTOMER ACCOUNT STATEMENT (estado de cuenta) ─────
function startOfWeek(dateStr) {
  const d = new Date(dateStr + 'T12:00:00');
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(d.setDate(diff)).toISOString().slice(0, 10);
}

function startOfMonth(dateStr) {
  return dateStr.slice(0, 7) + '-01';
}

// Build chronological ledger for a customer with running balance.
// filter: 'all' | 'sinceLastPayment' | 'week' | 'month' | '90d'
// Returns rows newest-first, each with { type, date, time, amount, kg, ref,
// operator, desc, monto (+ for credits, - for payments), saldo_actual }.
// saldo_actual starts at $0 within the selected period, so the final row
// equals the debt attributable to that period.
function getCustomerStatement(customerId, filter) {
  const movements = [];
  getCreditMovements(customerId).forEach(m => movements.push({
    type: 'credit',
    date: m.date,
    time: '',
    amount: Number(m.amount) || 0,
    kg: Number(m.kg) || 0,
    ref: m.ref,
    operator: m.operator || '—',
    desc: m.note || ((Number(m.kg) || 0) > 0 ? (Number(m.kg) || 0) + ' kg Tortilla' : 'Nota a Crédito'),
  }));
  getCustomerPayments(customerId).forEach(p => movements.push({
    type: 'payment',
    date: (p.timestamp || '').slice(0, 10),
    time: (p.timestamp || '').slice(11, 16),
    amount: Number(p.amount) || 0,
    kg: 0,
    ref: p.id,
    operator: p.operator || '—',
    desc: 'Pago Efectivo',
  }));
  // Saldo a favor (change owed) is a SEPARATE account running the other way.
  // It is deliberately not merged into the receivable: the receivable's sign
  // means "customer owes us" and clamping it at 0 is what makes that account
  // correct. This one means "we owe the customer", so the two need independent
  // running balances or a customer carrying both would show nonsense.
  getCustomerOwedRows(customerId).forEach(r => {
    const isOwed = r.kind !== 'applied';
    movements.push({
      type: isOwed ? 'owed' : 'owedApplied',
      date: (r.timestamp || '').slice(0, 10),
      time: (r.timestamp || '').slice(11, 16),
      amount: Number(r.amount) || 0,
      kg: Number(r.kg) || 0,
      ref: r.orderId || r.stopId || 'CAMBIO',
      operator: r.operator || '—',
      desc: isOwed
        ? 'Cambio pendiente (te lo debo)'
        : 'Saldo a favor aplicado a pedido',
    });
  });

  // Chronological, and within a day credits precede payments (the money that
  // arrived settles the oldest charge). Owed rows sort after both: a driver
  // hands the customer the note at the END of the stop, after the sale is
  // recorded and the cash counted.
  const typeRank = t => (t === 'credit' ? 0 : (t === 'payment' ? 1 : 2));
  movements.sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? -1 : 1;
    const ra = typeRank(a.type), rb = typeRank(b.type);
    if (ra !== rb) return ra - rb;
    return 0;
  });

  let from = null;
  if (filter === 'week') from = startOfWeek(today());
  else if (filter === 'month') from = startOfMonth(today());
  else if (filter === '90d') from = shiftDays(today(), -89);
  else if (filter === 'sinceLastPayment') {
    const lastPay = getCustomerPayments(customerId).slice(-1)[0];
    if (lastPay) from = (lastPay.timestamp || '').slice(0, 10);
  }

  const rows = [];
  let saldo = 0;       // receivable: what the customer owes us (unchanged)
  let saldoFavor = 0;  // liability: what we owe the customer
  movements.forEach(m => {
    if (from && m.date < from) return;
    if (m.type === 'credit') saldo += m.amount;
    else if (m.type === 'payment') saldo = Math.max(0, saldo - m.amount);
    else if (m.type === 'owed') saldoFavor += m.amount;
    else if (m.type === 'owedApplied') saldoFavor = Math.max(0, saldoFavor - m.amount);
    const isOwe = m.type === 'owed' || m.type === 'owedApplied';
    rows.push({
      ...m,
      monto: isOwe ? m.amount : (m.type === 'credit' ? m.amount : -m.amount),
      // Owed rows are not receivable movements, so they leave the receivable's
      // running balance untouched; their liability position is shown in the
      // separate column instead.
      saldo_actual: saldo,
      saldo_favor: isOwe ? saldoFavor : null,
    });
  });

  const periodTotal = rows.length ? rows[rows.length - 1].saldo_actual : 0;
  return { rows: rows.slice().reverse(), periodTotal, totalFavor: saldoFavor };
}

// Next date on/after fromDate matching the recurrence pattern.
function nextRecurrenceDate(r, fromDate) {
  if (!r || r.preset === 'none') return null;
  const anchor = r.anchor || fromDate;
  const start = new Date(fromDate + 'T12:00:00');
  for (let i = 0; i < 366; i++) {
    const d = new Date(start.getTime() + i * 86400000);
    const ds = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    if (isRecurrenceDate(anchor, r, ds)) return ds;
  }
  return null;
}

function addPayment(customerId, amount, method) {
  const amt = Number(amount) || 0;
  if (amt <= 0) return null;
  const p = {
    id: genId(),
    customerId,
    amount: amt,
    method: 'cash',
    operator: (AppState.driver && AppState.driver.name) || '—',
    timestamp: new Date().toISOString(),
  };
  PAYMENTS.push(p);
  savePayments();
  const c = getCustomerSafe(customerId, { label: 'Cliente' });
  if (c) {
    c.balance = Math.max(0, (c.balance || 0) - amt);
    touchCustomer(c);
    saveClients();
  }
  return p;
}

// Applies a cash abono toward an outstanding old debt WITHOUT recording a
// new collection entry — the caller (confirmStop) already recorded the full
// cash via addCollection, so this only decrements the customer balance and
// appends the ABONO row to their account statement.
function recordDebtPayment(customerId, amount) {
  const amt = Number(amount) || 0;
  if (amt <= 0) return null;
  const p = {
    id: genId(),
    customerId,
    amount: amt,
    method: 'cash',
    operator: (AppState.driver && AppState.driver.name) || '—',
    timestamp: new Date().toISOString(),
  };
  PAYMENTS.push(p);
  savePayments();
  const c = getCustomerSafe(customerId, { label: 'Cliente' });
  if (c) {
    c.balance = Math.max(0, (c.balance || 0) - amt);
    touchCustomer(c);
    saveClients();
  }
  return p;
}

function loadAdvanceOrders() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_ORDERS);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return [];
}

function saveAdvanceOrders() {
  try { localStorage.setItem(STORAGE_KEY_ORDERS, JSON.stringify(advanceOrders)); } catch (e) {}
}

function stopsProgressKey(routeName) {
  const d = AppState.routeDate || today();
  return 'stops_' + routeName.replace(/\s/g, '') + '_' + d;
}

function loadStopProgress(routeName) {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_STOPS + '_' + stopsProgressKey(routeName));
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return null;
}

function saveStopProgress(routeName, stops) {
  try {
    const data = stops.map(s => ({
      stopId: s.stopId,
      status: s.status,
      devolucionKg: s.devolucionKg,
      recompraKg: s.recompraKg,
      recompraCollected: s.recompraCollected || 0,
      stopPhase: s.stopPhase,
      extraKg: s.extraKg,
      creditAmount: s.creditAmount,
      creditPaidType: s.creditPaidType,
      creditPaidAmount: s.creditPaidAmount,
      paymentType: s.paymentType,
      cashTendered: s.cashTendered,
      oldDebtPaid: s.oldDebtPaid || 0,
      deliveryDraft: s.deliveryDraft || null,
    }));
    localStorage.setItem(STORAGE_KEY_STOPS + '_' + stopsProgressKey(routeName), JSON.stringify(data));
  } catch (e) {}
}

let _tripCounter = 0;
function generateTripId(routeName) {
  // Collision-proof: route prefix + driver initials + short timestamp.
  const prefix = (routeName || 'MIX').replace(/[^A-Za-z0-9]/g, '').slice(0, 3).toUpperCase() || 'MIX';
  const initials = (AppState.driver && AppState.driver.name
    ? AppState.driver.name.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase()
    : 'DR');
  const ts = Date.now().toString(36).slice(-4).toUpperCase();
  return prefix + '-' + initials + '-' + ts;
}

function loadTrips() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_TRIPS);
    if (!saved) return [];
    const trips = JSON.parse(saved);
    let changed = false;
    trips.forEach(t => {
      const unique = [...new Set(t.orderIds || [])];
      if (unique.length !== (t.orderIds || []).length) {
        t.orderIds = unique;
        changed = true;
      }
    });
    if (changed) localStorage.setItem(STORAGE_KEY_TRIPS, JSON.stringify(trips));
    return trips;
  } catch (e) {}
  return [];
}

function saveTrips() {
  try {
    AppState.trips.forEach(t => { t.orderIds = [...new Set(t.orderIds || [])]; });
    localStorage.setItem(STORAGE_KEY_TRIPS, JSON.stringify(AppState.trips));
  } catch (e) {}
}

// Creates the trip LOCALLY first (instant UI) and verifies the claims
// against Firestore in the background. The blocking Firestore
// transaction (N sequential reads) used to stall the modal 4-5s; now
// only a genuine conflict (another driver claimed first) walks it back.
async function createTrip(routeName, kilosLoaded, orderIds) {
  const routes = [...new Set(orderIds.map(oid => {
    const o = advanceOrders.find(x => x.id === oid);
    return o ? o.route : null;
  }).filter(Boolean))];
  const primaryRoute = routeName || routes[0] || 'MIX';
  const tripId = generateTripId(primaryRoute);

  const trip = {
    id: tripId,
    routeName: primaryRoute,
    routes,
    date: AppState.routeDate || today(),
    kilosLoaded: Number(kilosLoaded),
    orderIds: [...orderIds],
    status: 'active',
    expanded: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    createdBy: AppState.driver.id,
    createdByName: AppState.driver.name,
    assignedTo: AppState.driver.id,
    assignedToName: AppState.driver.name,
  };
  AppState.trips.push(trip);
  orderIds.forEach(oid => {
    const o = advanceOrders.find(x => x.id === oid);
    if (o) o.tripId = trip.id;
  });
  saveTrips();
  saveAdvanceOrders();

  // Background claim verification — never blocks the UI.
  (async () => {
    try {
      if (window.SyncDebug && SyncDebug.claimOrders) {
        await SyncDebug.claimOrders(orderIds, tripId, AppState.driver.id, AppState.driver.name);
      }
    } catch (e) {
      if (e && e.message === 'orders_taken') {
        const taken = e.taken || [];
        const takenNames = taken.map(oid => {
          const o = advanceOrders.find(x => x.id === oid);
          return o ? o.customerName : oid;
        });
        // Walk back the lost orders locally; the rest of the trip stands.
        // Re-resolve the trip: reloadData() swaps AppState.trips for a
        // fresh array, so the captured reference may be stale.
        const t = AppState.trips.find(x => x.id === tripId);
        if (t) {
          t.orderIds = (t.orderIds || []).filter(oid => !taken.includes(oid));
          if (t.orderIds.length === 0) {
            AppState.trips = AppState.trips.filter(x => x.id !== tripId);
            showToast('❌ Todas las órdenes ya fueron tomadas');
          } else {
            t.kilosLoaded = t.orderIds.reduce((s, oid) => {
              const o = advanceOrders.find(x => x.id === oid);
              return s + (o ? o.qty : 0);
            }, 0);
            showToast('⚠️ Órdenes ya tomadas: ' + takenNames.join(', '));
          }
          t.updatedAt = new Date().toISOString();
        }
        taken.forEach(oid => {
          const o = advanceOrders.find(x => x.id === oid);
          if (o && o.tripId === tripId) delete o.tripId;
        });
        saveTrips();
        saveAdvanceOrders();
        try { if (AppState.route) rebuildRouteStops(); } catch (err) {}
        render();
      } else {
        // Transient Firestore failures (permission, network) must NOT
        // block trip creation — deferred sync reconciles later.
        console.warn('claimOrders failed (deferred sync):', e && e.message);
      }
    }
  })();

  return trip;
}

function completeTrip(tripId) {
  const trip = AppState.trips.find(t => t.id === tripId);
  if (trip) {
    const now = new Date().toISOString();
    trip.status = 'completed';
    trip.completedBy = AppState.driver.id;
    trip.completedByName = AppState.driver.name;
    trip.completedAt = now;
    trip.updatedAt = now;
  }
  saveTrips();
}

function getTripsForRoute(routeName) {
  const d = AppState.routeDate || today();
  return AppState.trips.filter(t =>
    t.date === d &&
    (t.routes ? t.routes.includes(routeName) : t.routeName === routeName)
  );
}

function getAvailableOrdersForRoute(routeName) {
  const d = AppState.routeDate || today();
  return advanceOrders.filter(o =>
    o.route === routeName &&
    o.status === 'pending' &&
    !o.tripId &&
    o.date === d &&
    !(getCustomer(o.customerId) || {}).deleted
  );
}

function getOrdersForTrip(tripId) {
  const trip = AppState.trips.find(t => t.id === tripId);
  if (!trip) return [];
  return [...new Set(trip.orderIds || [])].map(oid => advanceOrders.find(o => o.id === oid)).filter(Boolean);
}

function getTripProgress(tripId) {
  const orders = getOrdersForTrip(tripId);
  const total = orders.length;
  const done = orders.filter(o => o.status === 'completed' || o.status === 'skipped').length;
  return { done, total };
}

function isTripCompleted(trip) {
  if (!trip) return false;
  if (trip.status === 'completed') return true;
  const orders = getOrdersForTrip(trip.id);
  return orders.length > 0 && orders.every(o => o.status === 'completed' || o.status === 'skipped');
}

// ─── TRIP OWNERSHIP & HANDOFFS ─────────────────────────
// Owner of a trip = assignedTo (after a takeover) || createdBy.
// Legacy trips without either field are visible to every driver.
function tripOwnerId(t) { return (t && (t.assignedTo || t.createdBy)) || null; }
function tripOwnerName(t) {
  if (!t) return '—';
  return t.assignedToName || t.createdByName || '—';
}
function isTripMine(t) {
  if (!t) return false;
  const owner = tripOwnerId(t);
  if (!owner) return true; // legacy trips have no owner → everyone
  return owner === (AppState.driver && AppState.driver.id);
}

// Handoff log on an order: one entry per driver who left a partial.
// kg/dev/rec are CUMULATIVE totals as of that partial; cash was booked
// by that driver at partial-commit time (true to who holds the cash).
function orderHandoffs(o) {
  return (o && Array.isArray(o.deliveryHandoffs)) ? o.deliveryHandoffs : [];
}
function sumHandoffCash(o) {
  return orderHandoffs(o).reduce((s, h) => s + (Number(h.cash) || 0), 0);
}
function otherHandoffs(o) {
  const me = AppState.driver && AppState.driver.id;
  return orderHandoffs(o).filter(h => h.by !== me);
}

// Jose takes one pending order from another driver's active trip.
// Destination: my active trip today sharing the order's route (kilos
// bumped by the undelivered remainder) — else a fresh trip is created.
async function takeOrder(orderId) {
  const me = AppState.driver;
  const o = getAdvanceOrder(orderId);
  if (!o) { showToast('❌ Orden no encontrada'); return false; }
  if (o.status !== 'pending') { showToast('❌ La orden ya no está pendiente'); return false; }
  const oldTrip = AppState.trips.find(t => (t.orderIds || []).includes(orderId));
  if (oldTrip && isTripMine(oldTrip)) { showToast('⚠️ La orden ya es tuya'); return false; }
  const taking = AppState._takingOrders || (AppState._takingOrders = new Set());
  if (taking.has(orderId)) return false;
  taking.add(orderId);

  const d = AppState.routeDate || today();
  const route = o.route;
  let dest = AppState.trips.find(t =>
    t.date === d && t.status === 'active' && isTripMine(t) &&
    (t.routes || [t.routeName]).includes(route)
  );
  const destIsNew = !dest;
  const alreadyInDest = !!(dest && (dest.orderIds || []).includes(orderId));
  const deliveredSoFar = orderHandoffs(o).length
    ? Math.max(...orderHandoffs(o).map(h => Number(h.kg) || 0))
    : 0;
  const remaining = Math.max(0, (o.qty || 0) - deliveredSoFar);
  if (destIsNew) {
    dest = {
      id: generateTripId(route),
      routeName: route,
      routes: [route],
      date: d,
      kilosLoaded: remaining,
      orderIds: [],
      status: 'active',
      expanded: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: me.id,
      createdByName: me.name,
      assignedTo: me.id,
      assignedToName: me.name,
    };
    AppState.trips.push(dest);
  } else if (!alreadyInDest) {
    dest.kilosLoaded = (dest.kilosLoaded || 0) + remaining;
  }
  dest.orderIds = [...new Set([...(dest.orderIds || []), orderId])];

  const previousOrder = {
    tripId: o.tripId,
    claimedBy: o.claimedBy,
    claimedByName: o.claimedByName,
    claimedAt: o.claimedAt,
    updatedAt: o.updatedAt,
  };
  const previousOldOrderIds = oldTrip ? [...(oldTrip.orderIds || [])] : null;
  const previousOldKilos = oldTrip ? oldTrip.kilosLoaded : null;
  if (oldTrip) oldTrip.orderIds = (oldTrip.orderIds || []).filter(x => x !== orderId);
  o.tripId = dest.id;
  o.claimedBy = me.id;
  o.claimedByName = me.name;
  o.claimedAt = new Date().toISOString();
  o.updatedAt = new Date().toISOString();
  saveTrips();
  saveAdvanceOrders();
  taking.delete(orderId);
  showToast('🙋 Entrega tomada — ahora es tuya');

  // Confirm ownership in the background. The UI is local-first; only a
  // real conflict rolls back the optimistic transfer.
  (async () => {
    try {
      if (!window.SyncDebug || !SyncDebug.transferOrders) return;
      const res = await SyncDebug.transferOrders([orderId], oldTrip ? oldTrip.id : null, dest.id, me.id, me.name);
      if (!res || !Array.isArray(res.conflicts) || res.conflicts.length === 0) return;
      const currentDest = AppState.trips.find(t => t.id === dest.id);
      if (currentDest) {
        currentDest.orderIds = (currentDest.orderIds || []).filter(x => x !== orderId);
        if (destIsNew) AppState.trips = AppState.trips.filter(t => t.id !== dest.id);
        else if (!alreadyInDest) currentDest.kilosLoaded = Math.max(0, (currentDest.kilosLoaded || 0) - remaining);
      }
      if (oldTrip) {
        const currentOld = AppState.trips.find(t => t.id === oldTrip.id);
        if (currentOld) {
          currentOld.orderIds = previousOldOrderIds;
          currentOld.kilosLoaded = previousOldKilos;
        }
      }
      const currentOrder = getAdvanceOrder(orderId);
      if (currentOrder) Object.assign(currentOrder, previousOrder);
      saveTrips();
      saveAdvanceOrders();
      const names = res.conflicts.map(oid => {
        const oo = getAdvanceOrder(oid);
        return oo ? oo.customerName : oid;
      });
      showToast('❌ Ya fue tomada: ' + names.join(', '));
      render();
    } catch (e) {
      console.warn('transferOrders failed (deferred sync):', e && e.message);
    }
  })();
  return true;
}

// Take over a whole active trip (ownership only; order claims unchanged).
function takeTrip(tripId) {
  const t = AppState.trips.find(x => x.id === tripId);
  if (!t) { showToast('❌ Ruta no encontrada'); return false; }
  const me = AppState.driver;
  if (isTripMine(t)) { showToast('⚠️ La ruta ya es tuya'); return false; }
  const previousOwner = tripOwnerId(t);
  const now = new Date().toISOString();
  t.assignedTo = me.id;
  t.assignedToName = me.name;
  t.takenFrom = previousOwner;
  t.takenAt = now;
  t.takenBy = me.id;
  t.takenByName = me.name;
  t.updatedAt = now;
  saveTrips();
  showToast('🙋 Ruta ' + t.id + ' asignada a ti');
  return true;
}

// ─── PRODUCTS ──────────────────────────────────────────
const PRODUCTS_KEY = 'elcomal_productCatalog';
const DEFAULT_PRODUCTOS = [
  { id: 'P1', sku: 'P1', uom: 'Kg', name: 'Tortilla de Maíz', price: 22, unit: 'kg', icon: '🫓' },
  { id: 'P2', sku: 'P2', uom: 'Kg', name: 'Tortilla de Harina', price: 28, unit: 'kg', icon: '🫔' },
  { id: 'P3', sku: 'P3', uom: 'Kg', name: 'Tostadas', price: 18, unit: 'kg', icon: '🟤' },
  { id: 'P4', sku: 'P4', uom: 'Kg', name: 'Totopos', price: 20, unit: 'kg', icon: '🔺' },
  { id: 'P5', sku: 'P5', uom: 'Kg', name: 'Kilo Frio', price: 8, unit: 'kg', icon: '❄️' },
];

function loadProducts() {
  const saved = DB.Storage.get(PRODUCTS_KEY, null);
  const list = Array.isArray(saved) && saved.length > 0 ? saved : JSON.parse(JSON.stringify(DEFAULT_PRODUCTOS));
  // Additive ERP-fields enrichment: older catalogs lack sku/uom. Never
  // removes or rewrites anything — only fills in missing fields.
  let enriched = false;
  list.forEach(p => {
    if (p.sku === undefined) { p.sku = p.id; enriched = true; }
    if (p.uom === undefined) { p.uom = 'Kg'; enriched = true; }
  });
  if (enriched) DB.Storage.set(PRODUCTS_KEY, list);
  return list;
}

function saveProducts() { DB.Storage.set(PRODUCTS_KEY, PRODUCTOS); }

let PRODUCTOS = loadProducts();

const RECOMPRA_PRICE = 8;

// ─── BUILD ROUTE ────────────────────────────────────────
function buildMockRoute(routeName) {
  const orders = getAdvanceOrdersForRoute(routeName);

  const stops = orders.map((o, i) => {
    const c = getCustomer(o.customerId);
    return {
      stopId: 'S' + (o.customerId.slice(1)),
      customerId: o.customerId,
      customerName: c ? c.name : o.customerName,
      preOrderKg: o.qty,
      staleKg: 0,
      devolucionKg: 0,
      recompraKg: 0,
      extraKg: 0,
      creditAmount: 0,
      creditPaidType: null,
    creditPaidAmount: 0,
    deliveryDraft: null,
      paymentType: '',
      cashTendered: 0,
      stopPhase: 'pendiente',
      deliveryDraft: null,
      status: i === 0 ? 'active' : 'pending',
      sequence: i + 1,
    };
  });

  const routeDate = AppState.routeDate || today();

  const saved = loadStopProgress(routeName);
  if (saved) {
    saved.forEach(sp => {
      const st = stops.find(s => s.stopId === sp.stopId);
      if (st) Object.assign(st, sp);
    });
  }

  return {
    id: 'R-' + routeName.replace(/\s/g, '') + '-' + routeDate.replace(/-/g, ''),
    name: routeName,
    date: routeDate,
    dateDisplay: capitalize(formatDate(routeDate)),
    startingInventory: stops.reduce((s, st) => s + st.preOrderKg, 0),
    stops,
  };
}

// ─── ROUTES ─────────────────────────────────────────────
const ROUTES = [
  'Pueblo Nuevo', 'La Perla', 'Dolores',
  'El Paso', '25 de Diciembre', 'Melgar', 'La Flor', 'La Una',
];

// ─── ROUTE RESOLUTION ────────────────────────────────────
// A customer's route MIRRORS the city named in their address. Matching is
// deliberately tolerant because the address is free text: "el paso",
// "El Paso, Calle 5", "EL PASO CENTRO" and "Pueblo Nuevo centro" must all
// resolve to the canonical route name. An address that does NOT name a
// city ("Calle 5", "Reforma 12") resolves to null so callers leave the
// existing route alone instead of guessing.
const _ROUTE_STOPWORDS = new Set([
  'de', 'del', 'la', 'el', 'los', 'las', 'y', 'en', 'col', 'colonia', 'cp',
]);

// Lowercase, strip accents, collapse punctuation to single spaces so
// "MÉLGAR" / "Melgar" / "melgar." all normalize identically.
function normalizeRouteText(s) {
  return String(s == null ? '' : s)
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

// Meaningful words of a route name ("25 de Diciembre" -> ["25", "diciembre"]).
function routeNameTokens(route) {
  return normalizeRouteText(route).split(' ').filter(t => t && !_ROUTE_STOPWORDS.has(t));
}

// Canonical route named in an address, or null when it names none.
// Longest match wins so "25 de Diciembre" beats a shorter partial hit.
function routeFromAddress(direccion) {
  const addr = normalizeRouteText(direccion);
  if (!addr) return null;
  const addrTokens = new Set(addr.split(' ').filter(Boolean));
  let best = null;
  let bestLen = -1;
  ROUTES.forEach(r => {
    const rn = normalizeRouteText(r);
    if (!rn) return;
    const tokens = routeNameTokens(r);
    const hit = addr === rn
      || addr.includes(rn)
      || (tokens.length > 0 && tokens.every(t => addrTokens.has(t)));
    if (hit && rn.length > bestLen) { best = r; bestLen = rn.length; }
  });
  return best;
}

// Sales-quadrant classification for a route name (used by the zone report).
// Keyword matching tolerates prefixes/gaps/casing (e.g. "Ruta Pueblo Nuevo",
// "EL PASO", "25 de diciembre"); anything unmatched drops to 'Otra'.
function _routeQuadrant(routeName) {
  const n = String(routeName || '').toLowerCase();
  if (!n) return 'Otra';
  if (/(base|el paso|centro)/.test(n)) return 'Base';
  if (/(norte|pueblo|perla|dolores)/.test(n)) return 'Norte';
  if (/(oeste|melgar|25|diciembre|flor)/.test(n)) return 'Oeste';
  if (/(este|la una|una)/.test(n)) return 'Este';
  return 'Otra';
}

// ─── STATE MANAGEMENT FUNCTIONS ────────────────────────
function rebuildRouteStops(routeName) {
  const r = AppState.route;
  if (!r) return;
  // Only trips I own feed my working stop list. Other drivers' trips
  // stay visible on the home screen (read-only + take buttons).
  const trips = getTripsForRoute(routeName || AppState.routeName).filter(isTripMine);
  const stops = [];
  const seenOrders = new Set();
  trips.forEach(trip => {
    const orders = getOrdersForTrip(trip.id);
    orders.forEach(o => {
      if (seenOrders.has(o.id)) return;
      seenOrders.add(o.id);
      const completed = o.status === 'completed' || o.status === 'skipped';
      stops.push({
        stopId: 'S-' + o.id,
        orderId: o.id,
        customerId: o.customerId,
        customerName: o.customerName,
        preOrderKg: o.qty,
        staleKg: 0,
        devolucionKg: o.devolucionKg || 0,
        recompraKg: o.recompraKg || 0,
        extraKg: 0,
        deliveredKg: completed ? (o.deliveredKg || o.qty) : 0,
        creditAmount: o.creditAmount || 0,
        creditPaidType: o.creditPaidType || null,
        creditPaidAmount: o.creditPaidAmount || 0,
        oldDebtPaid: o.oldDebtPaid || 0,
        skipReason: o.skipReason || null,
        skipNote: o.skipNote || null,
        completedAt: o.completedAt || null,
        paymentType: '',
        cashTendered: 0,
        stopPhase: 'pendiente',
        status: completed ? o.status : 'active',
        sequence: 1,
        deliveryDraft: completed ? null : (o.deliveryDraft || null),
      });
    });
  });
  r.stops = stops;
  r.startingInventory = trips.reduce((s, t) => s + (t.kilosLoaded || 0), 0);
}

function initRoute() {
  AppState.routeName = ROUTES[0];
  AppState.routeFilter = null;
  AppState.routeDate = today();
const session = DB.Session.load(AppState.routeName, AppState.routeDate);
 AppState.extraSales = DB.Street.byDate(AppState.routeDate || today());
 AppState.collections = session.collections;
  AppState.creditModal = null;
  AppState.collapsedCompleted = true;
  AppState.showRouteFilter = false;
  AppState.routeCreationDestFilter = [];
  AppState.routeCreationDestOpen = false;
  AppState.futureOrders = DB.FutureOrders.load();
  _tripCounter = 0;
  AppState.trips = loadTrips();
  pruneGhostTrips();
  AppState.route = {
    name: AppState.routeName,
    date: AppState.routeDate,
    dateDisplay: capitalize(formatDate(AppState.routeDate)),
    startingInventory: 0,
    stops: [],
  };
  rebuildRouteStops();
}

function getTripStats(routeName) {
  const trips = getTripsForRoute(routeName);
  let totalOrders = 0, doneOrders = 0, totalKilos = 0;
  trips.forEach(t => {
    totalKilos += t.kilosLoaded || 0;
    const orders = getOrdersForTrip(t.id);
    totalOrders += orders.length;
    doneOrders += orders.filter(o => o.status === 'completed' || o.status === 'skipped').length;
  });
  return { totalOrders, doneOrders, totalKilos, pending: totalOrders - doneOrders };
}

function getCustomer(id) { return CLIENTES.find(c => c.id === id); }

// Like getCustomer, but surfaces a toast when the customer is
// missing — e.g. after a whole-array clobber deleted Irma while
// her order survived. Silent no-ops here meant the gap was
// invisible (no credit, no payment, no edits possible).
function getCustomerSafe(id, ctx) {
  const c = getCustomer(id);
  if (!c) {
    try {
      const tag = (ctx && ctx.label) ? ctx.label : 'cliente';
      showToast('⚠️ ' + tag + ' no encontrado: ' + (id || '?'));
    } catch (e) {}
  }
  return c;
}

// Recover customers referenced by orders that are missing from CLIENTES
// (e.g. after a whole-array clobber deleted Irma while her order survived).
// Only creates rows for ids that do not exist at all — never resurrects
// intentionally soft-deleted customers.
function recoverCustomersFromOrders() {
  const existing = new Set(CLIENTES.map(c => c.id));
  let created = 0;
  advanceOrders.forEach(o => {
    const id = o.customerId;
    if (!id || existing.has(id)) return;
    CLIENTES.push({
      id,
      name: o.customerName || 'Desconocido',
      contact: '',
      phone: '',
      direccion: '',
      route: o.route || '',
      paymentTerm: 'COD',
      creditLimit: 0,
      defaultPrice: 0,
      recurrence: null,
      balance: 0,
      deleted: false,
      updatedAt: new Date().toISOString(),
      _recoveredFromOrder: true,
    });
    existing.add(id);
    created++;
  });
  if (created > 0) {
    saveClients();
    try { showToast('Recuperados ' + created + ' cliente(s) de pedidos activos'); } catch (e) {}
  }
}

function getCustomerBalance(customerId) {
  const c = getCustomer(customerId);
  return Math.max(0, (c && c.balance) || 0);
}

function getProduct(id) { return PRODUCTOS.find(p => p.id === id); }

function deleteProduct(id) {
  const idx = PRODUCTOS.findIndex(p => p.id === id);
  if (idx < 0) return false;
  PRODUCTOS.splice(idx, 1);
  saveProducts();
  return true;
}

// ─── PRODUCT PRICES (from settings, persisted) ──────────

function loadProductPrices() {
  const saved = DB.Prices.load();
  if (saved) return saved;
  const defaults = {};
  PRODUCTOS.forEach(p => { defaults[p.id] = p.price; });
  DB.Prices.save(defaults);
  return defaults;
}

function getProductPrice(productId) {
  const prices = loadProductPrices();
  return prices[productId] || PRODUCTOS.find(p => p.id === productId)?.price || 22;
}

function setProductPrice(productId, price) {
  const prices = loadProductPrices();
  prices[productId] = price;
  DB.Prices.save(prices);
}

function getEffectivePrice(customerId, productId) {
  const cust = customerId ? getCustomer(customerId) : null;
  if (cust && cust.defaultPrice > 0) return cust.defaultPrice;
  return getProductPrice(productId || 'P1');
}

// Price resolution for a stop: the order's price prevails, then the
// customer's default price, then the product price. Keeps order-level
// edits authoritative so rutas and all calculations stay consistent.
function getStopPrice(stop) {
  if (!stop) return getProductPrice('P1');
  if (stop.orderId) {
    const o = getAdvanceOrder(stop.orderId);
    if (o && Number(o.price) > 0) return Number(o.price);
  }
  return getEffectivePrice(stop.customerId, stop.productId || 'P1');
}

function completeStop(stopId) {
  const stop = AppState.route.stops.find(s => s.stopId === stopId);
  if (stop) { stop.status = 'completed'; saveStopProgress(AppState.routeName, AppState.route.stops); }
}

function skipStop(stopId) {
  const stop = AppState.route.stops.find(s => s.stopId === stopId);
  if (stop) { stop.status = 'skipped'; saveStopProgress(AppState.routeName, AppState.route.stops); }
}

function allStopsDone() {
  return AppState.route.stops.every(s => s.status === 'completed' || s.status === 'skipped');
}

function getStopProgress() {
  const stops = AppState.route.stops;
  return { done: stops.filter(s => s.status === 'completed').length, total: stops.length };
}

// ─── STREET SALES ───────────────────────────────────────
// One sale = one record: one description, one timestamp, one driver,
// and one or more product lines (tortilla + frío at the same stop).
// `lines` holds the per-product detail; the flat productId/kg/amount
// fields stay as aggregates so every existing consumer (settlement
// math, reports, ERP outbox, driver cash, sync merge) keeps working
// on both legacy single-line records and new multi-line ones.
function streetSaleLines(sale) {
  if (!sale) return [];
  if (Array.isArray(sale.lines) && sale.lines.length) {
    return sale.lines
      .filter(l => l && l.productId)
      .map(l => ({
        productId: l.productId,
        kg: Number(l.kg) || 0,
        price: Number(l.price) || 0,
        amount: Number(l.amount) || 0,
      }));
  }
  // Legacy record: one product, no lines[].
  const kg = Number(sale.kg) || 0;
  const amount = Number(sale.amount) || 0;
  if (!sale.productId || kg <= 0) return [];
  return [{ productId: sale.productId, kg, price: kg > 0 ? round2(amount / kg) : 0, amount }];
}

function addExtraSale(lines, description) {
  const clean = (Array.isArray(lines) ? lines : [])
    .filter(l => l && l.productId && (Number(l.kg) || 0) > 0)
    .map(l => ({
      productId: l.productId,
      kg: Number(l.kg) || 0,
      price: Number(l.price) || 0,
      amount: round2((Number(l.kg) || 0) * (Number(l.price) || 0)),
    }));
  if (!clean.length) return null;
  const sale = {
    id: genId(),
    lines: clean,
    description: description || '',
    date: AppState.routeDate || today(),
    timestamp: new Date().toISOString(),
    driverId: AppState.driver && AppState.driver.id,
    driverName: AppState.driver && AppState.driver.name,
    productId: clean[0].productId,
    kg: round2(clean.reduce((s, l) => s + l.kg, 0)),
    amount: round2(clean.reduce((s, l) => s + l.amount, 0)),
  };
  DB.Street.append(sale);
  AppState.extraSales.push(sale);
  return sale;
}

function addCollection(customerId, cash, card) {
  const id = genId();
  AppState.collections.push({
    id, customerId,
    cash: Number(cash) || 0,
    card: Number(card) || 0,
    timestamp: new Date().toISOString(),
  });
  const rn = AppState.routeName, rd = AppState.routeDate || today();
  if (rn) DB.Session.save(rn, rd, { routeName: rn, date: rd, extraSales: AppState.extraSales, collections: AppState.collections });
  return id;
}

// Which route-day a payment taken OUTSIDE any active route belongs to.
// Same precedence as the rest of the app: the customer's address is the
// source of truth, then their stored route. Returns null when the customer
// is gone or names no known route, since the cash cannot be attributed.
function settlementRouteForCustomer(customerId) {
  const c = getCustomer(customerId);
  if (!c || c.deleted) return null;
  return routeFromAddress(c.direccion) || c.route || null;
}

// Books a collection to a specific route-day WITHOUT that route being the
// one the driver has loaded. Needed because DB.Session.save() REPLACES the
// whole session object, so the target route's own extraSales/collections must
// be read back and preserved. When the target IS the active route the
// in-memory mirror is refreshed so the live settlement screen updates.
function addCollectionToRouteDay(customerId, cash, card, routeName, date, meta) {
  const rn = routeName, rd = date || today();
  if (!rn) return null;
  const entry = Object.assign({
    id: genId(), customerId,
    cash: Number(cash) || 0,
    card: Number(card) || 0,
    timestamp: new Date().toISOString(),
  }, meta || {});
  const session = DB.Session.load(rn, rd);
  const collections = Array.isArray(session.collections) ? session.collections.slice() : [];
  collections.push(entry);
  DB.Session.save(rn, rd, {
    routeName: rn,
    date: rd,
    extraSales: Array.isArray(session.extraSales) ? session.extraSales : [],
    collections,
  });
  if (rn === AppState.routeName && rd === (AppState.routeDate || today())) {
    AppState.collections = collections;
  }
  return entry.id;
}

// Books a payment into the settlement of the route-day it belongs to, and
// reports where it landed so the caller can tell the driver.
//
// Target resolution: the loaded route-day when a route is open, otherwise
// TODAY's route-day of the customer's own route (address first, then stored
// route) — so a payment taken from Clientes/Cobranza still counts.
//
// The closed-jornada case: a snapshot is a point-in-time total, so cash
// collected AFTER the driver closed the day would never reach it. When the
// target route-day is already snapshotted, the payment is applied to that
// snapshot as a post-close adjustment instead of being written to a session
// nobody will read again. That keeps one source of truth for the day's
// figures and makes the cash visible immediately, closed or not.
function bookSettlementCollection(customerId, cash, card) {
  const onRoute = !!(AppState.route && AppState.routeName);
  const rn = onRoute ? AppState.routeName : settlementRouteForCustomer(customerId);
  if (!rn) return { ok: false, reason: 'no-route' };
  const rd = onRoute ? (AppState.routeDate || today()) : today();
  const entry = {
    id: genId(),
    customerId,
    cash: Number(cash) || 0,
    card: Number(card) || 0,
    timestamp: new Date().toISOString(),
    // Marks this collection as an abono taken outside a stop handoff. Stop
    // collections are counted through the order's creditPaidAmount, so the
    // rutas dashboard must add ONLY these or it double counts every sale.
    // Untagged entries predate this and are stop handoffs.
    source: 'statement-payment',
    // Who physically holds the cash. An abono with no driver on the clock is
    // still in the settlement, but it is not in anyone's pocket, so it stays
    // out of the per-driver totals.
    driverId: (AppState.driver && AppState.driver.id) || null,
    driverName: (AppState.driver && AppState.driver.name) || null,
  };

  const snaps = DB.SettlementHistory.getByDate(rd);
  const snap = snaps.find(s => s.routeName === rn);
  if (snap) {
    // Jornada already closed for this route-day → adjust the snapshot.
    snap.totalCash = (Number(snap.totalCash) || 0) + entry.cash;
    snap.totalCard = (Number(snap.totalCard) || 0) + entry.card;
    snap.totalCollected = (Number(snap.totalCash) || 0) + (Number(snap.totalCard) || 0);
    snap.postCloseCollections = (snap.postCloseCollections || []).concat([entry]);
    DB.SettlementHistory.save(snaps);
    if (rn === AppState.routeName && rd === (AppState.routeDate || today())) {
      AppState.collections.push(entry);
    }
  } else {
    // Route-day still open → the collection belongs in its session, where the
    // aggregate picks it up (see _pendingSessionCollections) and finishDay
    // sweeps it into the snapshot when the day is closed. `meta` carries the
    // statement-payment marker through, otherwise the entry lands untagged and
    // the rutas dashboard cannot tell an abono from a stop handoff.
    addCollectionToRouteDay(customerId, entry.cash, entry.card, rn, rd, {
      source: entry.source,
      driverId: entry.driverId,
      driverName: entry.driverName,
    });
  }
  return { ok: true, routeName: rn, date: rd, afterClose: !!snap };
}

// Cash collected today on route-days that are still OPEN, e.g. a payment
// registered from Clientes with no route loaded. Those collections have not
// been swept into a snapshot yet, so without this they are missing from the
// day's total until the route is closed.
//
// Only the collections are folded in — never the rest of the session, because
// streetTotal is global per date and would multiply once per route. Routes
// already represented in `countedRoutes` (a snapshot for the date, or the live
// route) are skipped: their figures are already inside the aggregate.
function _pendingSessionCollections(date, countedRoutes) {
  const counted = new Set((countedRoutes || []).filter(Boolean));
  const prefix = 'elcomal_session_', suffix = '_' + date;
  let cash = 0, card = 0;
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key || key.indexOf(prefix) !== 0 || key.slice(-suffix.length) !== suffix) continue;
      const sess = DB.Storage.get(key, null);
      if (!sess) continue;
      if (sess.routeName && counted.has(sess.routeName)) continue;
      (sess.collections || []).forEach(c => {
        cash += Number(c.cash) || 0;
        card += Number(c.card) || 0;
      });
    }
  } catch (e) {
    console.error('_pendingSessionCollections error:', e);
  }
  return { cash, card };
}

function addFutureOrder(order) {
  AppState.futureOrders.push({ id: genId(), ...order, status: 'pending' });
  DB.FutureOrders.save(AppState.futureOrders);
}

function getSettlementData() {
  const r = AppState.route;
  if (!r) return { startingInventory: 0, totalDelivered: 0, totalExtraSold: 0, totalStaleReturned: 0, totalRecompra: 0, totalRecompraCollected: 0, totalCredited: 0, totalChangeOwed: 0, totalOwedApplied: 0, endingInventory: 0, totalCollected: 0, totalCard: 0, totalCash: 0, recompraValue: 0, streetTotal: 0, devValue: 0, brutoValue: 0 };
  const p1 = getProductPrice('P1');
  const daySales = DB.Street.byDate(AppState.routeDate || today());
  const totalDelivered = r.stops.reduce((s, st) => s + ((st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0), 0) +
    r.stops.reduce((s, st) => s + (st.extraKg || 0), 0);
  const totalExtraSold = daySales.reduce((s, e) => s + e.kg, 0);
  const totalStaleReturned = r.stops.reduce((s, st) => s + (st.devolucionKg || 0), 0);
  const totalRecompra = r.stops.reduce((s, st) => s + (st.recompraKg || 0), 0);
  const totalRecompraCollected = r.stops.reduce((s, st) => s + (st.recompraCollected || 0), 0);
  const totalCredited = r.stops.reduce((s, st) => s + (st.creditAmount || 0), 0);
  // Change owed is cash IN HAND that isn't revenue (the driver holds the
  // customer's bill unbroken). Owed-applied is the opposite: part of a sale
  // settled with a pre-existing liability, so no cash moved for it.
  const totalChangeOwed = r.stops.reduce((s, st) => s + (st.changeOwed || 0), 0);
  const totalOwedApplied = r.stops.reduce((s, st) => s + (st.owedApplied || 0), 0);
  let totalCash = 0, totalCard = 0;
  AppState.collections.forEach(c => {
    if (c.paymentType) {
      if (c.paymentType === 'cash') totalCash += c.amount || 0;
      if (c.paymentType === 'card') totalCard += c.amount || 0;
    } else {
      totalCash += c.cash || 0;
      totalCard += c.card || 0;
    }
  });
  const streetTotal = DB.Street.byDate(AppState.routeDate || today()).reduce((s, e) => s + e.amount, 0);
  const totalCollected = totalCash + totalCard;
  const endingInventory = r.startingInventory - totalDelivered - totalExtraSold + totalStaleReturned + totalRecompra;
  // Value sales and devoluciones per-stop using each order's effective price
  // (order-level price prevails; falls back to customer default / product price).
  const perStopGross = r.stops.reduce((s, st) => {
    const pr = getStopPrice(st);
    const dk = st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg;
    return s + (dk || 0) * pr;
  }, 0);
  const perStopDev = r.stops.reduce((s, st) => s + (st.devolucionKg || 0) * getStopPrice(st), 0);
  return {
    startingInventory: r.startingInventory,
    totalDelivered,
    totalExtraSold,
    totalStaleReturned,
    totalRecompra,
    totalRecompraCollected,
    totalCredited,
    totalChangeOwed,
    totalOwedApplied,
    endingInventory,
    totalCollected,
    totalCard,
    totalCash,
    recompraValue: totalRecompra * RECOMPRA_PRICE,
    streetTotal,
    devValue: perStopDev,
    brutoValue: perStopGross + totalRecompra * RECOMPRA_PRICE + streetTotal,
  };
}

function getTodaySettlement() {
  try {
    const date = today();
    const snaps = DB.SettlementHistory.getByDate(date);
    // Build the current live route as a pseudo-snapshot so the
    // finished routes plus the in-progress route are all counted.
    const liveRoute = (() => {
      const r = AppState.route;
      if (r && r.stops && r.stops.some(s => s.status === 'completed' || s.status === 'skipped')) {
        return { ...getSettlementData(), routeName: r.name, stops: r.stops, date };
      }
      return null;
    })();
    // If the live route is already captured in a snapshot for this date, don't double-count it.
    const liveAlreadySnapshotted = liveRoute && snaps.some(s => s.routeName === liveRoute.routeName);
    const all = liveAlreadySnapshotted ? snaps : [...snaps, liveRoute].filter(Boolean);
    // Collections taken on route-days that are still open (payment registered
    // from Clientes with no route loaded) are not inside any snapshot yet, so
    // add them on top of whatever the aggregate produced.
    const pending = _pendingSessionCollections(date, all.map(s => s.routeName).filter(Boolean));
    const hasPending = pending.cash > 0 || pending.card > 0;
    if (all.length === 0) {
      if (!hasPending) return null;
      // A day with only collections taken outside a route. Mirrors
      // emptySettlement()'s field set — the report derives its cash rows from
      // brutoValue/recompraValue/devValue, so omitting them renders NaN.
      return {
        id: 'pending-' + date, date, routeName: null, driverId: null, driverName: null,
        startingInventory: 0, endingInventory: 0, totalDelivered: 0, totalExtraSold: 0,
        totalStaleReturned: 0, totalRecompra: 0, totalRecompraCollected: 0, totalCredited: 0,
        totalChangeOwed: 0, totalOwedApplied: 0,
        totalCash: pending.cash, totalCard: pending.card,
        totalCollected: pending.cash + pending.card,
        recompraValue: 0, streetTotal: 0, devValue: 0, brutoValue: 0,
        stops: [], isLive: true, pendingOnly: true,
      };
    }
    if (all.length === 1 && !hasPending) {
      const only = all[0];
      return { ...only, isLive: !liveAlreadySnapshotted, stops: only.stops || [] };
    }
    const aggregated = _aggregateSnapshots(all);
    // Align credit totals with the all-routes live dashboard (advanceOrders),
    // so the settlement CRÉDITO matches the dashboard figure exactly. Same
    // alignment for the change-owed legs — both live on the order, and a
    // snapshot's stop copy is what the aggregate read.
    const live = getLiveDayMetrics(date);
    const totalCash = (aggregated.totalCash || 0) + pending.cash;
    const totalCard = (aggregated.totalCard || 0) + pending.card;
    return {
      ...aggregated,
      isLive: false,
      stops: aggregated.stops || [],
      totalCredited: live.totalCredited,
      totalChangeOwed: live.totalChangeOwed,
      totalOwedApplied: live.totalOwedApplied,
      totalCash,
      totalCard,
      totalCollected: totalCash + totalCard,
    };
  } catch (e) {
    console.error('getTodaySettlement error:', e);
    return null;
  }
}

function getSettlementForDate(d) {
  try {
    const date = d || today();
    if (date === today()) return getTodaySettlement();
    const snaps = DB.SettlementHistory.getByDate(date);
    if (snaps.length === 0) return null;
    if (snaps.length === 1) return snaps[0];
    return _aggregateSnapshots(snaps);
  } catch (e) {
    console.error('getSettlementForDate error:', e);
    return null;
  }
}

function _uniqueStops(stops) {
  const seen = new Set();
  return (Array.isArray(stops) ? stops : []).filter(st => {
    const key = st.stopId || st.orderId;
    if (!key) return true;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

// Cash from abonos registered on the customer statement with "Incluir en
// liquidación" ON. Those are real cash in the driver's pocket and belong on the
// rutas dashboard next to the stop handoffs, but they are not orders, so
// getDriverCashForDay cannot see them — without this the settlement and the
// dashboard disagree about the same money.
//
// Only entries tagged source='statement-payment' count. Stop collections are
// already represented by the order's creditPaidAmount, so counting them again
// here would double every sale on the day.
//
// Scope: this reads the route-day sessions, which finishDay does NOT clear, so
// it also answers for a day the driver already closed. It is safe to add to a
// figure that is built from orders + street sales (the rutas dashboard's
// cash-in-hand card), which never folds collections in. Do NOT add it to
// settlement.totalCash or to any total that already includes the session
// collections — that is the case _pendingSessionCollections guards against by
// skipping snapshotted routes, and adding this too would count it twice.
function getStatementCashForDay(date, driverId) {
  const d = date || today();
  const who = driverId !== undefined ? driverId : (AppState.driver && AppState.driver.id);
  const prefix = 'elcomal_session_', suffix = '_' + d;
  let cash = 0;
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key || key.indexOf(prefix) !== 0 || key.slice(-suffix.length) !== suffix) continue;
      const sess = DB.Storage.get(key, null);
      if (!sess) continue;
      (sess.collections || []).forEach(c => {
        if (c.source !== 'statement-payment') return;
        if (who && c.driverId !== who) return;
        cash += Number(c.cash) || 0;
      });
    }
  } catch (e) {
    console.error('getStatementCashForDay error:', e);
  }
  return cash;
}

function getLiveDayMetrics(date) {
  const d = date || today();
  const ords = advanceOrders.filter(o => o.date === d);
  let kilosEntregados = 0, kilosFrios = 0, totalCredited = 0, totalCash = 0, doneOrders = 0;
  let totalChangeOwed = 0, totalOwedApplied = 0;
  ords.forEach(o => {
    if (o.status !== 'completed' && o.status !== 'skipped') return;
    doneOrders++;
    if (o.status === 'completed') {
      const dk = o.deliveredKg !== undefined && o.deliveredKg !== null ? Number(o.deliveredKg) : Number(o.qty) || 0;
      const cash = Number(o.creditPaidAmount) || 0;
      kilosEntregados += dk;
      totalCredited += Number(o.creditAmount) || 0;
      totalCash += cash;
      totalChangeOwed += Number(o.changeOwed) || 0;
      totalOwedApplied += Number(o.owedApplied) || 0;
    }
    kilosFrios += Number(o.devolucionKg) || 0;
  });
  return { kilosEntregados, kilosFrios, totalCredited, totalCash, totalChangeOwed, totalOwedApplied, doneOrders };
}

function getDriverCashForDay(date) {
  const d = date || today();
  const driverId = AppState.driver && AppState.driver.id;
  return advanceOrders
    .filter(o => o.date === d && o.status === 'completed' && o.completedBy === driverId)
    .reduce((s, o) => s + (Number(o.creditPaidAmount) || 0), 0);
}

function settlementDeliveredKilos(s) {
  if (!s) return 0;
  if (Array.isArray(s.stops) && s.stops.length) {
    return _uniqueStops(s.stops)
      .filter(st => st.status === 'completed')
      .reduce((sum, st) => sum + ((st.deliveredKg !== undefined ? Number(st.deliveredKg) : Number(st.preOrderKg)) || 0) + (Number(st.extraKg) || 0), 0);
  }
  return Number(s.totalDelivered) || 0;
}

function settlementFriosKilos(s) {
  if (!s) return 0;
  if (Array.isArray(s.stops) && s.stops.length) {
    return _uniqueStops(s.stops)
      .filter(st => st.status === 'completed' || st.status === 'skipped')
      .reduce((sum, st) => sum + (Number(st.devolucionKg) || 0), 0);
  }
  return Number(s.totalStaleReturned || 0);
}

function getCompletedTripsVentas(routeName) {
  const d = AppState.routeDate || today();
  let trips = AppState.trips.filter(t => t.date === d && t.status === 'completed');
  if (routeName) {
    trips = trips.filter(t => (t.routes ? t.routes.includes(routeName) : t.routeName === routeName));
  }
  let ventas = 0;
  trips.forEach(t => {
    getOrdersForTrip(t.id).forEach(o => {
      if (o.status !== 'completed') return;
      const dk = o.deliveredKg || o.qty;
      const op = o.price || getProductPrice(o.productId || 'P1');
      ventas += dk * op - (o.devolucionKg || 0) * op + (o.recompraKg || 0) * RECOMPRA_PRICE;
    });
  });
  return ventas;
}

function _aggregateSnapshots(snapshots) {
  try {
    if (!snapshots || snapshots.length === 0) return null;
    const stops = [];
    const seen = new Set();
    snapshots.forEach(snap => {
      (snap.stops || []).forEach(st => {
        const key = st.stopId || st.orderId;
        if (!key || seen.has(key)) return;
        seen.add(key);
        stops.push(st);
      });
    });
    const stopPrice = st => Number(st.price) || getProductPrice(st.productId || 'P1');
    const deliveredKg = st => ((st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0);
    const totalDelivered = stops.reduce((s, st) => s + deliveredKg(st) + (Number(st.extraKg) || 0), 0);
    const totalStaleReturned = stops.reduce((s, st) => s + (Number(st.devolucionKg) || 0), 0);
    const totalRecompra = stops.reduce((s, st) => s + (Number(st.recompraKg) || 0), 0);
    const totalRecompraCollected = stops.reduce((s, st) => s + (Number(st.recompraCollected) || 0), 0);
    const totalCredited = stops.reduce((s, st) => s + (Number(st.creditAmount) || 0), 0);
    const totalChangeOwed = stops.reduce((s, st) => s + (Number(st.changeOwed) || 0), 0);
    const totalOwedApplied = stops.reduce((s, st) => s + (Number(st.owedApplied) || 0), 0);
    const devValue = stops.reduce((s, st) => s + (Number(st.devolucionKg) || 0) * stopPrice(st), 0);
    const recompraValue = stops.reduce((s, st) => s + (Number(st.recompraKg) || 0) * RECOMPRA_PRICE, 0);
    const routeGross = stops.reduce((s, st) => s + deliveredKg(st) * stopPrice(st), 0);
    const streetByDate = new Map();
    const extraByDate = new Map();
    snapshots.forEach(snap => {
      const d = snap.date || today();
      streetByDate.set(d, Math.max(streetByDate.get(d) || 0, Number(snap.streetTotal) || 0));
      extraByDate.set(d, Math.max(extraByDate.get(d) || 0, Number(snap.totalExtraSold) || 0));
    });
    const streetTotal = [...streetByDate.values()].reduce((s, v) => s + v, 0);
    const totalExtraSold = [...extraByDate.values()].reduce((s, v) => s + v, 0);
    const totalCash = snapshots.reduce((s, snap) => s + (Number(snap.totalCash) || 0), 0);
    const totalCard = snapshots.reduce((s, snap) => s + (Number(snap.totalCard) || 0), 0);
    const startingInventory = snapshots.reduce((s, snap) => s + (Number(snap.startingInventory) || 0), 0);
    const endingInventory = startingInventory - totalDelivered - totalExtraSold + totalStaleReturned + totalRecompra;
    return {
      ...snapshots[0],
      startingInventory,
      totalDelivered,
      totalExtraSold,
      totalStaleReturned,
      totalRecompra,
      totalRecompraCollected,
      totalCredited,
      totalChangeOwed,
      totalOwedApplied,
      endingInventory,
      totalCollected: totalCash + totalCard,
      totalCard,
      totalCash,
      recompraValue,
      streetTotal,
      devValue,
      brutoValue: routeGross + recompraValue + streetTotal,
      stopsCount: stops.length,
      completedStopsCount: stops.filter(st => st.status === 'completed').length,
      routeName: 'Todas las rutas',
      stops,
      isLive: false,
    };
  } catch (e) {
    console.error('_aggregateSnapshots error:', e);
    return snapshots[0] || { startingInventory: 0, totalDelivered: 0, totalExtraSold: 0, totalStaleReturned: 0, totalRecompra: 0, totalRecompraCollected: 0, totalCredited: 0, totalChangeOwed: 0, totalOwedApplied: 0, totalCash: 0, totalCard: 0, totalCollected: 0, recompraValue: 0, streetTotal: 0, devValue: 0, brutoValue: 0, routeName: '—', stops: [] };
  }
}

function shiftDays(dateStr, n) {
  const d = new Date(dateStr + 'T12:00:00');
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

// Single source of truth for the report range: the begin/end dates picked in
// the report calendar. Every aggregate report reads from here.
function reportRangeFrom() {
  const from = AppState.reportFrom || today();
  const to = AppState.reportTo || from;
  return from <= to ? { from, to } : { from: to, to: from };
}

// The range immediately before [from,to] with the same number of days, used
// for period-over-period deltas on the dashboard cards.
function prevRangeFrom(from, to) {
  const lo = from <= to ? from : to;
  const hi = from <= to ? to : from;
  const days = Math.round((new Date(hi + 'T12:00:00') - new Date(lo + 'T12:00:00')) / 86400000) + 1;
  const shift = (str, n) => {
    const d = new Date(str + 'T12:00:00');
    d.setDate(d.getDate() + n);
    return d.toISOString().slice(0, 10);
  };
  const pTo = shift(lo, -1);
  return { from: shift(pTo, -(days - 1)), to: pTo };
}

// ─── REPORT DATE RANGE (begin/end date) ─────

function getAggregatedSettlementForRange(from, to) {
  if (!from || !to) return null;
  const lo = from <= to ? from : to;
  const hi = from <= to ? to : from;
  const snaps = DB.SettlementHistory.getRange(lo, hi);
  if (snaps.length === 0) {
    if (lo <= today() && hi >= today()) return getTodaySettlement();
    return null;
  }
  return _aggregateSnapshots(snaps);
}

// ─── REPORT AGGREGATIONS (analytics tabs) ──────────────
// Long ranges roll up to months so the chart stays readable on a phone.
function reportGranularity(from, to) {
  const ms = new Date(to + 'T12:00:00') - new Date(from + 'T12:00:00');
  const days = Math.round(ms / 86400000) + 1;
  return days > 62 ? 'month' : 'day';
}

function _reportBucketKey(dateStr, gran) {
  return gran === 'month' ? String(dateStr).slice(0, 7) : dateStr;
}

function _reportBucketLabel(key, gran) {
  if (gran === 'month') {
    const [y, m] = String(key).split('-');
    return m + '/' + String(y).slice(2);
  }
  return formatStmtDate(key);
}

// ─── SALES TREND DRILL (PowerBI-style: month → week → day) ──
// Every level below is re-aggregated only over the dates inside the drilled
// parent, so a week straddling two months contributes per-month amounts and a
// day panning two ISO weeks is impossible (a day belongs to exactly one week).

function childBucketLevel(level) {
  if (level === 'month') return 'week';
  if (level === 'week') return 'day';
  return null;
}

// Adaptive opening level: shortest range → day, medium → week, long → month.
function reportStartLevel(from, to) {
  const ms = new Date(to + 'T12:00:00') - new Date(from + 'T12:00:00');
  const days = Math.round(ms / 86400000) + 1;
  if (days <= 8) return 'day';
  if (days <= 35) return 'week';
  return 'month';
}

// ISO-8601 week key "YYYY-Www"; the week belongs to the year of its Thursday.
// Pure UTC day arithmetic (DST-proof): weeks are counted from Jan 1 of the
// Thursday's year with week 1 = the week containing Jan 1's Thursday.
function _isoWeekKey(dateStr) {
  const [y, m, d] = String(dateStr).split('-').map(Number);
  const dayMs = Date.UTC(y, m - 1, d);
  const dow = new Date(dayMs).getUTCDay(); // 0=Sun..6=Sat
  const isoDow = dow === 0 ? 7 : dow; // Mon=1..Sun=7
  const thuMs = dayMs + (4 - isoDow) * 86400000; // Thursday of this ISO week
  const thu = new Date(thuMs);
  const thuYear = thu.getUTCFullYear();
  const jan1 = Date.UTC(thuYear, 0, 1);
  const days = Math.floor((thuMs - jan1) / 86400000);
  const week = Math.ceil((days + 1) / 7);
  return thuYear + '-W' + String(week).padStart(2, '0');
}

function _bucketKeyFor(dateStr, level) {
  return level === 'month' ? String(dateStr).slice(0, 7) : level === 'week' ? _isoWeekKey(dateStr) : dateStr;
}

function _bucketLabel(key, level) {
  if (level === 'month') return _reportBucketLabel(key, 'month');
  if (level === 'week') return 'Sem ' + String(key).slice(-2);
  return _reportBucketLabel(key, 'day');
}

// A date belongs inside a drilled parent only when the parent is the immediate
// level above: a month key ("YYYY-MM") for week buckets, a week key
// ("YYYY-Www") for day buckets. Top-level calls pass parentKey = null.
function _dateInParent(dateStr, parentKey, level) {
  if (!parentKey) return true;
  if (level === 'week') return String(dateStr).slice(0, 7) === parentKey;
  if (level === 'day') return _isoWeekKey(dateStr) === parentKey;
  return true;
}

// Sales (route net of devoluciones + street) and unsold kilos bucketed at the
// requested drill level. "Kilos fríos" (unsold) counts devoluciones on
// completed AND skipped stops — a skipped stop returns the whole order.
function getSalesBucketsIn(from, to, level, parentKey) {
  const gran = level || reportStartLevel(from, to);
  const { stops, snaps } = _reportStopsInRange(from, to);
  const buckets = new Map();
  const at = key => {
    if (!buckets.has(key)) buckets.set(key, { key, label: _bucketLabel(key, gran), revenue: 0, kg: 0, orderedKg: 0, devKg: 0, credit: 0, street: 0, stops: 0 });
    return buckets.get(key);
  };
  stops.forEach(({ stop: st, date }) => {
    if (!_dateInParent(date, parentKey, gran)) return;
    // FRÍOS eligibility before ANY accumulation or bucket creation: an
    // incomplete/cancelled stop must not create a trend observation.
    if (!_isFriosEligibleStop(st)) return;
    _validateFriosStop(st);
    const b = at(_bucketKeyFor(date, gran));
    const dv = Number(st.devolucionKg) || 0;
    const ordered = Number(st.preOrderKg) || 0;
    b.devKg += dv;
    b.orderedKg += ordered;
    const pr = getStopPrice(st) || getProductPrice(st.productId || 'P1');
    const dk = (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0;
    b.revenue += dk * pr - dv * pr + (Number(st.recompraKg) || 0) * RECOMPRA_PRICE;
    b.kg += dk;
    b.credit += Number(st.creditAmount) || 0;
    b.stops += 1;
  });
  const streetByDate = new Map();
  snaps.forEach(s => {
    const d = s.date || today();
    streetByDate.set(d, Math.max(streetByDate.get(d) || 0, Number(s.streetTotal) || 0));
  });
  streetByDate.forEach((v, d) => {
    if (!_dateInParent(d, parentKey, gran)) return;
    const b = at(_bucketKeyFor(d, gran));
    b.revenue += v;
    b.street += v;
  });
  const series = [...buckets.values()].sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
  return { level: gran, series };
}

// Top-level trend for a range, auto-selecting the opening drill level.
function getSalesTimeSeries(from, to) {
  const gran = reportStartLevel(from, to);
  const { series } = getSalesBucketsIn(from, to, gran, null);
  return { gran, series };
}

// Every unique stop across the settlements in [from,to], plus the live day
// when it falls inside the range but has not been snapshotted yet.
function _reportStopsInRange(from, to) {
  const snaps = DB.SettlementHistory.getRange(from, to).slice();
  if (from <= today() && to >= today()) {
    const live = getTodaySettlement();
    if (live && !snaps.some(s => s.date === live.date && s.routeName === live.routeName)) snaps.push(live);
  }
  const stops = [];
  const seen = new Set();
  snaps.forEach(s => {
    (s.stops || []).forEach(st => {
      const k = st.stopId || st.orderId;
      if (k) { if (seen.has(k)) return; seen.add(k); }
      stops.push({ stop: st, date: s.date || today(), route: s.routeName || null });
    });
  });
  return { stops, snaps };
}

// ─── FRÍOS canonical metrics ─────────────────────────────
// The only canonical internal values: 'pct' (% frío), 'returned' (kg frío),
// 'ordered' (kg pedidos). Business definition (do not change here):
// % frío = devKg / orderedKg * 100 (delivered kilos NOT used).
const FRIOS_METRICS = ['pct', 'returned', 'ordered'];

function normalizeFriosMetric(metric) {
  // Temporary compatibility with existing callers/state
  if (metric === '%') return 'pct';
  if (metric === 'kg') return 'returned';
  return FRIOS_METRICS.includes(metric) ? metric : 'pct';
}

// Single source of truth for FRÍOS metric values. pct returns null (not 0)
// when there is no ordered-kilos denominator: 0 kg pedidos → "—", never 0%.
function _friosMetricValue(row, metric) {
  metric = normalizeFriosMetric(metric);
  const returnedKg = Number(row?.devKg) || 0;
  const orderedKg = Number(row?.orderedKg) || 0;
  if (metric === 'returned') return returnedKg;
  if (metric === 'ordered') return orderedKg;
  return orderedKg > 0 ? returnedKg / orderedKg * 100 : null;
}

// Display metadata per metric: chart labels, tooltips, legends, units.
function _friosMetricConfig(metric) {
  metric = normalizeFriosMetric(metric);
  if (metric === 'returned') {
    return { label: 'Kg merma', buttonLabel: 'KG MERMA', axisLabel: 'KG MERMA', legend: 'Kilos devueltos', unit: 'kg', decimals: 1 };
  }
  if (metric === 'ordered') {
    return { label: 'Kg pedidos', buttonLabel: 'KG PEDIDOS', axisLabel: 'KG PEDIDOS', legend: 'Kilos pedidos', unit: 'kg', decimals: 1 };
  }
  return { label: '% merma', buttonLabel: '% MERMA', axisLabel: '% MERMA', legend: '% de kilos devueltos', unit: '%', decimals: 1 };
}

// Primary-value formatter for a FRÍOS metric: missing → "—".
function _formatFriosMetric(value, metric) {
  if (value == null) return '—';
  metric = normalizeFriosMetric(metric);
  if (metric === 'pct') return value.toFixed(1) + '%';
  return value.toFixed(1) + ' kg';
}

// Bar width for a FRÍOS metric. pct is absolute (0–100); absolute metrics
// are relative to the largest currently displayed value.
function _friosBarWidth(value, metric, maxValue) {
  metric = normalizeFriosMetric(metric);
  if (value == null) return 0;
  if (metric === 'pct') return Math.max(0, Math.min(value, 100));
  if (maxValue <= 0) return 0;
  return Math.max(0, Math.min(value / maxValue * 100, 100));
}

// ─── FRÍOS stop eligibility ──────────────────────────────
// One canonical rule for all FRÍOS analytics. A stop excluded here is
// excluded from orderedKg, devKg, delivered kg, stops counts, customer
// rollups, daily trend, weekday analysis, customer detail and KPI totals —
// no metric may include a stop another FRÍOS metric excludes. Missing
// status preserves historical behavior (treated as completed/valid) so
// records predating the status field keep working.
function _isFriosEligibleStop(st) {
  if (!st) return false;
  return !st.status || st.status === 'completed';
}

// Analytical kilo parsing: missing optional values → 0 is acceptable, but
// invalid values (non-numeric, negative) return null instead of silently
// becoming valid zeroes. Callers sum null as 0 (with a dev warning) or
// propagate it; they must never treat invalid as measured.
function _safeReportKg(value) {
  if (value === undefined || value === null || value === '') return 0;
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) return null;
  return n;
}

// Development-only FRÍOS data-quality validator (localhost only, deduped,
// never blocks the report). devKg > orderedKg is flagged but NOT rejected —
// it may be returns from an earlier delivery or accumulated returns.
const _friosWarned = new Set();
function _validateFriosStop(st) {
  try {
    const loc = (typeof location !== 'undefined' && location.hostname) || '';
    if (loc !== 'localhost' && loc !== '127.0.0.1') return;
  } catch (e) { return; }
  if (!st) return;
  const id = st.stopId || st.orderId || ((st.customerId || st.customerName || '?') + '|' + String(st.preOrderKg) + '|' + String(st.devolucionKg));
  const flag = issue => {
    const k = issue + '@' + id;
    if (_friosWarned.has(k)) return;
    _friosWarned.add(k);
    console.warn('[FRIOS DATA]', issue, st);
  };
  const ordered = _safeReportKg(st.preOrderKg);
  const dev = _safeReportKg(st.devolucionKg);
  if (ordered === null) flag('invalid orderedKg');
  if (dev === null) flag('invalid devKg');
  if (st.deliveredKg !== undefined && _safeReportKg(st.deliveredKg) === null) flag('invalid deliveredKg');
  if (ordered !== null && dev !== null && dev > ordered) flag('devKg > orderedKg (needs review, not rejected)');
  if (!st.customerId && !st.customerName) flag('eligible stop with missing customer');
}

// Per-customer rollup over the range: sales, delivered kg, devoluciones and
// credit taken. `orderedKg` feeds the "% devuelto" column.
function getCustomerRollup(from, to) {
  const { stops } = _reportStopsInRange(from, to);
  const map = new Map();
  stops.forEach(({ stop: st }) => {
    // Eligible stops only: the customer is not even created when their sole
    // stops in range are ineligible, so Clientes X / Y counts eligible activity.
    if (!_isFriosEligibleStop(st)) return;
    _validateFriosStop(st);
    const key = st.customerId || st.customerName || '—';
    if (!map.has(key)) map.set(key, { key, name: st.customerName || '—', kg: 0, orderedKg: 0, devKg: 0, recKg: 0, credit: 0, revenue: 0, stops: 0 });
    const r = map.get(key);
    const dv = Number(st.devolucionKg) || 0;
    const ordered = Number(st.preOrderKg) || 0;
    const pr = getStopPrice(st) || getProductPrice(st.productId || 'P1');
    const dk = (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0;
    const rc = Number(st.recompraKg) || 0;
    r.devKg += dv;
    r.orderedKg += ordered;
    r.kg += dk;
    r.recKg += rc;
    r.credit += Number(st.creditAmount) || 0;
    r.revenue += dk * pr - dv * pr + rc * RECOMPRA_PRICE;
    r.stops += 1;
  });
  const rows = [...map.values()].sort((a, b) => b.revenue - a.revenue);
  const totalRevenue = rows.reduce((s, r) => s + r.revenue, 0);
  rows.forEach(r => { r.share = totalRevenue > 0 ? r.revenue / totalRevenue * 100 : 0; });
  return { rows, totalRevenue };
}

// Per-customer, per-day series over a range (oldest first): ordered kilos
// (pedido), returns (frío), and delivered kilos (venta) per day. Powers the
// customer drill-down (promedios, tendencia, historial).
function getCustomerDailySeries(from, to, customerKey) {
  const target = String(customerKey);
  const { stops } = _reportStopsInRange(from, to);
  const map = new Map();
  stops.forEach(({ stop: st, date }) => {
    const key = st.customerId || st.customerName || '—';
    if (String(key) !== target) return;
    // Ineligible stops must not generate a customer-detail day.
    if (!_isFriosEligibleStop(st)) return;
    _validateFriosStop(st);
    if (!map.has(date)) map.set(date, { date, orderedKg: 0, devKg: 0, kg: 0, stops: 0 });
    const b = map.get(date);
    b.orderedKg += Number(st.preOrderKg) || 0;
    b.devKg += Number(st.devolucionKg) || 0;
    b.kg += (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0;
    b.stops += 1;
  });
  return [...map.values()].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
}

// Weekday aggregation over a range: ordered/dev kilos per day-of-week
// (dow 0=Dom … 6=Sáb). Reveals patterns like "Sundays consistently have
// more returns" so Sunday orders can be investigated/reduced.
function getWeekdayFrios(from, to) {
  const { stops } = _reportStopsInRange(from, to);
  const days = [0, 1, 2, 3, 4, 5, 6].map(dow => ({ dow, orderedKg: 0, devKg: 0, stops: 0 }));
  stops.forEach(({ stop: st, date }) => {
    if (!_isFriosEligibleStop(st)) return;
    _validateFriosStop(st);
    const b = days[new Date(date + 'T12:00:00').getDay()];
    b.orderedKg += Number(st.preOrderKg) || 0;
    b.devKg += Number(st.devolucionKg) || 0;
    b.stops += 1;
  });
  return days;
}

// Route a snapshotted stop ACTUALLY belongs to, for the by-location report.
// A settlement snapshot carries ONE day-route (AppState.routeName), so
// trusting it alone collapses every sale of a multi-route day into one
// quadrant — that is what left the zone report with a single populated
// square. Precedence: the customer's address (source of truth, so a
// corrected address relocates the customer and their history with them),
// then the order that was planned, then a per-stop stamp, then the
// day-route. A deleted customer or missing order just falls through.
function _stopRouteName(st, snapshotRoute) {
  if (st) {
    const c = st.customerId ? getCustomer(st.customerId) : null;
    if (c && !c.deleted) {
      const byAddress = routeFromAddress(c.direccion);
      if (byAddress) return byAddress;
      if (c.route) return c.route;
    }
    const o = st.orderId ? advanceOrders.find(x => x.id === st.orderId) : null;
    if (o && o.route) return o.route;
    if (st.routeName) return st.routeName;
  }
  return snapshotRoute || '—';
}

// Per-route rollup over the range: sales $, delivered kg and stops per route,
// tagged with its sales quadrant (see _routeQuadrant).
function getSalesByRoute(from, to) {
  const { stops } = _reportStopsInRange(from, to);
  const map = new Map();
  stops.forEach(({ stop: st, route: rn }) => {
    const route = _stopRouteName(st, rn);
    if (!map.has(route)) map.set(route, { route, quadrant: _routeQuadrant(route), revenue: 0, kg: 0, orderedKg: 0, devKg: 0, stops: 0 });
    const r = map.get(route);
    r.devKg += Number(st.devolucionKg) || 0;
    r.orderedKg += Number(st.preOrderKg) || 0;
    if (st.status && st.status !== 'completed') return;
    const pr = getStopPrice(st) || getProductPrice(st.productId || 'P1');
    const dk = (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0;
    const dv = Number(st.devolucionKg) || 0;
    const rc = Number(st.recompraKg) || 0;
    r.revenue += dk * pr - dv * pr + rc * RECOMPRA_PRICE;
    r.kg += dk;
    r.stops += 1;
  });
  const rows = [...map.values()].sort((a, b) => b.revenue - a.revenue);
  const totalRevenue = rows.reduce((s, r) => s + r.revenue, 0);
  rows.forEach(r => { r.share = totalRevenue > 0 ? r.revenue / totalRevenue * 100 : 0; });
  return { rows, totalRevenue };
}

// Current accounts receivable from the canonical replay. Rows carry stored
// vs ledger balances for audit (stored is shown; never overwritten here).
// Age is the oldest DATED open credit — undated debt reports ageDays null
// (never 0), so it can no longer land in the 0–30 bucket by default.
function getReceivablesSnapshot() {
  const rows = CLIENTES.filter(c => !c.deleted).map(c => {
    const ledger = _replayCustomerCreditLedger(c.id);
    const storedBalance = Number(c.balance) || 0;
    const ledgerBalance = ledger.totalOpen;
    const reconciliationDifference = storedBalance - ledgerBalance;
    const isReconciled = Math.abs(reconciliationDifference) <= 0.005;
    if (!isReconciled) {
      _cobWarnOnce('recon@' + c.id,
        '[COBRANZA RECONCILIATION]', { customerId: c.id, storedBalance, ledgerBalance, difference: reconciliationDifference });
    }
    const datedOpen = ledger.openCredits.filter(q => q.dateKnown && q.date);
    const oldest = datedOpen.length ? datedOpen.reduce((m, q) => (q.date < m ? q.date : m), datedOpen[0].date) : null;
    return {
      id: c.id, name: c.name,
      balance: storedBalance, storedBalance, ledgerBalance, reconciliationDifference, isReconciled,
      creditLimit: Number(c.creditLimit) || 0,
      phone: c.phone || '', route: c.route || '',
      oldest, ageDays: oldest ? _daysBetween(oldest, today()) : null,
      openCount: ledger.openCredits.length,
      hasUnknownAge: ledger.openCredits.some(q => !q.dateKnown || !q.date),
    };
  }).filter(r => r.balance > 0.005 || r.openCount > 0)
    .sort((a, b) => (b.balance - a.balance) || ((b.ageDays ?? -1) - (a.ageDays ?? -1)));
  const total = rows.reduce((s, r) => s + r.balance, 0);
  const overdue = rows.filter(r => (r.ageDays ?? 0) > 30);
  return { rows, total, overdueAmount: overdue.reduce((s, r) => s + r.balance, 0), overdueCount: overdue.length };
}

// Average days to FULLY settle a normal sales credit, derived from the
// canonical replay. Opening balances consume payments in FIFO but never
// contribute to sales performance stats; partial payments never count as
// settled. Overall is the mean over settled credits (not over customers).
function getPayRatioStats() {
  const rows = [];
  const allSettled = [];
  CLIENTES.filter(c => !c.deleted).forEach(c => {
    const ledger = _replayCustomerCreditLedger(c.id);
    const settledSales = ledger.settledCredits.filter(cr => !cr.isOpeningBalance && cr.dateKnown && cr.daysToSettle !== null);
    settledSales.forEach(cr => allSettled.push({ customerId: c.id, daysToSettle: cr.daysToSettle }));
    const open = ledger.openCredits;
    if (settledSales.length === 0 && open.length === 0) return;
    const datedOpen = open.filter(q => q.dateKnown && q.date);
    const oldestOpen = datedOpen.length ? datedOpen.reduce((m, q) => (q.date < m ? q.date : m), datedOpen[0].date) : null;
    rows.push({
      id: c.id, name: c.name,
      avgDays: settledSales.length ? settledSales.reduce((s, cr) => s + cr.daysToSettle, 0) / settledSales.length : null,
      settledCount: settledSales.length,
      openCount: open.length,
      openAmount: open.reduce((s, q) => s + q.remaining, 0),
      oldestOpen,
      oldestDays: oldestOpen ? _daysBetween(oldestOpen, today()) : null,
      hasUnknownAge: open.some(q => !q.dateKnown || !q.date),
    });
  });
  rows.sort((a, b) => ((b.avgDays === null ? -1 : b.avgDays) - (a.avgDays === null ? -1 : a.avgDays)));
  const settledCustomerIds = new Set(allSettled.map(s => s.customerId));
  return {
    rows,
    overall: allSettled.length ? allSettled.reduce((s, x) => s + x.daysToSettle, 0) / allSettled.length : null,
    settledCreditCount: allSettled.length,
    settledCustomerCount: settledCustomerIds.size,
  };
}

function _receivableAgeBucket(ageDays) {
  if (ageDays === null || ageDays === undefined) return 'unknown';
  if (ageDays <= 30) return '0_30';
  if (ageDays <= 60) return '31_60';
  if (ageDays <= 90) return '61_90';
  return '90_plus';
}

// Credit-level AR aging: every OPEN credit is classified independently, so a
// customer contributes remaining amounts (not whole balances) to each bucket
// a credit falls in. Counts are UNIQUE customers per bucket — a customer may
// appear in several buckets, so bucket counts must not be summed.
function getReceivablesAging() {
  const defs = [
    { key: '0_30', label: '0–30 días', color: 'var(--emerald-600)' },
    { key: '31_60', label: '31–60 días', color: 'var(--amber-500)' },
    { key: '61_90', label: '61–90 días', color: 'var(--orange)' },
    { key: '90_plus', label: '> 90 días', color: 'var(--red-600)' },
    { key: 'unknown', label: 'Sin fecha', color: 'var(--slate-400)' },
  ];
  const buckets = {};
  defs.forEach(d => { buckets[d.key] = { ...d, amount: 0, creditCount: 0, customerIds: new Set() }; });
  CLIENTES.filter(c => !c.deleted).forEach(c => {
    _replayCustomerCreditLedger(c.id).openCredits.forEach(cr => {
      const age = cr.dateKnown && cr.date ? _daysBetween(cr.date, today()) : null;
      const b = buckets[_receivableAgeBucket(age)];
      b.amount += cr.remaining;
      b.creditCount += 1;
      b.customerIds.add(c.id);
    });
  });
  return defs.map(d => {
    const b = buckets[d.key];
    return { key: b.key, label: b.label, color: b.color, amount: b.amount, creditCount: b.creditCount, customers: b.customerIds.size };
  });
}

// Each toast owns a timer. Without cancelling the previous one, a short
// toast's timer wipes a longer toast that replaced it (so a 7s accounting
// warning was being cleared by an earlier 2.5s toast after 2.5s).
let _toastTimer = null;
function showToast(msg, ms) {
  const dur = Number(ms) || 2500;
  if (_toastTimer) { clearTimeout(_toastTimer); _toastTimer = null; }
  AppState.toast = msg;
  AppState.toastMs = dur;               // read by renderToast() for the node
  render();
  _toastTimer = setTimeout(() => {
    AppState.toast = null; AppState.toastMs = 0; _toastTimer = null; render();
  }, dur);
}

// ─── ADVANCE ORDERS ────────────────────────────────────
let advanceOrders = loadAdvanceOrders();

function getAdvanceOrder(id) { return advanceOrders.find(x => x.id === id); }

function addAdvanceOrder(customerId, productId, qty, price, route, instructions, orderDate, recurrence) {
  const c = getCustomer(customerId);
  const p = getProduct(productId);
  advanceOrders.push({
    id: genId(),
    customerId,
    customerName: c ? c.name : 'Desconocido',
    productId,
    productName: p ? p.name : 'Desconocido',
    qty: Number(qty),
    price: Number(price),
    route,
    instructions: instructions || '',
    date: orderDate || today(),
    status: 'pending',
    tripId: null,
    skipReason: null,
    skipNote: null,
    devolucionKg: 0,
    recompraKg: 0,
    deliveredKg: 0,
    creditAmount: 0,
    creditPaidType: null,
    creditPaidAmount: 0,
    recurrence: recurrence && recurrence.preset !== 'none' ? recurrence : null,
    originOrderId: null,
    source: 'manual',
    createdBy: AppState.driver.id,
    createdByName: AppState.driver.name,
    createdAt: new Date().toISOString(),
    updatedBy: null,
    updatedByName: null,
    updatedAt: new Date().toISOString(),
  });
  saveAdvanceOrders();
}

function getAdvanceOrdersForRoute(routeName) {
  const d = AppState.routeDate || today();
  return advanceOrders.filter(o => o.route === routeName && o.status === 'pending' && o.date === d);
}

function getAllAdvanceOrders() {
  return advanceOrders;
}

function cancelAdvanceOrder(orderId) {
  const o = advanceOrders.find(x => x.id === orderId);
  if (o) { o.status = 'cancelled'; saveAdvanceOrders(); }
}

function deleteAdvanceOrder(orderId) {
  advanceOrders = advanceOrders.filter(x => x.id !== orderId);
  saveAdvanceOrders();
  pruneGhostTrips();
}

// Removes deleted/stale order ids from trips; drops trips left with no orders
// so they don't show up as empty "ghost" route cards.
// Grace period: trips created < 5 min ago are never pruned — their orders
// may still be in-flight on the sync layer, and a false deletion is
// irreversible (the local delete propagates and kills the remote doc).
function pruneGhostTrips() {
  return false;
}

// ─── Reload all module arrays from localStorage ───────────
// Called by sync.js after remote merges so the UI reflects live
// data without a full page reload.
function reloadData() {
  try {
    CLIENTES = loadClients();
    PRODUCTOS = loadProducts();
    advanceOrders = loadAdvanceOrders();
    AppState.trips = loadTrips();
    PAYMENTS = loadPayments();
    OPENING_DEBTS = loadOpeningDebts();
    AppState.futureOrders = DB.FutureOrders.load();
    AppState.extraSales = DB.Street.byDate(AppState.routeDate || today());
    if (AppState.routeName) {
      const session = DB.Session.load(AppState.routeName, AppState.routeDate);
      AppState.collections = session.collections;
    }
    pruneGhostTrips();
    // Heal pre-deterministic-id recurring duplicates so the shadow-diff
    // push propagates the deleteDoc to the cloud and every other device.
    dedupeRecurringOrders();
  } catch (e) {
    console.error('reloadData error:', e);
  }
}

function updateAdvanceOrder(orderId, data) {
  const o = advanceOrders.find(x => x.id === orderId);
  if (!o) return;
  if (data.customerId !== undefined) { o.customerId = data.customerId; o.customerName = getCustomer(data.customerId)?.name || 'Desconocido'; }
  if (data.productId !== undefined) { o.productId = data.productId; o.productName = getProduct(data.productId)?.name || 'Desconocido'; }
  if (data.qty !== undefined) o.qty = Number(data.qty);
  if (data.price !== undefined) o.price = Number(data.price);
  if (data.route !== undefined) o.route = data.route;
  if (data.instructions !== undefined) o.instructions = data.instructions;
  if (data.date !== undefined) o.date = data.date;
  if (data.tripId !== undefined) o.tripId = data.tripId;
  if (data.skipReason !== undefined) o.skipReason = data.skipReason;
  if (data.skipNote !== undefined) o.skipNote = data.skipNote;
  if (data.devolucionKg !== undefined) o.devolucionKg = Number(data.devolucionKg);
  if (data.recompraKg !== undefined) o.recompraKg = Number(data.recompraKg);
  if (data.deliveredKg !== undefined) o.deliveredKg = Number(data.deliveredKg);
  if (data.creditAmount !== undefined) o.creditAmount = Number(data.creditAmount);
  if (data.creditPaidType !== undefined) o.creditPaidType = data.creditPaidType;
  if (data.creditPaidAmount !== undefined) o.creditPaidAmount = Number(data.creditPaidAmount);
  if (data.recurrence !== undefined) o.recurrence = data.recurrence && data.recurrence.preset !== 'none' ? data.recurrence : null;
  if (data.originOrderId !== undefined) o.originOrderId = data.originOrderId;
  if (data.source !== undefined) o.source = data.source;
  o.updatedBy = AppState.driver.id;
  o.updatedByName = AppState.driver.name;
  o.updatedAt = new Date().toISOString();
  saveAdvanceOrders();
}

// ─── RECURRING ORDERS ───────────────────────────────────
// Generates today's pending order for every active recurrence
// template. Idempotent: never creates a duplicate for the same
// origin + date. Cancelled/deleted templates stop generation.

// Deterministic id for a recurring-generated order. Every device that
// generates the same template + delivery date computes the SAME id, so the
// sync merge (dedup by id) collapses concurrent duplicates into one doc.
function recurringChildId(originId, dateStr) {
  return 'rec_' + originId + '_' + dateStr;
}

// Self-heal: removes leftover duplicate recurring-generated orders that
// predate deterministic ids (each device used a random id, so the same
// origin+date could exist N times and sync kept every distinct id).
// Conservative: never touches templates, and never drops a copy that is
// attached to a trip or has delivery/credit outcomes. Returns removed count.
function dedupeRecurringOrders() {
  if (!advanceOrders || advanceOrders.length === 0) return 0;
  const groups = new Map();
  advanceOrders.forEach((o, ix) => {
    if (o.source !== 'recurring' || !o.originOrderId || !o.date) return;
    const key = o.originOrderId + '|' + o.date;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(ix);
  });
  let removed = 0;
  const dropIds = new Set();
  groups.forEach(indexes => {
    if (indexes.length < 2) return;
    // An order still carrying a recurrence preset is a TEMPLATE: it must
    // survive even if another copy (a generated child with the same origin
    // + date) was generated as a duplicate. Never drop templates.
    const isTemplate = ix => {
      const r = advanceOrders[ix].recurrence;
      return !!(r && r.preset && r.preset !== 'none');
    };
    // A copy is "claimed" when it's on a trip or has delivery/credit
    // outcomes — dropping it would orphan a stop or lose money data.
    const engaged = ix => advanceOrders[ix].tripId ||
      (Number(advanceOrders[ix].deliveredKg) +
       Number(advanceOrders[ix].devolucionKg) +
       Number(advanceOrders[ix].recompraKg) +
       Number(advanceOrders[ix].creditAmount)) > 0;
    // Drop only copies that are idle (unclaimed) AND not a template, and
    // only when at least one idle non-template copy is kept. Every copy
    // that is a template or is claimed is never a removal candidate.
    const idleIx = indexes.filter(ix => !isTemplate(ix) && !engaged(ix));
    if (idleIx.length < 2) return;
    // Keep the most recently touched idle copy; drop the less recent ones.
    idleIx.sort((a, b) =>
      (new Date(advanceOrders[b].updatedAt || advanceOrders[b].createdAt || 0))
      - (new Date(advanceOrders[a].updatedAt || advanceOrders[a].createdAt || 0)));
    idleIx.slice(1).forEach(ix => dropIds.add(advanceOrders[ix].id));
  });
  if (dropIds.size === 0) return 0;
  advanceOrders = advanceOrders.filter(o => !dropIds.has(o.id));
  saveAdvanceOrders();
  return removed = dropIds.size;
}

function isRecurrenceDate(anchor, r, dateStr) {
  if (dateStr < anchor) return false;
  if (r.endType === 'date' && r.endDate && dateStr > r.endDate) return false;
  const fu = r.frequencyUnit || 'weeks';
  const fv = Math.max(1, r.frequencyValue || 1);
  const start = new Date(anchor + 'T12:00:00');
  const target = new Date(dateStr + 'T12:00:00');
  const diffDays = Math.round((target - start) / 86400000);

  if (fu === 'days') return diffDays % fv === 0;
  if (fu === 'weeks') {
    const dw = r.daysOfWeek && r.daysOfWeek.length ? r.daysOfWeek : [start.getDay()];
    if (!dw.includes(target.getDay())) return false;
    return Math.floor(diffDays / 7) % fv === 0;
  }
  if (fu === 'months') {
    const monthsDiff = (target.getFullYear() - start.getFullYear()) * 12 + (target.getMonth() - start.getMonth());
    return monthsDiff % fv === 0 && target.getDate() === start.getDate();
  }
  if (fu === 'years') {
    const yearsDiff = target.getFullYear() - start.getFullYear();
    return yearsDiff % fv === 0 && target.getMonth() === start.getMonth() && target.getDate() === start.getDate();
  }
  return false;
}

function processRecurrences(dateStr) {
  const d = dateStr || today();
  // A recurrence template keeps generating even after its own day is
  // delivered (status 'completed'). Only cancelled/deleted templates stop.
  const templates = advanceOrders.filter(o =>
    o.recurrence && o.recurrence.preset && o.recurrence.preset !== 'none' &&
    (o.status === 'pending' || o.status === 'completed') &&
    !(getCustomer(o.customerId) || {}).deleted
  );
  let created = 0;
  templates.forEach(t => {
    const r = t.recurrence;
    const anchor = t.date || d;
    if (!isRecurrenceDate(anchor, r, d)) return;
    const originId = t.originOrderId || t.id;
    if (r.endType === 'occurrences') {
      const count = advanceOrders.filter(o => (o.originOrderId || o.id) === originId).length;
      if (count >= (r.endOccurrences || 1)) return;
    }
    const childId = recurringChildId(originId, d);
    const exists = advanceOrders.some(o => (o.originOrderId || o.id) === originId && o.date === d);
    if (exists) return;
    const c = getCustomer(t.customerId);
    const p = getProduct(t.productId);
    advanceOrders.push({
      id: childId,
      customerId: t.customerId,
      customerName: c ? c.name : t.customerName,
      productId: t.productId,
      productName: p ? p.name : t.productName,
      qty: Number(t.qty),
      price: Number(t.price),
      route: t.route,
      instructions: t.instructions || '',
      date: d,
      status: 'pending',
      tripId: null,
      skipReason: null,
      skipNote: null,
      devolucionKg: 0,
      recompraKg: 0,
      deliveredKg: 0,
      creditAmount: 0,
      creditPaidType: null,
      creditPaidAmount: 0,
      recurrence: null,
      originOrderId: originId,
      source: 'recurring',
      recurringFrom: t.id,
      // Every phone makes this same order (same id) on its own. Dated midnight
      // of its day, not "now": the same date on every phone, and older than
      // any real edit that day, so a late copy can never beat a delivery.
      updatedAt: new Date(d + 'T00:00:00').toISOString(),
    });
    created++;
  });
  if (created > 0) saveAdvanceOrders();
  return created;
}

// ─── CUSTOMER CRUD ──────────────────────────────────────
function addCustomer(data) {
  const ids = CLIENTES.map(c => Number(c.id.slice(1))).sort((a, b) => a - b);
  const nextNum = ids.length > 0 ? ids[ids.length - 1] + 1 : 1;
  const c = {
    id: 'C' + nextNum,
    name: data.name,
    contact: data.contact || '',
    phone: data.phone || '',
    direccion: data.direccion || '',
    // No silent ROUTES[0] fallback: an unresolvable address must surface as
    // "Sin ruta" so the admin picks it, never silently becoming Pueblo Nuevo.
    route: data.route || routeFromAddress(data.direccion) || '',
    paymentTerm: data.paymentTerm || 'COD',
    creditLimit: Number(data.creditLimit) || 0,
    defaultPrice: Number(data.defaultPrice) || 0,
    recurrence: data.recurrence || null,
    balance: 0,
    // ── ERP integration fields (additive; all optional) ──
    email: data.email || '',
    tax_id: data.tax_id || '',
    currency: data.currency || 'MXN',
    street: data.street || '',
    city: data.city || '',
    state: data.state || '',
    zip: data.zip || '',
    country: data.country || 'MX',
    deleted: false,
    updatedAt: new Date().toISOString(),
  };
  CLIENTES.push(c);
  saveClients();
  if (typeof ErpOutbox !== 'undefined') {
    try { ErpOutbox.emitCustomerUpsert(c); } catch (e) { console.error('erp outbox emit failed', e); }
  }
  return c;
}

function updateCustomer(id, data) {
  const c = CLIENTES.find(x => x.id === id);
  if (!c) return null;
  // No-op guard: only stamp/save/emit when something actually changes —
  // keeps the ERP outbox free of phantom customer.upsert events.
  const keys = Object.keys(data || {});
  const changed = keys.length === 0 ? false :
    keys.some(k => JSON.stringify(c[k]) !== JSON.stringify(data[k]));
  if (!changed) return c;
  Object.assign(c, data);
  delete c.builtIn; // edited by a person: a real customer now
  c.updatedAt = new Date().toISOString();
  saveClients();
  if (typeof ErpOutbox !== 'undefined') {
    try { ErpOutbox.emitCustomerUpsert(c); } catch (e) { console.error('erp outbox emit failed', e); }
  }
  return c;
}

// ─── ROUTE REPAIR ───────────────────────────────────────
// Re-derives each customer's route from the city named in their address and
// backfills the stored route on their orders. `previewRouteRepair()` is a
// pure read so the admin sees the blast radius before writing anything.
//
// Deliberate limits:
//  - Soft-deleted customers are never touched (their rows are history).
//  - An address that names no city resolves to null, and a null resolution is
//    SKIPPED — the repair only corrects a route that contradicts the address,
//    it never invents one and never blanks a good one.
//  - Orders whose customer is unknown or deleted are left alone.
function previewRouteRepair() {
  const customerChanges = [];
  const orderChanges = [];
  let skippedNoCity = 0;
  let skippedDeleted = 0;

  CLIENTES.forEach(c => {
    if (c.deleted) { skippedDeleted++; return; }
    const derived = routeFromAddress(c.direccion);
    if (!derived) { skippedNoCity++; return; }
    if ((c.route || '') === derived) return;
    customerChanges.push({
      id: c.id, name: c.name, direccion: c.direccion,
      from: c.route || '(sin ruta)', to: derived,
    });
  });

  // Orders snapshot the route at creation time, so fixing only the customer
  // would never reach historial: the order rows must be corrected too.
  const resolved = new Map();
  CLIENTES.forEach(c => {
    if (c.deleted) return;
    resolved.set(c.id, routeFromAddress(c.direccion) || c.route || '');
  });
  advanceOrders.forEach(o => {
    const target = resolved.get(o.customerId);
    if (!target) return;
    if ((o.route || '') === target) return;
    orderChanges.push({
      id: o.id, customerId: o.customerId,
      customer: (getCustomer(o.customerId) || {}).name || o.customerName || o.customerId,
      date: o.date, from: o.route || '(sin ruta)', to: target,
    });
  });

  return { customerChanges, orderChanges, skippedNoCity, skippedDeleted };
}

function repairCustomerRoutes() {
  const plan = previewRouteRepair();
  plan.customerChanges.forEach(ch => updateCustomer(ch.id, { route: ch.to }));
  plan.orderChanges.forEach(ch => {
    const o = advanceOrders.find(x => x.id === ch.id);
    if (o) o.route = ch.to;
  });
  if (plan.orderChanges.length) saveAdvanceOrders();
  return {
    customersFixed: plan.customerChanges.length,
    ordersFixed: plan.orderChanges.length,
    customerChanges: plan.customerChanges,
    orderChanges: plan.orderChanges,
    skippedNoCity: plan.skippedNoCity,
    skippedDeleted: plan.skippedDeleted,
  };
}

function deleteCustomer(id) {
  // SOFT DELETE — ledger integrity: never rewrite history. The customer
  // row stays (flagged) so settlements, statements, ledgers, and any
  // ERP posting that references it keep resolving. Pickers hide it.
  const c = CLIENTES.find(x => x.id === id);
  if (!c) return false;
  if (c.deleted) return true;
  c.deleted = true;
  delete c.builtIn;
  c.deletedAt = new Date().toISOString();
  c.updatedAt = new Date().toISOString();
  saveClients();
  if (typeof ErpOutbox !== 'undefined') {
    try { ErpOutbox.emitCustomerUpsert(c); } catch (e) { console.error('erp outbox emit failed', e); }
  }
  return true;
}

// Active (non-deleted) customers — use in every picker/list.
function activeCustomers() {
  return CLIENTES.filter(c => !c.deleted);
}

// ─── BACKUP / RESTORE ───────────────────────────────────
function exportBackup() {
  const data = {};
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.indexOf('elcomal_') === 0) {
      data[key] = localStorage.getItem(key);
    }
  }
  return data;
}

function backupSummary(data) {
  const count = (k) => {
    try { const v = JSON.parse(data[k]); return Array.isArray(v) ? v.length : 0; } catch (e) { return 0; }
  };
  const parts = [];
  if (data.elcomal_clientes) parts.push(count('elcomal_clientes') + ' clientes');
  if (data.elcomal_orders) parts.push(count('elcomal_orders') + ' órdenes');
  if (data.elcomal_trips) parts.push(count('elcomal_trips') + ' rutas');
  if (data.elcomal_settlements) parts.push(count('elcomal_settlements') + ' cortes');
  if (data.elcomal_payments) parts.push(count('elcomal_payments') + ' pagos');
  if (data.elcomal_futureOrders) parts.push(count('elcomal_futureOrders') + ' pedidos futuros');
  const dyn = Object.keys(data).filter(k => k.indexOf('elcomal_stops_') === 0 || k.indexOf('elcomal_session_') === 0).length;
  if (dyn) parts.push(dyn + ' paradas/sesiones');
  return parts.join(', ') || 'datos';
}

function _parseBackupText(text) {
  let t = String(text || '').trim();
  if (t.charCodeAt(0) === 0xFEFF) t = t.slice(1).trim();
  try { return JSON.parse(t); } catch (e) {}
  const start = t.indexOf('{');
  const end = t.lastIndexOf('}');
  if (start !== -1 && end > start) {
    try { return JSON.parse(t.slice(start, end + 1)); } catch (e) {}
  }
  return null;
}

function importBackup(jsonText) {
  const data = _parseBackupText(jsonText);
  if (!data) return { ok: false, error: 'El texto no es un JSON válido. Pulsa "Generar texto del respaldo" y copia ese texto completo.' };
  if (typeof data !== 'object' || Array.isArray(data)) return { ok: false, error: 'El respaldo no tiene un formato válido.' };
  const keys = Object.keys(data).filter(k => k.indexOf('elcomal_') === 0);
  if (keys.length === 0) return { ok: false, error: 'El respaldo no contiene datos de El Comal (claves elcomal_*).' };

  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  const preKey = 'elcomal_preimport_backup_' + ts;
  const pre = {};
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.indexOf('elcomal_') === 0) pre[key] = localStorage.getItem(key);
  }
  localStorage.setItem(preKey, JSON.stringify(pre));

  keys.forEach(k => {
    try { localStorage.setItem(k, data[k]); } catch (e) {}
  });
  return { ok: true, preKey, summary: backupSummary(data) };
}

function restorePreImportBackup() {
  let preKey = null, preData = null;
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.indexOf('elcomal_preimport_backup_') === 0) {
      preKey = key;
      try { preData = JSON.parse(localStorage.getItem(key)); } catch (e) {}
    }
  }
  if (!preData) return false;
  Object.keys(preData).forEach(k => { try { localStorage.setItem(k, preData[k]); } catch (e) {} });
  if (preKey) localStorage.removeItem(preKey);
  return true;
}

// ─── CLEANUP: LIMPIAR RUTAS Y TRANSACCIONES ──────────────
// Deletes only ruta/transaction data: trips, stops, sessions,
// settlements, and street sales. Customers, their preferential
// price, recurrence, and ALL orders (recurring included) are kept.
function collectTransactionKeys() {
  const keys = ['elcomal_trips', 'elcomal_settlements', 'elcomal_streetSales', PAYMENTS_KEY, OPENING_DEBTS_KEY, CUSTOMER_OWED_KEY];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && (key.indexOf('elcomal_stops_') === 0 || key.indexOf('elcomal_session_') === 0)) {
      keys.push(key);
    }
  }
  return keys;
}

async function cleanupRouteData() {
  const keys = collectTransactionKeys();
  if (window.SyncDebug && window.SyncDebug.clearRemoteKeys) {
    await SyncDebug.clearRemoteKeys(keys);
  }
  keys.forEach(k => DB.Storage.del(k));

  // Transaction-ledger state that feeds reports and customer
  // statements (CxC/Cobranza) must be wiped too, not just the
  // trips/settlements keys, so the reportes reset cleanly.
  PAYMENTS = [];
  OPENING_DEBTS = [];
  // Saldo a favor (change owed) is the mirror leg of the same cleanup: those
  // rows are point-in-time facts about delivered stops that have just been
  // deleted, so keeping them would make the app claim it still owes change for
  // orders that no longer exist — and the next sale would silently apply it.
  CUSTOMER_OWED = [];
  saveCustomerOwed();
  CLIENTES.forEach(c => { c.balance = 0; touchCustomer(c); });
  saveClients();

  // Detach orders from deleted trips so they become assignable again.
  // Any order that carried a delivery/transaction outcome (completed,
  // skipped, or with kg/credit data) is reset back to a clean pending
  // state — otherwise the Rutas dashboard would keep summing stale
  // delivered kilos, credit, and cash for the day.
  advanceOrders.forEach(o => {
    if (o.tripId) o.tripId = null;
    if (o.status === 'completed' || o.status === 'skipped' ||
        Number(o.deliveredKg) > 0 || Number(o.devolucionKg) > 0 || Number(o.recompraKg) > 0 ||
        Number(o.creditAmount) > 0 || Number(o.creditPaidAmount) > 0) {
      o.status = 'pending';
      o.skipReason = null;
      o.skipNote = null;
      o.deliveredKg = 0;
      o.devolucionKg = 0;
      o.recompraKg = 0;
      o.creditAmount = 0;
      o.creditPaidType = null;
      o.creditPaidAmount = 0;
    }
  });
  saveAdvanceOrders();

  AppState.trips = [];
  AppState.collections = [];
  AppState.extraSales = [];
  location.reload();
}

// ─── STOP SETTLEMENT: one math, two callers ────────────────────────
// confirmStop() (first capture) and saveStopAmendment() (correction) MUST
// agree on what a given set of numbers means, or a correction would be booked
// by different rules than the original. So the arithmetic lives here, pure and
// DOM-free, and both paths call it.
//
// `oldDebtChipOn` = the "saldo a favor" chip (this stop also collects an old
// debt). There is deliberately no `noChange` input any more: the "No tengo
// cambio" opt-in was removed, so cash may never exceed what the sale is worth
// and no stop can declare an unbreakable bill.
function computeStopSettlement(p) {
  const cash = Number(p.cash) || 0;
  const creditAmount = Number(p.creditAmount) || 0;
  const owedApplied = Number(p.owedApplied) || 0;
  const pending = Number(p.pending) || 0;
  const oldDebtChipOn = !!p.oldDebtChipOn;

  // Cash already booked by earlier partial legs on this order (any driver).
  const yaCobrado = Number(p.yaCobrado) || 0;
  const base = Math.max(0, (Number(p.neto) || 0) - yaCobrado);

  // ── Saldo a favor a aplicar ──
  // What we already owe this customer, consumed by this sale. No cash moves
  // for it, so it must not be counted as collected — it only reduces what this
  // stop still has to take in.
  const owedBase = Math.max(0, base - owedApplied);
  const sugerido = owedBase + (oldDebtChipOn && pending > 0.01 ? pending : 0);

  // ── Cambio pendiente ──
  // Always 0. Cash above the total is rejected rather than booked: there is no
  // opt-in that would make it a liability, so a surplus can only be a typo.
  // The `changeOwed` field is still returned (and still read by the booking
  // sinks, the stop/order docs and the settlement reports) so that stops booked
  // while the opt-in still existed keep reconciling correctly.
  if (cash > sugerido + 0.01) {
    return { ok: false, error: 'no-change', cash, base, owedBase, sugerido, yaCobrado };
  }
  const cashApplied = Math.min(cash, sugerido);
  const balance = cashApplied + creditAmount;
  if (Math.abs(balance - sugerido) > 0.01) {
    // `sugerido` is reported even on rejection. A caller that DERIVES the
    // credit from the cash (the correction editor does exactly this) has no
    // other way to learn what the stop should have taken in, and swallowing
    // it here is what makes "the cash was short, the rest was credit"
    // impossible to express.
    return { ok: false, error: 'unbalanced', cash, creditAmount, cashApplied, base, owedBase, sugerido, yaCobrado };
  }
  // The guard above rejects any surplus, so cashApplied === cash and the
  // surplus is structurally 0. Kept as a named field for the booking sinks and
  // the settlement reports, which must keep reconciling stops that were booked
  // while the opt-in still existed.
  const changeOwed = 0;

  const todayCredit = Math.max(0, owedBase - cashApplied);
  const oldDebtPaid = oldDebtChipOn && pending > 0.01
    ? Math.min(pending, Math.max(0, cash - owedBase))
    : 0;

  if (todayCredit > 0 && p.creditLimit > 0 && todayCredit > p.creditLimit) {
    return { ok: false, error: 'credit-limit', creditLimit: p.creditLimit };
  }

  const recompraValue = (Number(p.recompraKg) || 0) * (Number(p.recompraPrice) || 0);
  // Recompra collection is part of what settled the sale, so it is capped by
  // cashApplied, never by the raw figure — otherwise cash meant for something
  // else would be counted as recompra the company collected.
  const recompraCollected = Math.min(recompraValue, cashApplied);

  return {
    ok: true, cash, creditAmount, owedApplied, yaCobrado, base, owedBase, sugerido,
    cashApplied, changeOwed, todayCredit, oldDebtPaid, recompraValue, recompraCollected,
  };
}

function stopSettlementError(err) {
  if (err.error === 'no-change') {
    return '❌ El efectivo no puede ser mayor al total. Corrige el monto o cobra el resto como crédito';
  }
  if (err.error === 'unbalanced') {
    return '❌ Efectivo + Crédito debe ser igual al Total a Cobrar';
  }
  if (err.error === 'credit-limit') {
    return '❌ El crédito excede el límite de ' + formatCurrency(err.creditLimit);
  }
  return '❌ No se pudo calcular el cobro';
}

// Writes every sink for one completed stop: order doc, stop, collections +
// session, the change-owed ledger, the payments ledger and customer.balance.
// Returns the booking receipt ids so a later correction can reverse them.
function applyStopBooking(stop, s, ctx) {
  const { qty, devKg, recKg } = ctx;
  const order = stop.orderId ? getAdvanceOrder(stop.orderId) : null;
  let collectionId = null;
  let payment = null;

  stop.devolucionKg = devKg;
  stop.recompraKg = recKg;
  stop.recompraCollected = s.recompraCollected;
  stop.oldDebtPaid = s.oldDebtPaid;
  stop.changeOwed = s.changeOwed;
  stop.owedApplied = s.owedApplied;
  stop.deliveryDraft = null;

  if (order) {
    order.status = 'completed';
    order.devolucionKg = devKg;
    order.recompraKg = recKg;
    order.recompraCollected = s.recompraCollected;
    order.deliveredKg = qty;
    order.creditAmount = s.todayCredit;
    order.creditPaidType = s.cash > 0 ? 'cash' : null;
    // Raw cash across all legs, change owed INCLUDED: that money is
    // physically in the driver's pocket and must reach the day's cash
    // total, otherwise the corte shows a surplus nobody can explain.
    order.creditPaidAmount = s.yaCobrado + s.cash;
    order.oldDebtPaid = s.oldDebtPaid;
    order.changeOwed = s.changeOwed;
    order.owedApplied = s.owedApplied;
    order.completedAt = new Date().toISOString();
    order.completedBy = AppState.driver.id;
    order.completedByName = AppState.driver.name;
    order.updatedAt = new Date().toISOString();

    if (s.cash > 0) {
      collectionId = addCollection(stop.customerId, s.cash); // current leg only — partials booked their own
    }

    // ── Saldo a favor ledger ──
    // Written after the order is saved so both rows carry the orderId that
    // explains where the money went. `apply` re-clamps against the live
    // balance, so a stale UI can never drive it negative.
    const owedMeta = { orderId: order.id, stopId: stop.stopId, kg: qty };
    if (s.owedApplied > 0.01) {
      applyCustomerOwed(stop.customerId, s.owedApplied, owedMeta);
    }
  } else {
    if (s.cash > 0) {
      collectionId = addCollection(stop.customerId, s.cash);
    }
  }

  if (s.todayCredit > 0) {
    recordCustomerCredit(stop.customerId, s.todayCredit);
  }
  if (s.oldDebtPaid > 0.01) {
    payment = recordDebtPayment(stop.customerId, s.oldDebtPaid);
  }

  // Spontaneous stops (no order) still owe the ledger, so the money is not lost
  // just because the sale did not come from a pre-existing order.
  if (!order) {
    const owedMeta = { stopId: stop.stopId, kg: qty };
    if (s.owedApplied > 0.01) {
      applyCustomerOwed(stop.customerId, s.owedApplied, owedMeta);
    }
    stop.status = 'completed';
    stop.deliveredKg = qty;
    stop.creditAmount = s.todayCredit;
    stop.creditPaidType = s.cash > 0 ? 'cash' : null;
    stop.creditPaidAmount = s.yaCobrado + s.cash;
    stop.changeOwed = s.changeOwed;
    stop.owedApplied = s.owedApplied;
  } else {
    stop.status = 'completed';
    stop.deliveredKg = qty;
    stop.creditAmount = s.todayCredit;
    stop.creditPaidType = s.cash > 0 ? 'cash' : null;
    stop.creditPaidAmount = s.yaCobrado + s.cash;
    stop.changeOwed = s.changeOwed;
    stop.owedApplied = s.owedApplied;
  }

  // Receipt last, once every sink id is known.
  const receipt = {
    cash: s.cash, creditAmount: s.creditAmount, todayCredit: s.todayCredit,
    oldDebtPaid: s.oldDebtPaid, changeOwed: s.changeOwed, owedApplied: s.owedApplied,
    recompraCollected: s.recompraCollected, deliveredKg: qty,
    devolucionKg: devKg, recompraKg: recKg,
    collectionId, paymentIds: payment ? [payment.id] : [],
  };
  if (order) {
    recordStopBooking(order, stop, receipt);
    saveAdvanceOrders();
  } else {
    stop.booking = Object.assign({
      stopId: stop.stopId, at: new Date().toISOString(),
      by: currentActor().id, byName: currentActor().name,
    }, receipt);
  }
  saveStopProgress(AppState.routeName, AppState.route.stops);
  return receipt;
}
