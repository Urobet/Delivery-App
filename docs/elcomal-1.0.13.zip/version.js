// ─── WEB VERSION ─────────────────────────────────────────
// Single source of truth for the deployable web version.
// Bump this BEFORE running deploy.ps1; version.json on the
// update host must match for phones to see a new bundle.
const APP_VERSION = '1.0.13';
