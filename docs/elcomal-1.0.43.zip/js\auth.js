// ─── AUTH LAYER ─────────────────────────────────────────
// Username + password auth with role-based access (admin | driver).
// Users sync to Firestore via the elcomal_users key; active sessions stay
// tab-local in sessionStorage so multiple drivers can use the same origin
// in separate tabs without overwriting each other.
// Load AFTER persistence.js (uses DB.Storage), BEFORE data.js.

const Auth = {
  SESSION_KEY: 'elcomal_session',
  USERS_KEY: 'elcomal_users',

  _id() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  },

  // --- password hashing (SHA-256 via SubtleCrypto, salted with username) ---
  async _hash(plain, salt) {
    const enc = new TextEncoder();
    const data = enc.encode(salt + ':' + plain);
    const buf = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
  },

  hashPassword(plain, username) {
    return this._hash(plain, (username || '').toLowerCase().trim());
  },

  // --- user repo (synced to Firestore via elcomal_users) ---
  _loadUsers() { return DB.Storage.get(this.USERS_KEY, []); },
  _saveUsers(list) { DB.Storage.set(this.USERS_KEY, list); },

  getUsers() { return this._loadUsers(); },

  _findByUsername(username) {
    const u = (username || '').toLowerCase().trim();
    return this._loadUsers().find(x => x.username === u);
  },

  isFirstRun() { return this._loadUsers().length === 0; },

  async createUser(username, password, role, name) {
    const uname = (username || '').toLowerCase().trim();
    if (!uname || !password) throw new Error('Usuario y contraseña son obligatorios');
    if (password.length < 4) throw new Error('La contraseña debe tener al menos 4 caracteres');
    if (this._findByUsername(uname)) throw new Error('Ese usuario ya existe');
    const users = this._loadUsers();
    const user = {
      id: 'usr_' + this._id(),
      username: uname,
      passwordHash: await this._hash(password, uname),
      role: role === 'admin' ? 'admin' : 'driver',
      name: (name || uname).trim(),
      active: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    users.push(user);
    this._saveUsers(users);
    return user;
  },

  async login(username, password, rememberMe) {
    const user = this._findByUsername(username);
    if (!user || !user.active) throw new Error('Usuario o contraseña incorrectos');
    const hash = await this._hash(password, user.username);
    if (hash !== user.passwordHash) throw new Error('Usuario o contraseña incorrectos');
    const session = {
      userId: user.id,
      username: user.username,
      role: user.role,
      name: user.name,
      rememberMe: !!rememberMe,
      loginAt: new Date().toISOString(),
    };
    try { sessionStorage.setItem(this.SESSION_KEY, JSON.stringify(session)); } catch (e) {}
    try { localStorage.removeItem(this.SESSION_KEY); } catch (e) {}
    return session;
  },

  currentUser() {
    let s = null;
    try { s = sessionStorage.getItem(this.SESSION_KEY); } catch (e) {}
    if (!s) return null;
    try { return JSON.parse(s); } catch (e) { return null; }
  },

  logout() {
    try { localStorage.removeItem(this.SESSION_KEY); } catch (e) {}
    try { sessionStorage.removeItem(this.SESSION_KEY); } catch (e) {}
  },

  updateSession(fields) {
    const s = this.currentUser();
    if (!s) return;
    Object.assign(s, fields);
    try { sessionStorage.setItem(this.SESSION_KEY, JSON.stringify(s)); } catch (e) {}
  },

  isAdmin() { const u = this.currentUser(); return !!(u && u.role === 'admin'); },
  isDriver() { const u = this.currentUser(); return !!(u && u.role === 'driver'); },

  async updateUser(userId, fields) {
    const users = this._loadUsers();
    const u = users.find(x => x.id === userId);
    if (!u) throw new Error('Usuario no encontrado');
    if (fields.username !== undefined) u.username = fields.username.toLowerCase().trim();
    if (fields.name !== undefined) u.name = fields.name.trim();
    if (fields.role !== undefined) u.role = fields.role === 'admin' ? 'admin' : 'driver';
    if (fields.active !== undefined) u.active = !!fields.active;
    if (fields.password !== undefined && fields.password) {
      u.passwordHash = await this._hash(fields.password, u.username);
    }
    u.updatedAt = new Date().toISOString();
    this._saveUsers(users);
    return u;
  },

  deleteUser(userId) {
    this._saveUsers(this._loadUsers().filter(x => x.id !== userId));
  },
};