// ─── STATE ─────────────────────────────────────────────
const AppState = {
  driver: { name: 'Juan Pérez', id: 'DRV001' },
  screen: 'login',
  params: {},
  history: [],
  route: null,
  routeName: null,
  routeFilter: null,
  creditModal: null,
  extraSales: [],
  collections: [],
  futureOrders: DB.FutureOrders.load(),
  counterSales: [],
  currentStop: null,
  collapsedCompleted: true,
  toast: null,
  reportTab: 'settlement',
  reportPeriod: 'today',
  reportFrom: '',
  reportTo: '',
  routeSubTab: 'today',
  sheetCustomerId: null,
  paymentEntry: false,
  showRouteFilter: false,
  routeDate: today(),
  customersSortBy: 'name',
  customersSortDir: 'asc',
  customersPage: 1,
  customersPerPage: 8,
  customerFormId: null,
  selectedCustomers: [],
  editingOrderId: null,
  selectedOrders: [],
  showOrderForm: false,
  orderRecurrence: null,
  futureOrdersExpanded: false,
  trips: [],
  routeCreationModal: false,
  skipReasonModal: null,
  signatureSheet: null,
};

// ─── HELPERS ───────────────────────────────────────────
function genId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function today() { return new Date().toISOString().slice(0, 10); }
function formatDate(d) {
  const date = new Date(d + 'T12:00:00');
  return date.toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long' });
}
function formatCurrency(n) { return '$' + Number(n).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); }
function formatDateShort(d) {
  const date = new Date(d + 'T12:00:00');
  return date.toLocaleDateString('es-MX', { day: 'numeric', month: 'short' });
}
function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

// ─── PERSISTENCE ────────────────────────────────────────
const STORAGE_KEY_CLIENTS = 'elcomal_clientes';
const STORAGE_KEY_ORDERS = 'elcomal_orders';
const STORAGE_KEY_STOPS = 'elcomal_stops';
const STORAGE_KEY_TRIPS = 'elcomal_trips';

// ─── CUSTOMERS ─────────────────────────────────────────
const DEFAULT_CLIENTES = [
  { id: 'C1', name: 'La Tienda de María', contact: 'María García', phone: '555-0101', direccion: 'Av. Juárez 123, Centro', route: 'Pueblo Nuevo',
    paymentTerm: 'Semanal', creditLimit: 3000 },
  { id: 'C2', name: 'Abarrotes López', contact: 'Pedro López', phone: '555-0102', direccion: 'Calle Hidalgo 45, Col. Centro', route: 'La Perla',
    paymentTerm: 'COD', creditLimit: 0 },
  { id: 'C3', name: 'MiniSuper Ruiz', contact: 'Ana Ruiz', phone: '555-0103', direccion: 'Blvd. Independencia 678', route: 'Dolores',
    paymentTerm: 'Cada 3 días', creditLimit: 2000 },
  { id: 'C4', name: 'Dulces y Más', contact: 'José Martínez', phone: '555-0104', direccion: 'Calle Zaragoza 90, Col. Centro', route: 'El Paso',
    paymentTerm: 'COD', creditLimit: 0 },
  { id: 'C5', name: 'Tortillería San José', contact: 'Luis Hernández', phone: '555-0105', direccion: 'Av. Reforma 234', route: '25 de Diciembre',
    paymentTerm: 'Semanal', creditLimit: 2500 },
  { id: 'C6', name: 'Carnicería El Toro', contact: 'Carlos Torres', phone: '555-0106', direccion: 'Calle 5 de Mayo 56', route: 'Melgar',
    paymentTerm: 'COD', creditLimit: 0 },
  { id: 'C7', name: 'Frutería La Naranja', contact: 'Sofía Ramírez', phone: '555-0107', direccion: 'Av. Morelos 789, Col. Centro', route: 'Melgar',
    paymentTerm: 'Semanal', creditLimit: 1800 },
  { id: 'C8', name: 'Panadería El Trigal', contact: 'Miguel Ángel Díaz', phone: '555-0108', direccion: 'Calle Allende 12', route: 'La Flor',
    paymentTerm: 'COD', creditLimit: 0 },
  { id: 'C9', name: 'Lonchería Doña Tota', contact: 'Teresa Mendoza', phone: '555-0109', direccion: 'Blvd. Benito Juárez 345', route: 'La Flor',
    paymentTerm: 'Cada 3 días', creditLimit: 1200 },
  { id: 'C10', name: 'Tienda La Esquina', contact: 'Roberto Castro', phone: '555-0110', direccion: 'Calle 16 de Septiembre 78', route: 'La Una',
    paymentTerm: 'COD', creditLimit: 0 },
  { id: 'C11', name: 'Farmacia San Pablo', contact: 'Diana Flores', phone: '555-0111', direccion: 'Av. Universidad 901', route: 'Pueblo Nuevo',
    paymentTerm: 'Semanal', creditLimit: 4000 },
  { id: 'C12', name: 'Miscelánea El Sol', contact: 'Jorge Núñez', phone: '555-0112', direccion: 'Calle Victoria 23', route: 'La Perla',
    paymentTerm: 'COD', creditLimit: 0 },
  { id: 'C13', name: 'Cremería La Esperanza', contact: 'Elena Vázquez', phone: '555-0113', direccion: 'Calle Guerrero 456', route: 'Dolores',
    paymentTerm: 'Cada 3 días', creditLimit: 1500 },
  { id: 'C14', name: 'Zapatería El Buen Paso', contact: 'Fernando Ríos', phone: '555-0114', direccion: 'Av. Hidalgo 111', route: 'El Paso',
    paymentTerm: 'COD', creditLimit: 0 },
  { id: 'C15', name: 'Ferretrería El Martillo', contact: 'Ricardo Paredes', phone: '555-0115', direccion: 'Calle Obregón 222', route: '25 de Diciembre',
    paymentTerm: 'Semanal', creditLimit: 5000 },
];

function loadClients() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_CLIENTS);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return JSON.parse(JSON.stringify(DEFAULT_CLIENTES));
}

function saveClients() {
  try { localStorage.setItem(STORAGE_KEY_CLIENTS, JSON.stringify(CLIENTES)); } catch (e) {}
}

let CLIENTES = loadClients();
backfillCustomerBalances();

// ─── CUSTOMER PAYMENTS / CUENTA (kilos fiados) ─────────
const PAYMENTS_KEY = 'elcomal_payments';
let PAYMENTS = loadPayments();

function loadPayments() {
  try {
    const saved = localStorage.getItem(PAYMENTS_KEY);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return [];
}

function savePayments() {
  try { localStorage.setItem(PAYMENTS_KEY, JSON.stringify(PAYMENTS)); } catch (e) {}
}

// One-time migration: seed each customer's balance from historical
// settlement snapshots (sum of all credited kilos per stop).
function backfillCustomerBalances() {
  let changed = false;
  const snapshots = DB.SettlementHistory.load();
  CLIENTES.forEach(c => {
    if (typeof c.balance !== 'number') {
      let total = 0;
      snapshots.forEach(snap => {
        (snap.stops || []).forEach(st => {
          if (st.customerId === c.id) total += (Number(st.creditAmount) || 0);
        });
      });
      c.balance = total;
      changed = true;
    }
  });
  if (changed) saveClients();
}

function recordCustomerCredit(customerId, amount) {
  const amt = Number(amount) || 0;
  if (amt <= 0) return;
  const c = getCustomer(customerId);
  if (c) {
    c.balance = (c.balance || 0) + amt;
    saveClients();
  }
}

function getCustomerPayments(customerId) {
  return PAYMENTS.filter(p => p.customerId === customerId)
    .sort((a, b) => (a.timestamp || '').localeCompare(b.timestamp || ''));
}

function getTotalPayments(customerId) {
  return getCustomerPayments(customerId).reduce((s, p) => s + (Number(p.amount) || 0), 0);
}

function getPaymentsTotalForDate(dateStr) {
  const d = dateStr || today();
  return PAYMENTS.filter(p => (p.timestamp || '').slice(0, 10) === d)
    .reduce((s, p) => s + (Number(p.amount) || 0), 0);
}

// ─── CREDIT LEDGER (fiado) ─────────────────────────────
function getCreditMovements(customerId) {
  const rows = [];
  const liveDate = AppState.routeDate || today();
  const hasLiveRoute = !!AppState.route && AppState.route.stops.length > 0;
  DB.SettlementHistory.load().forEach(snap => {
    if (hasLiveRoute && snap.date === liveDate) return;
    (snap.stops || []).forEach(st => {
      if (st.customerId === customerId && (Number(st.creditAmount) || 0) > 0) {
        rows.push({
          type: 'credit',
          date: snap.date,
          amount: Number(st.creditAmount) || 0,
          kg: (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0,
          ref: st.orderId || st.stopId || 'INV',
        });
      }
    });
  });
  if (AppState.route) {
    AppState.route.stops.forEach(st => {
      if (st.customerId === customerId && st.status === 'completed' && (Number(st.creditAmount) || 0) > 0) {
        rows.push({
          type: 'credit',
          date: liveDate,
          amount: Number(st.creditAmount) || 0,
          kg: (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0,
          ref: st.orderId || st.stopId || 'INV',
        });
      }
    });
  }
  return rows;
}

// Unified credits + payments, FIFO-covered (payments settle oldest
// credit first). Returns newest-first rows for display.
function getUnifiedLedger(customerId) {
  const movements = [];
  getCreditMovements(customerId).forEach(m => movements.push({
    type: 'credit', date: m.date, amount: m.amount, kg: m.kg, ref: m.ref,
    status: 'pendiente', remaining: m.amount, method: null,
  }));
  getCustomerPayments(customerId).forEach(p => movements.push({
    type: 'payment', date: (p.timestamp || '').slice(0, 10), amount: Number(p.amount) || 0,
    method: p.method, ref: p.id, status: 'abono', remaining: 0, kg: 0,
  }));

  movements.sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? -1 : 1;
    if (a.type === 'credit' && b.type !== 'credit') return -1;
    if (b.type === 'credit' && a.type !== 'credit') return 1;
    return 0;
  });

  const open = [];
  movements.forEach(m => {
    if (m.type === 'credit') { open.push(m); return; }
    let rem = m.amount;
    while (rem > 0.001 && open.length > 0) {
      const head = open[0];
      const take = Math.min(head.remaining, rem);
      head.remaining -= take;
      rem -= take;
      if (head.remaining <= 0.001) open.shift();
    }
  });
  movements.forEach(m => {
    if (m.type === 'credit' && m.remaining <= 0.001) m.status = 'saldado';
  });

  return movements.slice().reverse();
}

// Next date on/after fromDate matching the recurrence pattern.
function nextRecurrenceDate(r, fromDate) {
  if (!r || r.preset === 'none') return null;
  const anchor = r.anchor || fromDate;
  const start = new Date(fromDate + 'T12:00:00');
  for (let i = 0; i < 366; i++) {
    const d = new Date(start.getTime() + i * 86400000);
    const ds = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    if (isRecurrenceDate(anchor, r, ds)) return ds;
  }
  return null;
}

function addPayment(customerId, amount, method) {
  const amt = Number(amount) || 0;
  if (amt <= 0) return null;
  const p = {
    id: genId(),
    customerId,
    amount: amt,
    method: method === 'card' ? 'card' : 'cash',
    timestamp: new Date().toISOString(),
  };
  PAYMENTS.push(p);
  savePayments();
  const c = getCustomer(customerId);
  if (c) {
    c.balance = Math.max(0, (c.balance || 0) - amt);
    saveClients();
  }
  if (p.method === 'card') addCollection(customerId, 0, amt);
  else addCollection(customerId, amt, 0);
  return p;
}

function loadAdvanceOrders() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_ORDERS);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return [];
}

function saveAdvanceOrders() {
  try { localStorage.setItem(STORAGE_KEY_ORDERS, JSON.stringify(advanceOrders)); } catch (e) {}
}

function stopsProgressKey(routeName) {
  const d = AppState.routeDate || today();
  return 'stops_' + routeName.replace(/\s/g, '') + '_' + d;
}

function loadStopProgress(routeName) {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_STOPS + '_' + stopsProgressKey(routeName));
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return null;
}

function saveStopProgress(routeName, stops) {
  try {
    const data = stops.map(s => ({
      stopId: s.stopId,
      status: s.status,
      devolucionKg: s.devolucionKg,
      recompraKg: s.recompraKg,
      recompraCollected: s.recompraCollected || 0,
      stopPhase: s.stopPhase,
      extraKg: s.extraKg,
      creditAmount: s.creditAmount,
      creditPaidType: s.creditPaidType,
      creditPaidAmount: s.creditPaidAmount,
      paymentType: s.paymentType,
      cashTendered: s.cashTendered,
      deliveryDraft: s.deliveryDraft || null,
    }));
    localStorage.setItem(STORAGE_KEY_STOPS + '_' + stopsProgressKey(routeName), JSON.stringify(data));
  } catch (e) {}
}

let _tripCounter = 0;
function generateTripId(routeName) {
  const prefix = routeName.replace(/[^A-Za-z0-9]/g, '').slice(0, 3).toUpperCase();
  let max = 0;
  AppState.trips.forEach(t => { const n = parseInt(t.id.split('-')[1]); if (!isNaN(n) && n > max) max = n; });
  return prefix + '-' + String(max + 1).padStart(3, '0');
}

function loadTrips() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_TRIPS);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return [];
}

function saveTrips() {
  try { localStorage.setItem(STORAGE_KEY_TRIPS, JSON.stringify(AppState.trips)); } catch (e) {}
}

function createTrip(routeName, kilosLoaded, orderIds) {
  const routes = [...new Set(orderIds.map(oid => {
    const o = advanceOrders.find(x => x.id === oid);
    return o ? o.route : null;
  }).filter(Boolean))];
  const primaryRoute = routeName || routes[0] || 'MIX';
  const trip = {
    id: generateTripId(primaryRoute),
    routeName: primaryRoute,
    routes,
    date: AppState.routeDate || today(),
    kilosLoaded: Number(kilosLoaded),
    orderIds,
    status: 'active',
    expanded: true,
    createdAt: new Date().toISOString(),
  };
  AppState.trips.push(trip);
  orderIds.forEach(oid => {
    const o = advanceOrders.find(x => x.id === oid);
    if (o) o.tripId = trip.id;
  });
  saveTrips();
  saveAdvanceOrders();
  return trip;
}

function completeTrip(tripId) {
  const trip = AppState.trips.find(t => t.id === tripId);
  if (trip) trip.status = 'completed';
  saveTrips();
}

function getTripsForRoute(routeName) {
  const d = AppState.routeDate || today();
  return AppState.trips.filter(t =>
    t.date === d &&
    (t.routes ? t.routes.includes(routeName) : t.routeName === routeName)
  );
}

function getAvailableOrdersForRoute(routeName) {
  const d = AppState.routeDate || today();
  return advanceOrders.filter(o =>
    o.route === routeName &&
    o.status === 'pending' &&
    !o.tripId &&
    o.date === d
  );
}

function getOrdersForTrip(tripId) {
  const trip = AppState.trips.find(t => t.id === tripId);
  if (!trip) return [];
  return trip.orderIds.map(oid => advanceOrders.find(o => o.id === oid)).filter(Boolean);
}

function getTripProgress(tripId) {
  const orders = getOrdersForTrip(tripId);
  const total = orders.length;
  const done = orders.filter(o => o.status === 'completed' || o.status === 'skipped').length;
  return { done, total };
}

// ─── PRODUCTS ──────────────────────────────────────────
const PRODUCTOS = [
  { id: 'P1', name: 'Tortilla de Maíz', price: 22, unit: 'kg', icon: '🫓' },
  { id: 'P2', name: 'Tortilla de Harina', price: 28, unit: 'kg', icon: '🫔' },
  { id: 'P3', name: 'Tostadas', price: 18, unit: 'kg', icon: '🟤' },
  { id: 'P4', name: 'Totopos', price: 20, unit: 'kg', icon: '🔺' },
  { id: 'P5', name: 'Kilo Frio', price: 8, unit: 'kg', icon: '❄️' },
];

const RECOMPRA_PRICE = 8;

// ─── BUILD ROUTE ────────────────────────────────────────
function buildMockRoute(routeName) {
  const orders = getAdvanceOrdersForRoute(routeName);

  const stops = orders.map((o, i) => {
    const c = getCustomer(o.customerId);
    return {
      stopId: 'S' + (o.customerId.slice(1)),
      customerId: o.customerId,
      customerName: c ? c.name : o.customerName,
      preOrderKg: o.qty,
      staleKg: 0,
      devolucionKg: 0,
      recompraKg: 0,
      extraKg: 0,
      creditAmount: 0,
      creditPaidType: null,
    creditPaidAmount: 0,
    deliveryDraft: null,
      paymentType: '',
      cashTendered: 0,
      stopPhase: 'pendiente',
      deliveryDraft: null,
      status: i === 0 ? 'active' : 'pending',
      sequence: i + 1,
    };
  });

  const routeDate = AppState.routeDate || today();

  const saved = loadStopProgress(routeName);
  if (saved) {
    saved.forEach(sp => {
      const st = stops.find(s => s.stopId === sp.stopId);
      if (st) Object.assign(st, sp);
    });
  }

  return {
    id: 'R-' + routeName.replace(/\s/g, '') + '-' + routeDate.replace(/-/g, ''),
    name: routeName,
    date: routeDate,
    dateDisplay: capitalize(formatDate(routeDate)),
    startingInventory: stops.reduce((s, st) => s + st.preOrderKg, 0),
    stops,
  };
}

// ─── ROUTES ─────────────────────────────────────────────
const ROUTES = [
  'Pueblo Nuevo', 'La Perla', 'Dolores',
  'El Paso', '25 de Diciembre', 'Melgar', 'La Flor', 'La Una',
];

// ─── STATE MANAGEMENT FUNCTIONS ────────────────────────
function rebuildRouteStops(routeName) {
  const r = AppState.route;
  if (!r) return;
  const trips = getTripsForRoute(routeName || AppState.routeName);
  const stops = [];
  const seenOrders = new Set();
  trips.forEach(trip => {
    const orders = getOrdersForTrip(trip.id);
    orders.forEach(o => {
      if (seenOrders.has(o.id)) return;
      seenOrders.add(o.id);
      const completed = o.status === 'completed' || o.status === 'skipped';
      stops.push({
        stopId: 'S-' + o.id,
        orderId: o.id,
        customerId: o.customerId,
        customerName: o.customerName,
        preOrderKg: o.qty,
        staleKg: 0,
        devolucionKg: o.devolucionKg || 0,
        recompraKg: o.recompraKg || 0,
        extraKg: 0,
        deliveredKg: completed ? (o.deliveredKg || o.qty) : 0,
        creditAmount: o.creditAmount || 0,
        creditPaidType: o.creditPaidType || null,
        creditPaidAmount: o.creditPaidAmount || 0,
        skipReason: o.skipReason || null,
        skipNote: o.skipNote || null,
        completedAt: o.completedAt || null,
        paymentType: '',
        cashTendered: 0,
        stopPhase: 'pendiente',
        status: completed ? o.status : 'active',
        sequence: 1,
        deliveryDraft: completed ? null : (o.deliveryDraft || null),
      });
    });
  });
  r.stops = stops;
  r.startingInventory = trips.reduce((s, t) => s + (t.kilosLoaded || 0), 0);
}

function initRoute() {
  AppState.routeName = ROUTES[0];
  AppState.routeFilter = null;
  AppState.routeDate = today();
  const session = DB.Session.load(AppState.routeName, AppState.routeDate);
  AppState.extraSales = session.extraSales;
  AppState.collections = session.collections;
  AppState.creditModal = null;
  AppState.collapsedCompleted = true;
  AppState.showRouteFilter = false;
  AppState.futureOrders = DB.FutureOrders.load();
  AppState.futureOrdersExpanded = false;
  _tripCounter = 0;
  AppState.trips = loadTrips();
  AppState.route = {
    name: AppState.routeName,
    date: AppState.routeDate,
    dateDisplay: capitalize(formatDate(AppState.routeDate)),
    startingInventory: 0,
    stops: [],
  };
  rebuildRouteStops();
}

function getTripStats(routeName) {
  const trips = getTripsForRoute(routeName);
  let totalOrders = 0, doneOrders = 0, totalKilos = 0;
  trips.forEach(t => {
    totalKilos += t.kilosLoaded || 0;
    const orders = getOrdersForTrip(t.id);
    totalOrders += orders.length;
    doneOrders += orders.filter(o => o.status === 'completed' || o.status === 'skipped').length;
  });
  return { totalOrders, doneOrders, totalKilos, pending: totalOrders - doneOrders };
}

function getCustomer(id) { return CLIENTES.find(c => c.id === id); }

function getCustomerBalance(customerId) {
  const c = getCustomer(customerId);
  return Math.max(0, (c && c.balance) || 0);
}

function getProduct(id) { return PRODUCTOS.find(p => p.id === id); }

// ─── PRODUCT PRICES (from settings, persisted) ──────────

function loadProductPrices() {
  const saved = DB.Prices.load();
  if (saved) return saved;
  const defaults = {};
  PRODUCTOS.forEach(p => { defaults[p.id] = p.price; });
  DB.Prices.save(defaults);
  return defaults;
}

function getProductPrice(productId) {
  const prices = loadProductPrices();
  return prices[productId] || PRODUCTOS.find(p => p.id === productId)?.price || 22;
}

function setProductPrice(productId, price) {
  const prices = loadProductPrices();
  prices[productId] = price;
  DB.Prices.save(prices);
}

function getEffectivePrice(customerId, productId) {
  const cust = customerId ? getCustomer(customerId) : null;
  if (cust && cust.defaultPrice > 0) return cust.defaultPrice;
  return getProductPrice(productId || 'P1');
}

function completeStop(stopId) {
  const stop = AppState.route.stops.find(s => s.stopId === stopId);
  if (stop) { stop.status = 'completed'; saveStopProgress(AppState.routeName, AppState.route.stops); }
}

function skipStop(stopId) {
  const stop = AppState.route.stops.find(s => s.stopId === stopId);
  if (stop) { stop.status = 'skipped'; saveStopProgress(AppState.routeName, AppState.route.stops); }
}

function allStopsDone() {
  return AppState.route.stops.every(s => s.status === 'completed' || s.status === 'skipped');
}

function getStopProgress() {
  const stops = AppState.route.stops;
  return { done: stops.filter(s => s.status === 'completed').length, total: stops.length };
}

function addExtraSale(productId, kg, amount) {
  AppState.extraSales.push({
    id: genId(), productId, kg: Number(kg), amount: Number(amount), timestamp: new Date().toISOString(),
  });
  const rn = AppState.routeName, rd = AppState.routeDate || today();
  if (rn) DB.Session.save(rn, rd, { routeName: rn, date: rd, extraSales: AppState.extraSales, collections: AppState.collections });
}

function addCollection(customerId, cash, card) {
  AppState.collections.push({
    id: genId(), customerId,
    cash: Number(cash) || 0,
    card: Number(card) || 0,
    timestamp: new Date().toISOString(),
  });
  const rn = AppState.routeName, rd = AppState.routeDate || today();
  if (rn) DB.Session.save(rn, rd, { routeName: rn, date: rd, extraSales: AppState.extraSales, collections: AppState.collections });
}

function addFutureOrder(order) {
  AppState.futureOrders.push({ id: genId(), ...order, status: 'pending' });
  DB.FutureOrders.save(AppState.futureOrders);
}

function getSettlementData() {
  const r = AppState.route;
  if (!r) return { startingInventory: 0, totalDelivered: 0, totalExtraSold: 0, totalStaleReturned: 0, totalRecompra: 0, totalRecompraCollected: 0, totalCredited: 0, endingInventory: 0, totalCollected: 0, totalCard: 0, totalCash: 0, recompraValue: 0, streetTotal: 0, devValue: 0, brutoValue: 0 };
  const p1 = getProductPrice('P1');
  const totalDelivered = r.stops.reduce((s, st) => s + st.preOrderKg, 0) +
    r.stops.reduce((s, st) => s + (st.extraKg || 0), 0);
  const totalExtraSold = AppState.extraSales.reduce((s, e) => s + e.kg, 0);
  const totalStaleReturned = r.stops.reduce((s, st) => s + (st.devolucionKg || 0), 0);
  const totalRecompra = r.stops.reduce((s, st) => s + (st.recompraKg || 0), 0);
  const totalRecompraCollected = r.stops.reduce((s, st) => s + (st.recompraCollected || 0), 0);
  const totalCredited = r.stops.reduce((s, st) => s + (st.creditAmount || 0), 0);
  let totalCash = 0, totalCard = 0;
  AppState.collections.forEach(c => {
    if (c.paymentType) {
      if (c.paymentType === 'cash') totalCash += c.amount || 0;
      if (c.paymentType === 'card') totalCard += c.amount || 0;
    } else {
      totalCash += c.cash || 0;
      totalCard += c.card || 0;
    }
  });
  const streetTotal = AppState.extraSales.reduce((s, e) => s + e.amount, 0);
  const totalCollected = totalCash + totalCard;
  const endingInventory = r.startingInventory - totalDelivered - totalExtraSold + totalStaleReturned + totalRecompra;
  return {
    startingInventory: r.startingInventory,
    totalDelivered,
    totalExtraSold,
    totalStaleReturned,
    totalRecompra,
    totalRecompraCollected,
    totalCredited,
    endingInventory,
    totalCollected,
    totalCard,
    totalCash,
    recompraValue: totalRecompra * RECOMPRA_PRICE,
    streetTotal,
    devValue: totalStaleReturned * p1,
    brutoValue: totalDelivered * p1 + totalRecompra * RECOMPRA_PRICE + streetTotal,
  };
}

function getTodaySettlement() {
  try {
    const r = AppState.route;
    if (r && r.stops && r.stops.some(s => s.status === 'completed' || s.status === 'skipped')) {
      const data = getSettlementData();
      return { ...data, routeName: r.name, driverName: AppState.driver.name, isLive: true, stops: r.stops };
    }
    const snaps = DB.SettlementHistory.getByDate(today());
    if (snaps.length === 1) return { ...snaps[0], isLive: false, stops: snaps[0].stops || [] };
    if (snaps.length > 1) {
      const agg = _aggregateSnapshots(snaps);
      return { ...agg, isLive: false, stops: [] };
    }
    return null;
  } catch (e) {
    console.error('getTodaySettlement error:', e);
    return null;
  }
}

function getSettlementForDate(d) {
  try {
    const date = d || today();
    if (date === today()) return getTodaySettlement();
    const snaps = DB.SettlementHistory.getByDate(date);
    if (snaps.length === 0) return null;
    if (snaps.length === 1) return snaps[0];
    return _aggregateSnapshots(snaps);
  } catch (e) {
    console.error('getSettlementForDate error:', e);
    return null;
  }
}

function _uniqueStops(stops) {
  const seen = new Set();
  return (Array.isArray(stops) ? stops : []).filter(st => {
    const key = st.stopId || st.orderId;
    if (!key) return true;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function settlementDeliveredKilos(s) {
  if (!s) return 0;
  if (Array.isArray(s.stops) && s.stops.length) {
    return _uniqueStops(s.stops)
      .filter(st => st.status === 'completed')
      .reduce((sum, st) => sum + ((st.deliveredKg !== undefined ? Number(st.deliveredKg) : Number(st.preOrderKg)) || 0) + (Number(st.extraKg) || 0), 0);
  }
  return Number(s.totalDelivered) || 0;
}

function settlementFriosKilos(s) {
  if (!s) return 0;
  if (Array.isArray(s.stops) && s.stops.length) {
    return _uniqueStops(s.stops)
      .filter(st => st.status === 'completed' || st.status === 'skipped')
      .reduce((sum, st) => sum + (Number(st.devolucionKg) || 0), 0);
  }
  return Number(s.totalStaleReturned || 0);
}

function getCompletedTripsVentas(routeName) {
  const d = AppState.routeDate || today();
  let trips = AppState.trips.filter(t => t.date === d && t.status === 'completed');
  if (routeName) {
    trips = trips.filter(t => (t.routes ? t.routes.includes(routeName) : t.routeName === routeName));
  }
  let ventas = 0;
  trips.forEach(t => {
    getOrdersForTrip(t.id).forEach(o => {
      if (o.status !== 'completed') return;
      const dk = o.deliveredKg || o.qty;
      const op = o.price || getProductPrice(o.productId || 'P1');
      ventas += dk * op - (o.devolucionKg || 0) * op + (o.recompraKg || 0) * (op / 2);
    });
  });
  return ventas;
}

function _aggregateSnapshots(snapshots) {
  try {
    const base = { ...snapshots[0] };
    const fields = ['startingInventory', 'totalDelivered', 'totalExtraSold', 'totalStaleReturned',
      'totalRecompra', 'totalRecompraCollected', 'totalCredited', 'totalCash', 'totalCard', 'totalCollected',
      'recompraValue', 'streetTotal', 'devValue', 'brutoValue', 'stopsCount', 'completedStopsCount'];
    fields.forEach(f => { base[f] = snapshots.reduce((s, snap) => s + (snap[f] || 0), 0); });
    base.routeName = 'Todas las rutas';
    base.stops = [];
    return base;
  } catch (e) {
    console.error('_aggregateSnapshots error:', e);
    return snapshots[0] || { startingInventory: 0, totalDelivered: 0, totalExtraSold: 0, totalStaleReturned: 0, totalRecompra: 0, totalRecompraCollected: 0, totalCredited: 0, totalCash: 0, totalCard: 0, totalCollected: 0, recompraValue: 0, streetTotal: 0, devValue: 0, brutoValue: 0, routeName: '—', stops: [] };
  }
}

function shiftDays(dateStr, n) {
  const d = new Date(dateStr + 'T12:00:00');
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

function settlementRange(period, customFrom, customTo) {
  const todayStr = today();
  if (period === 'yesterday') { const y = shiftDays(todayStr, -1); return { from: y, to: y }; }
  if (period === 'today' || !period) return { from: todayStr, to: todayStr };
  if (period === 'week') {
    const d = new Date(todayStr + 'T12:00:00');
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    return { from: new Date(d.setDate(diff)).toISOString().slice(0, 10), to: todayStr };
  }
  if (period === 'month') return { from: todayStr.slice(0, 7) + '-01', to: todayStr };
  if (period === 'year') return { from: todayStr.slice(0, 4) + '-01-01', to: todayStr };
  if (period === 'custom') {
    const from = customFrom || todayStr;
    const to = customTo || todayStr;
    return { from, to };
  }
  return { from: todayStr, to: todayStr };
}

function getAggregatedSettlementForPeriod(period, customFrom, customTo) {
  const { from, to } = settlementRange(period, customFrom, customTo);
  const snaps = DB.SettlementHistory.getRange(from, to);
  if (snaps.length === 0) {
    if (from <= today() && to >= today()) return getTodaySettlement();
    return null;
  }
  return _aggregateSnapshots(snaps);
}

function showToast(msg) {
  AppState.toast = msg;
  render();
  setTimeout(() => { AppState.toast = null; render(); }, 2500);
}

// ─── ADVANCE ORDERS ────────────────────────────────────
let advanceOrders = loadAdvanceOrders();

function getAdvanceOrder(id) { return advanceOrders.find(x => x.id === id); }

function addAdvanceOrder(customerId, productId, qty, price, route, instructions, orderDate, recurrence) {
  const c = getCustomer(customerId);
  const p = getProduct(productId);
  advanceOrders.push({
    id: genId(),
    customerId,
    customerName: c ? c.name : 'Desconocido',
    productId,
    productName: p ? p.name : 'Desconocido',
    qty: Number(qty),
    price: Number(price),
    route,
    instructions: instructions || '',
    date: orderDate || today(),
    status: 'pending',
    tripId: null,
    skipReason: null,
    skipNote: null,
    devolucionKg: 0,
    recompraKg: 0,
    deliveredKg: 0,
    creditAmount: 0,
    creditPaidType: null,
    creditPaidAmount: 0,
    recurrence: recurrence && recurrence.preset !== 'none' ? recurrence : null,
    originOrderId: null,
    source: 'manual',
  });
  saveAdvanceOrders();
}

function getAdvanceOrdersForRoute(routeName) {
  const d = AppState.routeDate || today();
  return advanceOrders.filter(o => o.route === routeName && o.status === 'pending' && o.date === d);
}

function getAllAdvanceOrders() {
  return advanceOrders;
}

function cancelAdvanceOrder(orderId) {
  const o = advanceOrders.find(x => x.id === orderId);
  if (o) { o.status = 'cancelled'; saveAdvanceOrders(); }
}

function deleteAdvanceOrder(orderId) {
  advanceOrders = advanceOrders.filter(x => x.id !== orderId);
  saveAdvanceOrders();
}

function updateAdvanceOrder(orderId, data) {
  const o = advanceOrders.find(x => x.id === orderId);
  if (!o) return;
  if (data.customerId !== undefined) { o.customerId = data.customerId; o.customerName = getCustomer(data.customerId)?.name || 'Desconocido'; }
  if (data.productId !== undefined) { o.productId = data.productId; o.productName = getProduct(data.productId)?.name || 'Desconocido'; }
  if (data.qty !== undefined) o.qty = Number(data.qty);
  if (data.price !== undefined) o.price = Number(data.price);
  if (data.route !== undefined) o.route = data.route;
  if (data.instructions !== undefined) o.instructions = data.instructions;
  if (data.date !== undefined) o.date = data.date;
  if (data.tripId !== undefined) o.tripId = data.tripId;
  if (data.skipReason !== undefined) o.skipReason = data.skipReason;
  if (data.skipNote !== undefined) o.skipNote = data.skipNote;
  if (data.devolucionKg !== undefined) o.devolucionKg = Number(data.devolucionKg);
  if (data.recompraKg !== undefined) o.recompraKg = Number(data.recompraKg);
  if (data.deliveredKg !== undefined) o.deliveredKg = Number(data.deliveredKg);
  if (data.creditAmount !== undefined) o.creditAmount = Number(data.creditAmount);
  if (data.creditPaidType !== undefined) o.creditPaidType = data.creditPaidType;
  if (data.creditPaidAmount !== undefined) o.creditPaidAmount = Number(data.creditPaidAmount);
  if (data.recurrence !== undefined) o.recurrence = data.recurrence && data.recurrence.preset !== 'none' ? data.recurrence : null;
  if (data.originOrderId !== undefined) o.originOrderId = data.originOrderId;
  if (data.source !== undefined) o.source = data.source;
  saveAdvanceOrders();
}

// ─── RECURRING ORDERS ───────────────────────────────────
// Generates today's pending order for every active recurrence
// template. Idempotent: never creates a duplicate for the same
// origin + date. Cancelled/deleted templates stop generation.
function isRecurrenceDate(anchor, r, dateStr) {
  if (dateStr < anchor) return false;
  if (r.endType === 'date' && r.endDate && dateStr > r.endDate) return false;
  const fu = r.frequencyUnit || 'weeks';
  const fv = Math.max(1, r.frequencyValue || 1);
  const start = new Date(anchor + 'T12:00:00');
  const target = new Date(dateStr + 'T12:00:00');
  const diffDays = Math.round((target - start) / 86400000);

  if (fu === 'days') return diffDays % fv === 0;
  if (fu === 'weeks') {
    const dw = r.daysOfWeek && r.daysOfWeek.length ? r.daysOfWeek : [start.getDay()];
    if (!dw.includes(target.getDay())) return false;
    return Math.floor(diffDays / 7) % fv === 0;
  }
  if (fu === 'months') {
    const monthsDiff = (target.getFullYear() - start.getFullYear()) * 12 + (target.getMonth() - start.getMonth());
    return monthsDiff % fv === 0 && target.getDate() === start.getDate();
  }
  if (fu === 'years') {
    const yearsDiff = target.getFullYear() - start.getFullYear();
    return yearsDiff % fv === 0 && target.getMonth() === start.getMonth() && target.getDate() === start.getDate();
  }
  return false;
}

function processRecurrences(dateStr) {
  const d = dateStr || today();
  const templates = advanceOrders.filter(o =>
    o.recurrence && o.recurrence.preset && o.recurrence.preset !== 'none' && o.status === 'pending'
  );
  let created = 0;
  templates.forEach(t => {
    const r = t.recurrence;
    const anchor = t.date || d;
    if (!isRecurrenceDate(anchor, r, d)) return;
    const originId = t.originOrderId || t.id;
    if (r.endType === 'occurrences') {
      const count = advanceOrders.filter(o => (o.originOrderId || o.id) === originId).length;
      if (count >= (r.endOccurrences || 1)) return;
    }
    const exists = advanceOrders.some(o => (o.originOrderId || o.id) === originId && o.date === d);
    if (exists) return;
    const c = getCustomer(t.customerId);
    const p = getProduct(t.productId);
    advanceOrders.push({
      id: genId(),
      customerId: t.customerId,
      customerName: c ? c.name : t.customerName,
      productId: t.productId,
      productName: p ? p.name : t.productName,
      qty: Number(t.qty),
      price: Number(t.price),
      route: t.route,
      instructions: t.instructions || '',
      date: d,
      status: 'pending',
      tripId: null,
      skipReason: null,
      skipNote: null,
      devolucionKg: 0,
      recompraKg: 0,
      deliveredKg: 0,
      creditAmount: 0,
      creditPaidType: null,
      creditPaidAmount: 0,
      recurrence: null,
      originOrderId: originId,
      source: 'recurring',
      recurringFrom: t.id,
    });
    created++;
  });
  if (created > 0) saveAdvanceOrders();
  return created;
}

// ─── CUSTOMER CRUD ──────────────────────────────────────
function addCustomer(data) {
  const ids = CLIENTES.map(c => Number(c.id.slice(1))).sort((a, b) => a - b);
  const nextNum = ids.length > 0 ? ids[ids.length - 1] + 1 : 1;
  const c = {
    id: 'C' + nextNum,
    name: data.name,
    contact: data.contact || '',
    phone: data.phone || '',
    direccion: data.direccion || '',
    route: data.route || ROUTES[0],
    paymentTerm: data.paymentTerm || 'COD',
    creditLimit: Number(data.creditLimit) || 0,
    defaultPrice: Number(data.defaultPrice) || 0,
    recurrence: data.recurrence || null,
    balance: 0,
  };
  CLIENTES.push(c);
  saveClients();
  return c;
}

function updateCustomer(id, data) {
  const c = CLIENTES.find(x => x.id === id);
  if (!c) return null;
  Object.assign(c, data);
  saveClients();
  return c;
}

function deleteCustomer(id) {
  const idx = CLIENTES.findIndex(x => x.id === id);
  if (idx === -1) return false;
  CLIENTES.splice(idx, 1);
  advanceOrders = advanceOrders.filter(o => o.customerId !== id);
  saveClients();
  saveAdvanceOrders();
  return true;
}

// ─── BACKUP / RESTORE ───────────────────────────────────
function exportBackup() {
  const data = {};
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.indexOf('elcomal_') === 0) {
      data[key] = localStorage.getItem(key);
    }
  }
  return data;
}

function backupSummary(data) {
  const count = (k) => {
    try { const v = JSON.parse(data[k]); return Array.isArray(v) ? v.length : 0; } catch (e) { return 0; }
  };
  const parts = [];
  if (data.elcomal_clientes) parts.push(count('elcomal_clientes') + ' clientes');
  if (data.elcomal_orders) parts.push(count('elcomal_orders') + ' órdenes');
  if (data.elcomal_trips) parts.push(count('elcomal_trips') + ' rutas');
  if (data.elcomal_settlements) parts.push(count('elcomal_settlements') + ' cortes');
  if (data.elcomal_payments) parts.push(count('elcomal_payments') + ' pagos');
  if (data.elcomal_futureOrders) parts.push(count('elcomal_futureOrders') + ' pedidos futuros');
  const dyn = Object.keys(data).filter(k => k.indexOf('elcomal_stops_') === 0 || k.indexOf('elcomal_session_') === 0).length;
  if (dyn) parts.push(dyn + ' paradas/sesiones');
  return parts.join(', ') || 'datos';
}

function _parseBackupText(text) {
  let t = String(text || '').trim();
  if (t.charCodeAt(0) === 0xFEFF) t = t.slice(1).trim();
  try { return JSON.parse(t); } catch (e) {}
  const start = t.indexOf('{');
  const end = t.lastIndexOf('}');
  if (start !== -1 && end > start) {
    try { return JSON.parse(t.slice(start, end + 1)); } catch (e) {}
  }
  return null;
}

function importBackup(jsonText) {
  const data = _parseBackupText(jsonText);
  if (!data) return { ok: false, error: 'El texto no es un JSON válido. Pulsa "Generar texto del respaldo" y copia ese texto completo.' };
  if (typeof data !== 'object' || Array.isArray(data)) return { ok: false, error: 'El respaldo no tiene un formato válido.' };
  const keys = Object.keys(data).filter(k => k.indexOf('elcomal_') === 0);
  if (keys.length === 0) return { ok: false, error: 'El respaldo no contiene datos de El Comal (claves elcomal_*).' };

  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  const preKey = 'elcomal_preimport_backup_' + ts;
  const pre = {};
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.indexOf('elcomal_') === 0) pre[key] = localStorage.getItem(key);
  }
  localStorage.setItem(preKey, JSON.stringify(pre));

  keys.forEach(k => {
    try { localStorage.setItem(k, data[k]); } catch (e) {}
  });
  return { ok: true, preKey, summary: backupSummary(data) };
}

function restorePreImportBackup() {
  let preKey = null, preData = null;
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.indexOf('elcomal_preimport_backup_') === 0) {
      preKey = key;
      try { preData = JSON.parse(localStorage.getItem(key)); } catch (e) {}
    }
  }
  if (!preData) return false;
  Object.keys(preData).forEach(k => { try { localStorage.setItem(k, preData[k]); } catch (e) {} });
  if (preKey) localStorage.removeItem(preKey);
  return true;
}
