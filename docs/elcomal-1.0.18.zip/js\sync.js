// ─── FIREBASE SYNC LAYER ─────────────────────────────────
// Loaded FIRST (before persistence.js). Two responsibilities:
//   1. Background pull: fetch kv/<key> docs from Firestore and
//      write newer ones to localStorage. If anything changed,
//      reload once so the app boots on fresh data.
//   2. Write interception: every localStorage elcomal_* write is
//      timestamped; a debounced push uploads changed keys to
//      Firestore. Works offline (queued locally, synced on next
//      successful online push).
//
// If Firebase config is missing or offline, the app runs exactly
// as before (localStorage only). 

// ─── CONFIG (populate from your Firebase project) ─────────
// https://console.firebase.google.com -> Project settings -> SDK setup
const SYNC_COLLECTION = 'kv';
const META_KEY = 'elcomal_sync_meta';     // { key: lastPushedTimestamp }
const SKIP_KEYS = ['elcomal_sync_meta', 'elcomal_schema_ver'];

// Allow runtime override (used in tests) — window.__FIREBASE_CONFIG wins
const FIREBASE_CONFIG = (typeof window !== 'undefined' && window.__FIREBASE_CONFIG)
  ? window.__FIREBASE_CONFIG
  : {
      apiKey: 'AIzaSyDfz4r-C9SWzhjkatEk4ngGZk2Ogli1Jxc',
      authDomain: 'delivery-app-49eab.firebaseapp.com',
      projectId: 'delivery-app-49eab',
      appId: '1:1005979978877:web:8c5b9f7a0e3d1c4b',
    };

// ─── Write interception (installed synchronously) ─────────
(function installInterception() {
  const orig = Storage.prototype.setItem;
  Storage.prototype.setItem = function (key, value) {
    const res = orig.call(this, key, value);
    try {
      if (typeof key === 'string' && key.indexOf('elcomal_') === 0 && !SKIP_KEYS.includes(key)) {
        schedulePush();
      }
    } catch (e) {}
    return res;
  };
})();

// ─── State ────────────────────────────────────────────────
let firebase = null;          // { app, auth, db }
let pushTimer = null;
let online = typeof navigator !== 'undefined' && navigator.onLine;

function getMeta() {
  try { return JSON.parse(localStorage.getItem(META_KEY) || '{}'); } catch (e) { return {}; }
}
function setMeta(m) {
  try { localStorage.setItem(META_KEY, JSON.stringify(m)); } catch (e) {}
}

// ─── Firebase init (lazy, CDN import with timeout) ────────
async function initFirebase() {
  if (firebase) return firebase;
  if (!FIREBASE_CONFIG.apiKey || !FIREBASE_CONFIG.projectId) return null;
  try {
    const base = 'https://www.gstatic.com/firebasejs/10.12.0';
    const [{ initializeApp }, { getAuth, signInAnonymously }, { getFirestore }] = await Promise.all([
      import(base + '/firebase-app.js'),
      import(base + '/firebase-auth.js'),
      import(base + '/firebase-firestore.js'),
    ]);
    const app = initializeApp(FIREBASE_CONFIG);
    const auth = getAuth(app);
    await signInAnonymously(auth);
    const db = getFirestore(app);
    firebase = { app, auth, db };
    return firebase;
  } catch (e) {
    console.error('sync: Firebase init failed', e);
    return null;
  }
}

// ─── Delete remote keys ───────────────────────────────────
// Removes kv/<key> docs from Firestore so a cleanup can't be
// re-pulled later. Also bumps the local meta timestamps so pull()
// never restores these keys (works offline: docs stay orphaned in
// the cloud but are never written back locally).
async function clearRemoteKeys(keys) {
  const meta = getMeta();
  for (const k of keys) {
    meta[k] = Date.now();
  }
  setMeta(meta);
  try {
    const fb = await initFirebase();
    if (fb) {
      const { doc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
      for (const k of keys) {
        try { await deleteDoc(doc(fb.db, SYNC_COLLECTION, k)); } catch (e) {}
      }
    }
  } catch (e) {}
}

// ─── Pull ─────────────────────────────────────────────────
async function pull() {
  const fb = await initFirebase();
  if (!fb) return false;
  const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  try {
    const snap = await getDocs(collection(fb.db, SYNC_COLLECTION));
    let changed = false;
    snap.docs.forEach(doc => {
      const key = doc.id;
      if (key.indexOf('elcomal_') !== 0 || SKIP_KEYS.includes(key)) return;
      const docData = doc.data() || {};
      const remoteTs = Number(docData.updatedAt) || 0;
      const meta = getMeta();
      const localTs = Number(meta[key]) || 0;
      if (remoteTs > localTs && typeof docData.data === 'string') {
        try {
          localStorage.setItem(key, docData.data);
          meta[key] = remoteTs;
          setMeta(meta);
          changed = true;
        } catch (e) {}
      }
    });
    return changed;
  } catch (e) {
    console.error('sync: pull failed', e);
    return false;
  }
}

// ─── Push ─────────────────────────────────────────────────
async function push() {
  const fb = await initFirebase();
  if (!fb) return;
  const { doc, setDoc } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  const meta = getMeta();
  const keys = [];
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.indexOf('elcomal_') === 0 && !SKIP_KEYS.includes(k)) keys.push(k);
  }
  for (const k of keys) {
    const ts = Number(meta[k]) || 0;
    const val = localStorage.getItem(k);
    if (val === null) continue;
    try {
      await setDoc(doc(fb.db, SYNC_COLLECTION, k), {
        data: val,
        updatedAt: Date.now(),
      });
      meta[k] = Date.now();
    } catch (e) {
      console.error('sync: push failed for ' + k, e);
    }
  }
  setMeta(meta);
}

function schedulePush() {
  if (pushTimer) clearTimeout(pushTimer);
  pushTimer = setTimeout(() => { pushTimer = null; push(); }, 3000);
}

// ─── Events ───────────────────────────────────────────────
if (typeof document !== 'undefined') {
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      if (pushTimer) { clearTimeout(pushTimer); pushTimer = null; }
      push();
    } else if (document.visibilityState === 'visible') {
      online = navigator.onLine;
      pull().then(changed => { if (changed) location.reload(); });
    }
  });
  window.addEventListener('online', () => { online = true; pull().then(changed => { if (changed) location.reload(); }); });
  window.addEventListener('offline', () => { online = false; });
}

// ─── Startup ──────────────────────────────────────────────
// Pull in the background; if remote data is newer, reload once
// so the app initializes from fresh data.
if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    pull().then(changed => { if (changed) location.reload(); });
  });
}

// ─── Test hooks (harmless in production) ──────────────────
window.SyncDebug = { pull, push, getMeta, setMeta, initFirebase, clearRemoteKeys };

