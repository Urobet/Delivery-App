// ─── FIREBASE SYNC LAYER ─────────────────────────────────
// Loaded FIRST (before persistence.js). Responsibilities:
//   1. Per-record sync for contended data (orders, trips,
//      settlements): each record is its own Firestore doc, so
//      two drivers editing different records never clobber each
//      other. Real-time onSnapshot pushes changes live (~1s).
//   2. Whole-array sync for low-contention data (clients, users,
//      prices, future orders, payments, street sales, opening
//      debts): one doc per localStorage key, merged in-place.
//   3. Transactional order claim on trip creation, so two drivers
//      can't grab the same order.
//   4. Write interception: every localStorage elcomal_* write is
//      timestamped; a debounced push uploads changed records.
//      Works offline (queued locally, synced on next success).
//
// If Firebase config is missing or offline, the app runs exactly
// as before (localStorage only).

// ─── Environment isolation ────────────────────────────────
// The Capacitor app (phone) is production: it owns the real cloud
// data in collection `kv`. A local browser sandbox must NEVER touch
// that collection — it writes to `kv_dev` instead, with its own meta
// key, so sandbox test data can't sync to the phone (or vice versa).
const IS_NATIVE = typeof window !== 'undefined' && window.Capacitor &&
  (window.Capacitor.Plugins || window.Capacitor.nativePromise);

const SYNC_COLLECTION = IS_NATIVE ? 'kv' : 'kv_dev';
const META_KEY = IS_NATIVE ? 'elcomal_sync_meta' : 'elcomal_sync_meta_dev'; // { key: lastPushedTimestamp }
const V2_FLAG = 'elcomal_sync_v2';

// Keys that are NEVER synced (device-local).
const SKIP_KEYS = [
  'elcomal_sync_meta', 'elcomal_sync_meta_dev',
  'elcomal_schema_ver', 'elcomal_sync_reconciled',
  'elcomal_session',
];
// Prefixes that are NEVER synced (device-local working state).
const SKIP_PREFIXES = ['elcomal_stops_', 'elcomal_session_'];

// Record collections: each record is its own Firestore doc.
//   docPrefix  -> Firestore doc id prefix
//   localKey   -> localStorage array key
//   idField    -> record's unique id field
//   updatedAt  -> record's updatedAt field (for conflict resolution)
const RECORD_COLLECTIONS = [
  { docPrefix: 'order__',       localKey: 'elcomal_orders',       idField: 'id',   updatedAt: 'updatedAt' },
  { docPrefix: 'trip__',        localKey: 'elcomal_trips',        idField: 'id',   updatedAt: 'updatedAt' },
  { docPrefix: 'settlement__',  localKey: 'elcomal_settlements',  idField: 'date', updatedAt: 'timestamp' },
  { docPrefix: 'user__',        localKey: 'elcomal_users',        idField: 'id',   updatedAt: 'updatedAt' },
  { docPrefix: 'event__',       localKey: 'elcomal_outbox',       idField: 'id',   updatedAt: 'updatedAt' },
  { docPrefix: 'erpmap__',      localKey: 'elcomal_erp_map',      idField: 'id',   updatedAt: 'updatedAt' },
];
// Whole-array keys (one doc per localStorage key).
const ARRAY_KEYS = [
  'elcomal_clientes', 'elcomal_productCatalog', 'elcomal_productPrices',
  'elcomal_futureOrders', 'elcomal_payments', 'elcomal_streetSales',
  'elcomal_openingDebts',
];

function isRecordDocId(id) { return RECORD_COLLECTIONS.some(c => id.indexOf(c.docPrefix) === 0); }
function isSkippedKey(k) {
  if (SKIP_KEYS.includes(k)) return true;
  return SKIP_PREFIXES.some(p => k.indexOf(p) === 0);
}
function isSkippedDocId(id) {
  if (isSkippedKey(id)) return true;
  // Legacy whole-array docs for record collections must be ignored —
  // real data now lives in per-record docs (user__, order__, trip__,
  // settlement__). Old devices may still push these; don't let them
  // clobber the per-record state.
  if (RECORD_COLLECTIONS.some(c => c.localKey === id)) return true;
  if (ARRAY_KEYS.includes(id)) return false;
  if (isRecordDocId(id)) return false;
  // Unknown doc id — treat as array key (legacy whole-array docs).
  return false;
}

// Allow runtime override (used in tests) — window.__FIREBASE_CONFIG wins
const FIREBASE_CONFIG = (typeof window !== 'undefined' && window.__FIREBASE_CONFIG)
  ? window.__FIREBASE_CONFIG
  : {
      apiKey: 'AIzaSyDfz4r-C9SWzhjkatEk4ngGZk2Ogli1Jxc',
      authDomain: 'delivery-app-49eab.firebaseapp.com',
      projectId: 'delivery-app-49eab',
      appId: '1:1005979978877:web:8c5b9f7a0e3d1c4b',
    };

// ─── Write interception (installed synchronously) ─────────
(function installInterception() {
  const orig = Storage.prototype.setItem;
  Storage.prototype.setItem = function (key, value) {
    const res = orig.call(this, key, value);
    try {
      if (typeof key === 'string' && key.indexOf('elcomal_') === 0 && !isSkippedKey(key)) {
        schedulePush();
      }
    } catch (e) {}
    return res;
  };
})();

// ─── State ────────────────────────────────────────────────
let firebase = null;          // { app, auth, db }
let pushTimer = null;
let unsubSnapshot = null;
let online = typeof navigator !== 'undefined' && navigator.onLine;

function getMeta() {
  try { return JSON.parse(localStorage.getItem(META_KEY) || '{}'); } catch (e) { return {}; }
}
function setMeta(m) {
  try { localStorage.setItem(META_KEY, JSON.stringify(m)); } catch (e) {}
}

// ─── Firebase init (lazy, CDN import with timeout) ────────
async function initFirebase() {
  if (firebase) return firebase;
  if (!FIREBASE_CONFIG.apiKey || !FIREBASE_CONFIG.projectId) return null;
  try {
    const base = 'https://www.gstatic.com/firebasejs/10.12.0';
    const [{ initializeApp }, { getAuth, signInAnonymously }, { getFirestore }] = await Promise.all([
      import(base + '/firebase-app.js'),
      import(base + '/firebase-auth.js'),
      import(base + '/firebase-firestore.js'),
    ]);
    const app = initializeApp(FIREBASE_CONFIG);
    const auth = getAuth(app);
    await signInAnonymously(auth);
    const db = getFirestore(app);
    firebase = { app, auth, db };
    return firebase;
  } catch (e) {
    console.error('sync: Firebase init failed', e);
    return null;
  }
}

// ─── Record helpers ───────────────────────────────────────
function _readLocalArray(key) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : [];
  } catch (e) { return []; }
}
function _writeLocalArray(key, arr) {
  try { localStorage.setItem(key, JSON.stringify(arr)); } catch (e) {}
}
function _recordUpdatedAt(rec, col) {
  const v = rec && rec[col.updatedAt || 'updatedAt'];
  return Number(new Date(v).getTime()) || 0;
}

// ─── Migration: fan out local records to per-record docs ──
// On first launch after upgrade, push every local order/trip/
// settlement as its own doc (idempotent). Then delete the stale
// whole-array docs for those keys so pull() can't restore them.
async function migrateToRecords() {
  try { if (localStorage.getItem(V2_FLAG) === '2') return; } catch (e) {}
  const fb = await initFirebase();
  if (!fb) return;
  const { doc, setDoc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  try {
    for (const col of RECORD_COLLECTIONS) {
      const arr = _readLocalArray(col.localKey);
      for (const rec of arr) {
        const id = rec[col.idField];
        if (!id) continue;
        try {
          await setDoc(doc(fb.db, SYNC_COLLECTION, col.docPrefix + id), {
            data: JSON.stringify(rec),
            updatedAt: _recordUpdatedAt(rec, col) || Date.now(),
          });
        } catch (e) {}
      }
      // Delete stale whole-array doc (if any) so pull() can't restore it.
      try { await deleteDoc(doc(fb.db, SYNC_COLLECTION, col.localKey)); } catch (e) {}
    }
    try { localStorage.setItem(V2_FLAG, '2'); } catch (e) {}
  } catch (e) {
    console.error('sync: migration failed', e);
  }
}

// ─── Shadow diff push ─────────────────────────────────────
// Persist a shadow of each record collection in meta. On setItem
// of a record key, diff old vs new by record id → push changed
// records as their own docs; deleteDoc removed records.
function _shadowKey(col) { return 'shadow_' + col.localKey; }

function _loadShadow(col) {
  const s = getMeta()[_shadowKey(col)];
  try { return s ? JSON.parse(s) : []; } catch (e) { return []; }
}
function _saveShadow(col, arr) {
  const m = getMeta();
  m[_shadowKey(col)] = JSON.stringify(arr);
  setMeta(m);
}

// UI-only state must not ride the sync layer: `expanded` on trips is
// per-device view state, and pushing it bumps updatedAt so a card
// expand could revert a concurrent ownership transfer (LWW).
function stripTripUiState(rec) {
  if (!rec || rec.expanded === undefined) return rec;
  const copy = { ...rec };
  delete copy.expanded;
  return copy;
}

async function pushRecordCollection(col) {
  const fb = await initFirebase();
  if (!fb) return;
  const { doc, setDoc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  const current = _readLocalArray(col.localKey);
  const shadow = _loadShadow(col);
  const shadowById = new Map(shadow.map(r => [r[col.idField], r]));
  const currentById = new Map(current.map(r => [r[col.idField], r]));

  // Removed records → delete remote doc.
  for (const [id] of shadowById) {
    if (!currentById.has(id)) {
      try { await deleteDoc(doc(fb.db, SYNC_COLLECTION, col.docPrefix + id)); } catch (e) {}
    }
  }
  // Added / changed records → push.
  for (const raw of current) {
    const id = raw[col.idField];
    if (!id) continue;
    const rec = col.docPrefix === 'trip__' ? stripTripUiState(raw) : raw;
    const old = shadowById.get(id);
    const isNew = !old;
    const changed = old && JSON.stringify(stripTripUiState(old)) !== JSON.stringify(rec);
    if (isNew || changed) {
      try {
        await setDoc(doc(fb.db, SYNC_COLLECTION, col.docPrefix + id), {
          data: JSON.stringify(rec),
          updatedAt: _recordUpdatedAt(rec, col) || Date.now(),
        });
      } catch (e) {
        console.error('sync: push failed for ' + col.docPrefix + id, e);
      }
    }
  }
  _saveShadow(col, current);
}

// ─── Whole-array push ─────────────────────────────────────
async function pushArrayKey(k) {
  const fb = await initFirebase();
  if (!fb) return;
  const { doc, setDoc } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  const val = localStorage.getItem(k);
  if (val === null) return;
  try {
    await setDoc(doc(fb.db, SYNC_COLLECTION, k), {
      data: val,
      updatedAt: Date.now(),
    });
    const meta = getMeta();
    meta[k] = Date.now();
    setMeta(meta);
  } catch (e) {
    console.error('sync: push failed for ' + k, e);
  }
}

// ─── Pull (one-shot, used at startup / visibility) ────────
async function pull() {
  const fb = await initFirebase();
  if (!fb) return false;
  const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  try {
    const snap = await getDocs(collection(fb.db, SYNC_COLLECTION));
    let changed = false;
    snap.docs.forEach(doc => {
      const id = doc.id;
      if (isSkippedDocId(id)) return;
      const docData = doc.data() || {};
      const remoteTs = Number(docData.updatedAt) || 0;
      if (isRecordDocId(id)) {
        changed = mergeRecordDoc(id, docData.data, remoteTs) || changed;
      } else {
        changed = mergeArrayDoc(id, docData.data, remoteTs) || changed;
      }
    });
    if (changed) {
      selfHealTrips();
      notifyChanged();
    }
    return changed;
  } catch (e) {
    console.error('sync: pull failed', e);
    return false;
  }
}

function mergeArrayDoc(key, dataStr, remoteTs) {
  if (typeof dataStr !== 'string') return false;
  const meta = getMeta();
  const localTs = Number(meta[key]) || 0;
  if (remoteTs <= localTs) return false;
  try {
    localStorage.setItem(key, dataStr);
    meta[key] = remoteTs;
    setMeta(meta);
    return true;
  } catch (e) { return false; }
}

function mergeRecordDoc(id, dataStr, remoteTs) {
  if (typeof dataStr !== 'string') return false;
  const col = RECORD_COLLECTIONS.find(c => id.indexOf(c.docPrefix) === 0);
  if (!col) return false;
  let rec;
  try { rec = JSON.parse(dataStr); } catch (e) { return false; }
  const recId = rec && rec[col.idField];
  if (!recId) return false;
  const arr = _readLocalArray(col.localKey);
  const idx = arr.findIndex(r => r[col.idField] === recId);
  if (idx >= 0) {
    const localTs = _recordUpdatedAt(arr[idx], col);
    if (remoteTs <= localTs) return false;
    // Preserve per-device UI state on trips.
    if (col.docPrefix === 'trip__' && arr[idx].expanded !== undefined) {
      rec.expanded = arr[idx].expanded;
    }
    arr[idx] = rec;
  } else {
    arr.push(rec);
  }
  _writeLocalArray(col.localKey, arr);
  // Keep shadow in sync so we don't re-push what we just merged.
  const shadow = _loadShadow(col);
  const sIdx = shadow.findIndex(r => r[col.idField] === recId);
  if (sIdx >= 0) shadow[sIdx] = rec; else shadow.push(rec);
  _saveShadow(col, shadow);
  return true;
}

// ─── Trip self-healing ────────────────────────────────────
// Re-derive each trip's orderIds from the orders (o.tripId === trip.id)
// so a stale trip drops orders claimed by another driver.
// IMPORTANT: an order that is unknown locally must NOT strip the trip —
// Firestore may deliver the trip doc before its order docs, and stripping
// here cascades into pruneGhostTrips deleting the trip (and its remote
// doc) on devices that simply haven't merged the orders yet.
function selfHealTrips() {
  try {
    const trips = _readLocalArray('elcomal_trips');
    const orders = _readLocalArray('elcomal_orders');
    let changed = false;
    trips.forEach(t => {
      const valid = (t.orderIds || []).filter(oid => {
        const o = orders.find(x => x.id === oid);
        return !o || o.tripId === t.id; // unknown order → keep it
      });
      if (valid.length !== (t.orderIds || []).length) {
        t.orderIds = valid;
        changed = true;
      }
    });
    if (changed) _writeLocalArray('elcomal_trips', trips);
  } catch (e) {}
}

// ─── Notify the app that data changed (no reload) ─────────
function notifyChanged() {
  try {
    if (typeof App !== 'undefined' && App.reloadData) App.reloadData();
  } catch (e) {}
}

// ─── Real-time subscription ───────────────────────────────
async function subscribe() {
  const fb = await initFirebase();
  if (!fb) return;
  const { collection, onSnapshot } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  if (unsubSnapshot) return;
  unsubSnapshot = onSnapshot(collection(fb.db, SYNC_COLLECTION), (snap) => {
    let changed = false;
    snap.docChanges().forEach(change => {
      const id = change.doc.id;
      if (isSkippedDocId(id)) return;
      const docData = change.doc.data() || {};
      const remoteTs = Number(docData.updatedAt) || 0;
      if (change.type === 'removed') {
        changed = removeRecordDoc(id) || changed;
      } else if (isRecordDocId(id)) {
        changed = mergeRecordDoc(id, docData.data, remoteTs) || changed;
      } else {
        changed = mergeArrayDoc(id, docData.data, remoteTs) || changed;
      }
    });
    if (changed) {
      selfHealTrips();
      notifyChanged();
    }
  }, (err) => {
    console.error('sync: onSnapshot error', err);
  });
}

function removeRecordDoc(id) {
  const col = RECORD_COLLECTIONS.find(c => id.indexOf(c.docPrefix) === 0);
  if (!col) return false;
  const recId = id.slice(col.docPrefix.length);
  const arr = _readLocalArray(col.localKey);
  const before = arr.length;
  const next = arr.filter(r => r[col.idField] !== recId);
  if (next.length === before) return false;
  _writeLocalArray(col.localKey, next);
  const shadow = _loadShadow(col).filter(r => r[col.idField] !== recId);
  _saveShadow(col, shadow);
  return true;
}

// ─── Push ─────────────────────────────────────────────────
async function push() {
  const fb = await initFirebase();
  if (!fb) return;
  // Record collections → per-record diff push.
  for (const col of RECORD_COLLECTIONS) {
    try { await pushRecordCollection(col); } catch (e) {}
  }
  // Whole-array keys → whole-doc push.
  for (const k of ARRAY_KEYS) {
    try { await pushArrayKey(k); } catch (e) {}
  }
  // Any other elcomal_* keys not in records/arrays → whole-doc push.
  const meta = getMeta();
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (!k || k.indexOf('elcomal_') !== 0 || isSkippedKey(k)) continue;
    if (RECORD_COLLECTIONS.some(c => c.localKey === k)) continue;
    if (ARRAY_KEYS.includes(k)) continue;
    try { await pushArrayKey(k); } catch (e) {}
  }
  void meta;
}

function schedulePush() {
  if (pushTimer) clearTimeout(pushTimer);
  pushTimer = setTimeout(() => { pushTimer = null; push(); }, 3000);
}

// ─── Transactional order claim ────────────────────────────
// Atomically claim orders for a new trip. Returns the claimed
// order ids; throws with the taken order ids if any are already
// claimed/completed.
async function claimOrders(orderIds, tripId, driverId, driverName) {
  const fb = await initFirebase();
  if (!fb) return orderIds; // offline → claim locally (deferred)
  const { doc, runTransaction } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  const taken = [];
  let txError = null;
  try {
    await runTransaction(fb.db, async (tx) => {
      for (const oid of orderIds) {
        const ref = doc(fb.db, SYNC_COLLECTION, 'order__' + oid);
        const snap = await tx.get(ref);
        if (snap.exists()) {
          const rec = JSON.parse(snap.data().data || '{}');
          if (rec.status !== 'pending' || rec.tripId) { taken.push(oid); continue; }
          rec.tripId = tripId;
          rec.claimedBy = driverId;
          rec.claimedByName = driverName;
          rec.claimedAt = new Date().toISOString();
          rec.updatedAt = new Date().toISOString();
          tx.set(ref, { data: JSON.stringify(rec), updatedAt: Date.now() });
        } else {
          // Doc doesn't exist in Firestore → unclaimed; write the claim.
          // If the order is unknown locally too, treat as taken to avoid orphans.
          const o = advanceOrders.find(x => x.id === oid);
          if (o) {
            const rec = { ...o, tripId, claimedBy: driverId, claimedByName: driverName,
                          claimedAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
            tx.set(ref, { data: JSON.stringify(rec), updatedAt: Date.now() });
          } else {
            taken.push(oid);
          }
        }
      }
    });
  } catch (e) {
    txError = e;
  }
  if (txError) {
    const err = new Error('claim_failed');
    err.cause = txError;
    err.taken = taken;
    throw err;
  }
  if (taken.length > 0) {
    const err = new Error('orders_taken');
    err.taken = taken;
    throw err;
  }
  return orderIds;
}

// ─── Transactional order transfer (takeover) ──────────────
// Moves pending orders from one trip to another atomically, so two
// drivers taking the same order race-resolve instead of clobbering.
// Returns { conflicts: [orderIds] } — empty on success.
async function transferOrders(orderIds, fromTripId, toTripId, driverId, driverName) {
  const fb = await initFirebase();
  if (!fb) return { conflicts: [] }; // offline → local change is authoritative
  const { doc, runTransaction } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  const conflicts = [];
  let txError = null;
  try {
    await runTransaction(fb.db, async (tx) => {
      const orderRefs = {};
      const recs = {};
      for (const oid of orderIds) {
        const ref = doc(fb.db, SYNC_COLLECTION, 'order__' + oid);
        orderRefs[oid] = ref;
        const snap = await tx.get(ref);
        if (!snap.exists()) { conflicts.push(oid); continue; }
        const rec = JSON.parse(snap.data().data || '{}');
        if (rec.status !== 'pending') { conflicts.push(oid); continue; }
        recs[oid] = rec;
      }
      if (conflicts.length) return;
      const now = Date.now();
      const fromRef = fromTripId ? doc(fb.db, SYNC_COLLECTION, 'trip__' + fromTripId) : null;
      const toRef = doc(fb.db, SYNC_COLLECTION, 'trip__' + toTripId);
      let fromRec = null, toRec = null;
      if (fromRef) {
        const fs = await tx.get(fromRef);
        if (fs.exists()) fromRec = JSON.parse(fs.data().data || '{}');
      }
      const ts = await tx.get(toRef);
      if (ts.exists()) toRec = JSON.parse(ts.data().data || '{}');
      for (const oid of orderIds) {
        const rec = recs[oid];
        rec.tripId = toTripId;
        rec.claimedBy = driverId;
        rec.claimedByName = driverName;
        rec.claimedAt = new Date().toISOString();
        rec.updatedAt = new Date().toISOString();
        tx.set(orderRefs[oid], { data: JSON.stringify(rec), updatedAt: now });
        if (fromRec) fromRec.orderIds = (fromRec.orderIds || []).filter(x => x !== oid);
        if (toRec) toRec.orderIds = [...(toRec.orderIds || []), oid];
      }
      if (fromRec) tx.set(fromRef, { data: JSON.stringify(fromRec), updatedAt: now });
      if (toRec) tx.set(toRef, { data: JSON.stringify(toRec), updatedAt: now });
    });
  } catch (e) {
    txError = e;
  }
  if (txError) return { conflicts: [], error: txError };
  return { conflicts };
}

// ─── Clear remote keys (cleanup) ──────────────────────────
async function clearRemoteKeys(keys) {
  const meta = getMeta();
  for (const k of keys) meta[k] = Date.now();
  setMeta(meta);
  try {
    const fb = await initFirebase();
    if (fb) {
      const { doc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
      for (const k of keys) {
        try { await deleteDoc(doc(fb.db, SYNC_COLLECTION, k)); } catch (e) {}
      }
    }
  } catch (e) {}
}

// ─── One-time production reconcile ────────────────────────
const RECONCILE_FLAG = 'elcomal_sync_reconciled';
async function reconcileLocal() {
  if (!IS_NATIVE) return false;
  try { if (localStorage.getItem(RECONCILE_FLAG) === '1') return false; } catch (e) {}
  const fb = await initFirebase();
  if (!fb) return false;
  const { collection, getDocs, doc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  try {
    const snap = await getDocs(collection(fb.db, SYNC_COLLECTION));
    const ids = snap.docs.map(d => d.id).filter(id => !isSkippedDocId(id));
    for (const id of ids) {
      try { await deleteDoc(doc(fb.db, SYNC_COLLECTION, id)); } catch (e) {}
    }
    try { localStorage.setItem(RECONCILE_FLAG, '1'); } catch (e) {}
    await push();
    return true;
  } catch (e) {
    console.error('sync: reconcile failed', e);
    return false;
  }
}

// ─── Events ───────────────────────────────────────────────
if (typeof document !== 'undefined') {
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      if (pushTimer) { clearTimeout(pushTimer); pushTimer = null; }
      push();
    } else if (document.visibilityState === 'visible') {
      online = navigator.onLine;
      pull().then(() => {});
    }
  });
  window.addEventListener('online', () => { online = true; pull().then(() => {}); });
  window.addEventListener('offline', () => { online = false; });
}

// ─── Startup ──────────────────────────────────────────────
// Migrate, pull, then subscribe for real-time.
if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    (async () => {
      await migrateToRecords();
      await pull();
      await subscribe();
    })();
  });
}

// ─── Test hooks (harmless in production) ──────────────────
window.SyncDebug = {
  pull, push, getMeta, setMeta, initFirebase, clearRemoteKeys, reconcileLocal,
  claimOrders, transferOrders, subscribe, migrateToRecords, isSkippedKey,
};