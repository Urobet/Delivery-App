// ─── ERP OUTBOX (integration boundary) ──────────────────
// Append-only event queue feeding the ERPNext worker. Events are
// regular per-record synced documents (event__{id} in the kv
// collection), so they flow to the cloud with the existing sync
// machinery — offline-safe, with automatic retry semantics.
//
// The APP never talks to an ERP. It only writes here. The worker
// (worker/erpnext-worker.js) consumes this queue and writes back
// erpRef mappings into elcomal_erp_map.
//
// Rounding discipline: money in the app is untouched; round2() is
// applied ONLY here, when serializing the outbound payload.
//
// Load AFTER data.js (uses round2/genId), BEFORE screens.js.

const ErpOutbox = {
  OUTBOX_KEY: 'elcomal_outbox',
  MAP_KEY: 'elcomal_erp_map',

  _load(key) {
    try { return DB.Storage.get(key, []); } catch (e) { return []; }
  },
  _save(key, arr) {
    try { DB.Storage.set(key, arr); } catch (e) {}
  },

  // --- local-id → erp-id mapping ---
  getMapping(localType, localId) {
    return this._load(this.MAP_KEY).find(m => m.localType === localType && m.localId === localId) || null;
  },
  setMapping(localType, localId, erpType, erpId) {
    const all = this._load(this.MAP_KEY);
    let m = all.find(x => x.localType === localType && x.localId === localId);
    if (m) { m.erpType = erpType; m.erpId = erpId; m.syncedAt = new Date().toISOString(); }
    else {
      m = {
        id: 'map_' + genId(),
        localType, localId, erpType, erpId,
        syncedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      all.push(m);
    }
    this._save(this.MAP_KEY, all);
    return m;
  },

  // --- events ---------------------------------------------------------
  _loadOutbox() { return this._load(this.OUTBOX_KEY); },
  _saveOutbox(arr) { this._save(this.OUTBOX_KEY, arr); },

  // Emit an event. Dedupes by idempotencyKey while a matching event is
  // still pending/failed — retry storms can't stack duplicates.
  emit(type, entity, entityId, payload, idempotencyKey) {
    const key = idempotencyKey || (type + ':' + entityId);
    const existing = this._loadOutbox().find(e =>
      e.idempotencyKey === key && e.status !== 'failed');
    if (existing) return existing;
    const ev = {
      id: 'evt_' + genId(),
      type,                    // 'customer.upsert' | 'settlement.close'
      entity,                  // 'Customer' | 'Settlement'
      entityId,
      idempotencyKey: key,
      payload,                 // already boundary-rounded by the caller
      status: 'pending',       // pending | sent | failed
      attempts: 0,
      lastError: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      sentAt: null,
      erpRef: null,
    };
    const all = this._loadOutbox();
    all.push(ev);
    this._saveOutbox(all);
    return ev;
  },

  // Worker writes back: mark sent with the ERP document reference.
  markSent(eventId, erpRef) {
    const all = this._loadOutbox();
    const ev = all.find(e => e.id === eventId);
    if (!ev) return null;
    ev.status = 'sent';
    ev.erpRef = erpRef || null;
    ev.sentAt = new Date().toISOString();
    ev.updatedAt = new Date().toISOString();
    ev.lastError = null;
    this._saveOutbox(all);
    return ev;
  },

  // Worker records a failed attempt (with backoff bookkeeping).
  markFailed(eventId, error, attempts) {
    const all = this._loadOutbox();
    const ev = all.find(e => e.id === eventId);
    if (!ev) return null;
    ev.status = 'failed';
    ev.lastError = String(error || '').slice(0, 500);
    ev.attempts = attempts !== undefined ? attempts : (ev.attempts || 0) + 1;
    ev.updatedAt = new Date().toISOString();
    this._saveOutbox(all);
    return ev;
  },

  // Admin retry: reset failed events so the worker picks them up again.
  retryFailed() {
    const all = this._loadOutbox();
    let n = 0;
    all.forEach(ev => {
      if (ev.status === 'failed') { ev.status = 'pending'; ev.updatedAt = new Date().toISOString(); n++; }
    });
    if (n > 0) this._saveOutbox(all);
    return n;
  },

  counts() {
    const all = this._loadOutbox();
    return {
      pending: all.filter(e => e.status === 'pending').length,
      sent: all.filter(e => e.status === 'sent').length,
      failed: all.filter(e => e.status === 'failed').length,
      total: all.length,
    };
  },

  // --- domain emitters ------------------------------------------------
  // Customer master data. Idempotency keyed on the customer's own
  // updatedAt so a re-save after a change emits a fresh event, but
  // unrelated re-renders never do.
  emitCustomerUpsert(customer) {
    if (!customer || !customer.id) return null;
    return this.emit(
      'customer.upsert', 'Customer', customer.id,
      {
        localId: customer.id,
        name: customer.name || '',
        email: customer.email || '',
        tax_id: customer.tax_id || '',
        phone: customer.phone || '',
        currency: customer.currency || 'MXN',
        payment_terms: customer.paymentTerm === 'credit' ? 'credit' : 'COD',
        credit_limit: round2(customer.creditLimit || 0),
        route: customer.route || '',
        address: {
          street: customer.street || customer.direccion || '',
          city: customer.city || '',
          state: customer.state || '',
          zip: customer.zip || '',
          country: customer.country || 'MX',
        },
        deleted: !!customer.deleted,
      },
      'customer.upsert:' + customer.id + ':' + (customer.updatedAt || customer.createdAt || customer.id)
    );
  },

  emitOrderCompleted(order, trip) {
    if (!order || !order.id || order.status !== 'completed') return null;
    const payload = {
      settlementDate: (order.completedAt || new Date().toISOString()).slice(0, 10),
      currency: 'MXN',
      driverId: order.completedBy || null,
      driverName: order.completedByName || null,
      stops: [{
        stopId: 'S-' + order.id,
        orderId: order.id,
        tripId: trip ? trip.id : order.tripId || null,
        customerId: order.customerId,
        customerName: order.customerName,
        productId: order.productId || null,
        deliveredKg: round2(order.deliveredKg || 0),
        extraKg: round2(order.extraKg || 0),
        devolucionKg: round2(order.devolucionKg || 0),
        recompraKg: round2(order.recompraKg || 0),
        recompraCollected: round2(order.recompraCollected || 0),
        unitPrice: round2(order.price || 0),
        creditAmount: round2(order.creditAmount || 0),
        creditPaidAmount: round2(order.creditPaidAmount || 0),
        oldDebtPaid: round2(order.oldDebtPaid || 0),
        completedAt: order.completedAt || null,
        completedBy: order.completedBy || null,
        completedByName: order.completedByName || null,
      }],
    };
    return this.emit('order.completed', 'Sales Invoice', order.id, payload, 'order.completed:' + order.id + ':' + (order.completedAt || order.updatedAt || ''));
  },

  // Settlement close. Payload = the full snapshot (self-contained:
  // every stop carries customer, kg, prices, cash, credit, returns).
  emitSettlementClose(snapshot) {
    if (!snapshot || !snapshot.date) return null;
    const stops = (snapshot.stops || []).filter(s => s.status === 'completed').map(s => ({
      stopId: s.stopId,
      orderId: s.orderId || null,
      customerId: s.customerId,
      customerName: s.customerName,
      productId: s.productId || null,
      deliveredKg: round2(s.deliveredKg || 0),
      extraKg: round2(s.extraKg || 0),
      devolucionKg: round2(s.devolucionKg || 0),
      recompraKg: round2(s.recompraKg || 0),
      recompraCollected: round2(s.recompraCollected || 0),
      unitPrice: round2(s.price !== undefined ? s.price : 0),
      creditAmount: round2(s.creditAmount || 0),
      creditPaidAmount: round2(s.creditPaidAmount || 0),
      oldDebtPaid: round2(s.oldDebtPaid || 0),
      tripId: s.tripId || null,
      completedBy: s.completedBy || null,
      completedByName: s.completedByName || snapshot.driverName || null,
      completedAt: s.completedAt || null,
    }));
    return this.emit(
      'settlement.close', 'Settlement', snapshot.date + '|' + snapshot.routeName,
      {
        settlementDate: snapshot.date,
        routeName: snapshot.routeName,
        driverName: snapshot.driverName || '',
        currency: snapshot.currency || 'MXN',
        totals: {
          startingInventory: round2(snapshot.startingInventory || 0),
          totalDelivered: round2(snapshot.totalDelivered || 0),
          totalExtraSold: round2(snapshot.totalExtraSold || 0),
          totalStaleReturned: round2(snapshot.totalStaleReturned || 0),
          totalRecompra: round2(snapshot.totalRecompra || 0),
          totalRecompraCollected: round2(snapshot.totalRecompraCollected || 0),
          totalCredited: round2(snapshot.totalCredited || 0),
          totalCash: round2(snapshot.totalCash || 0),
          totalCard: round2(snapshot.totalCard || 0),
          totalCollected: round2(snapshot.totalCollected || 0),
          streetTotal: round2(snapshot.streetTotal || 0),
          devValue: round2(snapshot.devValue || 0),
          brutoValue: round2(snapshot.brutoValue || 0),
        },
        stops,
      },
      'settlement.close:' + snapshot.date + ':' + snapshot.routeName
    );
  },

  // Find the settlement.close event for a given date+route (for the
  // posted/erpRef chip and the admin retry UI).
  settlementEvent(date, routeName) {
    return this._loadOutbox().find(e =>
      e.type === 'settlement.close' &&
      e.idempotencyKey === 'settlement.close:' + date + ':' + routeName) || null;
  },
};