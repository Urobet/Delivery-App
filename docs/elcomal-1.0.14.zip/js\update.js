const UPDATE_MANIFEST_URL = 'https://urobet.github.io/Delivery-App/version.json';
const UPDATE_BANNER_STORAGE_KEY = 'elcomal_update_ack';

let updateInfo = null;
let updateBusy = false;

function updaterApi() {
  if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater) {
    return window.Capacitor.Plugins.CapacitorUpdater;
  }
  const cap = window.Capacitor;
  return {
    download: (o) => cap.nativePromise('CapacitorUpdater', 'download', o),
    set: (o) => cap.nativePromise('CapacitorUpdater', 'set', o),
    reload: () => cap.nativePromise('CapacitorUpdater', 'reload', {})
  };
}

function isNative() {
  return !!(window.Capacitor && (window.Capacitor.Plugins || window.Capacitor.nativePromise));
}

function compareVersions(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const x = pa[i] || 0;
    const y = pb[i] || 0;
    if (x !== y) return x - y;
  }
  return 0;
}

async function checkForUpdate() {
  try {
    const res = await fetch(UPDATE_MANIFEST_URL + '?v=' + Date.now(), { cache: 'no-store' });
    if (!res.ok) return;
    updateInfo = await res.json();
    if (!updateInfo || !updateInfo.version) return;
    if (compareVersions(updateInfo.version, APP_VERSION) <= 0) return;
    const ack = localStorage.getItem(UPDATE_BANNER_STORAGE_KEY);
    if (ack === updateInfo.version) return;
    renderUpdateBanner();
  } catch (e) {}
}

function renderUpdateBanner() {
  let el = document.getElementById('update-banner');
  if (el) el.remove();
  el = document.createElement('div');
  el.id = 'update-banner';
  el.className = 'erp-update-banner';
  el.innerHTML =
    '<div class="erp-update-icon">📦</div>' +
    '<div class="erp-update-body">' +
      '<div class="erp-update-title">Actualización disponible</div>' +
      '<div class="erp-update-text">Nueva versión <b>' + updateInfo.version + '</b> lista. Se instalará sin borrar tus datos.</div>' +
      '<div class="erp-update-actions">' +
        '<button class="erp-btn erp-btn-sm erp-btn-primary" id="update-install-btn">Descargar e instalar</button>' +
        '<button class="erp-update-dismiss" id="update-dismiss-btn">Ahora no</button>' +
      '</div>' +
    '</div>';
  document.body.appendChild(el);

  const btn = document.getElementById('update-install-btn');
  if (btn) btn.addEventListener('click', installUpdate);

  const dismiss = document.getElementById('update-dismiss-btn');
  if (dismiss) dismiss.addEventListener('click', () => {
    localStorage.setItem(UPDATE_BANNER_STORAGE_KEY, updateInfo.version);
    el.remove();
  });
}

function installUpdate() {
  if (updateBusy) return;
  updateBusy = true;
  const btn = document.getElementById('update-install-btn');
  if (btn) btn.textContent = 'Descargando…';

  if (isNative()) {
    const api = updaterApi();
    api.download({ url: updateInfo.url, version: updateInfo.version })
      .then(async (res) => {
        if (btn) btn.textContent = 'Instalando…';
        if (res && res.id) {
          await api.set({ id: res.id, version: updateInfo.version });
          try { await api.reload(); } catch (e) {}
          return;
        }
        fallbackDownload();
      })
      .catch(() => fallbackDownload())
      .finally(() => { updateBusy = false; });
  } else {
    fallbackDownload();
  }
}

function fallbackDownload() {
  const btn = document.getElementById('update-install-btn');
  if (btn) btn.textContent = 'Abrir enlace';
  if (updateInfo && updateInfo.url) window.open(updateInfo.url, '_blank');
  setTimeout(() => {
    const b = document.getElementById('update-install-btn');
    if (b) b.textContent = 'Descargar e instalar';
    updateBusy = false;
  }, 3000);
}

document.addEventListener('DOMContentLoaded', () => {
  if (isNative()) {
    window.Capacitor.nativePromise('CapacitorUpdater', 'notifyAppReady', {}).catch(() => {});
  }
  setTimeout(checkForUpdate, 1500);
});