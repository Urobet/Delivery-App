﻿// ─── APP ROUTER ────────────────────────────────────────

const App = {
  stack: [],

  navigate(screen, params = {}) {
    if (screen === 'orderForm') processRecurrences();
    this.stack.push({ screen: AppState.screen, params: AppState.params });
    AppState.screen = screen;
    AppState.params = params;
    render();
  },

  goBack() {
    if (this.stack.length > 0) {
      const prev = this.stack.pop();
      AppState.screen = prev.screen || 'mainMenu';
      AppState.params = prev.params || {};
      if (AppState.screen === 'route' && AppState._prevRouteFilter !== undefined) {
        AppState.routeFilter = AppState._prevRouteFilter;
        AppState.routeName = AppState._prevRouteName;
        AppState.route = AppState._prevRoute;
        delete AppState._prevRouteFilter;
        delete AppState._prevRouteName;
        delete AppState._prevRoute;
      }
      render();
    } else {
      AppState.screen = 'mainMenu';
      AppState.params = {};
      render();
    }
  },

  openCustomerSheet(customerId) {
    AppState.sheetCustomerId = customerId;
    render();
  },

  closeCustomerSheet() {
    AppState.sheetCustomerId = null;
    render();
  },

  reset() {
    this.stack = [];
    AppState.screen = 'login';
    AppState.params = {};
    render();
  },

  // Android hardware back button — use the navigation stack, never exit the app
  handleBackPress() {
    if (this.stack.length > 0) {
      this.goBack();
      return true;
    }
    // If we are on the main menu, ask the user to confirm exit
    if (AppState.screen === 'mainMenu') {
      if (this._exitConfirmTimer) clearTimeout(this._exitConfirmTimer);
      showToast('⚠️ Toca el botón atrás otra vez para salir');
      this._exitConfirmTimer = setTimeout(() => {}, 3000);
      return true;
    }
    return false;
  },

  logout() {
    Auth.logout();
    this.stack = [];
    AppState.screen = 'login';
    AppState.params = {};
    AppState.driver = { name: 'Usuario', id: 'USR000', role: 'driver' };
    render();
  },

  startRoute() {
    if (!AppState.route) initRoute();
    AppState.screen = 'route';
    AppState.params = {};
    this.stack = [];
    render();
  },

  switchRoute(routeName) {
    AppState.routeName = routeName;
    const session2 = DB.Session.load(routeName, AppState.routeDate || today());
    AppState.extraSales = DB.Street.byDate(AppState.routeDate || today());
    AppState.collections = session2.collections;
    AppState.currentStop = null;
    rebuildRouteStops(routeName);
    render();
  },

  filterRoute(filter) {
    if (filter === '') {
      AppState.routeFilter = null;
    } else {
      AppState.routeFilter = filter;
      if (filter !== AppState.routeName) {
        AppState.routeName = filter;
        const session2 = DB.Session.load(filter, AppState.routeDate || today());
        AppState.extraSales = DB.Street.byDate(AppState.routeDate || today());
        AppState.collections = session2.collections;
        AppState.creditModal = null;
        AppState.currentStop = null;
        rebuildRouteStops(filter);
      }
    }
    render();
  },

  toggleRouteCreationModal() {
    AppState.routeCreationModal = !AppState.routeCreationModal;
    if (AppState.routeCreationModal) {
      let max = 0;
      const prefix = AppState.routeName.replace(/[^A-Za-z0-9]/g, '').slice(0, 3).toUpperCase();
      AppState.trips.forEach(t => { const n = parseInt(t.id.split('-')[1]); if (n > max) max = n; });
      AppState._nextTripId = max + 1;
    }
    render();
  },

  openRouteCreationModal() {
    AppState.routeCreationModal = true;
    AppState.routeCreationDestFilter = [];
    AppState.routeCreationDestOpen = false;
    render();
  },

  closeRouteCreationModal() { AppState.routeCreationModal = false; AppState.routeCreationDestFilter = []; AppState.routeCreationDestOpen = false; render(); },

  toggleRouteCreationDestFilter() {
    AppState.routeCreationDestOpen = !AppState.routeCreationDestOpen;
    render();
  },

  closeRouteCreationDestFilter() {
    AppState.routeCreationDestOpen = false;
    render();
  },

  setRouteCreationDestFilter(dest) {
    // 'all' → clear selection; otherwise treat as a single toggle
    if (dest === 'all') {
      AppState.routeCreationDestFilter = [];
    } else {
      AppState.routeCreationDestFilter = [];
      AppState.routeCreationDestFilter.push(dest);
    }
    AppState.routeCreationDestOpen = false;
    render();
  },

  toggleRouteCreationDestFilterItem(dest) {
    if (!dest) { AppState.routeCreationDestFilter = []; return; }
    const arr = AppState.routeCreationDestFilter || [];
    const i = arr.indexOf(dest);
    if (i >= 0) arr.splice(i, 1);
    else arr.push(dest);
    AppState.routeCreationDestFilter = arr;
    AppState.routeCreationDestOpen = true;
    render();
  },
  openStreetModal() { AppState.streetModal = true; render(); },
  closeStreetModal() { AppState.streetModal = false; render(); },

  toggleTripExpanded(tripId) {
    const trip = AppState.trips.find(t => t.id === tripId);
    if (trip) { trip.expanded = !trip.expanded; render(); }
  },

  async takeOrder(orderId) {
    const ok = await takeOrder(orderId);
    if (ok) {
      try { if (AppState.route) rebuildRouteStops(); } catch (e) {}
      render();
    }
  },

  async createTrip() {
    const kilosEl = document.getElementById('trip-kilos');
    const kilos = parseFloat(kilosEl?.value) || 0;
    if (kilos <= 0) { showToast('❌ Indica los kilos cargados'); return; }

    const cbEls = document.querySelectorAll('.trip-order-cb:checked');
    if (cbEls.length === 0) { showToast('❌ Selecciona al menos una orden'); return; }

    const orderIds = Array.from(cbEls).map(el => el.value);
    try {
      const trip = await createTrip(null, kilos, orderIds);
      AppState.routeCreationModal = false;
      showToast('✅ Ruta ' + trip.id + ' creada con ' + orderIds.length + ' órdenes');
      render();
    } catch (e) {
      if (e && e.message === 'orders_taken') {
        const names = e.takenNames || e.taken || [];
        showToast('❌ Órdenes ya tomadas: ' + names.join(', '));
        render();
       } else {
         console.error('createTrip error:', e);
         showToast('❌ No se pudo crear la ruta');
       }
    }
  },

  reloadData() {
    if (typeof reloadData === 'function') reloadData();
    const midEntry = ['stop', 'orderForm', 'customerForm', 'customerInfo', 'userManagement', 'login', 'futureOrder', 'more'].includes(AppState.screen);
    const openOverlay = AppState.sheetCustomerId || AppState.creditModal || AppState.streetModal || AppState.routeCreationModal || AppState.openingDebtModal || AppState.statementModal || AppState.signatureSheet || AppState.skipReasonModal || AppState.calendarOpen || AppState.routeCreationDestOpen;
    if (midEntry || openOverlay) return;
    try {
      if (AppState.screen === 'route' || AppState.route) rebuildRouteStops();
    } catch (e) {}
    render();
  },

  toggleCompleted() {
    AppState.collapsedCompleted = !AppState.collapsedCompleted;
    render();
  },

  switchRouteTab(tab) {
    AppState.routeSubTab = tab;
    render();
  },

  switchReportTab(tab) {
    AppState.reportTab = tab;
    AppState.reportDrill = null;
    AppState.reportDrillDay = null;
    render();
  },

  setReportDate(date) {
    AppState.reportDate = date || today();
    render();
  },

  changeReportDate(delta) {
    const d = new Date((AppState.reportDate || today()) + 'T12:00:00');
    d.setDate(d.getDate() + delta);
    AppState.reportDate = d.toISOString().slice(0, 10);
    render();
  },

  setReportRangeFrom(date) {
    const from = date || today();
    AppState.reportFrom = from;
    if (!AppState.reportTo || AppState.reportTo < from) AppState.reportTo = from;
    AppState.reportDrill = null;
    AppState.reportDrillDay = null;
    render();
  },

  setReportRangeTo(date) {
    const to = date || today();
    AppState.reportTo = to;
    if (!AppState.reportFrom || AppState.reportFrom > to) AppState.reportFrom = to;
    AppState.reportDrill = null;
    AppState.reportDrillDay = null;
    render();
  },

  searchReportRange() { render(); },

  // Fríos trend chart metric: 'pct', 'returned' or 'ordered'.
  // Independent from friosSort (chart metric never changes client ranking).
  toggleFriosTrendView(view) {
    AppState.friosTrendView = normalizeFriosMetric(view);
    render();
  },

  // Fríos per-customer list sort: 'pct', 'returned' or 'ordered'.
  setFriosSort(sort) {
    AppState.friosSort = normalizeFriosMetric(sort);
    render();
  },

  // Fríos customer drill-down: tap a client row to see its daily promedios,
  // % frío trend and per-day historial within the current report range.
  openFriosCustomer(key) {
    AppState.friosCustomer = String(key);
    render();
  },

  closeFriosCustomer() {
    AppState.friosCustomer = null;
    render();
  },

  // Sales trend chart drill (PowerBI-style: month → week → day).
  drillReport(level, key) {
    if (!level || !['month', 'week', 'day'].includes(level)) return;
    AppState.reportDrill = { level, parentKey: String(key) };
    AppState.reportDrillDay = null;
    render();
  },

  setReportDrillTop() {
    AppState.reportDrill = null;
    AppState.reportDrillDay = null;
    render();
  },

  drillReportUp() {
    const d = AppState.reportDrill;
    if (!d || !d.parentKey) { AppState.reportDrill = null; AppState.reportDrillDay = null; render(); return; }
    if (d.level === 'day') {
      const wk = d.parentKey;
      const month = _weekToMonth(wk);
      AppState.reportDrill = { level: 'week', parentKey: month };
    } else {
      AppState.reportDrill = null;
    }
    AppState.reportDrillDay = null;
    render();
  },

  selectReportDay(date) {
    AppState.reportDrillDay = String(date);
    render();
  },

  clearReportDay() {
    AppState.reportDrillDay = null;
    render();
  },

  downloadReport() {
    const parts = (AppState.reportTab || '').split('.');
    const cat = parts[0] || 'ventas';
    const sub = parts[1] || 'resumen';
    const rng = reportRangeFrom();
    const dateDisplay = formatDateNumeric(rng.from) + ' – ' + formatDateNumeric(rng.to);
    const agg = getAggregatedSettlementForRange(rng.from, rng.to);
    const p1 = getProductPrice('P1');
    const driver = AppState.driver || { name: '—' };
    const route = AppState.route || { name: '—' };
    let rows = [];
    let filename = '';
    if (cat === 'ventas' && sub === 'resumen') {
      filename = 'ventas_' + rng.from + '_' + rng.to + '.csv';
      rows.push(['Reporte de Ventas — ' + dateDisplay]);
      rows.push(['Ruta', route.name || '—', 'Conductor', driver.name || '—', 'Período', rng.from === rng.to ? 'DEL DÍA' : 'DEL RANGO']);
      rows.push([]);
      rows.push(['Parada', 'Cliente', 'Kg', 'Dev', 'Rec', 'Total $']);
      (agg && agg.stops || []).filter(s => s.status === 'completed').forEach(st => {
        const price = getStopPrice(st) || p1;
        const kg = (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0;
        const dev = Number(st.devolucionKg) || 0;
        const rec = Number(st.recompraKg) || 0;
        rows.push([st.customerName, st.customerName, kg.toFixed(2), dev.toFixed(2), rec.toFixed(2), (kg * price - dev * price + rec * RECOMPRA_PRICE).toFixed(2)]);
      });
      rows.push([]);
      if (agg) {
        const net = (agg.totalDelivered * p1) + agg.streetTotal - agg.devValue + agg.recompraValue;
        rows.push(['Total Ventas Netos', net.toFixed(2)]);
        rows.push(['Efectivo Recolectado', agg.totalCash.toFixed(2)]);
        rows.push(['Venta en Calle', agg.streetTotal.toFixed(2)]);
        rows.push(['Nuevo Crédito', agg.totalCredited.toFixed(2)]);
        rows.push(['Devoluciones', agg.devValue.toFixed(2)]);
      }
    } else {
      showToast('⚠️ Exportación no disponible para este reporte');
      return;
    }
    const csv = rows.map(r => r.map(c => /[",\n]/.test(String(c)) ? '"' + String(c).replace(/"/g, '""') + '"' : String(c)).join(',')).join('\n') + '\n';
    downloadBlob(csv, filename, 'text/csv;charset=utf-8');
    showToast('✅ Reporte exportado a ' + filename);
  },

  setRouteDate(date) {
    AppState.routeDate = date;
    AppState.calendarMonth = date.slice(0, 7);
    render();
  },

  toggleRouteCalendar() {
    if (!AppState.calendarOpen) AppState.calendarMonth = (AppState.routeDate || today()).slice(0, 7);
    AppState.calendarOpen = !AppState.calendarOpen;
    render();
  },

  closeRouteCalendar() {
    if (!AppState.calendarOpen) return;
    AppState.calendarOpen = false;
    render();
  },

  changeRouteCalendarMonth(delta) {
    const [year, month] = AppState.calendarMonth.split('-').map(Number);
    const next = new Date(year, month - 1 + delta, 1);
    AppState.calendarMonth = next.getFullYear() + '-' + String(next.getMonth() + 1).padStart(2, '0');
    render();
  },

  sortCustomers(col) {
    if (AppState.customersSortBy === col) {
      AppState.customersSortDir = AppState.customersSortDir === 'asc' ? 'desc' : 'asc';
    } else {
      AppState.customersSortBy = col;
      AppState.customersSortDir = 'asc';
    }
    AppState.customersPage = 1;
    render();
  },

  setCustomersPage(page) {
    AppState.customersPage = page;
    render();
  },

  toggleSelectCustomer(id, checked) {
    if (!AppState.selectedCustomers) AppState.selectedCustomers = [];
    if (checked) {
      if (!AppState.selectedCustomers.includes(id)) AppState.selectedCustomers.push(id);
    } else {
      AppState.selectedCustomers = AppState.selectedCustomers.filter(x => x !== id);
    }
    render();
  },

  toggleSelectAllCustomers(checked) {
    const perPage = AppState.customersPerPage;
    const page = AppState.customersPage;
    const start = (page - 1) * perPage;
    const paged = activeCustomers().slice(start, start + perPage);
    if (checked) {
      const ids = paged.map(c => c.id);
      AppState.selectedCustomers = [...new Set([...(AppState.selectedCustomers || []), ...ids])];
    } else {
      const ids = new Set(paged.map(c => c.id));
      AppState.selectedCustomers = (AppState.selectedCustomers || []).filter(x => !ids.has(x));
    }
    render();
  },

  toggleSelectOrder(id, checked) {
    if (!AppState.selectedOrders) AppState.selectedOrders = [];
    if (checked) {
      if (!AppState.selectedOrders.includes(id)) AppState.selectedOrders.push(id);
    } else {
      AppState.selectedOrders = AppState.selectedOrders.filter(x => x !== id);
    }
    render();
  },

  toggleSelectAllOrders(checked) {
    const active = getAllAdvanceOrders().filter(o => o.status === 'pending');
    if (checked) {
      AppState.selectedOrders = active.map(o => o.id);
    } else {
      AppState.selectedOrders = [];
    }
    render();
  },

  toggleOrderForm() {
    AppState.showOrderForm = !AppState.showOrderForm;
    render();
  },

  openOrderForm() {
    AppState.editingOrderId = null;
    AppState.orderRecurrence = null;
    AppState.showOrderForm = true;
    render();
    setTimeout(() => {
      const el = document.querySelector('.erp-content');
      if (el) el.scrollTop = 0;
    }, 50);
  },

  getScreen(screen, params) {
    switch (screen) {
      case 'login': return renderLogin();
      case 'mainMenu': return renderMainMenu();
      case 'route': return renderRouteHome();
      case 'stop': {
        let stop = findStop(params.stopId);
        if (!stop && params.orderId) {
          const o = getAdvanceOrder(params.orderId);
          if (o) {
            stop = buildStopFromOrder(o);
            AppState.route.stops = [stop, ...AppState.route.stops];
          }
        }
        if (!stop && params.historical && AppState.currentStop) {
          stop = AppState.currentStop;
        }
        if (!stop) return { html: '<div class="erp-screen"><div class="erp-empty"><span class="erp-empty-icon">⚠️</span><div class="erp-empty-text">Parada no encontrada</div></div></div>', init: () => {} };
        AppState.currentStop = stop;
        return renderStop(stop);
      }
      case 'streetSale': return renderStreetSale();
      case 'customers': return renderCustomers();
      case 'customerDetail': return renderCustomerDetail(params.customerId);
      case 'customerStatement': return renderCustomerStatement(params.customerId);
      case 'customerInfo': return renderCustomerInfo(params.customerId);
      case 'routes': return renderRoutes();
      case 'reports': return renderReports();
      case 'more': return renderMore();
      case 'settingsProducts': return renderSettingsProducts();
      case 'settingsFutureOrders': return renderSettingsFutureOrders();
      case 'settingsBackup': return renderSettingsBackup();
      case 'settingsData': return renderSettingsData();
      case 'settingsDriver': return renderSettingsDriver();
      case 'settingsAccessibility': return renderSettingsAccessibility();
      case 'userManagement': return renderUserManagement();
      case 'settingsBalances': return renderSettingsBalances();
      case 'settingsErp': return renderSettingsErp();
      case 'orderForm': return renderOrderForm();
      case 'futureOrder': return renderFutureOrderForm();
      case 'customerForm': return renderCustomerFormScreen();
      default: return { html: '<div class="erp-screen"><div class="erp-empty"><span class="erp-empty-icon">⚠️</span><div class="erp-empty-text">Pantalla no encontrada</div></div></div>', init: () => {} };
    }
  }
};

function findStop(stopId) {
  if (!AppState.route) return null;
  return AppState.route.stops.find(s => s.stopId === stopId);
}

function captureScrollState(root) {
  const state = [];
  const selectors = ['.erp-content', '.erp-stmt-scroll', '.sheet-body', '.erp-sheet-body', '.md-settings', '.erp-popover', '.erp-report-body', '.erp-scroll'];
  selectors.forEach(sel => {
    root.querySelectorAll(sel).forEach(el => {
      if (el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1) {
        state.push({ sel, top: el.scrollTop, left: el.scrollLeft });
      }
    });
  });
  return state;
}

function restoreScrollState(root, state) {
  if (!state.length) return;
  let attempts = 0;
  const tryRestore = () => {
    let restored = 0;
    state.forEach(item => {
      const el = root.querySelector(item.sel);
      if (el && (el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1)) {
        el.scrollTop = item.top;
        el.scrollLeft = item.left;
        restored++;
      }
    });
    if (restored < state.length && attempts < 10) {
      attempts++;
      requestAnimationFrame(tryRestore);
    }
  };
  requestAnimationFrame(tryRestore);
}

function downloadBlob(content, filename, mimeType) {
  const blob = new Blob([content], { type: mimeType || 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function render() {
  const appEl = document.getElementById('app');
  if (!appEl) return;
  const previousScreen = AppState._renderedScreen;
  const sameScreen = previousScreen === AppState.screen;
  const scrollState = sameScreen ? captureScrollState(appEl) : [];
  const screen = App.getScreen(AppState.screen, AppState.params);
  appEl.innerHTML = screen.html;
  if (screen.init) screen.init();
  if (typeof A11Y !== 'undefined') A11Y.apply();
  renderToast();
  AppState._renderedScreen = AppState.screen;
  if (sameScreen && scrollState.length) {
    requestAnimationFrame(() => restoreScrollState(appEl, scrollState));
  }
}

function renderToast() {
  document.querySelectorAll('.erp-toast').forEach(el => el.remove());
  if (AppState.toast) {
    const el = document.createElement('div');
    el.className = 'erp-toast';
    el.textContent = AppState.toast;
    document.body.appendChild(el);
    setTimeout(() => { if (el.parentNode) el.remove(); }, 2500);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  processRecurrences();
  const u = Auth.currentUser();
  if (u) {
    AppState.driver = { name: u.name, id: u.userId, role: u.role };
    AppState.screen = 'mainMenu';
    AppState.params = {};
  } else {
    AppState.driver = { name: 'Usuario', id: 'USR000', role: 'driver' };
    AppState.screen = 'login';
    AppState.params = {};
  }
  render();

  // Android hardware back button — route through the app stack
  document.addEventListener('backbutton', () => {
    if (App.handleBackPress()) {
      // Event handled by the app; do not let the OS close the app
      if (typeof window.Capacitor !== 'undefined' && window.Capacitor.Plugins?.App) {
        window.Capacitor.Plugins.App.exitApp = window.Capacitor.Plugins.App.exitApp;
      }
      return;
    }
  });
});
