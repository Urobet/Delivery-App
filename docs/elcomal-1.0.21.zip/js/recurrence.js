// ─── Recurence Sheet ────────────────────────────────────
// Google Calendar-inspired bottom sheet for configuring
// recurring events: orders, payments, reminders, etc.
// API: showRecurrenceSheet(options, onSave)

let _sheetState = null;
let _onSave = null;

const DAY_LABELS = ['L', 'M', 'X', 'J', 'V', 'S', 'D'];
const DISPLAY_TO_JS = [1, 2, 3, 4, 5, 6, 0];

const PRESET_MAP = [
  { key: 'none',    label: 'No repetir' },
  { key: 'daily',   label: 'Diario',   fv: 1, fu: 'days',   dw: [] },
  { key: 'weekly',  label: 'Semanal',  fv: 1, fu: 'weeks',  dw: [1] },
  { key: 'monthly', label: 'Mensual',  fv: 1, fu: 'months', dw: [] },
  { key: 'yearly',  label: 'Anual',    fv: 1, fu: 'years',  dw: [] },
  { key: 'custom',  label: 'Personalizado' },
];

const DEFAULTS = {
  preset: 'none',
  frequencyValue: 1,
  frequencyUnit: 'weeks',
  daysOfWeek: [1],
  endType: 'never',
  endDate: '',
  endOccurrences: 10,
};

function showRecurrenceSheet(options = {}, onSave) {
  if (document.getElementById('rs-overlay')) closeRecurrenceSheet(null);

  const current = options.current;
  const state = current
    ? { ...DEFAULTS, ...current, preset: current.preset || 'custom' }
    : { ...DEFAULTS };

  if (state.preset !== 'none' && state.preset !== 'custom') {
    const p = PRESET_MAP.find(x => x.key === state.preset);
    if (p && p.fv) {
      state.frequencyValue = p.fv;
      state.frequencyUnit = p.fu;
      state.daysOfWeek = [...p.dw];
    }
  }

  _sheetState = state;
  _onSave = onSave || (() => {});

  const overlay = document.createElement('div');
  overlay.className = 'erp-overlay';
  overlay.id = 'rs-overlay';
  overlay.onclick = () => closeRecurrenceSheet(null);

  const panel = document.createElement('div');
  panel.className = 'erp-sheet';
  panel.id = 'rs-panel';
  panel.onclick = (e) => e.stopPropagation();

  overlay.appendChild(panel);
  document.body.appendChild(overlay);
  renderSheetContent();
}

function renderSheetContent() {
  const panel = document.getElementById('rs-panel');
  if (!panel || !_sheetState) return;
  panel.innerHTML = buildSheetHTML(_sheetState);
}

function buildSheetHTML(s) {
  const isWeekly = s.frequencyUnit === 'weeks';
  const showCustom = s.preset !== 'none';

  return `
    <div class="erp-sheet-handle"></div>
    <div class="erp-sheet-title">🔄 Repetir</div>
    <div class="erp-sheet-body">

    <hr class="erp-divider">

    <div class="erp-freq-grid">
      ${PRESET_MAP.map(p => `
        <button class="erp-freq-pill ${s.preset === p.key ? 'selected' : ''}"
          onclick="selectRSP('${p.key}')">${p.label}</button>
      `).join('')}
    </div>

    ${showCustom ? `
    <hr class="erp-divider">

    <div id="rs-custom-section">

      <div class="erp-field">
        <div class="erp-label">Repetir cada</div>
        <div style="display:flex;align-items:center;gap:8px">
          <div class="erp-stepper-inline">
            <input type="number" id="rs-fv" value="${s.frequencyValue}" min="1" max="365" inputmode="numeric" onchange="onRSFV()">
          </div>
          <select class="erp-select" id="rs-fu" style="width:auto" onchange="onRSFU()">
            ${['days','weeks','months','years'].map(u => `
              <option value="${u}" ${s.frequencyUnit === u ? 'selected' : ''}>${unitLabel(u)}</option>
            `).join('')}
          </select>
        </div>
      </div>

      <div id="rs-day-section" class="erp-field" style="display:${isWeekly ? 'block' : 'none'}">
        <div class="erp-label">Repetir los</div>
        <div class="erp-day-pills">
          ${DAY_LABELS.map((label, i) => `
            <button class="erp-day-pill ${s.daysOfWeek.includes(DISPLAY_TO_JS[i]) ? 'selected' : ''}"
              data-j="${DISPLAY_TO_JS[i]}" onclick="onRSD(this)">${label}</button>
          `).join('')}
        </div>
      </div>

      <hr class="erp-divider">

      <div class="erp-label" style="margin-bottom:6px">Finaliza</div>

      ${[
        { k: 'never', lbl: 'Nunca', ctrl: '' },
        { k: 'date', lbl: 'El', ctrl: `<input type="date" class="erp-input" id="rs-ed" style="width:auto" value="${s.endDate}" ${s.endType !== 'date' ? 'disabled' : ''} onchange="onRSED()">` },
        { k: 'occurrences', lbl: 'Después de', ctrl: `
          <div style="display:flex;align-items:center;gap:4px">
            <div class="erp-stepper-inline">
              <button id="rs-occ-dec" ${s.endType !== 'occurrences' ? 'disabled' : ''} onclick="onRSOcc(-1)">−</button>
              <span id="rs-occ-v" style="cursor:pointer" onclick="editQty('rs-occ-v')">${s.endOccurrences}</span>
              <button id="rs-occ-inc" ${s.endType !== 'occurrences' ? 'disabled' : ''} onclick="onRSOcc(1)">+</button>
            </div>
            <span style="font-size:13px;color:var(--slate-500);font-family:monospace">repeticiones</span>
          </div>` },
      ].map(r => `
        <label class="erp-ends-row ${s.endType === r.k ? 'selected' : ''}" onclick="onRSET('${r.k}')">
          <span class="erp-ends-radio"></span>
          <span style="flex:1;font-size:13px;font-weight:600;color:var(--slate-900)">${r.lbl}</span>
          ${r.ctrl}
        </label>
      `).join('')}
    </div>
    ` : ''}

    <hr class="erp-divider">

    <div style="display:flex;gap:8px;padding-top:4px">
      <button class="erp-btn erp-btn-secondary" style="flex:1" onclick="closeRecurrenceSheet(null)">Cancelar</button>
      <button class="erp-btn erp-btn-primary" style="flex:2" onclick="onRSSave()">${s.preset === 'none' ? 'Listo' : '💾 Guardar'}</button>
    </div>

    </div>
  `;
}

function closeSheetDOM() {
  const el = document.getElementById('rs-overlay');
  if (el) el.remove();
}

// ─── GLOBAL HANDLERS ───

window.selectRSP = function (key) {
  const s = _sheetState;
  s.preset = key;
  if (key !== 'none' && key !== 'custom') {
    const p = PRESET_MAP.find(x => x.key === key);
    if (p && p.fv) {
      s.frequencyValue = p.fv;
      s.frequencyUnit = p.fu;
      s.daysOfWeek = [...p.dw];
    }
  }
  renderSheetContent();
};

window.onRSD = function (btn) {
  const jsDay = parseInt(btn.dataset.j);
  const s = _sheetState;
  const idx = s.daysOfWeek.indexOf(jsDay);
  if (idx >= 0) { s.daysOfWeek.splice(idx, 1); btn.classList.remove('selected'); }
  else { s.daysOfWeek.push(jsDay); btn.classList.add('selected'); }
};

window.onRSET = function (type) {
  _sheetState.endType = type;
  renderSheetContent();
};

window.onRSFV = function () {
  const el = document.getElementById('rs-fv');
  if (el) _sheetState.frequencyValue = parseInt(el.value) || 1;
};

window.onRSFU = function () {
  const el = document.getElementById('rs-fu');
  if (!el) return;
  _sheetState.frequencyUnit = el.value;
  _sheetState.preset = 'custom';
  renderSheetContent();
};

window.onRSED = function () {
  const el = document.getElementById('rs-ed');
  if (el) _sheetState.endDate = el.value;
};

window.onRSOcc = function (delta) {
  const s = _sheetState;
  s.endOccurrences = Math.max(1, Math.min(999, (s.endOccurrences || 1) + delta));
  const el = document.getElementById('rs-occ-v');
  if (el) el.textContent = s.endOccurrences;
};

window.onRSOccEdit = function () {
  const el = document.getElementById('rs-occ-v');
  if (!el) return;
  _sheetState.endOccurrences = Math.max(1, Math.min(999, parseInt(el.textContent) || 1));
  el.textContent = _sheetState.endOccurrences;
};

window.onRSSave = function () {
  const s = _sheetState;
  if (s.preset === 'none') {
    closeRecurrenceSheet({ preset: 'none' });
    return;
  }
  if (s.frequencyUnit === 'weeks' && s.daysOfWeek.length === 0) {
    showToast('Selecciona al menos un día');
    return;
  }
  closeRecurrenceSheet({
    preset: s.preset,
    frequencyValue: s.frequencyValue,
    frequencyUnit: s.frequencyUnit,
    daysOfWeek: s.daysOfWeek,
    endType: s.endType,
    endDate: s.endDate,
    endOccurrences: s.endOccurrences,
  });
};

window.closeRecurrenceSheet = function (result) {
  closeSheetDOM();
  if (_onSave) { _onSave(result); }
  _sheetState = null;
  _onSave = null;
};

function unitLabel(u) {
  return { days: 'día(s)', weeks: 'semana(s)', months: 'mes(es)', years: 'año(s)' }[u] || u;
}
