// ─── DATA LAYER ──────────────────────────────────────
// Single source of truth for all localStorage operations.
// Repository pattern — swap this module to migrate to an HTTP API.
// Load this BEFORE data.js.

const DB = {};

// ── Generic storage primitives ──

DB.Storage = {
  get(key, fallback) {
    try { const v = localStorage.getItem(key); if (v !== null) return JSON.parse(v); } catch (e) {}
    return fallback;
  },
  set(key, data) {
    try { localStorage.setItem(key, JSON.stringify(data)); } catch (e) {}
  },
  del(key) {
    try { localStorage.removeItem(key); } catch (e) {}
  },
};

// ── Entity repositories (thin wrappers, data.js owns defaults) ──

DB.Entities = {
  CLIENTS: 'elcomal_clientes',
  ORDERS: 'elcomal_orders',
  TRIPS: 'elcomal_trips',

  loadClients() { return DB.Storage.get(DB.Entities.CLIENTS, null); },
  saveClients(data) { DB.Storage.set(DB.Entities.CLIENTS, data); },

  loadOrders() { return DB.Storage.get(DB.Entities.ORDERS, null); },
  saveOrders(data) { DB.Storage.set(DB.Entities.ORDERS, data); },

  loadTrips() { return DB.Storage.get(DB.Entities.TRIPS, null); },
  saveTrips(data) { DB.Storage.set(DB.Entities.TRIPS, data); },

  stopsKey(routeName, date) {
    return 'elcomal_stops_' + routeName.replace(/\s/g, '') + '_' + (date || _today());
  },
  loadStops(routeName, date) { return DB.Storage.get(DB.Entities.stopsKey(routeName, date), null); },
  saveStops(routeName, date, data) { DB.Storage.set(DB.Entities.stopsKey(routeName, date), data); },
};

// ── Session store (per-route-day: extraSales + collections) ──

DB.Session = {
  _key(routeName, date) {
    return 'elcomal_session_' + routeName.replace(/\s/g, '') + '_' + (date || _today());
  },
  load(routeName, date) {
    const data = DB.Storage.get(this._key(routeName, date), null);
    return data || { routeName, date: date || _today(), extraSales: [], collections: [] };
  },
  save(routeName, date, data) {
    DB.Storage.set(this._key(routeName, date), data);
  },
};

// ── Settlement history (persistent snapshots per route-day) ──

DB.SettlementHistory = {
  _key: 'elcomal_settlements',
  load() { return DB.Storage.get(this._key, []); },
  save(data) { DB.Storage.set(this._key, data); },
  addSnapshot(snapshot) {
    const all = this.load();
    const idx = all.findIndex(s => s.date === snapshot.date && s.routeName === snapshot.routeName);
    if (idx >= 0) all[idx] = snapshot;
    else all.push(snapshot);
    this.save(all);
  },
  getByDate(date) {
    return this.load().filter(s => s.date === date);
  },
  getRange(from, to) {
    const f = from || '0000-00-00', t = to || '9999-99-99';
    return this.load().filter(s => s.date >= f && s.date <= t);
  },
  clear() {
    DB.Storage.del(this._key);
  },
};

// ── Future orders (global, not scoped to route-day) ──

DB.FutureOrders = {
  _key: 'elcomal_futureOrders',
  load() { return DB.Storage.get(this._key, []); },
  save(data) { DB.Storage.set(this._key, data); },
};

// ── User / driver profile settings ──

DB.User = {
  _key: 'elcomal_user',
  load() { return DB.Storage.get(this._key, null); },
  save(data) { DB.Storage.set(this._key, data); },
};

// ── Product prices (global settings, editable at runtime) ──

DB.Prices = {
  _key: 'elcomal_productPrices',
  load() { return DB.Storage.get(this._key, null); },
  save(data) { DB.Storage.set(this._key, data); },
};

// ── Street sales (ventas callejeras), global & tagged by sale date ──

DB.Street = {
  _key: 'elcomal_streetSales',
  load() { return DB.Storage.get(this._key, []); },
  save(list) { DB.Storage.set(this._key, list); },
  byDate(date) {
    const d = date || _today();
    return this.load().filter(s => (s.date || _today()) === d);
  },
  append(sale) {
    const all = this.load();
    all.push(sale);
    this.save(all);
    return sale;
  },
};

// ── Customer payments ledger (cuenta por cobrar abonos) ──

DB.Payments = {
  _key: 'elcomal_payments',
  load() { return DB.Storage.get(this._key, []); },
  save(data) { DB.Storage.set(this._key, data); },
};

// ── Schema versioning ──

DB.Schema = {
  _key: 'elcomal_schema_ver',
  VERSION: 1,
  init() {
    const ver = DB.Storage.get(this._key, null);
    if (ver === null) {
      // First run — set version and migrate if needed
      DB.Storage.set(this._key, this.VERSION);
    } else if (ver < this.VERSION) {
      this._migrate(ver);
      DB.Storage.set(this._key, this.VERSION);
    }
  },
  _migrate(fromVersion) {
    // Future: handle schema migrations here
  },
};

function _today() {
  return new Date().toISOString().slice(0, 10);
}

DB.Schema.init();
