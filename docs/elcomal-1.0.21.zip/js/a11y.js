// ─── ACCESIBILIDAD VISUAL ───────────────────────────────
// Adds on-screen text size (Grande / Muy grande) and high-contrast
// toggles for drivers with vision problems (farsighted or shortsighted).
//
// The app renders ~200 inline `font-size` styles plus CSS classes, so a
// pure-CSS fix is not enough. `A11Y.apply()` runs after every render:
//  - tags <body> with a11y-lg / a11y-xl / a11y-high-contrast classes
//    (CSS in styles.css bumps class-based text and touch targets), and
//  - scales inline font-size/min-height px values in #app.
// Since innerHTML is rebuilt from source templates on every render(),
// applying once per render is idempotent (source always has base px).
const A11Y_KEY = 'elcomal_a11y';

const A11Y = {
  scale: 1,           // 1 | 1.2 | 1.4
  highContrast: false,

  load() {
    try {
      const s = JSON.parse(localStorage.getItem(A11Y_KEY) || 'null');
      if (s) {
        this.scale = Number(s.scale) || 1;
        this.highContrast = !!s.highContrast;
      }
    } catch (e) {}
  },

  save() {
    try { localStorage.setItem(A11Y_KEY, JSON.stringify({ scale: this.scale, highContrast: this.highContrast })); } catch (e) {}
  },

  setScale(v) {
    this.scale = v;
    this.save();
    render();
  },

  setHighContrast(v) {
    this.highContrast = !!v;
    this.save();
    render();
  },

  apply() {
    const body = document.body;
    if (!body) return;
    body.classList.toggle('a11y-lg', this.scale >= 1.2);
    body.classList.toggle('a11y-xl', this.scale >= 1.4);
    body.classList.toggle('a11y-high-contrast', this.highContrast);
    if (this.scale <= 1) return;
    document.querySelectorAll('#app [style]').forEach(el => {
      const s = el.style;
      if (s.fontSize && s.fontSize.endsWith('px')) {
        const v = parseFloat(s.fontSize);
        if (v > 0 && v < 60) s.fontSize = Math.round(v * this.scale) + 'px';
      }
      if (s.minHeight && s.minHeight.endsWith('px')) {
        const v = parseFloat(s.minHeight);
        if (v > 0) s.minHeight = Math.round(v * this.scale) + 'px';
      }
    });
  }
};

function setTextScale(v) { A11Y.setScale(v); }
function toggleHighContrast() { A11Y.setHighContrast(!A11Y.highContrast); }

A11Y.load();