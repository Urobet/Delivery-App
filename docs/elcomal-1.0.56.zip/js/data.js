// ─── STATE ─────────────────────────────────────────────
const AppState = {
  driver: (() => {
    const s = Auth.currentUser();
    if (s) return { name: s.name, id: s.userId, role: s.role };
    const u = DB.User.load();
    return { name: (u && u.name) || 'Usuario', id: (u && u.id) || 'USR000', role: 'driver' };
  })(),
  screen: 'login',
  params: {},
  history: [],
  route: null,
  routeName: null,
  routeFilter: null,
  creditModal: null,
  extraSales: [],
  streetExpanded: false,
  streetModal: false,
  collections: [],
  futureOrders: DB.FutureOrders.load(),
  counterSales: [],
  currentStop: null,
  collapsedCompleted: true,
  toast: null,
  reportTab: 'ventas.liquidacion',
  reportDate: today(),
  reportFrom: today(),
  reportTo: today(),
  reportDrill: null,
  reportDrillDay: null,
  friosTrendView: 'pct',
  friosSort: 'pct',
  friosCustomer: null,
  routeSubTab: 'today',
  sheetCustomerId: null,
  paymentEntry: false,
  statementModal: null,
  openingDebtModal: null,
  statementFilter: 'all',
  showRouteFilter: false,
  routeDate: today(),
  calendarOpen: false,
  calendarMonth: today().slice(0, 7),
  customersSortBy: 'name',
  customersSortDir: 'asc',
  customersPage: 1,
  customersPerPage: 8,
  customerFormId: null,
  selectedCustomers: [],
  editingOrderId: null,
  selectedOrders: [],
  productEditId: null,
  showOrderForm: false,
  orderRecurrence: null,
  trips: [],
  routeCreationModal: false,
  skipReasonModal: null,
  signatureSheet: null,
  showNewUserForm: false,
  nuName: '',
  nuUsername: '',
  nuPassword: '',
  nuRole: 'driver',
  editUserId: null,
  euName: '',
  euUsername: '',
  loginUsername: '',
  loginPassword: '',
  loginName: '',
  loginPassword2: '',
  loginRemember: true,
};

// ─── HELPERS ───────────────────────────────────────────
function genId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function today() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
}
function formatDate(d) {
  const date = new Date(d + 'T12:00:00');
  return date.toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long' });
}
function formatCurrency(n) { return '$' + Number(n).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'); }
function formatDateShort(d) {
  const date = new Date(d + 'T12:00:00');
  return date.toLocaleDateString('es-MX', { day: 'numeric', month: 'short' });
}
function formatStmtDate(d) {
  const date = new Date(d + 'T12:00:00');
  const mon = date.toLocaleDateString('es-MX', { month: 'short' }).replace('.', '');
  return String(date.getDate()).padStart(2, '0') + '/' + mon.charAt(0).toUpperCase() + mon.slice(1);
}
function formatDateNumeric(d) {
  if (!d) return '';
  const date = new Date(d + 'T12:00:00');
  return String(date.getDate()).padStart(2, '0') + '/' + String(date.getMonth() + 1).padStart(2, '0') + '/' + date.getFullYear();
}
function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

// ─── PERSISTENCE ────────────────────────────────────────
const STORAGE_KEY_CLIENTS = 'elcomal_clientes';
const STORAGE_KEY_ORDERS = 'elcomal_orders';
const STORAGE_KEY_STOPS = 'elcomal_stops';
const STORAGE_KEY_TRIPS = 'elcomal_trips';

// ─── CUSTOMERS ─────────────────────────────────────────
const DEFAULT_CLIENTES = [
  { id: 'C15', name: 'Juanito', contact: '', phone: '', direccion: 'Pueblo Nuevo', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 22.5,
    recurrence: { preset: 'weekly', frequencyValue: 1, frequencyUnit: 'weeks', daysOfWeek: [1], endType: 'never', endDate: '', endOccurrences: 10 } },
  { id: 'C16', name: 'Lupe', contact: '', phone: '', direccion: 'Pueblo Nuevo', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0 },
  { id: 'C17', name: 'Santos', contact: '', phone: '', direccion: 'Dolores', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 21 },
  { id: 'C18', name: 'Pepe', contact: '', phone: '', direccion: 'La Perla', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 22 },
  { id: 'C19', name: 'Jorge', contact: '', phone: '', direccion: 'La Perla', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 22 },
  { id: 'C20', name: 'Chuy', contact: '', phone: '', direccion: 'La Perla', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 22 },
  { id: 'C21', name: 'Eliza', contact: '', phone: '', direccion: 'Melgar', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C22', name: 'Molino', contact: '', phone: '', direccion: 'Melgar', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C23', name: 'Cona 25', contact: '', phone: '', direccion: '25 de Diciembre', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 23, recurrence: null },
  { id: 'C24', name: 'Hugo', contact: '', phone: '', direccion: '25 de Diciembre', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C25', name: 'Mundo', contact: '', phone: '', direccion: 'El Paso', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C26', name: 'Paco', contact: '', phone: '', direccion: 'El Paso', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C27', name: 'Chata', contact: '', phone: '', direccion: 'El Paso', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C28', name: 'Milenio', contact: '', phone: '', direccion: 'El Paso', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C29', name: 'Fermina', contact: '', phone: '', direccion: 'El Paso', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C30', name: 'Casas', contact: '', phone: '', direccion: '25 de Diciembre', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 24, recurrence: null },
  { id: 'C31', name: 'Chuy la flor', contact: '', phone: '', direccion: 'La Flor', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C32', name: 'susana', contact: '', phone: '', direccion: 'La Flor', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C33', name: 'tienda la flor', contact: '', phone: '', direccion: 'La Flor', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
  { id: 'C34', name: 'lupita', contact: '', phone: '', direccion: 'La Flor', route: 'Pueblo Nuevo',
    paymentTerm: 'COD', creditLimit: 0, defaultPrice: 0, recurrence: null },
];

function loadClients() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_CLIENTS);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return JSON.parse(JSON.stringify(DEFAULT_CLIENTES));
}

function saveClients() {
  try { localStorage.setItem(STORAGE_KEY_CLIENTS, JSON.stringify(CLIENTES)); } catch (e) {}
}

let CLIENTES = loadClients();
backfillCustomerBalances();

// ─── CUSTOMER PAYMENTS / CUENTA (kilos fiados) ─────────
const PAYMENTS_KEY = 'elcomal_payments';
let PAYMENTS = loadPayments();

function loadPayments() {
  try {
    const saved = localStorage.getItem(PAYMENTS_KEY);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return [];
}

function savePayments() {
  try { localStorage.setItem(PAYMENTS_KEY, JSON.stringify(PAYMENTS)); } catch (e) {}
}

// One-time migration: seed each customer's balance from historical
// settlement snapshots (sum of all credited kilos per stop).
function backfillCustomerBalances() {
  let changed = false;
  const snapshots = DB.SettlementHistory.load();
  CLIENTES.forEach(c => {
    if (typeof c.balance !== 'number') {
      let total = 0;
      snapshots.forEach(snap => {
        (snap.stops || []).forEach(st => {
          if (st.customerId === c.id) total += (Number(st.creditAmount) || 0);
        });
      });
      c.balance = total;
      changed = true;
    }
  });
  if (changed) saveClients();
}

function recordCustomerCredit(customerId, amount) {
  const amt = Number(amount) || 0;
  if (amt <= 0) return;
  const c = getCustomerSafe(customerId, { label: 'Cliente' });
  if (c) {
    c.balance = (c.balance || 0) + amt;
    saveClients();
  }
}

// ─── ERP BOUNDARY HELPERS (additive; app math never uses these) ──
// Round money to 2 decimals — ONLY for ERP outbox serialization.
function round2(n) { return Math.round((Number(n) + Number.EPSILON) * 100) / 100; }

// Derive a customer's balance from the synced ledger rows, mirroring the
// mutation semantics exactly:
//   + opening debts (addOpeningDebt → recordCustomerCredit)
//   + completed order credits (confirmStop → recordCustomerCredit == o.creditAmount)
//   − payment ledger rows (addPayment / recordDebtPayment)
// Mutations clamp decreases at 0 (Math.max), so a negative raw sum is a
// valid match for a stored 0. Diagnostic only — never writes balance.
function computeBalanceFromLedger(customerId) {
  const opening = OPENING_DEBTS.filter(d => d.customerId === customerId)
    .reduce((s, d) => s + (Number(d.amount) || 0), 0);
  const credits = advanceOrders.filter(o =>
      o.customerId === customerId && o.status === 'completed')
    .reduce((s, o) => s + (Number(o.creditAmount) || 0), 0);
  const paid = PAYMENTS.filter(p => p.customerId === customerId)
    .reduce((s, p) => s + (Number(p.amount) || 0), 0);
  return opening + credits - paid;
}

// True when the stored balance drifts from the ledger derivation.
// Tolerance 0.01 (float money); stored 0 with negative raw is the clamp.
function balanceDrift(customerId) {
  const c = getCustomer(customerId);
  if (!c) return false;
  const derived = computeBalanceFromLedger(customerId);
  const stored = Number(c.balance) || 0;
  if (derived < 0 && stored === 0) return false; // clamp effect
  return Math.abs(stored - derived) > 0.01;
}

function getCustomerPayments(customerId) {
  return PAYMENTS.filter(p => p.customerId === customerId)
    .sort((a, b) => (a.timestamp || '').localeCompare(b.timestamp || ''));
}

function getTotalPayments(customerId) {
  return getCustomerPayments(customerId).reduce((s, p) => s + (Number(p.amount) || 0), 0);
}

function getPaymentsTotalForDate(dateStr) {
  const d = dateStr || today();
  return PAYMENTS.filter(p => (p.timestamp || '').slice(0, 10) === d)
    .reduce((s, p) => s + (Number(p.amount) || 0), 0);
}

// ─── OPENING DEBTS (deuda previa / saldo inicial) ───────
const OPENING_DEBTS_KEY = 'elcomal_openingDebts';
let OPENING_DEBTS = loadOpeningDebts();

function loadOpeningDebts() {
  try {
    const saved = localStorage.getItem(OPENING_DEBTS_KEY);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return [];
}

function saveOpeningDebts() {
  try { localStorage.setItem(OPENING_DEBTS_KEY, JSON.stringify(OPENING_DEBTS)); } catch (e) {}
}

// Registers debt the customer already owed before using the app.
// Bumps c.balance (drives the stop highlight) AND persists a row so
// the ledger/statement shows where the debt came from.
function addOpeningDebt(customerId, amount, date) {
  const amt = Number(amount) || 0;
  if (amt <= 0) return null;
  const entry = {
    id: genId(),
    customerId,
    amount: amt,
    date: date || today(),
    note: 'Deuda previa / Saldo inicial',
    operator: (AppState.driver && AppState.driver.name) || '—',
    timestamp: new Date().toISOString(),
  };
  OPENING_DEBTS.push(entry);
  saveOpeningDebts();
  recordCustomerCredit(customerId, amt);
  return entry;
}

function getOpeningDebts(customerId) {
  return OPENING_DEBTS.filter(d => d.customerId === customerId);
}

// ─── CREDIT LEDGER (fiado) ─────────────────────────────
function getCreditMovements(customerId) {
  const rows = [];
  const seen = new Set();
  const liveDate = AppState.routeDate || today();
  const hasLiveRoute = !!AppState.route && AppState.route.stops.length > 0;
  const push = r => {
    const key = r.orderId || r.stopId || (r.date + '|' + r.ref);
    if (seen.has(key)) return;
    seen.add(key);
    rows.push(r);
  };
  advanceOrders.forEach(o => {
    if (o.customerId === customerId && o.status === 'completed' && (Number(o.creditAmount) || 0) > 0) {
      push({
        type: 'credit',
        date: o.date,
        amount: Number(o.creditAmount) || 0,
        kg: (o.deliveredKg !== undefined ? o.deliveredKg : o.qty) || 0,
        ref: o.id,
        stopId: 'S-' + o.id,
        orderId: o.id,
        routeName: o.route || null,
        operator: '—',
        source: 'sale',
        isOpeningBalance: false,
        dateKnown: !!o.date,
      });
    }
  });
  OPENING_DEBTS.forEach(d => {
    if (d.customerId === customerId && (Number(d.amount) || 0) > 0) {
      push({
        type: 'credit',
        // Undated opening debt keeps missing-date semantics (real debt,
        // unknown age) — never invent today() as its age.
        date: d.date || null,
        amount: Number(d.amount) || 0,
        kg: 0,
        ref: 'SALDO-' + d.id,
        stopId: null,
        orderId: null,
        routeName: null,
        operator: d.operator || '—',
        note: d.note || 'Deuda previa / Saldo inicial',
        source: 'opening',
        isOpeningBalance: true,
        dateKnown: !!d.date,
      });
    }
  });
  DB.SettlementHistory.load().forEach(snap => {
    if (hasLiveRoute && snap.date === liveDate) return;
    (snap.stops || []).forEach(st => {
      // No receivables from cancelled/pending stops; missing status stays
      // eligible (records predating the status field).
      if (st.status && st.status !== 'completed') return;
      if (st.customerId === customerId && (Number(st.creditAmount) || 0) > 0) {
        push({
          type: 'credit',
          date: snap.date,
          amount: Number(st.creditAmount) || 0,
          kg: (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0,
          ref: st.orderId || st.stopId || 'INV',
          stopId: st.stopId || null,
          orderId: st.orderId || null,
          routeName: snap.routeName || null,
          operator: snap.driverName || '—',
          source: 'sale',
          isOpeningBalance: false,
          dateKnown: !!snap.date,
        });
      }
    });
  });
  if (AppState.route) {
    AppState.route.stops.forEach(st => {
      if (st.customerId === customerId && st.status === 'completed' && (Number(st.creditAmount) || 0) > 0) {
        push({
          type: 'credit',
          date: liveDate,
          amount: Number(st.creditAmount) || 0,
          kg: (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0,
          ref: st.orderId || st.stopId || 'INV',
          stopId: st.stopId || null,
          orderId: st.orderId || null,
          routeName: AppState.routeName || null,
          operator: (AppState.driver && AppState.driver.name) || '—',
          source: 'sale',
          isOpeningBalance: false,
          dateKnown: !!liveDate,
        });
      }
    });
  }
  return rows;
}

// Unified credits + payments, FIFO-covered (payments settle oldest
// credit first). Returns newest-first rows for display.
function getUnifiedLedger(customerId) {
  const movements = [];
  getCreditMovements(customerId).forEach(m => movements.push({
    type: 'credit', date: m.date, amount: m.amount, kg: m.kg, ref: m.ref,
    status: 'pendiente', remaining: m.amount, method: null,
  }));
  getCustomerPayments(customerId).forEach(p => movements.push({
    type: 'payment', date: (p.timestamp || '').slice(0, 10), amount: Number(p.amount) || 0,
    method: p.method, ref: p.id, status: 'abono', remaining: 0, kg: 0,
  }));

  movements.sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? -1 : 1;
    if (a.type === 'credit' && b.type !== 'credit') return -1;
    if (b.type === 'credit' && a.type !== 'credit') return 1;
    return 0;
  });

  const open = [];
  movements.forEach(m => {
    if (m.type === 'credit') { open.push(m); return; }
    let rem = m.amount;
    while (rem > 0.001 && open.length > 0) {
      const head = open[0];
      const take = Math.min(head.remaining, rem);
      head.remaining -= take;
      rem -= take;
      if (head.remaining <= 0.001) open.shift();
    }
  });
  movements.forEach(m => {
    if (m.type === 'credit' && m.remaining <= 0.001) m.status = 'saldado';
  });

  return movements.slice().reverse();
}

// True when the customer has a payment recurrence configured
// (e.g. "pays every Monday"). Such customers collect old debt on
// their scheduled day, not at the delivery stop.
function hasPaymentRecurrence(c) {
  return !!(c && c.recurrence && c.recurrence.preset && c.recurrence.preset !== 'none');
}

// ─── CANONICAL CREDIT LEDGER REPLAY (Cobranza) ─────────
// Single FIFO implementation for all Cobranza analytics. Undated opening
// balances predate app sales; same-day credits precede same-day payments.
function _creditEventSort(a, b) {
  const aUndated = !!a.isOpeningBalance && !a.dateKnown;
  const bUndated = !!b.isOpeningBalance && !b.dateKnown;
  if (aUndated && !bUndated) return -1;
  if (bUndated && !aUndated) return 1;
  const ad = a.date || '', bd = b.date || '';
  if (ad !== bd) return ad < bd ? -1 : 1;
  if (a.type === 'credit' && b.type === 'payment') return -1;
  if (a.type === 'payment' && b.type === 'credit') return 1;
  return 0;
}

function _daysBetween(a, b) {
  if (!a || !b) return null;
  return Math.max(0, Math.round((new Date(b + 'T12:00:00') - new Date(a + 'T12:00:00')) / 86400000));
}

// Pure FIFO replay over pre-built {credits, payments} arrays (no DB reads,
// no mutation of inputs) so ledger semantics are unit-testable. A payment
// only ever touches credits already outstanding at its date — future credits
// are unreachable by construction.
function _replayLedgerEvents(credits, payments) {
  const cs = (credits || []).map(c => ({
    ref: c.ref, date: c.date || null,
    // Explicit dateKnown wins (guarded by date presence); otherwise a dated
    // credit is known and a dateless one is not.
    dateKnown: c.dateKnown !== undefined ? (!!c.dateKnown && !!c.date) : !!c.date,
    source: c.source || (c.isOpeningBalance ? 'opening' : 'sale'),
    isOpeningBalance: !!c.isOpeningBalance,
    kg: Number(c.kg) || 0,
    stopId: c.stopId || null, orderId: c.orderId || null, routeName: c.routeName || null,
    originalAmount: Number(c.amount) || 0, remaining: Number(c.amount) || 0,
    settled: false, settledDate: null, daysToSettle: null, allocations: [],
  })).filter(c => c.originalAmount > 0.001);
  const ps = (payments || [])
    .map(p => ({ id: p.id || p.ref || null, date: p.date || ((p.timestamp || '').slice(0, 10)) || null, amount: Number(p.amount) || 0 }))
    .filter(p => p.date && p.amount > 0.001);
  const events = [...cs.map(c => ({ kind: 'credit', c })), ...ps.map(p => ({ kind: 'payment', p }))];
  events.sort((x, y) => _creditEventSort(
    x.kind === 'credit' ? { ...x.c, type: 'credit' } : { ...x.p, type: 'payment', isOpeningBalance: false, dateKnown: !!x.p.date },
    y.kind === 'credit' ? { ...y.c, type: 'credit' } : { ...y.p, type: 'payment', isOpeningBalance: false, dateKnown: !!y.p.date }
  ));
  const queue = [];
  const unappliedPayments = [];
  events.forEach(ev => {
    if (ev.kind === 'credit') { queue.push(ev.c); return; }
    let remainingPayment = ev.p.amount;
    while (remainingPayment > 0.001 && queue.length > 0) {
      const credit = queue[0];
      const allocated = Math.min(credit.remaining, remainingPayment);
      credit.remaining -= allocated;
      remainingPayment -= allocated;
      credit.allocations.push({
        paymentId: ev.p.id, paymentDate: ev.p.date, amount: allocated,
        daysFromCredit: credit.dateKnown ? _daysBetween(credit.date, ev.p.date) : null,
      });
      if (credit.remaining <= 0.001) {
        credit.remaining = 0;
        credit.settled = true;
        credit.settledDate = ev.p.date;
        if (credit.dateKnown) credit.daysToSettle = _daysBetween(credit.date, ev.p.date);
        queue.shift();
      }
    }
    if (remainingPayment > 0.001) {
      unappliedPayments.push({ paymentId: ev.p.id, date: ev.p.date, amount: remainingPayment });
    }
  });
  const openCredits = cs.filter(c => !c.settled);
  const settledCredits = cs.filter(c => c.settled);
  return {
    credits: cs, payments: ps, openCredits, settledCredits, unappliedPayments,
    totalOriginalCredit: cs.reduce((s, c) => s + c.originalAmount, 0),
    totalOpen: openCredits.reduce((s, c) => s + c.remaining, 0),
  };
}

const _cobWarned = new Set();
function _cobWarnOnce(key, ...args) {
  if (_cobWarned.has(key)) return;
  _cobWarned.add(key);
  console.warn(...args);
}

// DB-backed wrapper: loads movements, replays, and surfaces unapplied
// payments as data-quality warnings (deduped; console only, never UI).
function _replayCustomerCreditLedger(customerId) {
  const replay = _replayLedgerEvents(getCreditMovements(customerId), getCustomerPayments(customerId));
  replay.unappliedPayments.forEach(u => {
    _cobWarnOnce('unapplied@' + customerId + '@' + (u.paymentId || u.date + '|' + u.amount),
      '[COBRANZA UNAPPLIED]', { customerId, paymentId: u.paymentId, date: u.date, amount: u.amount });
  });
  return replay;
}

// Open (unpaid) credits via the canonical replay, oldest first. Shape stays
// compatible with statement-screen callers (ref/kg/date/remaining/ids).
function getOpenCredits(customerId) {
  return _replayCustomerCreditLedger(customerId).openCredits.map(c => ({
    ref: c.ref, kg: c.kg, date: c.date, dateKnown: c.dateKnown,
    remaining: c.remaining, stopId: c.stopId, orderId: c.orderId,
    routeName: c.routeName, isOpeningBalance: c.isOpeningBalance,
  }));
}

function getOldestPendingCredit(customerId) {
  const open = getOpenCredits(customerId);
  if (open.length === 0) return null;
  return open[0];
}

function getRecentPendingCredit(customerId) {
  const open = getOpenCredits(customerId);
  if (open.length === 0) return null;
  return open[open.length - 1];
}

// ─── CUSTOMER ACCOUNT STATEMENT (estado de cuenta) ─────
function startOfWeek(dateStr) {
  const d = new Date(dateStr + 'T12:00:00');
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(d.setDate(diff)).toISOString().slice(0, 10);
}

function startOfMonth(dateStr) {
  return dateStr.slice(0, 7) + '-01';
}

// Build chronological ledger for a customer with running balance.
// filter: 'all' | 'sinceLastPayment' | 'week' | 'month' | '90d'
// Returns rows newest-first, each with { type, date, time, amount, kg, ref,
// operator, desc, monto (+ for credits, - for payments), saldo_actual }.
// saldo_actual starts at $0 within the selected period, so the final row
// equals the debt attributable to that period.
function getCustomerStatement(customerId, filter) {
  const movements = [];
  getCreditMovements(customerId).forEach(m => movements.push({
    type: 'credit',
    date: m.date,
    time: '',
    amount: Number(m.amount) || 0,
    kg: Number(m.kg) || 0,
    ref: m.ref,
    operator: m.operator || '—',
    desc: m.note || ((Number(m.kg) || 0) > 0 ? (Number(m.kg) || 0) + ' kg Tortilla' : 'Nota a Crédito'),
  }));
  getCustomerPayments(customerId).forEach(p => movements.push({
    type: 'payment',
    date: (p.timestamp || '').slice(0, 10),
    time: (p.timestamp || '').slice(11, 16),
    amount: Number(p.amount) || 0,
    kg: 0,
    ref: p.id,
    operator: p.operator || '—',
    desc: 'Pago Efectivo',
  }));

  movements.sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? -1 : 1;
    if (a.type === 'credit' && b.type === 'payment') return -1;
    if (a.type === 'payment' && b.type === 'credit') return 1;
    return 0;
  });

  let from = null;
  if (filter === 'week') from = startOfWeek(today());
  else if (filter === 'month') from = startOfMonth(today());
  else if (filter === '90d') from = shiftDays(today(), -89);
  else if (filter === 'sinceLastPayment') {
    const lastPay = getCustomerPayments(customerId).slice(-1)[0];
    if (lastPay) from = (lastPay.timestamp || '').slice(0, 10);
  }

  const rows = [];
  let saldo = 0;
  movements.forEach(m => {
    if (from && m.date < from) return;
    if (m.type === 'credit') saldo += m.amount;
    else saldo = Math.max(0, saldo - m.amount);
    rows.push({ ...m, monto: m.type === 'credit' ? m.amount : -m.amount, saldo_actual: saldo });
  });

  const periodTotal = rows.length ? rows[rows.length - 1].saldo_actual : 0;
  return { rows: rows.slice().reverse(), periodTotal };
}

// Next date on/after fromDate matching the recurrence pattern.
function nextRecurrenceDate(r, fromDate) {
  if (!r || r.preset === 'none') return null;
  const anchor = r.anchor || fromDate;
  const start = new Date(fromDate + 'T12:00:00');
  for (let i = 0; i < 366; i++) {
    const d = new Date(start.getTime() + i * 86400000);
    const ds = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    if (isRecurrenceDate(anchor, r, ds)) return ds;
  }
  return null;
}

function addPayment(customerId, amount, method) {
  const amt = Number(amount) || 0;
  if (amt <= 0) return null;
  const p = {
    id: genId(),
    customerId,
    amount: amt,
    method: 'cash',
    operator: (AppState.driver && AppState.driver.name) || '—',
    timestamp: new Date().toISOString(),
  };
  PAYMENTS.push(p);
  savePayments();
  const c = getCustomerSafe(customerId, { label: 'Cliente' });
  if (c) {
    c.balance = Math.max(0, (c.balance || 0) - amt);
    saveClients();
  }
  return p;
}

// Applies a cash abono toward an outstanding old debt WITHOUT recording a
// new collection entry — the caller (confirmStop) already recorded the full
// cash via addCollection, so this only decrements the customer balance and
// appends the ABONO row to their account statement.
function recordDebtPayment(customerId, amount) {
  const amt = Number(amount) || 0;
  if (amt <= 0) return null;
  const p = {
    id: genId(),
    customerId,
    amount: amt,
    method: 'cash',
    operator: (AppState.driver && AppState.driver.name) || '—',
    timestamp: new Date().toISOString(),
  };
  PAYMENTS.push(p);
  savePayments();
  const c = getCustomerSafe(customerId, { label: 'Cliente' });
  if (c) {
    c.balance = Math.max(0, (c.balance || 0) - amt);
    saveClients();
  }
  return p;
}

function loadAdvanceOrders() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_ORDERS);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return [];
}

function saveAdvanceOrders() {
  try { localStorage.setItem(STORAGE_KEY_ORDERS, JSON.stringify(advanceOrders)); } catch (e) {}
}

function stopsProgressKey(routeName) {
  const d = AppState.routeDate || today();
  return 'stops_' + routeName.replace(/\s/g, '') + '_' + d;
}

function loadStopProgress(routeName) {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_STOPS + '_' + stopsProgressKey(routeName));
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return null;
}

function saveStopProgress(routeName, stops) {
  try {
    const data = stops.map(s => ({
      stopId: s.stopId,
      status: s.status,
      devolucionKg: s.devolucionKg,
      recompraKg: s.recompraKg,
      recompraCollected: s.recompraCollected || 0,
      stopPhase: s.stopPhase,
      extraKg: s.extraKg,
      creditAmount: s.creditAmount,
      creditPaidType: s.creditPaidType,
      creditPaidAmount: s.creditPaidAmount,
      paymentType: s.paymentType,
      cashTendered: s.cashTendered,
      oldDebtPaid: s.oldDebtPaid || 0,
      deliveryDraft: s.deliveryDraft || null,
    }));
    localStorage.setItem(STORAGE_KEY_STOPS + '_' + stopsProgressKey(routeName), JSON.stringify(data));
  } catch (e) {}
}

let _tripCounter = 0;
function generateTripId(routeName) {
  // Collision-proof: route prefix + driver initials + short timestamp.
  const prefix = (routeName || 'MIX').replace(/[^A-Za-z0-9]/g, '').slice(0, 3).toUpperCase() || 'MIX';
  const initials = (AppState.driver && AppState.driver.name
    ? AppState.driver.name.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase()
    : 'DR');
  const ts = Date.now().toString(36).slice(-4).toUpperCase();
  return prefix + '-' + initials + '-' + ts;
}

function loadTrips() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_TRIPS);
    if (!saved) return [];
    const trips = JSON.parse(saved);
    let changed = false;
    trips.forEach(t => {
      const unique = [...new Set(t.orderIds || [])];
      if (unique.length !== (t.orderIds || []).length) {
        t.orderIds = unique;
        changed = true;
      }
    });
    if (changed) localStorage.setItem(STORAGE_KEY_TRIPS, JSON.stringify(trips));
    return trips;
  } catch (e) {}
  return [];
}

function saveTrips() {
  try {
    AppState.trips.forEach(t => { t.orderIds = [...new Set(t.orderIds || [])]; });
    localStorage.setItem(STORAGE_KEY_TRIPS, JSON.stringify(AppState.trips));
  } catch (e) {}
}

// Creates the trip LOCALLY first (instant UI) and verifies the claims
// against Firestore in the background. The blocking Firestore
// transaction (N sequential reads) used to stall the modal 4-5s; now
// only a genuine conflict (another driver claimed first) walks it back.
async function createTrip(routeName, kilosLoaded, orderIds) {
  const routes = [...new Set(orderIds.map(oid => {
    const o = advanceOrders.find(x => x.id === oid);
    return o ? o.route : null;
  }).filter(Boolean))];
  const primaryRoute = routeName || routes[0] || 'MIX';
  const tripId = generateTripId(primaryRoute);

  const trip = {
    id: tripId,
    routeName: primaryRoute,
    routes,
    date: AppState.routeDate || today(),
    kilosLoaded: Number(kilosLoaded),
    orderIds: [...orderIds],
    status: 'active',
    expanded: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    createdBy: AppState.driver.id,
    createdByName: AppState.driver.name,
    assignedTo: AppState.driver.id,
    assignedToName: AppState.driver.name,
  };
  AppState.trips.push(trip);
  orderIds.forEach(oid => {
    const o = advanceOrders.find(x => x.id === oid);
    if (o) o.tripId = trip.id;
  });
  saveTrips();
  saveAdvanceOrders();

  // Background claim verification — never blocks the UI.
  (async () => {
    try {
      if (window.SyncDebug && SyncDebug.claimOrders) {
        await SyncDebug.claimOrders(orderIds, tripId, AppState.driver.id, AppState.driver.name);
      }
    } catch (e) {
      if (e && e.message === 'orders_taken') {
        const taken = e.taken || [];
        const takenNames = taken.map(oid => {
          const o = advanceOrders.find(x => x.id === oid);
          return o ? o.customerName : oid;
        });
        // Walk back the lost orders locally; the rest of the trip stands.
        // Re-resolve the trip: reloadData() swaps AppState.trips for a
        // fresh array, so the captured reference may be stale.
        const t = AppState.trips.find(x => x.id === tripId);
        if (t) {
          t.orderIds = (t.orderIds || []).filter(oid => !taken.includes(oid));
          if (t.orderIds.length === 0) {
            AppState.trips = AppState.trips.filter(x => x.id !== tripId);
            showToast('❌ Todas las órdenes ya fueron tomadas');
          } else {
            t.kilosLoaded = t.orderIds.reduce((s, oid) => {
              const o = advanceOrders.find(x => x.id === oid);
              return s + (o ? o.qty : 0);
            }, 0);
            showToast('⚠️ Órdenes ya tomadas: ' + takenNames.join(', '));
          }
          t.updatedAt = new Date().toISOString();
        }
        taken.forEach(oid => {
          const o = advanceOrders.find(x => x.id === oid);
          if (o && o.tripId === tripId) delete o.tripId;
        });
        saveTrips();
        saveAdvanceOrders();
        try { if (AppState.route) rebuildRouteStops(); } catch (err) {}
        render();
      } else {
        // Transient Firestore failures (permission, network) must NOT
        // block trip creation — deferred sync reconciles later.
        console.warn('claimOrders failed (deferred sync):', e && e.message);
      }
    }
  })();

  return trip;
}

function completeTrip(tripId) {
  const trip = AppState.trips.find(t => t.id === tripId);
  if (trip) {
    const now = new Date().toISOString();
    trip.status = 'completed';
    trip.completedBy = AppState.driver.id;
    trip.completedByName = AppState.driver.name;
    trip.completedAt = now;
    trip.updatedAt = now;
  }
  saveTrips();
}

function getTripsForRoute(routeName) {
  const d = AppState.routeDate || today();
  return AppState.trips.filter(t =>
    t.date === d &&
    (t.routes ? t.routes.includes(routeName) : t.routeName === routeName)
  );
}

function getAvailableOrdersForRoute(routeName) {
  const d = AppState.routeDate || today();
  return advanceOrders.filter(o =>
    o.route === routeName &&
    o.status === 'pending' &&
    !o.tripId &&
    o.date === d &&
    !(getCustomer(o.customerId) || {}).deleted
  );
}

function getOrdersForTrip(tripId) {
  const trip = AppState.trips.find(t => t.id === tripId);
  if (!trip) return [];
  return [...new Set(trip.orderIds || [])].map(oid => advanceOrders.find(o => o.id === oid)).filter(Boolean);
}

function getTripProgress(tripId) {
  const orders = getOrdersForTrip(tripId);
  const total = orders.length;
  const done = orders.filter(o => o.status === 'completed' || o.status === 'skipped').length;
  return { done, total };
}

function isTripCompleted(trip) {
  if (!trip) return false;
  if (trip.status === 'completed') return true;
  const orders = getOrdersForTrip(trip.id);
  return orders.length > 0 && orders.every(o => o.status === 'completed' || o.status === 'skipped');
}

// ─── TRIP OWNERSHIP & HANDOFFS ─────────────────────────
// Owner of a trip = assignedTo (after a takeover) || createdBy.
// Legacy trips without either field are visible to every driver.
function tripOwnerId(t) { return (t && (t.assignedTo || t.createdBy)) || null; }
function tripOwnerName(t) {
  if (!t) return '—';
  return t.assignedToName || t.createdByName || '—';
}
function isTripMine(t) {
  if (!t) return false;
  const owner = tripOwnerId(t);
  if (!owner) return true; // legacy trips have no owner → everyone
  return owner === (AppState.driver && AppState.driver.id);
}

// Handoff log on an order: one entry per driver who left a partial.
// kg/dev/rec are CUMULATIVE totals as of that partial; cash was booked
// by that driver at partial-commit time (true to who holds the cash).
function orderHandoffs(o) {
  return (o && Array.isArray(o.deliveryHandoffs)) ? o.deliveryHandoffs : [];
}
function sumHandoffCash(o) {
  return orderHandoffs(o).reduce((s, h) => s + (Number(h.cash) || 0), 0);
}
function otherHandoffs(o) {
  const me = AppState.driver && AppState.driver.id;
  return orderHandoffs(o).filter(h => h.by !== me);
}

// Jose takes one pending order from another driver's active trip.
// Destination: my active trip today sharing the order's route (kilos
// bumped by the undelivered remainder) — else a fresh trip is created.
async function takeOrder(orderId) {
  const me = AppState.driver;
  const o = getAdvanceOrder(orderId);
  if (!o) { showToast('❌ Orden no encontrada'); return false; }
  if (o.status !== 'pending') { showToast('❌ La orden ya no está pendiente'); return false; }
  const oldTrip = AppState.trips.find(t => (t.orderIds || []).includes(orderId));
  if (oldTrip && isTripMine(oldTrip)) { showToast('⚠️ La orden ya es tuya'); return false; }
  const taking = AppState._takingOrders || (AppState._takingOrders = new Set());
  if (taking.has(orderId)) return false;
  taking.add(orderId);

  const d = AppState.routeDate || today();
  const route = o.route;
  let dest = AppState.trips.find(t =>
    t.date === d && t.status === 'active' && isTripMine(t) &&
    (t.routes || [t.routeName]).includes(route)
  );
  const destIsNew = !dest;
  const alreadyInDest = !!(dest && (dest.orderIds || []).includes(orderId));
  const deliveredSoFar = orderHandoffs(o).length
    ? Math.max(...orderHandoffs(o).map(h => Number(h.kg) || 0))
    : 0;
  const remaining = Math.max(0, (o.qty || 0) - deliveredSoFar);
  if (destIsNew) {
    dest = {
      id: generateTripId(route),
      routeName: route,
      routes: [route],
      date: d,
      kilosLoaded: remaining,
      orderIds: [],
      status: 'active',
      expanded: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: me.id,
      createdByName: me.name,
      assignedTo: me.id,
      assignedToName: me.name,
    };
    AppState.trips.push(dest);
  } else if (!alreadyInDest) {
    dest.kilosLoaded = (dest.kilosLoaded || 0) + remaining;
  }
  dest.orderIds = [...new Set([...(dest.orderIds || []), orderId])];

  const previousOrder = {
    tripId: o.tripId,
    claimedBy: o.claimedBy,
    claimedByName: o.claimedByName,
    claimedAt: o.claimedAt,
    updatedAt: o.updatedAt,
  };
  const previousOldOrderIds = oldTrip ? [...(oldTrip.orderIds || [])] : null;
  const previousOldKilos = oldTrip ? oldTrip.kilosLoaded : null;
  if (oldTrip) oldTrip.orderIds = (oldTrip.orderIds || []).filter(x => x !== orderId);
  o.tripId = dest.id;
  o.claimedBy = me.id;
  o.claimedByName = me.name;
  o.claimedAt = new Date().toISOString();
  o.updatedAt = new Date().toISOString();
  saveTrips();
  saveAdvanceOrders();
  taking.delete(orderId);
  showToast('🙋 Entrega tomada — ahora es tuya');

  // Confirm ownership in the background. The UI is local-first; only a
  // real conflict rolls back the optimistic transfer.
  (async () => {
    try {
      if (!window.SyncDebug || !SyncDebug.transferOrders) return;
      const res = await SyncDebug.transferOrders([orderId], oldTrip ? oldTrip.id : null, dest.id, me.id, me.name);
      if (!res || !Array.isArray(res.conflicts) || res.conflicts.length === 0) return;
      const currentDest = AppState.trips.find(t => t.id === dest.id);
      if (currentDest) {
        currentDest.orderIds = (currentDest.orderIds || []).filter(x => x !== orderId);
        if (destIsNew) AppState.trips = AppState.trips.filter(t => t.id !== dest.id);
        else if (!alreadyInDest) currentDest.kilosLoaded = Math.max(0, (currentDest.kilosLoaded || 0) - remaining);
      }
      if (oldTrip) {
        const currentOld = AppState.trips.find(t => t.id === oldTrip.id);
        if (currentOld) {
          currentOld.orderIds = previousOldOrderIds;
          currentOld.kilosLoaded = previousOldKilos;
        }
      }
      const currentOrder = getAdvanceOrder(orderId);
      if (currentOrder) Object.assign(currentOrder, previousOrder);
      saveTrips();
      saveAdvanceOrders();
      const names = res.conflicts.map(oid => {
        const oo = getAdvanceOrder(oid);
        return oo ? oo.customerName : oid;
      });
      showToast('❌ Ya fue tomada: ' + names.join(', '));
      render();
    } catch (e) {
      console.warn('transferOrders failed (deferred sync):', e && e.message);
    }
  })();
  return true;
}

// Take over a whole active trip (ownership only; order claims unchanged).
function takeTrip(tripId) {
  const t = AppState.trips.find(x => x.id === tripId);
  if (!t) { showToast('❌ Ruta no encontrada'); return false; }
  const me = AppState.driver;
  if (isTripMine(t)) { showToast('⚠️ La ruta ya es tuya'); return false; }
  const previousOwner = tripOwnerId(t);
  const now = new Date().toISOString();
  t.assignedTo = me.id;
  t.assignedToName = me.name;
  t.takenFrom = previousOwner;
  t.takenAt = now;
  t.takenBy = me.id;
  t.takenByName = me.name;
  t.updatedAt = now;
  saveTrips();
  showToast('🙋 Ruta ' + t.id + ' asignada a ti');
  return true;
}

// ─── PRODUCTS ──────────────────────────────────────────
const PRODUCTS_KEY = 'elcomal_productCatalog';
const DEFAULT_PRODUCTOS = [
  { id: 'P1', sku: 'P1', uom: 'Kg', name: 'Tortilla de Maíz', price: 22, unit: 'kg', icon: '🫓' },
  { id: 'P2', sku: 'P2', uom: 'Kg', name: 'Tortilla de Harina', price: 28, unit: 'kg', icon: '🫔' },
  { id: 'P3', sku: 'P3', uom: 'Kg', name: 'Tostadas', price: 18, unit: 'kg', icon: '🟤' },
  { id: 'P4', sku: 'P4', uom: 'Kg', name: 'Totopos', price: 20, unit: 'kg', icon: '🔺' },
  { id: 'P5', sku: 'P5', uom: 'Kg', name: 'Kilo Frio', price: 8, unit: 'kg', icon: '❄️' },
];

function loadProducts() {
  const saved = DB.Storage.get(PRODUCTS_KEY, null);
  const list = Array.isArray(saved) && saved.length > 0 ? saved : JSON.parse(JSON.stringify(DEFAULT_PRODUCTOS));
  // Additive ERP-fields enrichment: older catalogs lack sku/uom. Never
  // removes or rewrites anything — only fills in missing fields.
  let enriched = false;
  list.forEach(p => {
    if (p.sku === undefined) { p.sku = p.id; enriched = true; }
    if (p.uom === undefined) { p.uom = 'Kg'; enriched = true; }
  });
  if (enriched) DB.Storage.set(PRODUCTS_KEY, list);
  return list;
}

function saveProducts() { DB.Storage.set(PRODUCTS_KEY, PRODUCTOS); }

let PRODUCTOS = loadProducts();

const RECOMPRA_PRICE = 8;

// ─── BUILD ROUTE ────────────────────────────────────────
function buildMockRoute(routeName) {
  const orders = getAdvanceOrdersForRoute(routeName);

  const stops = orders.map((o, i) => {
    const c = getCustomer(o.customerId);
    return {
      stopId: 'S' + (o.customerId.slice(1)),
      customerId: o.customerId,
      customerName: c ? c.name : o.customerName,
      preOrderKg: o.qty,
      staleKg: 0,
      devolucionKg: 0,
      recompraKg: 0,
      extraKg: 0,
      creditAmount: 0,
      creditPaidType: null,
    creditPaidAmount: 0,
    deliveryDraft: null,
      paymentType: '',
      cashTendered: 0,
      stopPhase: 'pendiente',
      deliveryDraft: null,
      status: i === 0 ? 'active' : 'pending',
      sequence: i + 1,
    };
  });

  const routeDate = AppState.routeDate || today();

  const saved = loadStopProgress(routeName);
  if (saved) {
    saved.forEach(sp => {
      const st = stops.find(s => s.stopId === sp.stopId);
      if (st) Object.assign(st, sp);
    });
  }

  return {
    id: 'R-' + routeName.replace(/\s/g, '') + '-' + routeDate.replace(/-/g, ''),
    name: routeName,
    date: routeDate,
    dateDisplay: capitalize(formatDate(routeDate)),
    startingInventory: stops.reduce((s, st) => s + st.preOrderKg, 0),
    stops,
  };
}

// ─── ROUTES ─────────────────────────────────────────────
const ROUTES = [
  'Pueblo Nuevo', 'La Perla', 'Dolores',
  'El Paso', '25 de Diciembre', 'Melgar', 'La Flor', 'La Una',
];

// Sales-quadrant classification for a route name (used by the zone report).
// Keyword matching tolerates prefixes/gaps/casing (e.g. "Ruta Pueblo Nuevo",
// "EL PASO", "25 de diciembre"); anything unmatched drops to 'Otra'.
function _routeQuadrant(routeName) {
  const n = String(routeName || '').toLowerCase();
  if (!n) return 'Otra';
  if (/(base|el paso|centro)/.test(n)) return 'Base';
  if (/(norte|pueblo|perla|dolores)/.test(n)) return 'Norte';
  if (/(oeste|melgar|25|diciembre|flor)/.test(n)) return 'Oeste';
  if (/(este|la una|una)/.test(n)) return 'Este';
  return 'Otra';
}

// ─── STATE MANAGEMENT FUNCTIONS ────────────────────────
function rebuildRouteStops(routeName) {
  const r = AppState.route;
  if (!r) return;
  // Only trips I own feed my working stop list. Other drivers' trips
  // stay visible on the home screen (read-only + take buttons).
  const trips = getTripsForRoute(routeName || AppState.routeName).filter(isTripMine);
  const stops = [];
  const seenOrders = new Set();
  trips.forEach(trip => {
    const orders = getOrdersForTrip(trip.id);
    orders.forEach(o => {
      if (seenOrders.has(o.id)) return;
      seenOrders.add(o.id);
      const completed = o.status === 'completed' || o.status === 'skipped';
      stops.push({
        stopId: 'S-' + o.id,
        orderId: o.id,
        customerId: o.customerId,
        customerName: o.customerName,
        preOrderKg: o.qty,
        staleKg: 0,
        devolucionKg: o.devolucionKg || 0,
        recompraKg: o.recompraKg || 0,
        extraKg: 0,
        deliveredKg: completed ? (o.deliveredKg || o.qty) : 0,
        creditAmount: o.creditAmount || 0,
        creditPaidType: o.creditPaidType || null,
        creditPaidAmount: o.creditPaidAmount || 0,
        oldDebtPaid: o.oldDebtPaid || 0,
        skipReason: o.skipReason || null,
        skipNote: o.skipNote || null,
        completedAt: o.completedAt || null,
        paymentType: '',
        cashTendered: 0,
        stopPhase: 'pendiente',
        status: completed ? o.status : 'active',
        sequence: 1,
        deliveryDraft: completed ? null : (o.deliveryDraft || null),
      });
    });
  });
  r.stops = stops;
  r.startingInventory = trips.reduce((s, t) => s + (t.kilosLoaded || 0), 0);
}

function initRoute() {
  AppState.routeName = ROUTES[0];
  AppState.routeFilter = null;
  AppState.routeDate = today();
const session = DB.Session.load(AppState.routeName, AppState.routeDate);
 AppState.extraSales = DB.Street.byDate(AppState.routeDate || today());
 AppState.collections = session.collections;
  AppState.creditModal = null;
  AppState.collapsedCompleted = true;
  AppState.showRouteFilter = false;
  AppState.routeCreationDestFilter = [];
  AppState.routeCreationDestOpen = false;
  AppState.futureOrders = DB.FutureOrders.load();
  _tripCounter = 0;
  AppState.trips = loadTrips();
  pruneGhostTrips();
  AppState.route = {
    name: AppState.routeName,
    date: AppState.routeDate,
    dateDisplay: capitalize(formatDate(AppState.routeDate)),
    startingInventory: 0,
    stops: [],
  };
  rebuildRouteStops();
}

function getTripStats(routeName) {
  const trips = getTripsForRoute(routeName);
  let totalOrders = 0, doneOrders = 0, totalKilos = 0;
  trips.forEach(t => {
    totalKilos += t.kilosLoaded || 0;
    const orders = getOrdersForTrip(t.id);
    totalOrders += orders.length;
    doneOrders += orders.filter(o => o.status === 'completed' || o.status === 'skipped').length;
  });
  return { totalOrders, doneOrders, totalKilos, pending: totalOrders - doneOrders };
}

function getCustomer(id) { return CLIENTES.find(c => c.id === id); }

// Like getCustomer, but surfaces a toast when the customer is
// missing — e.g. after a whole-array clobber deleted Irma while
// her order survived. Silent no-ops here meant the gap was
// invisible (no credit, no payment, no edits possible).
function getCustomerSafe(id, ctx) {
  const c = getCustomer(id);
  if (!c) {
    try {
      const tag = (ctx && ctx.label) ? ctx.label : 'cliente';
      showToast('⚠️ ' + tag + ' no encontrado: ' + (id || '?'));
    } catch (e) {}
  }
  return c;
}

// Recover customers referenced by orders that are missing from CLIENTES
// (e.g. after a whole-array clobber deleted Irma while her order survived).
// Only creates rows for ids that do not exist at all — never resurrects
// intentionally soft-deleted customers.
function recoverCustomersFromOrders() {
  const existing = new Set(CLIENTES.map(c => c.id));
  let created = 0;
  advanceOrders.forEach(o => {
    const id = o.customerId;
    if (!id || existing.has(id)) return;
    CLIENTES.push({
      id,
      name: o.customerName || 'Desconocido',
      contact: '',
      phone: '',
      direccion: '',
      route: o.route || '',
      paymentTerm: 'COD',
      creditLimit: 0,
      defaultPrice: 0,
      recurrence: null,
      balance: 0,
      deleted: false,
      updatedAt: new Date().toISOString(),
      _recoveredFromOrder: true,
    });
    existing.add(id);
    created++;
  });
  if (created > 0) {
    saveClients();
    try { showToast('Recuperados ' + created + ' cliente(s) de pedidos activos'); } catch (e) {}
  }
}

function getCustomerBalance(customerId) {
  const c = getCustomer(customerId);
  return Math.max(0, (c && c.balance) || 0);
}

function getProduct(id) { return PRODUCTOS.find(p => p.id === id); }

function deleteProduct(id) {
  const idx = PRODUCTOS.findIndex(p => p.id === id);
  if (idx < 0) return false;
  PRODUCTOS.splice(idx, 1);
  saveProducts();
  return true;
}

// ─── PRODUCT PRICES (from settings, persisted) ──────────

function loadProductPrices() {
  const saved = DB.Prices.load();
  if (saved) return saved;
  const defaults = {};
  PRODUCTOS.forEach(p => { defaults[p.id] = p.price; });
  DB.Prices.save(defaults);
  return defaults;
}

function getProductPrice(productId) {
  const prices = loadProductPrices();
  return prices[productId] || PRODUCTOS.find(p => p.id === productId)?.price || 22;
}

function setProductPrice(productId, price) {
  const prices = loadProductPrices();
  prices[productId] = price;
  DB.Prices.save(prices);
}

function getEffectivePrice(customerId, productId) {
  const cust = customerId ? getCustomer(customerId) : null;
  if (cust && cust.defaultPrice > 0) return cust.defaultPrice;
  return getProductPrice(productId || 'P1');
}

// Price resolution for a stop: the order's price prevails, then the
// customer's default price, then the product price. Keeps order-level
// edits authoritative so rutas and all calculations stay consistent.
function getStopPrice(stop) {
  if (!stop) return getProductPrice('P1');
  if (stop.orderId) {
    const o = getAdvanceOrder(stop.orderId);
    if (o && Number(o.price) > 0) return Number(o.price);
  }
  return getEffectivePrice(stop.customerId, stop.productId || 'P1');
}

function completeStop(stopId) {
  const stop = AppState.route.stops.find(s => s.stopId === stopId);
  if (stop) { stop.status = 'completed'; saveStopProgress(AppState.routeName, AppState.route.stops); }
}

function skipStop(stopId) {
  const stop = AppState.route.stops.find(s => s.stopId === stopId);
  if (stop) { stop.status = 'skipped'; saveStopProgress(AppState.routeName, AppState.route.stops); }
}

function allStopsDone() {
  return AppState.route.stops.every(s => s.status === 'completed' || s.status === 'skipped');
}

function getStopProgress() {
  const stops = AppState.route.stops;
  return { done: stops.filter(s => s.status === 'completed').length, total: stops.length };
}

function addExtraSale(productId, kg, amount, description) {
  const sale = {
    id: genId(), productId, kg: Number(kg), amount: Number(amount),
    description: description || '', date: AppState.routeDate || today(), timestamp: new Date().toISOString(),
    driverId: AppState.driver && AppState.driver.id,
    driverName: AppState.driver && AppState.driver.name,
  };
  DB.Street.append(sale);
  AppState.extraSales.push(sale);
}

function addCollection(customerId, cash, card) {
  const id = genId();
  AppState.collections.push({
    id, customerId,
    cash: Number(cash) || 0,
    card: Number(card) || 0,
    timestamp: new Date().toISOString(),
  });
  const rn = AppState.routeName, rd = AppState.routeDate || today();
  if (rn) DB.Session.save(rn, rd, { routeName: rn, date: rd, extraSales: AppState.extraSales, collections: AppState.collections });
  return id;
}

function addFutureOrder(order) {
  AppState.futureOrders.push({ id: genId(), ...order, status: 'pending' });
  DB.FutureOrders.save(AppState.futureOrders);
}

function getSettlementData() {
  const r = AppState.route;
  if (!r) return { startingInventory: 0, totalDelivered: 0, totalExtraSold: 0, totalStaleReturned: 0, totalRecompra: 0, totalRecompraCollected: 0, totalCredited: 0, endingInventory: 0, totalCollected: 0, totalCard: 0, totalCash: 0, recompraValue: 0, streetTotal: 0, devValue: 0, brutoValue: 0 };
 const p1 = getProductPrice('P1');
 const daySales = DB.Street.byDate(AppState.routeDate || today());
  const totalDelivered = r.stops.reduce((s, st) => s + ((st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0), 0) +
    r.stops.reduce((s, st) => s + (st.extraKg || 0), 0);
 const totalExtraSold = daySales.reduce((s, e) => s + e.kg, 0);
  const totalStaleReturned = r.stops.reduce((s, st) => s + (st.devolucionKg || 0), 0);
  const totalRecompra = r.stops.reduce((s, st) => s + (st.recompraKg || 0), 0);
  const totalRecompraCollected = r.stops.reduce((s, st) => s + (st.recompraCollected || 0), 0);
  const totalCredited = r.stops.reduce((s, st) => s + (st.creditAmount || 0), 0);
  let totalCash = 0, totalCard = 0;
  AppState.collections.forEach(c => {
    if (c.paymentType) {
      if (c.paymentType === 'cash') totalCash += c.amount || 0;
      if (c.paymentType === 'card') totalCard += c.amount || 0;
    } else {
      totalCash += c.cash || 0;
      totalCard += c.card || 0;
    }
  });
  const streetTotal = DB.Street.byDate(AppState.routeDate || today()).reduce((s, e) => s + e.amount, 0);
  const totalCollected = totalCash + totalCard;
  const endingInventory = r.startingInventory - totalDelivered - totalExtraSold + totalStaleReturned + totalRecompra;
  // Value sales and devoluciones per-stop using each order's effective price
  // (order-level price prevails; falls back to customer default / product price).
  const perStopGross = r.stops.reduce((s, st) => {
    const pr = getStopPrice(st);
    const dk = st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg;
    return s + (dk || 0) * pr;
  }, 0);
  const perStopDev = r.stops.reduce((s, st) => s + (st.devolucionKg || 0) * getStopPrice(st), 0);
  return {
    startingInventory: r.startingInventory,
    totalDelivered,
    totalExtraSold,
    totalStaleReturned,
    totalRecompra,
    totalRecompraCollected,
    totalCredited,
    endingInventory,
    totalCollected,
    totalCard,
    totalCash,
    recompraValue: totalRecompra * RECOMPRA_PRICE,
    streetTotal,
    devValue: perStopDev,
    brutoValue: perStopGross + totalRecompra * RECOMPRA_PRICE + streetTotal,
  };
}

function getTodaySettlement() {
  try {
    const date = today();
    const snaps = DB.SettlementHistory.getByDate(date);
    // Build the current live route as a pseudo-snapshot so the
    // finished routes plus the in-progress route are all counted.
    const liveRoute = (() => {
      const r = AppState.route;
      if (r && r.stops && r.stops.some(s => s.status === 'completed' || s.status === 'skipped')) {
        return { ...getSettlementData(), routeName: r.name, stops: r.stops, date };
      }
      return null;
    })();
    // If the live route is already captured in a snapshot for this date, don't double-count it.
    const liveAlreadySnapshotted = liveRoute && snaps.some(s => s.routeName === liveRoute.routeName);
    const all = liveAlreadySnapshotted ? snaps : [...snaps, liveRoute].filter(Boolean);
    if (all.length === 0) return null;
    if (all.length === 1) {
      const only = all[0];
      return { ...only, isLive: !liveAlreadySnapshotted, stops: only.stops || [] };
    }
    const aggregated = _aggregateSnapshots(all);
    // Align credit totals with the all-routes live dashboard (advanceOrders),
    // so the settlement CRÉDITO matches the dashboard figure exactly.
    const live = getLiveDayMetrics(date);
    return {
      ...aggregated,
      isLive: false,
      stops: aggregated.stops || [],
      totalCredited: live.totalCredited,
      totalCash: aggregated.totalCash,
      totalCollected: aggregated.totalCash + (aggregated.totalCard || 0),
    };
  } catch (e) {
    console.error('getTodaySettlement error:', e);
    return null;
  }
}

function getSettlementForDate(d) {
  try {
    const date = d || today();
    if (date === today()) return getTodaySettlement();
    const snaps = DB.SettlementHistory.getByDate(date);
    if (snaps.length === 0) return null;
    if (snaps.length === 1) return snaps[0];
    return _aggregateSnapshots(snaps);
  } catch (e) {
    console.error('getSettlementForDate error:', e);
    return null;
  }
}

function _uniqueStops(stops) {
  const seen = new Set();
  return (Array.isArray(stops) ? stops : []).filter(st => {
    const key = st.stopId || st.orderId;
    if (!key) return true;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function getLiveDayMetrics(date) {
  const d = date || today();
  const ords = advanceOrders.filter(o => o.date === d);
  let kilosEntregados = 0, kilosFrios = 0, totalCredited = 0, totalCash = 0, doneOrders = 0;
  ords.forEach(o => {
    if (o.status !== 'completed' && o.status !== 'skipped') return;
    doneOrders++;
    if (o.status === 'completed') {
      const dk = o.deliveredKg !== undefined && o.deliveredKg !== null ? Number(o.deliveredKg) : Number(o.qty) || 0;
      const cash = Number(o.creditPaidAmount) || 0;
      kilosEntregados += dk;
      totalCredited += Number(o.creditAmount) || 0;
      totalCash += cash;
    }
    kilosFrios += Number(o.devolucionKg) || 0;
  });
  return { kilosEntregados, kilosFrios, totalCredited, totalCash, doneOrders };
}

function getDriverCashForDay(date) {
  const d = date || today();
  const driverId = AppState.driver && AppState.driver.id;
  return advanceOrders
    .filter(o => o.date === d && o.status === 'completed' && o.completedBy === driverId)
    .reduce((s, o) => s + (Number(o.creditPaidAmount) || 0), 0);
}

function settlementDeliveredKilos(s) {
  if (!s) return 0;
  if (Array.isArray(s.stops) && s.stops.length) {
    return _uniqueStops(s.stops)
      .filter(st => st.status === 'completed')
      .reduce((sum, st) => sum + ((st.deliveredKg !== undefined ? Number(st.deliveredKg) : Number(st.preOrderKg)) || 0) + (Number(st.extraKg) || 0), 0);
  }
  return Number(s.totalDelivered) || 0;
}

function settlementFriosKilos(s) {
  if (!s) return 0;
  if (Array.isArray(s.stops) && s.stops.length) {
    return _uniqueStops(s.stops)
      .filter(st => st.status === 'completed' || st.status === 'skipped')
      .reduce((sum, st) => sum + (Number(st.devolucionKg) || 0), 0);
  }
  return Number(s.totalStaleReturned || 0);
}

function getCompletedTripsVentas(routeName) {
  const d = AppState.routeDate || today();
  let trips = AppState.trips.filter(t => t.date === d && t.status === 'completed');
  if (routeName) {
    trips = trips.filter(t => (t.routes ? t.routes.includes(routeName) : t.routeName === routeName));
  }
  let ventas = 0;
  trips.forEach(t => {
    getOrdersForTrip(t.id).forEach(o => {
      if (o.status !== 'completed') return;
      const dk = o.deliveredKg || o.qty;
      const op = o.price || getProductPrice(o.productId || 'P1');
      ventas += dk * op - (o.devolucionKg || 0) * op + (o.recompraKg || 0) * RECOMPRA_PRICE;
    });
  });
  return ventas;
}

function _aggregateSnapshots(snapshots) {
  try {
    if (!snapshots || snapshots.length === 0) return null;
    const stops = [];
    const seen = new Set();
    snapshots.forEach(snap => {
      (snap.stops || []).forEach(st => {
        const key = st.stopId || st.orderId;
        if (!key || seen.has(key)) return;
        seen.add(key);
        stops.push(st);
      });
    });
    const stopPrice = st => Number(st.price) || getProductPrice(st.productId || 'P1');
    const deliveredKg = st => ((st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0);
    const totalDelivered = stops.reduce((s, st) => s + deliveredKg(st) + (Number(st.extraKg) || 0), 0);
    const totalStaleReturned = stops.reduce((s, st) => s + (Number(st.devolucionKg) || 0), 0);
    const totalRecompra = stops.reduce((s, st) => s + (Number(st.recompraKg) || 0), 0);
    const totalRecompraCollected = stops.reduce((s, st) => s + (Number(st.recompraCollected) || 0), 0);
    const totalCredited = stops.reduce((s, st) => s + (Number(st.creditAmount) || 0), 0);
    const devValue = stops.reduce((s, st) => s + (Number(st.devolucionKg) || 0) * stopPrice(st), 0);
    const recompraValue = stops.reduce((s, st) => s + (Number(st.recompraKg) || 0) * RECOMPRA_PRICE, 0);
    const routeGross = stops.reduce((s, st) => s + deliveredKg(st) * stopPrice(st), 0);
    const streetByDate = new Map();
    const extraByDate = new Map();
    snapshots.forEach(snap => {
      const d = snap.date || today();
      streetByDate.set(d, Math.max(streetByDate.get(d) || 0, Number(snap.streetTotal) || 0));
      extraByDate.set(d, Math.max(extraByDate.get(d) || 0, Number(snap.totalExtraSold) || 0));
    });
    const streetTotal = [...streetByDate.values()].reduce((s, v) => s + v, 0);
    const totalExtraSold = [...extraByDate.values()].reduce((s, v) => s + v, 0);
    const totalCash = snapshots.reduce((s, snap) => s + (Number(snap.totalCash) || 0), 0);
    const totalCard = snapshots.reduce((s, snap) => s + (Number(snap.totalCard) || 0), 0);
    const startingInventory = snapshots.reduce((s, snap) => s + (Number(snap.startingInventory) || 0), 0);
    const endingInventory = startingInventory - totalDelivered - totalExtraSold + totalStaleReturned + totalRecompra;
    return {
      ...snapshots[0],
      startingInventory,
      totalDelivered,
      totalExtraSold,
      totalStaleReturned,
      totalRecompra,
      totalRecompraCollected,
      totalCredited,
      endingInventory,
      totalCollected: totalCash + totalCard,
      totalCard,
      totalCash,
      recompraValue,
      streetTotal,
      devValue,
      brutoValue: routeGross + recompraValue + streetTotal,
      stopsCount: stops.length,
      completedStopsCount: stops.filter(st => st.status === 'completed').length,
      routeName: 'Todas las rutas',
      stops,
      isLive: false,
    };
  } catch (e) {
    console.error('_aggregateSnapshots error:', e);
    return snapshots[0] || { startingInventory: 0, totalDelivered: 0, totalExtraSold: 0, totalStaleReturned: 0, totalRecompra: 0, totalRecompraCollected: 0, totalCredited: 0, totalCash: 0, totalCard: 0, totalCollected: 0, recompraValue: 0, streetTotal: 0, devValue: 0, brutoValue: 0, routeName: '—', stops: [] };
  }
}

function shiftDays(dateStr, n) {
  const d = new Date(dateStr + 'T12:00:00');
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

// Single source of truth for the report range: the begin/end dates picked in
// the report calendar. Every aggregate report reads from here.
function reportRangeFrom() {
  const from = AppState.reportFrom || today();
  const to = AppState.reportTo || from;
  return from <= to ? { from, to } : { from: to, to: from };
}

// The range immediately before [from,to] with the same number of days, used
// for period-over-period deltas on the dashboard cards.
function prevRangeFrom(from, to) {
  const lo = from <= to ? from : to;
  const hi = from <= to ? to : from;
  const days = Math.round((new Date(hi + 'T12:00:00') - new Date(lo + 'T12:00:00')) / 86400000) + 1;
  const shift = (str, n) => {
    const d = new Date(str + 'T12:00:00');
    d.setDate(d.getDate() + n);
    return d.toISOString().slice(0, 10);
  };
  const pTo = shift(lo, -1);
  return { from: shift(pTo, -(days - 1)), to: pTo };
}

// ─── REPORT DATE RANGE (begin/end date) ─────

function getAggregatedSettlementForRange(from, to) {
  if (!from || !to) return null;
  const lo = from <= to ? from : to;
  const hi = from <= to ? to : from;
  const snaps = DB.SettlementHistory.getRange(lo, hi);
  if (snaps.length === 0) {
    if (lo <= today() && hi >= today()) return getTodaySettlement();
    return null;
  }
  return _aggregateSnapshots(snaps);
}

// ─── REPORT AGGREGATIONS (analytics tabs) ──────────────
// Long ranges roll up to months so the chart stays readable on a phone.
function reportGranularity(from, to) {
  const ms = new Date(to + 'T12:00:00') - new Date(from + 'T12:00:00');
  const days = Math.round(ms / 86400000) + 1;
  return days > 62 ? 'month' : 'day';
}

function _reportBucketKey(dateStr, gran) {
  return gran === 'month' ? String(dateStr).slice(0, 7) : dateStr;
}

function _reportBucketLabel(key, gran) {
  if (gran === 'month') {
    const [y, m] = String(key).split('-');
    return m + '/' + String(y).slice(2);
  }
  return formatStmtDate(key);
}

// ─── SALES TREND DRILL (PowerBI-style: month → week → day) ──
// Every level below is re-aggregated only over the dates inside the drilled
// parent, so a week straddling two months contributes per-month amounts and a
// day panning two ISO weeks is impossible (a day belongs to exactly one week).

function childBucketLevel(level) {
  if (level === 'month') return 'week';
  if (level === 'week') return 'day';
  return null;
}

// Adaptive opening level: shortest range → day, medium → week, long → month.
function reportStartLevel(from, to) {
  const ms = new Date(to + 'T12:00:00') - new Date(from + 'T12:00:00');
  const days = Math.round(ms / 86400000) + 1;
  if (days <= 8) return 'day';
  if (days <= 35) return 'week';
  return 'month';
}

// ISO-8601 week key "YYYY-Www"; the week belongs to the year of its Thursday.
// Pure UTC day arithmetic (DST-proof): weeks are counted from Jan 1 of the
// Thursday's year with week 1 = the week containing Jan 1's Thursday.
function _isoWeekKey(dateStr) {
  const [y, m, d] = String(dateStr).split('-').map(Number);
  const dayMs = Date.UTC(y, m - 1, d);
  const dow = new Date(dayMs).getUTCDay(); // 0=Sun..6=Sat
  const isoDow = dow === 0 ? 7 : dow; // Mon=1..Sun=7
  const thuMs = dayMs + (4 - isoDow) * 86400000; // Thursday of this ISO week
  const thu = new Date(thuMs);
  const thuYear = thu.getUTCFullYear();
  const jan1 = Date.UTC(thuYear, 0, 1);
  const days = Math.floor((thuMs - jan1) / 86400000);
  const week = Math.ceil((days + 1) / 7);
  return thuYear + '-W' + String(week).padStart(2, '0');
}

function _bucketKeyFor(dateStr, level) {
  return level === 'month' ? String(dateStr).slice(0, 7) : level === 'week' ? _isoWeekKey(dateStr) : dateStr;
}

function _bucketLabel(key, level) {
  if (level === 'month') return _reportBucketLabel(key, 'month');
  if (level === 'week') return 'Sem ' + String(key).slice(-2);
  return _reportBucketLabel(key, 'day');
}

// A date belongs inside a drilled parent only when the parent is the immediate
// level above: a month key ("YYYY-MM") for week buckets, a week key
// ("YYYY-Www") for day buckets. Top-level calls pass parentKey = null.
function _dateInParent(dateStr, parentKey, level) {
  if (!parentKey) return true;
  if (level === 'week') return String(dateStr).slice(0, 7) === parentKey;
  if (level === 'day') return _isoWeekKey(dateStr) === parentKey;
  return true;
}

// Sales (route net of devoluciones + street) and unsold kilos bucketed at the
// requested drill level. "Kilos fríos" (unsold) counts devoluciones on
// completed AND skipped stops — a skipped stop returns the whole order.
function getSalesBucketsIn(from, to, level, parentKey) {
  const gran = level || reportStartLevel(from, to);
  const { stops, snaps } = _reportStopsInRange(from, to);
  const buckets = new Map();
  const at = key => {
    if (!buckets.has(key)) buckets.set(key, { key, label: _bucketLabel(key, gran), revenue: 0, kg: 0, orderedKg: 0, devKg: 0, credit: 0, street: 0, stops: 0 });
    return buckets.get(key);
  };
  stops.forEach(({ stop: st, date }) => {
    if (!_dateInParent(date, parentKey, gran)) return;
    // FRÍOS eligibility before ANY accumulation or bucket creation: an
    // incomplete/cancelled stop must not create a trend observation.
    if (!_isFriosEligibleStop(st)) return;
    _validateFriosStop(st);
    const b = at(_bucketKeyFor(date, gran));
    const dv = Number(st.devolucionKg) || 0;
    const ordered = Number(st.preOrderKg) || 0;
    b.devKg += dv;
    b.orderedKg += ordered;
    const pr = getStopPrice(st) || getProductPrice(st.productId || 'P1');
    const dk = (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0;
    b.revenue += dk * pr - dv * pr + (Number(st.recompraKg) || 0) * RECOMPRA_PRICE;
    b.kg += dk;
    b.credit += Number(st.creditAmount) || 0;
    b.stops += 1;
  });
  const streetByDate = new Map();
  snaps.forEach(s => {
    const d = s.date || today();
    streetByDate.set(d, Math.max(streetByDate.get(d) || 0, Number(s.streetTotal) || 0));
  });
  streetByDate.forEach((v, d) => {
    if (!_dateInParent(d, parentKey, gran)) return;
    const b = at(_bucketKeyFor(d, gran));
    b.revenue += v;
    b.street += v;
  });
  const series = [...buckets.values()].sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
  return { level: gran, series };
}

// Top-level trend for a range, auto-selecting the opening drill level.
function getSalesTimeSeries(from, to) {
  const gran = reportStartLevel(from, to);
  const { series } = getSalesBucketsIn(from, to, gran, null);
  return { gran, series };
}

// Every unique stop across the settlements in [from,to], plus the live day
// when it falls inside the range but has not been snapshotted yet.
function _reportStopsInRange(from, to) {
  const snaps = DB.SettlementHistory.getRange(from, to).slice();
  if (from <= today() && to >= today()) {
    const live = getTodaySettlement();
    if (live && !snaps.some(s => s.date === live.date && s.routeName === live.routeName)) snaps.push(live);
  }
  const stops = [];
  const seen = new Set();
  snaps.forEach(s => {
    (s.stops || []).forEach(st => {
      const k = st.stopId || st.orderId;
      if (k) { if (seen.has(k)) return; seen.add(k); }
      stops.push({ stop: st, date: s.date || today(), route: s.routeName || null });
    });
  });
  return { stops, snaps };
}

// ─── FRÍOS canonical metrics ─────────────────────────────
// The only canonical internal values: 'pct' (% frío), 'returned' (kg frío),
// 'ordered' (kg pedidos). Business definition (do not change here):
// % frío = devKg / orderedKg * 100 (delivered kilos NOT used).
const FRIOS_METRICS = ['pct', 'returned', 'ordered'];

function normalizeFriosMetric(metric) {
  // Temporary compatibility with existing callers/state
  if (metric === '%') return 'pct';
  if (metric === 'kg') return 'returned';
  return FRIOS_METRICS.includes(metric) ? metric : 'pct';
}

// Single source of truth for FRÍOS metric values. pct returns null (not 0)
// when there is no ordered-kilos denominator: 0 kg pedidos → "—", never 0%.
function _friosMetricValue(row, metric) {
  metric = normalizeFriosMetric(metric);
  const returnedKg = Number(row?.devKg) || 0;
  const orderedKg = Number(row?.orderedKg) || 0;
  if (metric === 'returned') return returnedKg;
  if (metric === 'ordered') return orderedKg;
  return orderedKg > 0 ? returnedKg / orderedKg * 100 : null;
}

// Display metadata per metric: chart labels, tooltips, legends, units.
function _friosMetricConfig(metric) {
  metric = normalizeFriosMetric(metric);
  if (metric === 'returned') {
    return { label: 'Kg merma', buttonLabel: 'KG MERMA', axisLabel: 'KG MERMA', legend: 'Kilos devueltos', unit: 'kg', decimals: 1 };
  }
  if (metric === 'ordered') {
    return { label: 'Kg pedidos', buttonLabel: 'KG PEDIDOS', axisLabel: 'KG PEDIDOS', legend: 'Kilos pedidos', unit: 'kg', decimals: 1 };
  }
  return { label: '% merma', buttonLabel: '% MERMA', axisLabel: '% MERMA', legend: '% de kilos devueltos', unit: '%', decimals: 1 };
}

// Primary-value formatter for a FRÍOS metric: missing → "—".
function _formatFriosMetric(value, metric) {
  if (value == null) return '—';
  metric = normalizeFriosMetric(metric);
  if (metric === 'pct') return value.toFixed(1) + '%';
  return value.toFixed(1) + ' kg';
}

// Bar width for a FRÍOS metric. pct is absolute (0–100); absolute metrics
// are relative to the largest currently displayed value.
function _friosBarWidth(value, metric, maxValue) {
  metric = normalizeFriosMetric(metric);
  if (value == null) return 0;
  if (metric === 'pct') return Math.max(0, Math.min(value, 100));
  if (maxValue <= 0) return 0;
  return Math.max(0, Math.min(value / maxValue * 100, 100));
}

// ─── FRÍOS stop eligibility ──────────────────────────────
// One canonical rule for all FRÍOS analytics. A stop excluded here is
// excluded from orderedKg, devKg, delivered kg, stops counts, customer
// rollups, daily trend, weekday analysis, customer detail and KPI totals —
// no metric may include a stop another FRÍOS metric excludes. Missing
// status preserves historical behavior (treated as completed/valid) so
// records predating the status field keep working.
function _isFriosEligibleStop(st) {
  if (!st) return false;
  return !st.status || st.status === 'completed';
}

// Analytical kilo parsing: missing optional values → 0 is acceptable, but
// invalid values (non-numeric, negative) return null instead of silently
// becoming valid zeroes. Callers sum null as 0 (with a dev warning) or
// propagate it; they must never treat invalid as measured.
function _safeReportKg(value) {
  if (value === undefined || value === null || value === '') return 0;
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) return null;
  return n;
}

// Development-only FRÍOS data-quality validator (localhost only, deduped,
// never blocks the report). devKg > orderedKg is flagged but NOT rejected —
// it may be returns from an earlier delivery or accumulated returns.
const _friosWarned = new Set();
function _validateFriosStop(st) {
  try {
    const loc = (typeof location !== 'undefined' && location.hostname) || '';
    if (loc !== 'localhost' && loc !== '127.0.0.1') return;
  } catch (e) { return; }
  if (!st) return;
  const id = st.stopId || st.orderId || ((st.customerId || st.customerName || '?') + '|' + String(st.preOrderKg) + '|' + String(st.devolucionKg));
  const flag = issue => {
    const k = issue + '@' + id;
    if (_friosWarned.has(k)) return;
    _friosWarned.add(k);
    console.warn('[FRIOS DATA]', issue, st);
  };
  const ordered = _safeReportKg(st.preOrderKg);
  const dev = _safeReportKg(st.devolucionKg);
  if (ordered === null) flag('invalid orderedKg');
  if (dev === null) flag('invalid devKg');
  if (st.deliveredKg !== undefined && _safeReportKg(st.deliveredKg) === null) flag('invalid deliveredKg');
  if (ordered !== null && dev !== null && dev > ordered) flag('devKg > orderedKg (needs review, not rejected)');
  if (!st.customerId && !st.customerName) flag('eligible stop with missing customer');
}

// Per-customer rollup over the range: sales, delivered kg, devoluciones and
// credit taken. `orderedKg` feeds the "% devuelto" column.
function getCustomerRollup(from, to) {
  const { stops } = _reportStopsInRange(from, to);
  const map = new Map();
  stops.forEach(({ stop: st }) => {
    // Eligible stops only: the customer is not even created when their sole
    // stops in range are ineligible, so Clientes X / Y counts eligible activity.
    if (!_isFriosEligibleStop(st)) return;
    _validateFriosStop(st);
    const key = st.customerId || st.customerName || '—';
    if (!map.has(key)) map.set(key, { key, name: st.customerName || '—', kg: 0, orderedKg: 0, devKg: 0, recKg: 0, credit: 0, revenue: 0, stops: 0 });
    const r = map.get(key);
    const dv = Number(st.devolucionKg) || 0;
    const ordered = Number(st.preOrderKg) || 0;
    const pr = getStopPrice(st) || getProductPrice(st.productId || 'P1');
    const dk = (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0;
    const rc = Number(st.recompraKg) || 0;
    r.devKg += dv;
    r.orderedKg += ordered;
    r.kg += dk;
    r.recKg += rc;
    r.credit += Number(st.creditAmount) || 0;
    r.revenue += dk * pr - dv * pr + rc * RECOMPRA_PRICE;
    r.stops += 1;
  });
  const rows = [...map.values()].sort((a, b) => b.revenue - a.revenue);
  const totalRevenue = rows.reduce((s, r) => s + r.revenue, 0);
  rows.forEach(r => { r.share = totalRevenue > 0 ? r.revenue / totalRevenue * 100 : 0; });
  return { rows, totalRevenue };
}

// Per-customer, per-day series over a range (oldest first): ordered kilos
// (pedido), returns (frío), and delivered kilos (venta) per day. Powers the
// customer drill-down (promedios, tendencia, historial).
function getCustomerDailySeries(from, to, customerKey) {
  const target = String(customerKey);
  const { stops } = _reportStopsInRange(from, to);
  const map = new Map();
  stops.forEach(({ stop: st, date }) => {
    const key = st.customerId || st.customerName || '—';
    if (String(key) !== target) return;
    // Ineligible stops must not generate a customer-detail day.
    if (!_isFriosEligibleStop(st)) return;
    _validateFriosStop(st);
    if (!map.has(date)) map.set(date, { date, orderedKg: 0, devKg: 0, kg: 0, stops: 0 });
    const b = map.get(date);
    b.orderedKg += Number(st.preOrderKg) || 0;
    b.devKg += Number(st.devolucionKg) || 0;
    b.kg += (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0;
    b.stops += 1;
  });
  return [...map.values()].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
}

// Weekday aggregation over a range: ordered/dev kilos per day-of-week
// (dow 0=Dom … 6=Sáb). Reveals patterns like "Sundays consistently have
// more returns" so Sunday orders can be investigated/reduced.
function getWeekdayFrios(from, to) {
  const { stops } = _reportStopsInRange(from, to);
  const days = [0, 1, 2, 3, 4, 5, 6].map(dow => ({ dow, orderedKg: 0, devKg: 0, stops: 0 }));
  stops.forEach(({ stop: st, date }) => {
    if (!_isFriosEligibleStop(st)) return;
    _validateFriosStop(st);
    const b = days[new Date(date + 'T12:00:00').getDay()];
    b.orderedKg += Number(st.preOrderKg) || 0;
    b.devKg += Number(st.devolucionKg) || 0;
    b.stops += 1;
  });
  return days;
}

// Per-route rollup over the range: sales $, delivered kg and stops per route,
// tagged with its sales quadrant (see _routeQuadrant).
function getSalesByRoute(from, to) {
  const { stops } = _reportStopsInRange(from, to);
  const map = new Map();
  stops.forEach(({ stop: st, route: rn }) => {
    const route = rn || st.routeName || '—';
    if (!map.has(route)) map.set(route, { route, quadrant: _routeQuadrant(route), revenue: 0, kg: 0, orderedKg: 0, devKg: 0, stops: 0 });
    const r = map.get(route);
    r.devKg += Number(st.devolucionKg) || 0;
    r.orderedKg += Number(st.preOrderKg) || 0;
    if (st.status && st.status !== 'completed') return;
    const pr = getStopPrice(st) || getProductPrice(st.productId || 'P1');
    const dk = (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0;
    const dv = Number(st.devolucionKg) || 0;
    const rc = Number(st.recompraKg) || 0;
    r.revenue += dk * pr - dv * pr + rc * RECOMPRA_PRICE;
    r.kg += dk;
    r.stops += 1;
  });
  const rows = [...map.values()].sort((a, b) => b.revenue - a.revenue);
  const totalRevenue = rows.reduce((s, r) => s + r.revenue, 0);
  rows.forEach(r => { r.share = totalRevenue > 0 ? r.revenue / totalRevenue * 100 : 0; });
  return { rows, totalRevenue };
}

// Current accounts receivable from the canonical replay. Rows carry stored
// vs ledger balances for audit (stored is shown; never overwritten here).
// Age is the oldest DATED open credit — undated debt reports ageDays null
// (never 0), so it can no longer land in the 0–30 bucket by default.
function getReceivablesSnapshot() {
  const rows = CLIENTES.filter(c => !c.deleted).map(c => {
    const ledger = _replayCustomerCreditLedger(c.id);
    const storedBalance = Number(c.balance) || 0;
    const ledgerBalance = ledger.totalOpen;
    const reconciliationDifference = storedBalance - ledgerBalance;
    const isReconciled = Math.abs(reconciliationDifference) <= 0.005;
    if (!isReconciled) {
      _cobWarnOnce('recon@' + c.id,
        '[COBRANZA RECONCILIATION]', { customerId: c.id, storedBalance, ledgerBalance, difference: reconciliationDifference });
    }
    const datedOpen = ledger.openCredits.filter(q => q.dateKnown && q.date);
    const oldest = datedOpen.length ? datedOpen.reduce((m, q) => (q.date < m ? q.date : m), datedOpen[0].date) : null;
    return {
      id: c.id, name: c.name,
      balance: storedBalance, storedBalance, ledgerBalance, reconciliationDifference, isReconciled,
      creditLimit: Number(c.creditLimit) || 0,
      phone: c.phone || '', route: c.route || '',
      oldest, ageDays: oldest ? _daysBetween(oldest, today()) : null,
      openCount: ledger.openCredits.length,
      hasUnknownAge: ledger.openCredits.some(q => !q.dateKnown || !q.date),
    };
  }).filter(r => r.balance > 0.005 || r.openCount > 0)
    .sort((a, b) => (b.balance - a.balance) || ((b.ageDays ?? -1) - (a.ageDays ?? -1)));
  const total = rows.reduce((s, r) => s + r.balance, 0);
  const overdue = rows.filter(r => (r.ageDays ?? 0) > 30);
  return { rows, total, overdueAmount: overdue.reduce((s, r) => s + r.balance, 0), overdueCount: overdue.length };
}

// Average days to FULLY settle a normal sales credit, derived from the
// canonical replay. Opening balances consume payments in FIFO but never
// contribute to sales performance stats; partial payments never count as
// settled. Overall is the mean over settled credits (not over customers).
function getPayRatioStats() {
  const rows = [];
  const allSettled = [];
  CLIENTES.filter(c => !c.deleted).forEach(c => {
    const ledger = _replayCustomerCreditLedger(c.id);
    const settledSales = ledger.settledCredits.filter(cr => !cr.isOpeningBalance && cr.dateKnown && cr.daysToSettle !== null);
    settledSales.forEach(cr => allSettled.push({ customerId: c.id, daysToSettle: cr.daysToSettle }));
    const open = ledger.openCredits;
    if (settledSales.length === 0 && open.length === 0) return;
    const datedOpen = open.filter(q => q.dateKnown && q.date);
    const oldestOpen = datedOpen.length ? datedOpen.reduce((m, q) => (q.date < m ? q.date : m), datedOpen[0].date) : null;
    rows.push({
      id: c.id, name: c.name,
      avgDays: settledSales.length ? settledSales.reduce((s, cr) => s + cr.daysToSettle, 0) / settledSales.length : null,
      settledCount: settledSales.length,
      openCount: open.length,
      openAmount: open.reduce((s, q) => s + q.remaining, 0),
      oldestOpen,
      oldestDays: oldestOpen ? _daysBetween(oldestOpen, today()) : null,
      hasUnknownAge: open.some(q => !q.dateKnown || !q.date),
    });
  });
  rows.sort((a, b) => ((b.avgDays === null ? -1 : b.avgDays) - (a.avgDays === null ? -1 : a.avgDays)));
  const settledCustomerIds = new Set(allSettled.map(s => s.customerId));
  return {
    rows,
    overall: allSettled.length ? allSettled.reduce((s, x) => s + x.daysToSettle, 0) / allSettled.length : null,
    settledCreditCount: allSettled.length,
    settledCustomerCount: settledCustomerIds.size,
  };
}

function _receivableAgeBucket(ageDays) {
  if (ageDays === null || ageDays === undefined) return 'unknown';
  if (ageDays <= 30) return '0_30';
  if (ageDays <= 60) return '31_60';
  if (ageDays <= 90) return '61_90';
  return '90_plus';
}

// Credit-level AR aging: every OPEN credit is classified independently, so a
// customer contributes remaining amounts (not whole balances) to each bucket
// a credit falls in. Counts are UNIQUE customers per bucket — a customer may
// appear in several buckets, so bucket counts must not be summed.
function getReceivablesAging() {
  const defs = [
    { key: '0_30', label: '0–30 días', color: 'var(--emerald-600)' },
    { key: '31_60', label: '31–60 días', color: 'var(--amber-500)' },
    { key: '61_90', label: '61–90 días', color: 'var(--orange)' },
    { key: '90_plus', label: '> 90 días', color: 'var(--red-600)' },
    { key: 'unknown', label: 'Sin fecha', color: 'var(--slate-400)' },
  ];
  const buckets = {};
  defs.forEach(d => { buckets[d.key] = { ...d, amount: 0, creditCount: 0, customerIds: new Set() }; });
  CLIENTES.filter(c => !c.deleted).forEach(c => {
    _replayCustomerCreditLedger(c.id).openCredits.forEach(cr => {
      const age = cr.dateKnown && cr.date ? _daysBetween(cr.date, today()) : null;
      const b = buckets[_receivableAgeBucket(age)];
      b.amount += cr.remaining;
      b.creditCount += 1;
      b.customerIds.add(c.id);
    });
  });
  return defs.map(d => {
    const b = buckets[d.key];
    return { key: b.key, label: b.label, color: b.color, amount: b.amount, creditCount: b.creditCount, customers: b.customerIds.size };
  });
}

function showToast(msg) {
  AppState.toast = msg;
  render();
  setTimeout(() => { AppState.toast = null; render(); }, 2500);
}

// ─── ADVANCE ORDERS ────────────────────────────────────
let advanceOrders = loadAdvanceOrders();

function getAdvanceOrder(id) { return advanceOrders.find(x => x.id === id); }

function addAdvanceOrder(customerId, productId, qty, price, route, instructions, orderDate, recurrence) {
  const c = getCustomer(customerId);
  const p = getProduct(productId);
  advanceOrders.push({
    id: genId(),
    customerId,
    customerName: c ? c.name : 'Desconocido',
    productId,
    productName: p ? p.name : 'Desconocido',
    qty: Number(qty),
    price: Number(price),
    route,
    instructions: instructions || '',
    date: orderDate || today(),
    status: 'pending',
    tripId: null,
    skipReason: null,
    skipNote: null,
    devolucionKg: 0,
    recompraKg: 0,
    deliveredKg: 0,
    creditAmount: 0,
    creditPaidType: null,
    creditPaidAmount: 0,
    recurrence: recurrence && recurrence.preset !== 'none' ? recurrence : null,
    originOrderId: null,
    source: 'manual',
    createdBy: AppState.driver.id,
    createdByName: AppState.driver.name,
    createdAt: new Date().toISOString(),
    updatedBy: null,
    updatedByName: null,
    updatedAt: null,
  });
  saveAdvanceOrders();
}

function getAdvanceOrdersForRoute(routeName) {
  const d = AppState.routeDate || today();
  return advanceOrders.filter(o => o.route === routeName && o.status === 'pending' && o.date === d);
}

function getAllAdvanceOrders() {
  return advanceOrders;
}

function cancelAdvanceOrder(orderId) {
  const o = advanceOrders.find(x => x.id === orderId);
  if (o) { o.status = 'cancelled'; saveAdvanceOrders(); }
}

function deleteAdvanceOrder(orderId) {
  advanceOrders = advanceOrders.filter(x => x.id !== orderId);
  saveAdvanceOrders();
  pruneGhostTrips();
}

// Removes deleted/stale order ids from trips; drops trips left with no orders
// so they don't show up as empty "ghost" route cards.
// Grace period: trips created < 5 min ago are never pruned — their orders
// may still be in-flight on the sync layer, and a false deletion is
// irreversible (the local delete propagates and kills the remote doc).
function pruneGhostTrips() {
  return false;
}

// ─── Reload all module arrays from localStorage ───────────
// Called by sync.js after remote merges so the UI reflects live
// data without a full page reload.
function reloadData() {
  try {
    CLIENTES = loadClients();
    PRODUCTOS = loadProducts();
    advanceOrders = loadAdvanceOrders();
    AppState.trips = loadTrips();
    PAYMENTS = loadPayments();
    OPENING_DEBTS = loadOpeningDebts();
    AppState.futureOrders = DB.FutureOrders.load();
    AppState.extraSales = DB.Street.byDate(AppState.routeDate || today());
    if (AppState.routeName) {
      const session = DB.Session.load(AppState.routeName, AppState.routeDate);
      AppState.collections = session.collections;
    }
    pruneGhostTrips();
  } catch (e) {
    console.error('reloadData error:', e);
  }
}

function updateAdvanceOrder(orderId, data) {
  const o = advanceOrders.find(x => x.id === orderId);
  if (!o) return;
  if (data.customerId !== undefined) { o.customerId = data.customerId; o.customerName = getCustomer(data.customerId)?.name || 'Desconocido'; }
  if (data.productId !== undefined) { o.productId = data.productId; o.productName = getProduct(data.productId)?.name || 'Desconocido'; }
  if (data.qty !== undefined) o.qty = Number(data.qty);
  if (data.price !== undefined) o.price = Number(data.price);
  if (data.route !== undefined) o.route = data.route;
  if (data.instructions !== undefined) o.instructions = data.instructions;
  if (data.date !== undefined) o.date = data.date;
  if (data.tripId !== undefined) o.tripId = data.tripId;
  if (data.skipReason !== undefined) o.skipReason = data.skipReason;
  if (data.skipNote !== undefined) o.skipNote = data.skipNote;
  if (data.devolucionKg !== undefined) o.devolucionKg = Number(data.devolucionKg);
  if (data.recompraKg !== undefined) o.recompraKg = Number(data.recompraKg);
  if (data.deliveredKg !== undefined) o.deliveredKg = Number(data.deliveredKg);
  if (data.creditAmount !== undefined) o.creditAmount = Number(data.creditAmount);
  if (data.creditPaidType !== undefined) o.creditPaidType = data.creditPaidType;
  if (data.creditPaidAmount !== undefined) o.creditPaidAmount = Number(data.creditPaidAmount);
  if (data.recurrence !== undefined) o.recurrence = data.recurrence && data.recurrence.preset !== 'none' ? data.recurrence : null;
  if (data.originOrderId !== undefined) o.originOrderId = data.originOrderId;
  if (data.source !== undefined) o.source = data.source;
  o.updatedBy = AppState.driver.id;
  o.updatedByName = AppState.driver.name;
  o.updatedAt = new Date().toISOString();
  saveAdvanceOrders();
}

// ─── RECURRING ORDERS ───────────────────────────────────
// Generates today's pending order for every active recurrence
// template. Idempotent: never creates a duplicate for the same
// origin + date. Cancelled/deleted templates stop generation.
function isRecurrenceDate(anchor, r, dateStr) {
  if (dateStr < anchor) return false;
  if (r.endType === 'date' && r.endDate && dateStr > r.endDate) return false;
  const fu = r.frequencyUnit || 'weeks';
  const fv = Math.max(1, r.frequencyValue || 1);
  const start = new Date(anchor + 'T12:00:00');
  const target = new Date(dateStr + 'T12:00:00');
  const diffDays = Math.round((target - start) / 86400000);

  if (fu === 'days') return diffDays % fv === 0;
  if (fu === 'weeks') {
    const dw = r.daysOfWeek && r.daysOfWeek.length ? r.daysOfWeek : [start.getDay()];
    if (!dw.includes(target.getDay())) return false;
    return Math.floor(diffDays / 7) % fv === 0;
  }
  if (fu === 'months') {
    const monthsDiff = (target.getFullYear() - start.getFullYear()) * 12 + (target.getMonth() - start.getMonth());
    return monthsDiff % fv === 0 && target.getDate() === start.getDate();
  }
  if (fu === 'years') {
    const yearsDiff = target.getFullYear() - start.getFullYear();
    return yearsDiff % fv === 0 && target.getMonth() === start.getMonth() && target.getDate() === start.getDate();
  }
  return false;
}

function processRecurrences(dateStr) {
  const d = dateStr || today();
  // A recurrence template keeps generating even after its own day is
  // delivered (status 'completed'). Only cancelled/deleted templates stop.
  const templates = advanceOrders.filter(o =>
    o.recurrence && o.recurrence.preset && o.recurrence.preset !== 'none' &&
    (o.status === 'pending' || o.status === 'completed') &&
    !(getCustomer(o.customerId) || {}).deleted
  );
  let created = 0;
  templates.forEach(t => {
    const r = t.recurrence;
    const anchor = t.date || d;
    if (!isRecurrenceDate(anchor, r, d)) return;
    const originId = t.originOrderId || t.id;
    if (r.endType === 'occurrences') {
      const count = advanceOrders.filter(o => (o.originOrderId || o.id) === originId).length;
      if (count >= (r.endOccurrences || 1)) return;
    }
    const exists = advanceOrders.some(o => (o.originOrderId || o.id) === originId && o.date === d);
    if (exists) return;
    const c = getCustomer(t.customerId);
    const p = getProduct(t.productId);
    advanceOrders.push({
      id: genId(),
      customerId: t.customerId,
      customerName: c ? c.name : t.customerName,
      productId: t.productId,
      productName: p ? p.name : t.productName,
      qty: Number(t.qty),
      price: Number(t.price),
      route: t.route,
      instructions: t.instructions || '',
      date: d,
      status: 'pending',
      tripId: null,
      skipReason: null,
      skipNote: null,
      devolucionKg: 0,
      recompraKg: 0,
      deliveredKg: 0,
      creditAmount: 0,
      creditPaidType: null,
      creditPaidAmount: 0,
      recurrence: null,
      originOrderId: originId,
      source: 'recurring',
      recurringFrom: t.id,
    });
    created++;
  });
  if (created > 0) saveAdvanceOrders();
  return created;
}

// ─── CUSTOMER CRUD ──────────────────────────────────────
function addCustomer(data) {
  const ids = CLIENTES.map(c => Number(c.id.slice(1))).sort((a, b) => a - b);
  const nextNum = ids.length > 0 ? ids[ids.length - 1] + 1 : 1;
  const c = {
    id: 'C' + nextNum,
    name: data.name,
    contact: data.contact || '',
    phone: data.phone || '',
    direccion: data.direccion || '',
    route: data.route || ROUTES[0],
    paymentTerm: data.paymentTerm || 'COD',
    creditLimit: Number(data.creditLimit) || 0,
    defaultPrice: Number(data.defaultPrice) || 0,
    recurrence: data.recurrence || null,
    balance: 0,
    // ── ERP integration fields (additive; all optional) ──
    email: data.email || '',
    tax_id: data.tax_id || '',
    currency: data.currency || 'MXN',
    street: data.street || '',
    city: data.city || '',
    state: data.state || '',
    zip: data.zip || '',
    country: data.country || 'MX',
    deleted: false,
    updatedAt: new Date().toISOString(),
  };
  CLIENTES.push(c);
  saveClients();
  if (typeof ErpOutbox !== 'undefined') {
    try { ErpOutbox.emitCustomerUpsert(c); } catch (e) { console.error('erp outbox emit failed', e); }
  }
  return c;
}

function updateCustomer(id, data) {
  const c = CLIENTES.find(x => x.id === id);
  if (!c) return null;
  // No-op guard: only stamp/save/emit when something actually changes —
  // keeps the ERP outbox free of phantom customer.upsert events.
  const keys = Object.keys(data || {});
  const changed = keys.length === 0 ? false :
    keys.some(k => JSON.stringify(c[k]) !== JSON.stringify(data[k]));
  if (!changed) return c;
  Object.assign(c, data);
  c.updatedAt = new Date().toISOString();
  saveClients();
  if (typeof ErpOutbox !== 'undefined') {
    try { ErpOutbox.emitCustomerUpsert(c); } catch (e) { console.error('erp outbox emit failed', e); }
  }
  return c;
}

function deleteCustomer(id) {
  // SOFT DELETE — ledger integrity: never rewrite history. The customer
  // row stays (flagged) so settlements, statements, ledgers, and any
  // ERP posting that references it keep resolving. Pickers hide it.
  const c = CLIENTES.find(x => x.id === id);
  if (!c) return false;
  if (c.deleted) return true;
  c.deleted = true;
  c.deletedAt = new Date().toISOString();
  c.updatedAt = new Date().toISOString();
  saveClients();
  if (typeof ErpOutbox !== 'undefined') {
    try { ErpOutbox.emitCustomerUpsert(c); } catch (e) { console.error('erp outbox emit failed', e); }
  }
  return true;
}

// Active (non-deleted) customers — use in every picker/list.
function activeCustomers() {
  return CLIENTES.filter(c => !c.deleted);
}

// ─── BACKUP / RESTORE ───────────────────────────────────
function exportBackup() {
  const data = {};
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.indexOf('elcomal_') === 0) {
      data[key] = localStorage.getItem(key);
    }
  }
  return data;
}

function backupSummary(data) {
  const count = (k) => {
    try { const v = JSON.parse(data[k]); return Array.isArray(v) ? v.length : 0; } catch (e) { return 0; }
  };
  const parts = [];
  if (data.elcomal_clientes) parts.push(count('elcomal_clientes') + ' clientes');
  if (data.elcomal_orders) parts.push(count('elcomal_orders') + ' órdenes');
  if (data.elcomal_trips) parts.push(count('elcomal_trips') + ' rutas');
  if (data.elcomal_settlements) parts.push(count('elcomal_settlements') + ' cortes');
  if (data.elcomal_payments) parts.push(count('elcomal_payments') + ' pagos');
  if (data.elcomal_futureOrders) parts.push(count('elcomal_futureOrders') + ' pedidos futuros');
  const dyn = Object.keys(data).filter(k => k.indexOf('elcomal_stops_') === 0 || k.indexOf('elcomal_session_') === 0).length;
  if (dyn) parts.push(dyn + ' paradas/sesiones');
  return parts.join(', ') || 'datos';
}

function _parseBackupText(text) {
  let t = String(text || '').trim();
  if (t.charCodeAt(0) === 0xFEFF) t = t.slice(1).trim();
  try { return JSON.parse(t); } catch (e) {}
  const start = t.indexOf('{');
  const end = t.lastIndexOf('}');
  if (start !== -1 && end > start) {
    try { return JSON.parse(t.slice(start, end + 1)); } catch (e) {}
  }
  return null;
}

function importBackup(jsonText) {
  const data = _parseBackupText(jsonText);
  if (!data) return { ok: false, error: 'El texto no es un JSON válido. Pulsa "Generar texto del respaldo" y copia ese texto completo.' };
  if (typeof data !== 'object' || Array.isArray(data)) return { ok: false, error: 'El respaldo no tiene un formato válido.' };
  const keys = Object.keys(data).filter(k => k.indexOf('elcomal_') === 0);
  if (keys.length === 0) return { ok: false, error: 'El respaldo no contiene datos de El Comal (claves elcomal_*).' };

  const ts = new Date().toISOString().replace(/[:.]/g, '-');
  const preKey = 'elcomal_preimport_backup_' + ts;
  const pre = {};
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.indexOf('elcomal_') === 0) pre[key] = localStorage.getItem(key);
  }
  localStorage.setItem(preKey, JSON.stringify(pre));

  keys.forEach(k => {
    try { localStorage.setItem(k, data[k]); } catch (e) {}
  });
  return { ok: true, preKey, summary: backupSummary(data) };
}

function restorePreImportBackup() {
  let preKey = null, preData = null;
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.indexOf('elcomal_preimport_backup_') === 0) {
      preKey = key;
      try { preData = JSON.parse(localStorage.getItem(key)); } catch (e) {}
    }
  }
  if (!preData) return false;
  Object.keys(preData).forEach(k => { try { localStorage.setItem(k, preData[k]); } catch (e) {} });
  if (preKey) localStorage.removeItem(preKey);
  return true;
}

// ─── CLEANUP: LIMPIAR RUTAS Y TRANSACCIONES ──────────────
// Deletes only ruta/transaction data: trips, stops, sessions,
// settlements, and street sales. Customers, their preferential
// price, recurrence, and ALL orders (recurring included) are kept.
function collectTransactionKeys() {
  const keys = ['elcomal_trips', 'elcomal_settlements', 'elcomal_streetSales', PAYMENTS_KEY, OPENING_DEBTS_KEY];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && (key.indexOf('elcomal_stops_') === 0 || key.indexOf('elcomal_session_') === 0)) {
      keys.push(key);
    }
  }
  return keys;
}

async function cleanupRouteData() {
  const keys = collectTransactionKeys();
  if (window.SyncDebug && window.SyncDebug.clearRemoteKeys) {
    await SyncDebug.clearRemoteKeys(keys);
  }
  keys.forEach(k => DB.Storage.del(k));

  // Transaction-ledger state that feeds reports and customer
  // statements (CxC/Cobranza) must be wiped too, not just the
  // trips/settlements keys, so the reportes reset cleanly.
  PAYMENTS = [];
  OPENING_DEBTS = [];
  CLIENTES.forEach(c => { c.balance = 0; });
  saveClients();

  // Detach orders from deleted trips so they become assignable again.
  // Any order that carried a delivery/transaction outcome (completed,
  // skipped, or with kg/credit data) is reset back to a clean pending
  // state — otherwise the Rutas dashboard would keep summing stale
  // delivered kilos, credit, and cash for the day.
  advanceOrders.forEach(o => {
    if (o.tripId) o.tripId = null;
    if (o.status === 'completed' || o.status === 'skipped' ||
        Number(o.deliveredKg) > 0 || Number(o.devolucionKg) > 0 || Number(o.recompraKg) > 0 ||
        Number(o.creditAmount) > 0 || Number(o.creditPaidAmount) > 0) {
      o.status = 'pending';
      o.skipReason = null;
      o.skipNote = null;
      o.deliveredKg = 0;
      o.devolucionKg = 0;
      o.recompraKg = 0;
      o.creditAmount = 0;
      o.creditPaidType = null;
      o.creditPaidAmount = 0;
    }
  });
  saveAdvanceOrders();

  AppState.trips = [];
  AppState.collections = [];
  AppState.extraSales = [];
  location.reload();
}
