const UPDATE_MANIFEST_URL = 'https://urobet.github.io/Delivery-App/version.json';
const UPDATE_BANNER_STORAGE_KEY = 'elcomal_update_ack';

// ─── Update lanes ───
// production: version.json  -> every phone (default).
// test:       version-test.json -> only phones where an admin switched
//             Configuración > Canal de actualizaciones to PRUEBA.
// The choice lives in this phone's localStorage under an elcomal_device_*
// key, which sync.js never uploads, so it cannot travel to another phone.
// See docs/release.md.
const UPDATE_TEST_MANIFEST_URL = 'https://urobet.github.io/Delivery-App/version-test.json';
// Must stay device-local: sync.js skips every elcomal_device_* key.
const UPDATE_CHANNEL_STORAGE_KEY = 'elcomal_device_update_lane';

// The saved lane counts only while an Admin is logged in. A Chofer, or a
// phone with nobody logged in, always reads production, whatever the phone
// has saved (docs/diagnosis/driver-lane.md). The saved value is left as is.
function getUpdateChannel() {
  try {
    const admin = typeof Auth !== 'undefined' && Auth.isAdmin();
    return admin && localStorage.getItem(UPDATE_CHANNEL_STORAGE_KEY) === 'test' ? 'test' : 'production';
  } catch (e) { return 'production'; }
}

// Run after login and logout: the lane depends on who is logged in. Drops a
// banner the previous user's lane brought up, then checks again.
function recheckUpdates() {
  if (updateBusy) return;
  const el = document.getElementById('update-banner');
  if (el) el.remove();
  checkForUpdate();
}

function setUpdateChannel(channel) {
  try {
    if (channel === 'test') localStorage.setItem(UPDATE_CHANNEL_STORAGE_KEY, 'test');
    else localStorage.removeItem(UPDATE_CHANNEL_STORAGE_KEY);
    localStorage.removeItem(UPDATE_BANNER_STORAGE_KEY);
  } catch (e) {}
  checkForUpdate();
}

function toggleUpdateChannel() {
  setUpdateChannel(getUpdateChannel() === 'test' ? 'production' : 'test');
  if (typeof render === 'function') render();
}

function updateManifestUrl() {
  return getUpdateChannel() === 'test' ? UPDATE_TEST_MANIFEST_URL : UPDATE_MANIFEST_URL;
}

let updateInfo = null;
let updateBusy = false;

function updaterApi() {
  if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater) {
    return window.Capacitor.Plugins.CapacitorUpdater;
  }
  const cap = window.Capacitor;
  // Capgo's native plugin is registered as CapacitorUpdater. The raw
  // bridge works for vanilla apps that don't bundle @capacitor/core.
  return {
    download: (o) => cap.nativePromise('CapacitorUpdater', 'download', o),
    next: (o) => cap.nativePromise('CapacitorUpdater', 'next', o),
    reload: () => cap.nativePromise('CapacitorUpdater', 'reload', {}),
    set: (o) => cap.nativePromise('CapacitorUpdater', 'set', o),
    notifyAppReady: () => cap.nativePromise('CapacitorUpdater', 'notifyAppReady', {})
  };
}

function isNative() {
  return !!(window.Capacitor && (window.Capacitor.Plugins || window.Capacitor.nativePromise));
}

function compareVersions(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const x = pa[i] || 0;
    const y = pb[i] || 0;
    if (x !== y) return x - y;
  }
  return 0;
}

async function checkForUpdate() {
  try {
    const res = await fetch(updateManifestUrl() + '?v=' + Date.now(), { cache: 'no-store' });
    if (!res.ok) return;
    updateInfo = await res.json();
    if (!updateInfo || !updateInfo.version) return;
    if (compareVersions(updateInfo.version, APP_VERSION) <= 0) return;
    const ack = localStorage.getItem(UPDATE_BANNER_STORAGE_KEY);
    if (ack === updateInfo.version) return;
    renderUpdateBanner();
  } catch (e) {}
}

function renderUpdateBanner() {
  let el = document.getElementById('update-banner');
  if (el) el.remove();
  el = document.createElement('div');
  el.id = 'update-banner';
  el.className = 'erp-update-banner';
  el.innerHTML =
    '<div class="erp-update-icon">📦</div>' +
    '<div class="erp-update-body">' +
      '<div class="erp-update-title">Actualización disponible</div>' +
      '<div class="erp-update-text">Nueva versión <b>' + updateInfo.version + '</b> lista. Se instalará sin borrar tus datos.</div>' +
      '<div class="erp-update-actions">' +
        '<button class="erp-btn erp-btn-sm erp-btn-primary" id="update-install-btn">Descargar e instalar</button>' +
        '<button class="erp-update-dismiss" id="update-dismiss-btn">Ahora no</button>' +
      '</div>' +
    '</div>';
  document.body.appendChild(el);

  const btn = document.getElementById('update-install-btn');
  if (btn) btn.addEventListener('click', installUpdate);

  const dismiss = document.getElementById('update-dismiss-btn');
  if (dismiss) dismiss.addEventListener('click', () => {
    localStorage.setItem(UPDATE_BANNER_STORAGE_KEY, updateInfo.version);
    el.remove();
  });
}

function setBannerText(txt) {
  const text = document.querySelector('#update-banner .erp-update-text');
  if (text) text.textContent = txt;
}

function installUpdate() {
  if (updateBusy) return;
  updateBusy = true;
  const btn = document.getElementById('update-install-btn');
  if (btn) btn.textContent = 'Descargando…';

  if (!isNative()) {
    setBannerText('Estás en la versión web (navegador). Recarga la página para tomar la última versión publicada; no necesitas el zip.');
    if (btn) btn.textContent = 'Recargar ahora';
    btn.onclick = () => location.reload();
    updateBusy = false;
    return;
  }

  const api = updaterApi();
  const rel = updateInfo.version || APP_VERSION;
  api.download({ url: updateInfo.url, version: rel })
    .then((bundle) => {
      if (btn) btn.textContent = 'Instalando…';
      setBannerText('Descargado. Aplicando versión ' + rel + '…');
       const bundleId = bundle && (bundle.id || (bundle.bundle && bundle.bundle.id));
       if (!bundleId) { throw new Error('download returned no bundle id'); }
       if (!api.set) return api.next({ id: bundleId }).then(() => api.reload());
       return api.set({ id: bundleId }).catch((setError) => {
         if (!api.next) throw setError;
         return api.next({ id: bundleId }).then(() => api.reload());
       });
    })
    .then(() => { updateBusy = false; })
    .catch((err) => {
      updateBusy = false;
      console.error('update: native install failed', err);
       const detail = err && err.message ? ' (' + err.message + ')' : '';
       setBannerText('No se pudo instalar automáticamente' + detail + '. El APK se instala aparte; pide la versión ' + rel + ' para instalarla a mano.');
      if (btn) btn.textContent = 'Cerrar';
      btn.onclick = () => {
        localStorage.setItem(UPDATE_BANNER_STORAGE_KEY, updateInfo.version);
        const b = document.getElementById('update-banner');
        if (b) b.remove();
      };
    });
}

function fallbackDownload() {
  // Intentionally does NOT open the zip in the browser anymore — a raw zip
  // is useless outside the native updater. Kept only as a no-op hook.
  updateBusy = false;
}

document.addEventListener('DOMContentLoaded', () => {
  if (isNative()) {
    try {
      const api = updaterApi();
      (api.notifyAppReady || function () {})().catch(() => {});
    } catch (e) {}
  }
  setTimeout(checkForUpdate, 1500);
});