﻿// ─── APP ROUTER ────────────────────────────────────────

const App = {
  stack: [],

  navigate(screen, params = {}) {
    if (screen === 'orderForm') processRecurrences();
    this.stack.push({ screen: AppState.screen, params: AppState.params });
    AppState.screen = screen;
    AppState.params = params;
    render();
  },

  goBack() {
    if (this.stack.length > 0) {
      const prev = this.stack.pop();
      AppState.screen = prev.screen || 'mainMenu';
      AppState.params = prev.params || {};
      if (AppState.screen === 'route' && AppState._prevRouteFilter !== undefined) {
        AppState.routeFilter = AppState._prevRouteFilter;
        AppState.routeName = AppState._prevRouteName;
        AppState.route = AppState._prevRoute;
        delete AppState._prevRouteFilter;
        delete AppState._prevRouteName;
        delete AppState._prevRoute;
      }
      render();
    } else {
      AppState.screen = 'mainMenu';
      AppState.params = {};
      render();
    }
  },

  openCustomerSheet(customerId) {
    AppState.sheetCustomerId = customerId;
    render();
  },

  closeCustomerSheet() {
    AppState.sheetCustomerId = null;
    render();
  },

  toggleFutureOrders() {
    AppState.futureOrdersExpanded = !AppState.futureOrdersExpanded;
    render();
  },

  reset() {
    this.stack = [];
    AppState.screen = 'login';
    AppState.params = {};
    render();
  },

  startRoute() {
    if (!AppState.route) initRoute();
    AppState.screen = 'route';
    AppState.params = {};
    this.stack = [];
    render();
  },

  switchRoute(routeName) {
    AppState.routeName = routeName;
    const session2 = DB.Session.load(routeName, AppState.routeDate || today());
    AppState.extraSales = session2.extraSales;
    AppState.collections = session2.collections;
    AppState.currentStop = null;
    rebuildRouteStops(routeName);
    render();
  },

  filterRoute(filter) {
    if (filter === '') {
      AppState.routeFilter = null;
    } else {
      AppState.routeFilter = filter;
      if (filter !== AppState.routeName) {
        AppState.routeName = filter;
        const session2 = DB.Session.load(filter, AppState.routeDate || today());
        AppState.extraSales = session2.extraSales;
        AppState.collections = session2.collections;
        AppState.creditModal = null;
        AppState.currentStop = null;
        rebuildRouteStops(filter);
      }
    }
    render();
  },

  toggleRouteCreationModal() {
    AppState.routeCreationModal = !AppState.routeCreationModal;
    if (AppState.routeCreationModal) {
      let max = 0;
      const prefix = AppState.routeName.replace(/[^A-Za-z0-9]/g, '').slice(0, 3).toUpperCase();
      AppState.trips.forEach(t => { const n = parseInt(t.id.split('-')[1]); if (n > max) max = n; });
      AppState._nextTripId = max + 1;
    }
    render();
  },

  openRouteCreationModal() {
    AppState.routeCreationModal = true;
    render();
  },

  closeRouteCreationModal() { AppState.routeCreationModal = false; render(); },

  toggleTripExpanded(tripId) {
    const trip = AppState.trips.find(t => t.id === tripId);
    if (trip) { trip.expanded = !trip.expanded; render(); }
  },

  createTrip() {
    const kilosEl = document.getElementById('trip-kilos');
    const kilos = parseFloat(kilosEl?.value) || 0;
    if (kilos <= 0) { showToast('❌ Indica los kilos cargados'); return; }

    const cbEls = document.querySelectorAll('.trip-order-cb:checked');
    if (cbEls.length === 0) { showToast('❌ Selecciona al menos una orden'); return; }

    const orderIds = Array.from(cbEls).map(el => el.value);
    const trip = createTrip(null, kilos, orderIds);
    AppState.routeCreationModal = false;
    showToast('✅ Ruta ' + trip.id + ' creada con ' + orderIds.length + ' órdenes');
    render();
  },

  toggleCompleted() {
    AppState.collapsedCompleted = !AppState.collapsedCompleted;
    render();
  },

  switchRouteTab(tab) {
    AppState.routeSubTab = tab;
    render();
  },

  switchReportTab(tab) {
    AppState.reportTab = tab;
    render();
  },

  switchReportPeriod(period) {
    AppState.reportPeriod = period;
    render();
  },

  setRouteDate(date) {
    AppState.routeDate = date;
    render();
  },

  sortCustomers(col) {
    if (AppState.customersSortBy === col) {
      AppState.customersSortDir = AppState.customersSortDir === 'asc' ? 'desc' : 'asc';
    } else {
      AppState.customersSortBy = col;
      AppState.customersSortDir = 'asc';
    }
    AppState.customersPage = 1;
    render();
  },

  setCustomersPage(page) {
    AppState.customersPage = page;
    render();
  },

  toggleSelectCustomer(id, checked) {
    if (!AppState.selectedCustomers) AppState.selectedCustomers = [];
    if (checked) {
      if (!AppState.selectedCustomers.includes(id)) AppState.selectedCustomers.push(id);
    } else {
      AppState.selectedCustomers = AppState.selectedCustomers.filter(x => x !== id);
    }
    render();
  },

  toggleSelectAllCustomers(checked) {
    const perPage = AppState.customersPerPage;
    const page = AppState.customersPage;
    const start = (page - 1) * perPage;
    const paged = CLIENTES.slice(start, start + perPage);
    if (checked) {
      const ids = paged.map(c => c.id);
      AppState.selectedCustomers = [...new Set([...(AppState.selectedCustomers || []), ...ids])];
    } else {
      const ids = new Set(paged.map(c => c.id));
      AppState.selectedCustomers = (AppState.selectedCustomers || []).filter(x => !ids.has(x));
    }
    render();
  },

  toggleSelectOrder(id, checked) {
    if (!AppState.selectedOrders) AppState.selectedOrders = [];
    if (checked) {
      if (!AppState.selectedOrders.includes(id)) AppState.selectedOrders.push(id);
    } else {
      AppState.selectedOrders = AppState.selectedOrders.filter(x => x !== id);
    }
    render();
  },

  toggleSelectAllOrders(checked) {
    const active = getAllAdvanceOrders().filter(o => o.status === 'pending');
    if (checked) {
      AppState.selectedOrders = active.map(o => o.id);
    } else {
      AppState.selectedOrders = [];
    }
    render();
  },

  toggleOrderForm() {
    AppState.showOrderForm = !AppState.showOrderForm;
    render();
  },

  openOrderForm() {
    AppState.editingOrderId = null;
    AppState.orderRecurrence = null;
    AppState.showOrderForm = true;
    render();
    setTimeout(() => {
      const el = document.querySelector('.erp-content');
      if (el) el.scrollTop = 0;
    }, 50);
  },

  getScreen(screen, params) {
    switch (screen) {
      case 'login': return renderLogin();
      case 'mainMenu': return renderMainMenu();
      case 'route': return renderRouteHome();
      case 'stop': {
        let stop = findStop(params.stopId);
        if (!stop && params.orderId) {
          const o = getAdvanceOrder(params.orderId);
          if (o) {
            stop = buildStopFromOrder(o);
            AppState.route.stops = [stop, ...AppState.route.stops];
          }
        }
        if (!stop) return { html: '<div class="erp-screen"><div class="erp-empty"><span class="erp-empty-icon">⚠️</span><div class="erp-empty-text">Parada no encontrada</div></div></div>', init: () => {} };
        AppState.currentStop = stop;
        return renderStop(stop);
      }
      case 'streetSale': return renderStreetSale();
      case 'customers': return renderCustomers();
      case 'customerDetail': return renderCustomerDetail(params.customerId);
      case 'customerStatement': return renderCustomerStatement(params.customerId);
      case 'customerInfo': return renderCustomerInfo(params.customerId);
      case 'routes': return renderRoutes();
      case 'reports': return renderReports();
      case 'more': return renderMore();
      case 'orderForm': return renderOrderForm();
      case 'futureOrder': return renderFutureOrderForm();
      case 'customerForm': return renderCustomerFormScreen();
      default: return { html: '<div class="erp-screen"><div class="erp-empty"><span class="erp-empty-icon">⚠️</span><div class="erp-empty-text">Pantalla no encontrada</div></div></div>', init: () => {} };
    }
  }
};

function findStop(stopId) {
  if (!AppState.route) return null;
  return AppState.route.stops.find(s => s.stopId === stopId);
}

function render() {
  const screen = App.getScreen(AppState.screen, AppState.params);
  const appEl = document.getElementById('app');
  if (!appEl) return;
  appEl.innerHTML = screen.html;
  if (screen.init) screen.init();
  renderToast();
}

function renderToast() {
  document.querySelectorAll('.erp-toast').forEach(el => el.remove());
  if (AppState.toast) {
    const el = document.createElement('div');
    el.className = 'erp-toast';
    el.textContent = AppState.toast;
    document.body.appendChild(el);
    setTimeout(() => { if (el.parentNode) el.remove(); }, 2500);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  processRecurrences();
  AppState.screen = 'login';
  render();
});
