// ─── SCREEN RENDERERS ───
function renderLogin() {
  const firstRun = Auth.isFirstRun();
  return {
    html: `
      <div class="login-screen">
        <div class="login-logo">🌽</div>
        <div class="login-title">El Comal</div>
        <div class="login-sub">Tortillería</div>
        <div class="login-form">
          ${firstRun ? `
            <div class="login-form-title">Crear cuenta de administrador</div>
            <input class="erp-input" id="auth-name" placeholder="Nombre completo" autocomplete="name" value="${escHtml(AppState.loginName)}" oninput="AppState.loginName=this.value">
            <input class="erp-input" id="auth-username" placeholder="Usuario" autocomplete="username" value="${escHtml(AppState.loginUsername)}" oninput="AppState.loginUsername=this.value">
            <input class="erp-input" id="auth-password" type="password" placeholder="Contraseña" autocomplete="new-password" value="${escHtml(AppState.loginPassword)}" oninput="AppState.loginPassword=this.value">
            <input class="erp-input" id="auth-password2" type="password" placeholder="Confirmar contraseña" autocomplete="new-password" value="${escHtml(AppState.loginPassword2)}" oninput="AppState.loginPassword2=this.value">
            <div class="login-error" id="auth-error"></div>
            <button class="erp-btn erp-btn-primary" id="auth-submit">Crear cuenta</button>
          ` : `
            <input class="erp-input" id="auth-username" placeholder="Usuario" autocomplete="username" value="${escHtml(AppState.loginUsername)}" oninput="AppState.loginUsername=this.value">
            <input class="erp-input" id="auth-password" type="password" placeholder="Contraseña" autocomplete="current-password" value="${escHtml(AppState.loginPassword)}" oninput="AppState.loginPassword=this.value">
            <label class="login-remember"><input type="checkbox" id="auth-remember" ${AppState.loginRemember ? 'checked' : ''} onchange="AppState.loginRemember=this.checked"> Mantener sesión en esta pestaña</label>
            <div class="login-error" id="auth-error"></div>
            <button class="erp-btn erp-btn-primary" id="auth-submit">Entrar</button>
          `}
        </div>
      </div>
    `,
    init: () => {
      const submit = document.getElementById('auth-submit');
      const doSubmit = async () => {
        const err = document.getElementById('auth-error');
        if (!err) return;
        err.textContent = '';
        const username = (document.getElementById('auth-username').value || '').trim();
        const password = document.getElementById('auth-password').value || '';
        if (!username || !password) { err.textContent = 'Escribe usuario y contraseña.'; return; }
        try {
          let session;
          if (firstRun) {
            const name = (document.getElementById('auth-name').value || '').trim();
            const password2 = document.getElementById('auth-password2').value || '';
            if (!name) { err.textContent = 'Escribe tu nombre completo.'; return; }
            if (password.length < 4) { err.textContent = 'La contraseña debe tener al menos 4 caracteres.'; return; }
            if (password !== password2) { err.textContent = 'Las contraseñas no coinciden.'; return; }
            await Auth.createUser(username, password, 'admin', name);
            session = await Auth.login(username, password, true);
          } else {
            const remember = !!(document.getElementById('auth-remember') && document.getElementById('auth-remember').checked);
            session = await Auth.login(username, password, remember);
          }
          AppState.driver = { name: session.name, id: session.userId, role: session.role };
          AppState.screen = 'mainMenu';
          AppState.params = {};
          App.stack = [];
          render();
        } catch (e) {
          err.textContent = firstRun ? e.message : 'Usuario o contraseña incorrectos.';
        }
      };
      submit.addEventListener('click', doSubmit);
      document.querySelectorAll('.login-form input').forEach(inp => {
        inp.addEventListener('keydown', e => { if (e.key === 'Enter') doSubmit(); });
      });
    }
  };
}

// ─── MAIN MENU ──────────────────────────────────────────
function renderMainMenu() {
  const driverName = AppState.driver ? AppState.driver.name : 'Usuario';
  const isAdmin = Auth.isAdmin();
  const items = [
    { id: 'ventas', icon: '💰', label: 'Ventas', action: "App.navigate('orderForm')" },
    { id: 'reportes', icon: '📊', label: 'Reportes', action: "App.navigate('reports')" },
    { id: 'rutas', icon: '🗺️', label: 'Rutas', action: "App.startRoute()" },
    { id: 'clientes', icon: '👥', label: 'Clientes', action: "App.navigate('customers')" },
  ];
  if (isAdmin) items.push({ id: 'configuracion', icon: '⚙️', label: 'Configuración', action: "App.navigate('more')" });
  return {
    html: `
      <div class="erp-screen">
        <div class="erp-hero">
          <div class="erp-hero-logo">🌽</div>
          <div class="erp-hero-title">El Comal</div>
          <div class="erp-hero-sub">Tortillería</div>
        </div>
        <div class="erp-menu-list">
          ${items.map(item => `
            <button class="erp-btn erp-btn-block erp-menu-item" onclick="${item.action}">
              <span class="erp-menu-icon">${item.icon}</span>
              <span class="erp-menu-label">${item.label}</span>
            </button>
          `).join('')}
        </div>
        <div class="erp-menu-driver">
          ${driverName} · ${isAdmin ? 'Admin' : 'Chofer'}
          <button class="erp-btn erp-btn-sm erp-btn-block" style="margin-top:8px" onclick="App.logout()">🚪 Cerrar sesión</button>
        </div>
      </div>
    `,
    init: () => {}
  };
}

// ─── ROUTE HOME ────────────────────────────────────────
function renderTripList(activeTrips, completedTrips) {
  if (activeTrips.length === 0 && completedTrips.length === 0) {
    return '<div class="erp-empty"><span class="erp-empty-icon">🗺️</span><div class="erp-empty-text">Sin rutas aún. Crea una para comenzar.</div></div>';
  }

  let html = '';

  if (activeTrips.length > 0) {
    html += `<div style="padding:4px 4px 0;font-size:11px;font-weight:700;font-family:monospace;text-transform:uppercase;color:var(--slate-500);letter-spacing:0.3px">🚛 Rutas activas</div>`;
    html += activeTrips.map(t => renderTripCard(t)).join('');
  }

  if (completedTrips.length > 0) {
    const collapseIcon = AppState.collapsedCompleted ? '▶' : '▼';
    html += `<div style="cursor:pointer;display:flex;align-items:center;gap:8px;padding:12px 4px 0;font-size:11px;font-weight:700;font-family:monospace;text-transform:uppercase;color:var(--slate-500);letter-spacing:0.3px" onclick="App.toggleCompleted()">
        <span>${collapseIcon}</span>
        <span>✅ Completadas · ${completedTrips.length}</span>
      </div>`;
    html += `<div style="${AppState.collapsedCompleted ? 'display:none' : ''}">`;
    html += completedTrips.map(t => renderTripCard(t)).join('');
    html += `</div>`;
  }

  return html;
}

function renderTripCard(trip) {
  const orders = getOrdersForTrip(trip.id);
  const p = getTripProgress(trip.id);
  const isActive = trip.status === 'active';
  const pendiente = orders.filter(o => o.status === 'pending').reduce((s, o) => s + o.qty, 0);
  const ownerIsMe = isTripMine(trip);
  const ownerNm = tripOwnerName(trip);

  const dft = o => o.deliveryDraft || {};
  const deliveredTotal = orders.filter(o => o.status === 'completed').reduce((s, o) => s + (o.deliveredKg || o.qty), 0)
    + orders.filter(o => o.status === 'pending').reduce((s, o) => s + ((dft(o).kg || 0)), 0);
  const devTotal = orders.filter(o => o.status === 'completed').reduce((s, o) => s + (o.devolucionKg || 0), 0)
    + orders.filter(o => o.status === 'pending').reduce((s, o) => s + ((dft(o).dev || 0)), 0);
// Cobrado = efectivo realmente cobrado en cada parada (cash collected).
  const cobradoTotal = orders.filter(o => o.status === 'completed').reduce((s, o) => {
    return s + (Number(o.creditPaidAmount) || 0);
  }, 0) + orders.filter(o => o.status === 'pending').reduce((s, o) => {
    const dft = o.deliveryDraft || {};
    if (!dft.kg && !dft.dev && !dft.rec && !dft.cash && !dft.credit) return s;
    return s + (Number(dft.cash) || 0);
  }, 0);

  const statusBadge = isActive
    ? `<span class="erp-chip erp-chip-blue">${p.done}/${p.total}</span>`
    : `<span class="erp-chip erp-chip-green">✅ ${p.done}/${p.total}</span>`;

  const expandIcon = trip.expanded ? '▼' : '▶';

  const routeChips = (trip.routes || [trip.routeName]).map(r =>
    `<span class="erp-chip erp-chip-blue" style="margin-right:4px">${r}</span>`
  ).join('');

  const orderRows = orders.map(o => {
    const isDone = o.status === 'completed';
    const isSkipped = o.status === 'skipped';
    const isPending = o.status === 'pending';
    const draft = o.deliveryDraft || {};
    const hasDraft = isPending && (draft.kg || draft.dev || draft.rec);
    const hasHandoff = orderHandoffs(o).length > 0;
    const dqty = isDone ? (o.deliveredKg || o.qty) : (hasDraft ? draft.kg : o.qty);
    const dev = isDone ? (o.devolucionKg || 0) : (hasDraft ? (draft.dev || 0) : 0);
    const op = o.price || getProductPrice(o.productId || 'P1');
    const total = isDone ? (Number(o.creditPaidAmount) || 0) : (hasDraft ? (Number(draft.cash) || 0) : null);
    const skipText = isSkipped ? (o.skipReason === 'no_salio' ? 'No salió' : o.skipReason === 'estaba_cerrado' ? 'Estaba cerrado' : o.skipNote || 'Saltada') : '';
    const dim = isDone || isSkipped;
    return `
      <tr style="cursor:pointer;opacity:${dim ? '0.5' : '1'}"
        onclick="navigateToTripOrder('${trip.id}','${o.id}')">
        <td class="name">
          ${o.customerName}
          ${hasHandoff && !isDone ? '<span class="erp-chip erp-chip-amber" style="margin-left:4px;font-size:8px">🤝</span>' : ''}
          <div style="font-weight:400;font-size:10px;color:var(--slate-400)">
            ${o.productName}
            ${(isDone ? (o.recompraKg || 0) : (hasDraft ? (draft.rec || 0) : 0)) > 0 ? '<span class="erp-chip erp-chip-green" style="margin-left:4px;font-size:8px">♻️ REC</span>' : ''}
          </div>
          ${isPending && !ownerIsMe ? `<button class="erp-take-mini" onclick="event.stopPropagation();App.takeOrder('${o.id}')">🙋 TOMAR ORDEN</button>` : ''}
        </td>
        <td class="num">${isSkipped ? '⏭️' : dqty + ' kg' + (isDone ? ' ✅' : hasDraft ? ' ✏️' : '')}</td>
        <td class="num">${(isDone || hasDraft) ? dev + ' kg' : '—'}</td>
        <td class="num">${total !== null ? formatCurrency(total) + (hasDraft ? ' ✏️' : '') : '—'}</td>
      </tr>
      ${isSkipped ? `<tr><td colspan="4" style="padding:0 6px 6px;font-size:11px;color:var(--slate-400);font-family:monospace">⏭️ ${skipText}</td></tr>` : ''}
      ${isDone && o.creditAmount > 0 ? `<tr><td colspan="4" style="padding:0 6px 6px;font-size:11px;color:var(--amber-400);font-family:monospace">💰 ${formatCurrency(o.creditAmount)} a cuenta</td></tr>` : ''}
    `;
  }).join('');

  return `
    <div style="background:white;border:1px solid var(--slate-200);margin:6px 0">
      <div style="cursor:pointer;margin-bottom:${trip.expanded ? '8px' : '0'}" onclick="App.toggleTripExpanded('${trip.id}')">
        <div style="display:flex;justify-content:space-between;align-items:center;padding:10px 12px">
          <div>
            <div style="font-size:13px;font-weight:700;color:var(--slate-900)">${expandIcon} ${trip.id}</div>
            <div style="font-size:11px;color:var(--slate-500);font-family:monospace;margin-top:2px">${trip.kilosLoaded}kg cargados · ${pendiente}kg pend</div>
            <div style="margin-top:4px">${routeChips}${ownerIsMe ? '' : `<span class="erp-chip erp-chip-amber" style="margin-right:4px">👤 ${escHtml(ownerNm)}</span>`}</div>
          </div>
          ${statusBadge}
        </div>

      </div>
      ${trip.expanded ? `
        <table class="erp-trip-table">
          <thead>
            <tr>
              <th>Cliente</th>
              <th class="num">A entregar</th>
              <th class="num">Dev</th>
              <th class="num">$ Cobrado</th>
            </tr>
          </thead>
          <tbody>
            ${orderRows}
            <tr style="font-weight:700;border-top:2px solid var(--slate-200)">
              <td style="padding:6px;font-weight:700">Total</td>
              <td class="num" style="font-weight:700">${deliveredTotal} kg ✅</td>
              <td class="num" style="font-weight:700">${devTotal} kg</td>
              <td class="num" style="font-weight:700">${formatCurrency(cobradoTotal)}</td>
            </tr>
          </tbody>
        </table>
      ` : ''}
    </div>
  `;
}

function syncTripKilosFromOrders() {
  const kilosEl = document.getElementById('trip-kilos');
  if (!kilosEl) return;
  const total = Array.from(document.querySelectorAll('.trip-order-cb:checked'))
    .reduce((s, el) => s + (parseFloat(el.dataset.qty) || 0), 0);
  kilosEl.value = total;
}

function renderRouteCreationModal() {
  if (!AppState.routeCreationModal) return '';
  const d = AppState.routeDate || today();
  const allAvailable = advanceOrders.filter(o =>
    o.status === 'pending' && !o.tripId && o.date === d &&
    !(getCustomer(o.customerId) || {}).deleted
  );
  const pendingInTrips = advanceOrders.filter(o =>
    o.status === 'pending' && o.tripId && o.date === d
  ).length;

  const destFilter = Array.isArray(AppState.routeCreationDestFilter) ? AppState.routeCreationDestFilter : [];
  const destinations = Array.from(new Set(allAvailable.map(o => o.route).filter(Boolean))).sort();
  const available = destFilter.length === 0
    ? allAvailable
    : allAvailable.filter(o => destFilter.includes(o.route));
  const defaultKilos = available.reduce((s, o) => s + (o.qty || 0), 0);

  return `
    <div class="erp-overlay" onclick="App.closeRouteCreationModal()">
      <div class="erp-sheet" onclick="event.stopPropagation()">
        <div class="erp-sheet-handle"></div>
        <div class="erp-sheet-title">🚛 Nueva ruta combinada</div>
        <div class="erp-sheet-body">

          <div class="erp-field">
            <div class="erp-label">Ruta ID (automático)</div>
            <div style="font-size:20px;font-weight:700;color:var(--slate-900);font-family:monospace" id="new-trip-id">${generateTripId('MIX')}</div>
          </div>

          <div class="erp-field">
            <div class="erp-label">Kilos cargados en el camión</div>
            <input class="erp-input" type="number" id="trip-kilos" value="${defaultKilos}" min="0" step="1" onchange="syncTripKilosFromOrders()">
          </div>

          <div style="margin-top:16px;margin-bottom:8px;display:flex;align-items:center;justify-content:space-between;gap:8px">
            <div style="font-size:13px;font-weight:600;color:var(--slate-900)">
              Órdenes disponibles (${available.length}${destFilter.length > 0 ? ` de ${allAvailable.length}` : ''})
            </div>
            <button type="button" class="erp-filter-btn ${destFilter.length > 0 ? 'erp-filter-btn-active' : ''}" onclick="App.toggleRouteCreationDestFilter()" title="Filtrar por destino">
              <svg class="erp-filter-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <polygon points="3 4 21 4 14 12.5 14 19 10 21 10 12.5 3 4"></polygon>
              </svg>
              <span class="erp-filter-label">${destFilter.length === 0 ? 'Filtrar' : (destFilter.length === 1 ? destFilter[0] : destFilter.length + ' destinos')}</span>
            </button>
          </div>

          ${AppState.routeCreationDestOpen ? `
            <div class="erp-popover-backdrop" onclick="App.closeRouteCreationDestFilter()"></div>
            <div class="erp-popover">
              <div class="erp-popover-title">Filtrar por destino <span style="float:right;color:var(--slate-400);text-transform:none;letter-spacing:0;font-weight:500">(selección múltiple)</span></div>
              <div class="erp-popover-list">
                <button type="button" class="erp-popover-item ${destFilter.length === 0 ? 'erp-popover-item-active' : ''}" onclick="App.setRouteCreationDestFilter('all')">
                  <span class="erp-popover-check">${destFilter.length === 0 ? '✓' : ''}</span>
                  <span>Todos los destinos</span>
                  <span class="erp-popover-count">${allAvailable.length}</span>
                </button>
                ${destinations.map(dest => {
                  const count = allAvailable.filter(o => o.route === dest).length;
                  const isSel = destFilter.includes(dest);
                  return `<button type="button" class="erp-popover-item ${isSel ? 'erp-popover-item-active' : ''}" onclick="App.toggleRouteCreationDestFilterItem('${dest.replace(/'/g, "\\'")}')">
                    <span class="erp-popover-check">${isSel ? '✓' : ''}</span>
                    <span>${dest}</span>
                    <span class="erp-popover-count">${count}</span>
                  </button>`;
                }).join('')}
              </div>
              <div class="erp-popover-actions">
                <button type="button" class="erp-popover-action-btn" onclick="App.setRouteCreationDestFilter('all')">Limpiar</button>
                <button type="button" class="erp-popover-action-btn erp-popover-action-primary" onclick="App.closeRouteCreationDestFilter()">Listo</button>
              </div>
            </div>
          ` : ''}

          ${allAvailable.length === 0 ? `
            <div class="erp-empty">
              <span class="erp-empty-icon">📦</span>
              <div class="erp-empty-text">
                ${pendingInTrips > 0
                  ? `${pendingInTrips} orden(es) pendiente(s) ya están en rutas activas — expándelas para continuar`
                  : 'Sin órdenes disponibles para hoy'
                }
              </div>
              <button class="erp-btn erp-btn-secondary" style="margin-top:12px" onclick="App.closeRouteCreationModal();App.navigate('orderForm')">📝 Ir a Ventas</button>
            </div>
          ` : available.length === 0 ? `
            <div class="erp-empty">
              <span class="erp-empty-icon">🔍</span>
              <div class="erp-empty-text">Sin órdenes para los destinos seleccionados</div>
              <button class="erp-btn erp-btn-secondary" style="margin-top:12px" onclick="App.setRouteCreationDestFilter('all')">Ver todos los destinos</button>
            </div>
          ` : `
            <div style="max-height:300px;overflow-y:auto;border:1px solid var(--slate-200);margin-bottom:12px" id="trip-orders-list">
              ${available.map(o => `
                <div class="erp-trip-order">
                  <input type="checkbox" class="trip-order-cb" value="${o.id}" data-qty="${o.qty}" checked onchange="syncTripKilosFromOrders()">
                  <div class="erp-trip-order-info">
                    <div class="erp-trip-order-name">${o.customerName}</div>
                    <div class="erp-trip-order-detail">${o.productName} · ${o.qty}kg · ${formatCurrency(o.price * o.qty)}</div>
                    <span class="erp-chip erp-chip-blue" style="align-self:flex-start">${o.route}</span>
                  </div>
                </div>
              `).join('')}
            </div>
          `}

          ${available.length > 0 ? `
            <button class="erp-btn erp-btn-primary erp-btn-lg erp-btn-block" onclick="App.createTrip()">✅ Crear ruta</button>
          ` : ''}

          <button class="erp-btn erp-btn-secondary erp-btn-block" style="margin-top:6px" onclick="App.closeRouteCreationModal()">Cancelar</button>
        </div>
      </div>
    </div>
  `;
}
function aggregateRouteStats() {
  const d = AppState.routeDate || today();
  const dayTrips = AppState.trips.filter(t => t.date === d);
  const seen = new Set();
  let totalOrders = 0, doneOrders = 0, pending = 0;
  const allActiveTrips = [], allCompletedTrips = [];
  dayTrips.forEach(t => {
    if (seen.has(t.id)) return;
    seen.add(t.id);
    const ords = getOrdersForTrip(t.id);
    totalOrders += ords.length;
    doneOrders += ords.filter(o => o.status === 'completed' || o.status === 'skipped').length;
    pending += ords.filter(o => o.status === 'pending').length;
    if (t.status === 'active') allActiveTrips.push(t);
    else if (t.status === 'completed') allCompletedTrips.push(t);
  });
  const totalKilos = allActiveTrips.reduce((s, t) => s + (t.kilosLoaded || 0), 0) + allCompletedTrips.reduce((s, t) => s + (t.kilosLoaded || 0), 0);
  const allOrders = advanceOrders.filter(o => o.date === d && o.status === 'pending' && !o.tripId);
  return { totalOrders, doneOrders, pending, totalKilos, allActiveTrips, allCompletedTrips, availableOrders: allOrders.length };
}

function renderRouteCalendar() {
  if (!AppState.calendarOpen) return '';
  const [year, month] = AppState.calendarMonth.split('-').map(Number);
  const firstDay = new Date(year, month - 1, 1).getDay();
  const daysInMonth = new Date(year, month, 0).getDate();
  const monthLabel = new Date(year, month - 1, 1).toLocaleDateString('es-MX', { month: 'long', year: 'numeric' });
  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push('<span class="erp-calendar-day erp-calendar-day-empty"></span>');
  for (let day = 1; day <= daysInMonth; day++) {
    const date = year + '-' + String(month).padStart(2, '0') + '-' + String(day).padStart(2, '0');
    const selected = date === AppState.routeDate ? ' selected' : '';
    cells.push(`<button class="erp-calendar-day${selected}" onclick="App.setRouteDate('${date}')">${day}</button>`);
  }
  return `
    <div class="erp-calendar-backdrop" onclick="App.closeRouteCalendar()"></div>
    <div class="erp-calendar" onclick="event.stopPropagation()">
      <div class="erp-calendar-header">
        <button class="erp-calendar-nav" onclick="App.changeRouteCalendarMonth(-1)">‹</button>
        <span>${capitalize(monthLabel)}</span>
        <button class="erp-calendar-nav" onclick="App.changeRouteCalendarMonth(1)">›</button>
      </div>
      <div class="erp-calendar-weekdays"><span>DOM</span><span>LUN</span><span>MAR</span><span>MIÉ</span><span>JUE</span><span>VIE</span><span>SÁB</span></div>
      <div class="erp-calendar-grid">${cells.join('')}</div>
    </div>
  `;
}

function renderRouteHome() {
  const allRoutes = AppState.routeFilter === null;
  const routeName = AppState.routeName;
  const projectToday = AppState.routeDate || today();
  const dateDisplay = capitalize(formatDate(projectToday));

  let stats, activeTrips, completedTrips, totalKilos, displayLabel;
  if (allRoutes) {
    const agg = aggregateRouteStats();
    stats = { totalOrders: agg.totalOrders, doneOrders: agg.doneOrders, pending: agg.pending };
    activeTrips = agg.allActiveTrips;
    completedTrips = agg.allCompletedTrips;
    totalKilos = agg.totalKilos;
    displayLabel = 'Todas las rutas';
  } else {
    stats = getTripStats(routeName);
    activeTrips = getTripsForRoute(routeName).filter(t => t.status === 'active');
    completedTrips = getTripsForRoute(routeName).filter(t => t.status === 'completed');
    totalKilos = activeTrips.reduce((s, t) => s + (t.kilosLoaded || 0), 0) + completedTrips.reduce((s, t) => s + (t.kilosLoaded || 0), 0);
    displayLabel = routeName;
  }

  const projectDate = projectToday;
  const live = getLiveDayMetrics(projectDate);
  const settlement = getSettlementForDate(projectDate);
  const useLive = live && live.doneOrders > 0;
  const dayStreet = DB.Street.byDate(projectToday);
  const streetTotal = dayStreet.reduce((s, e) => s + e.amount, 0);
  const kilosEntregados = useLive ? live.kilosEntregados : (settlement ? settlementDeliveredKilos(settlement) : 0);
  const kilosFrios = useLive ? live.kilosFrios : (settlement ? settlementFriosKilos(settlement) : 0);
  const baseVentas = useLive ? (live.totalCredited + live.totalCash) : (settlement ? ((settlement.totalCredited || 0) + (settlement.totalCash || 0)) : 0);
  const ventasTotales = baseVentas + streetTotal;
  const credito = useLive ? live.totalCredited : (settlement ? (settlement.totalCredited || 0) : 0);
  const efectivo = useLive ? (live.totalCash + streetTotal) : ((settlement ? (settlement.totalCash || 0) : 0) + streetTotal);

  const statCard = (label, value, color, sub) => `
    <div class="erp-stat-card">
      <div style="font-size:8px;font-weight:700;text-transform:uppercase;color:var(--slate-400);margin-bottom:4px">${label}</div>
      <div style="font-size:17px;font-weight:700;color:${color};line-height:1.15">${value}</div>
      ${sub ? `<div style="font-size:7px;color:var(--slate-400);margin-top:2px">${sub}</div>` : ''}
    </div>`;

  return {
    html: `
      <div class="erp-screen">
        <div style="display:flex;align-items:center;gap:8px;padding:10px 10px 4px">
          <button class="erp-btn erp-btn-sm" onclick="App.goBack()">← VOLVER</button>
          <div style="flex:1;min-width:0">
            <div style="font-size:15px;font-weight:700;color:var(--slate-900)">${displayLabel}</div>
            <div class="erp-header-date" onclick="App.toggleRouteCalendar()">${dateDisplay} 📅</div>
            ${renderRouteCalendar()}
          </div>

        </div>

        <div style="flex:1;overflow-y:auto;padding:4px 10px 160px">

          <div style="background:white;border:1px solid var(--slate-200);padding:12px;margin-bottom:8px">
            <div style="margin-bottom:12px">
              <div style="font-size:15px;font-weight:700;color:var(--slate-900)">👋 ¡Buenos días, ${AppState.driver.name.split(' ')[0]}!</div>
              <div style="font-size:11px;color:var(--slate-500);font-family:monospace;margin-top:2px">${displayLabel} · ${stats.doneOrders}/${stats.totalOrders} completadas</div>
            </div>
            <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.4px;color:var(--slate-400);margin-bottom:6px">Kilos</div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px">
              ${statCard('Total a repartir', totalKilos.toFixed(2) + ' <small style="font-weight:400">kg</small>', 'var(--slate-900)', 'Suma de las rutas creadas')}
              ${statCard('Kilos entregados', kilosEntregados.toFixed(2) + ' <small style="font-weight:400">kg</small>', 'var(--emerald-600)', '')}
              ${statCard('Kilos fríos', kilosFrios.toFixed(2) + ' <small style="font-weight:400">kg</small>', 'var(--amber-400)', 'No vendidos por tiendas')}
            </div>
            <div style="font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:0.4px;color:var(--slate-400);margin-bottom:6px">Dinero</div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
              ${statCard('Ventas totales', formatCurrency(ventasTotales), 'var(--emerald-600)', 'Revenue total (Crédito + Efectivo)')}
              ${statCard('Crédito', formatCurrency(credito), '#1E40AF', 'Cuentas por cobrar')}
              ${statCard('Efectivo', formatCurrency(efectivo), 'var(--green-700)', 'Cobrado en efectivo')}
            </div>
          </div>

          <button class="erp-btn erp-btn-primary erp-btn-lg erp-btn-block" onclick="App.openRouteCreationModal()">🚛 Rutas</button>

          ${renderTripList(activeTrips, completedTrips)}

          ${dayStreet.length > 0 ? `
          <div style="background:white;border:1px solid var(--slate-200);padding:12px;margin-top:8px">
            <div style="display:flex;justify-content:space-between;align-items:center;cursor:pointer;-webkit-tap-highlight-color:transparent" onclick="toggleStreetList()">
              <span style="font-size:11px;font-weight:700;font-family:monospace;text-transform:uppercase;color:var(--slate-600)">🛵 Ventas callejeras (${dayStreet.length})</span>
              <span style="font-size:13px;font-weight:700;color:var(--emerald-600);font-family:monospace">${formatCurrency(streetTotal)} ${AppState.streetExpanded ? '▲' : '▼'}</span>
            </div>
            ${AppState.streetExpanded ? dayStreet.map(e => {
              const p = getProduct(e.productId);
              return `<div class="erp-collection-item"><span class="erp-collection-item-name">${p ? p.name : '—'} · ${e.kg}kg</span><span class="erp-collection-item-amount">${formatCurrency(e.amount)}</span>${e.description ? `<div style="font-size:10px;color:var(--slate-500);font-family:monospace;margin-top:2px">${e.description}</div>` : ''}</div>`;
            }).join('') : ''}
          </div>` : ''}

          <div style="height:8px"></div>

        </div>
      </div>
      <div style="position:fixed;bottom:0;left:0;right:0;max-width:480px;margin:0 auto;background:#fff;border-top:1px solid var(--slate-200);padding:8px 12px calc(8px + var(--safe-bottom));z-index:30">
        <button class="erp-btn erp-btn-secondary erp-btn-block" onclick="App.openStreetModal()">🛵 Venta callejera</button>
        ${allStopsDone() ? '<button class="erp-btn erp-btn-success erp-btn-lg erp-btn-block" style="margin-top:8px" onclick="finishDay()">🎯 Finalizar jornada</button>' : ''}
      </div>
      ${renderStreetSaleModal()}
      ${renderRouteCreationModal()}
    `,
    init: () => {
      AppState.extraSales = DB.Street.byDate(projectToday);
      updateSyncStatusChip();
    }
  };
}

// ─── Sync status chip ─────────────────────────────────────
function updateSyncStatusChip() {
  const chip = document.getElementById('sync-status-chip');
  if (!chip) return;
  try {
    const online = typeof navigator !== 'undefined' && navigator.onLine;
    if (!online) { chip.textContent = '📴 Sin conexión'; chip.className = 'erp-chip erp-chip-amber'; return; }
    const meta = window.SyncDebug ? SyncDebug.getMeta() : {};
    const keys = Object.keys(meta).filter(k => k.indexOf('shadow_') === 0);
    const pending = keys.some(k => {
      const shadow = meta[k];
      return shadow && shadow.length > 0;
    });
    if (pending) { chip.textContent = '🔄 Sincronizando…'; chip.className = 'erp-chip erp-chip-amber'; }
    else { chip.textContent = '✓ Al día'; chip.className = 'erp-chip erp-chip-green'; }
  } catch (e) {
    chip.textContent = '✓ Al día';
    chip.className = 'erp-chip erp-chip-green';
  }
}

function toggleStreetList() {
  AppState.streetExpanded = !AppState.streetExpanded;
  render();
}

function renderStreetSaleModal() {
  if (!AppState.streetModal) return '';
  const defaultPrice = getProductPrice(PRODUCTOS[0].id);
  return `
    <div class="erp-overlay" onclick="App.closeStreetModal()"></div>
    <div class="erp-sheet" style="max-height:85%">
      <div class="erp-sheet-handle"></div>
      <div class="erp-sheet-title">🛵 Venta callejera</div>
      <div class="erp-sheet-body">
        <div class="erp-field">
          <div class="erp-label">Producto</div>
          <select class="erp-select" id="street-product" onchange="onStreetProductChange()">
            ${PRODUCTOS.map(p => `<option value="${p.id}">${p.icon} ${p.name}</option>`).join('')}
          </select>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <div class="erp-field">
            <div class="erp-label">Cantidad (kg)</div>
            <div style="display:flex;align-items:center;gap:8px">
              <button class="erp-btn erp-btn-sm" onclick="adjustStreet(-0.5)">−</button>
              <span style="font-size:22px;font-weight:700;font-family:monospace;flex:1;text-align:center;color:var(--slate-900);cursor:pointer" id="street-qty" onclick="editQty('street-qty')">1</span>
              <button class="erp-btn erp-btn-sm" onclick="adjustStreet(0.5)">+</button>
            </div>
          </div>
          <div class="erp-field">
            <div class="erp-label">Precio/kg ($)</div>
            <input class="erp-input" style="height:44px;font-size:18px;font-weight:700;font-family:monospace;text-align:center" type="text" inputmode="decimal" id="street-price" value="${defaultPrice}" oninput="onStreetPriceInput()">
          </div>
        </div>
        <div class="erp-field">
          <div class="erp-label">Descripción <span style="color:var(--red-500)">*</span></div>
          <input class="erp-input" type="text" id="street-description" placeholder="¿Qué se vendió y a quién?">
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;margin-top:4px;border-top:1px solid var(--slate-100)">
          <span style="font-size:12px;font-weight:600;color:var(--slate-600);font-family:monospace">Total a cobrar</span>
          <span style="font-size:16px;font-weight:700;color:var(--emerald-600);font-family:monospace" id="street-total">${formatCurrency(defaultPrice)}</span>
        </div>
        <button class="erp-btn erp-btn-primary erp-btn-lg erp-btn-block" style="margin-top:12px" onclick="confirmStreetModalSale()">💵 Registrar venta</button>
      </div>
    </div>
  `;
}

function confirmStreetModalSale() {
  const prodId = document.getElementById('street-product')?.value;
  const qty = parseFloat(document.getElementById('street-qty')?.textContent) || 0;
  const price = parseFloat(document.getElementById('street-price')?.value) || 0;
  const total = qty * price;
  const description = document.getElementById('street-description')?.value.trim() || '';
  if (qty <= 0 || price <= 0) { showToast('❌ Cantidad o precio inválidos'); return; }
  if (!description) { showToast('❌ Ingresa una descripción de la venta'); return; }
  addExtraSale(prodId, qty, total, description);
  showToast('✅ Venta registrada: ' + formatCurrency(total));
  AppState.streetModal = false;
  AppState.streetExpanded = true;
  render();
}

// ─── STOP SCREEN (Unified: Delivery + Returns + Payment) ─
function renderStop(stop) {
  const c = getCustomer(stop.customerId);
  const isReadOnly = stop.status === 'completed' || stop.status === 'skipped';
  const orderId = stop.orderId || stop.stopId || '—';
  const isCOD = c && c.paymentTerm === 'COD';
  const price = getStopPrice(stop);
  const halfPrice = RECOMPRA_PRICE;

  if (isReadOnly) {
    const dkg = stop.deliveredKg || stop.preOrderKg || 0;
    const neto = dkg * price - (stop.devolucionKg || 0) * price + (stop.recompraKg || 0) * halfPrice;
    const paidAmt = stop.creditPaidAmount || 0;

    if (stop.status === 'skipped') {
      const skipLabels = { no_salio: 'No salió a ruta', estaba_cerrado: 'Estaba cerrado' };
      const skipText = stop.skipNote || skipLabels[stop.skipReason] || 'Saltada';
      return {
        html: `
          <div class="erp-header">
            <div class="erp-header-left">
              <button class="erp-back-btn" onclick="App.goBack()">← VOLVER</button>
              <div class="erp-header-info">
                <div class="erp-header-name">
                  <span class="erp-header-name-text">${stop.customerName}</span>
                  <span class="${isCOD ? 'erp-badge-contado' : 'erp-badge-credito'}">${isCOD ? 'CONTADO' : 'CRÉDITO'}</span>
                </div>
                <div class="erp-header-sub">ORDEN: #${orderId}</div>
              </div>
            </div>
          </div>
          <div class="erp-content" id="stop-content">
            <div class="erp-panel">
              <div class="erp-panel-header"><span class="erp-panel-title">⏭️ Parada saltada</span></div>
              <div class="erp-panel-body">
                <div style="padding:12px 0;text-align:center">
                  <div style="font-size:28px;margin-bottom:8px">⏭️</div>
                  <div style="font-size:15px;font-weight:600;color:var(--slate-700)">${skipText}</div>
                </div>
              </div>
            </div>
            <div style="height:85px"></div>
          </div>
          <div class="erp-footer">
            <button class="erp-btn-register" onclick="App.goBack()" style="background:var(--slate-400);width:100%">← VOLVER</button>
          </div>
        `,
        init: () => {}
      };
    }

    const payLabel = stop.creditPaidType ? 'Efectivo' : null;
    return {
      html: `
        <div class="erp-header">
          <div class="erp-header-left">
            <button class="erp-back-btn" onclick="App.goBack()">← VOLVER</button>
            <div class="erp-header-info">
              <div class="erp-header-name">
                <span class="erp-header-name-text">${stop.customerName}</span>
                <span class="${isCOD ? 'erp-badge-contado' : 'erp-badge-credito'}">${isCOD ? 'CONTADO' : 'CRÉDITO'}</span>
              </div>
              <div class="erp-header-sub">ORDEN: #${orderId} · <span class="erp-status-completed">COMPLETADA</span>${stop.recompraKg > 0 ? ' <span class="erp-chip erp-chip-green" style="font-size:8px;padding:0 4px">♻️ REC</span>' : ''}</div>
            </div>
          </div>
        </div>
        <div class="erp-content" id="stop-content">
          <div class="erp-panel">
            <div class="erp-panel-header"><span class="erp-panel-title">Despacho</span></div>
            <div class="erp-panel-body">
              <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0">
                <div>
                  <div style="font-weight:600;font-size:14px;color:var(--slate-900)">🌽 Tortilla de Maíz</div>
                  <div style="font-size:11px;color:var(--slate-400);font-family:monospace">Solicitado: ${stop.preOrderKg} kg · ${formatCurrency(price)}/kg</div>
                </div>
                <div style="text-align:right">
                  <div style="font-size:9px;color:var(--slate-400);text-transform:uppercase;font-family:monospace">Entregado</div>
                  <div style="font-weight:700;font-size:20px;color:var(--emerald-600);font-family:monospace">${dkg} kg</div>
                </div>
              </div>
            </div>
          </div>
          ${(stop.devolucionKg > 0 || stop.recompraKg > 0) ? `
          <div class="erp-panel">
            <div class="erp-panel-header"><span class="erp-panel-title">Ajustes</span></div>
            <div class="erp-panel-body" style="padding:4px 12px 10px">
              <table class="erp-table">
                <thead><tr><th>Concepto</th><th class="num">Cant</th><th class="num">Monto</th></tr></thead>
                <tbody>
                  ${stop.devolucionKg > 0 ? `<tr><td>Devolución <span class="erp-concept-detail">−${formatCurrency(price)}/kg</span></td><td class="num">${stop.devolucionKg} kg</td><td class="num" style="color:var(--amber-400)">−${formatCurrency(stop.devolucionKg * price)}</td></tr>` : ''}
                  ${stop.recompraKg > 0 ? `<tr><td>Recompra <span class="erp-concept-detail">+${formatCurrency(halfPrice)}/kg</span></td><td class="num">${stop.recompraKg} kg</td><td class="num" style="color:var(--emerald-600)">${formatCurrency(stop.recompraKg * halfPrice)}</td></tr>` : ''}
                </tbody>
              </table>
            </div>
          </div>
          ` : ''}
          <div class="erp-panel">
            <div class="erp-panel-header">
              <span class="erp-panel-title">Cobro</span>
              <span style="font-size:12px;font-weight:700;color:var(--slate-900);font-family:monospace">NETO: ${formatCurrency(neto)}</span>
            </div>
            <div class="erp-panel-body">
              <div style="padding:8px 0">
                ${stop.creditAmount > 0 ? `<div class="erp-collection-item"><span>💰 Crédito</span><span class="erp-collection-item-amount">${formatCurrency(stop.creditAmount)}</span></div>` : ''}
                ${(stop.oldDebtPaid || 0) > 0 ? `<div class="erp-collection-item"><span>🧾 Abono Deuda Anterior</span><span class="erp-collection-item-amount">${formatCurrency(stop.oldDebtPaid)}</span></div>` : ''}
                ${payLabel ? `<div class="erp-collection-item"><span>${payLabel}</span><span class="erp-collection-item-amount">${formatCurrency(paidAmt)}</span></div>` : paidAmt > 0 ? `<div class="erp-collection-item"><span>Efectivo</span><span class="erp-collection-item-amount">${formatCurrency(paidAmt)}</span></div>` : ''}
                ${paidAmt === 0 && !stop.creditAmount ? '<div style="font-size:12px;color:var(--slate-400);text-align:center;padding:4px 0">Sin cobro registrado</div>' : ''}
              </div>
            </div>
            ${stop.completedAt ? `<div style="font-size:10px;color:var(--slate-400);font-family:monospace;padding:8px 12px;border-top:1px solid var(--slate-100)">🕓 Completado: ${new Date(stop.completedAt).toLocaleString('es-MX')}</div>` : ''}
          </div>
          <div style="height:85px"></div>
        </div>
        <div class="erp-footer">
          <div class="erp-footer-total">
            <span class="erp-footer-total-label">Total</span>
            <span class="erp-footer-total-value" style="color:var(--emerald-600)">${formatCurrency(neto)}</span>
          </div>
          <button class="erp-btn-register" onclick="App.goBack()" style="background:var(--slate-500);width:100%">← VOLVER</button>
        </div>
      `,
      init: () => {}
    };
  }

  // Another driver's pending stop → read-only with take buttons.
  if (stop.orderId) {
    const viewOrder = getAdvanceOrder(stop.orderId);
    const viewTrip = AppState.trips.find(t => (t.orderIds || []).includes(stop.orderId));
    if (viewOrder && viewOrder.status === 'pending' && viewTrip && !isTripMine(viewTrip)) {
      const hfs = orderHandoffs(viewOrder);
      const otherLegs2 = hfs.filter(h => h.by !== (AppState.driver && AppState.driver.id));
      const deliveredSoFar = hfs.length ? Math.max(...hfs.map(h => Number(h.kg) || 0)) : 0;
      const yaCobradoView = sumHandoffCash(viewOrder);
      const quedanView = Math.max(0, (viewOrder.qty || 0) - deliveredSoFar);
      return {
        html: `
          <div class="erp-header">
            <div class="erp-header-left">
              <button class="erp-back-btn" onclick="App.goBack()">← VOLVER</button>
              <div class="erp-header-info">
                <div class="erp-header-name">
                  <span class="erp-header-name-text">${stop.customerName}</span>
                  <span class="${isCOD ? 'erp-badge-contado' : 'erp-badge-credito'}">${isCOD ? 'CONTADO' : 'CRÉDITO'}</span>
                </div>
                <div class="erp-header-sub">ORDEN: #${orderId} · <span class="erp-status-draft">SOLO LECTURA</span></div>
              </div>
            </div>
          </div>
          <div class="erp-content" id="stop-content">
            <div class="erp-handoff-banner">
              <div class="erp-handoff-row"><span>🚛 Ruta de <b>${escHtml(tripOwnerName(viewTrip))}</b></span><span class="erp-handoff-detail">${viewTrip.id}</span></div>
              <div class="erp-handoff-sub">Solicitado ${viewOrder.qty}kg · Ya entregado ${deliveredSoFar}kg · Quedan ${quedanView}kg</div>
            </div>
            ${otherLegs2.map(h => `
              <div class="erp-handoff-banner">
                <div class="erp-handoff-row">
                  <span>🤝 Parcial de <b>${escHtml(h.byName || '—')}</b></span>
                  <span class="erp-handoff-detail">${Number(h.kg) || 0}kg ent · ${Number(h.dev) || 0}kg dev · ${formatCurrency(Number(h.cash) || 0)} cob</span>
                </div>
              </div>
            `).join('')}
            <div class="erp-panel">
              <div class="erp-panel-header"><span class="erp-panel-title">Resumen</span></div>
              <div class="erp-panel-body">
                <div class="erp-collection-item"><span>📦 Kilos pedidos</span><span class="erp-collection-item-amount">${viewOrder.qty} kg</span></div>
                <div class="erp-collection-item"><span>✅ Ya entregados</span><span class="erp-collection-item-amount">${deliveredSoFar} kg</span></div>
                ${yaCobradoView > 0 ? `<div class="erp-collection-item"><span>💰 Ya cobrado</span><span class="erp-collection-item-amount">${formatCurrency(yaCobradoView)}</span></div>` : ''}
              </div>
            </div>
            <div style="height:120px"></div>
          </div>
          <div class="erp-footer">
            <div style="width:100%">
              <button class="erp-btn-register" onclick="App.takeOrder('${stop.orderId}')">
                <span>🙋</span> TOMAR ORDEN
              </button>
            </div>
          </div>
        `,
        init: () => {}
      };
    }
  }

  const draft = stop.deliveryDraft || {};
  const currentTrip = stop.orderId ? AppState.trips.find(t => (t.orderIds || []).includes(stop.orderId)) : null;
  const draftBeforeTakeover = !!(currentTrip && currentTrip.takenAt && draft.updatedAt && draft.updatedAt < currentTrip.takenAt);
  const draftBelongsToOther = !!((draft.driverId && draft.driverId !== (AppState.driver && AppState.driver.id)) || draftBeforeTakeover);
  const orderRec = stop.orderId ? getAdvanceOrder(stop.orderId) : null;
  const handoffs = orderRec ? orderHandoffs(orderRec) : [];
  const otherLegs = handoffs.filter(h => h.by !== (AppState.driver && AppState.driver.id));
  const yaCobrado = handoffs.reduce((s, h) => s + (Number(h.cash) || 0), 0);
  const kg = otherLegs.length ? stop.preOrderKg : (draft.kg || stop.preOrderKg);
  const dev = draft.dev !== undefined ? draft.dev : (stop.devolucionKg || 0);
  const rec = draft.rec !== undefined ? draft.rec : (stop.recompraKg || 0);
  const neto = kg * price - dev * price + rec * halfPrice;
  const subtotal = kg * price;
  const inventoryExpanded = draft.inventoryExpanded || dev > 0 || rec > 0;
  const recValue = rec * halfPrice;
  const pending = getCustomerBalance(stop.customerId);
  const recentPending = getRecentPendingCredit(stop.customerId);
  const pendingDateLabel = recentPending && recentPending.date ? formatStmtDate(recentPending.date) : null;
  const chipVisible = pending > 0.01 && !hasPaymentRecurrence(c);
  const collectPending = draft.collectPending === true;
  const sugerido = Math.max(0, neto - yaCobrado) + (collectPending ? pending : 0);
  const cashDefault = draftBelongsToOther || handoffs.length > 0
    ? sugerido
    : (draft.cash !== undefined ? draft.cash : (collectPending ? sugerido : (recValue > 0 ? recValue : neto)));
  const creditDefault = Math.max(0, sugerido - cashDefault);
  const quedanKg = Math.max(0, stop.preOrderKg - kg);
  const handoffBanner = otherLegs.length ? `
    <div class="erp-handoff-banner">
      ${otherLegs.map(h => `
        <div class="erp-handoff-row">
          <span>🤝 Parcial de <b>${escHtml(h.byName || '—')}</b></span>
          <span class="erp-handoff-detail">${Number(h.kg) || 0}kg ent · ${Number(h.dev) || 0}kg dev · ${formatCurrency(Number(h.cash) || 0)} cob</span>
        </div>
      `).join('')}
      <div class="erp-handoff-sub">Solicitado ${stop.preOrderKg}kg · Ya entregado ${Math.max(...handoffs.map(h => Number(h.kg) || 0))}kg · Quedan ${quedanKg}kg</div>
    </div>
  ` : '';

  return {
    html: `
      <div class="erp-header">
        <div class="erp-header-left">
          <button class="erp-back-btn" onclick="saveDraftAndGoBack('${stop.stopId}')">← VOLVER</button>
          <div class="erp-header-info">
            <div class="erp-header-name">
              <span class="erp-header-name-text">${stop.customerName}</span>
              <span class="${isCOD ? 'erp-badge-contado' : 'erp-badge-credito'}">${isCOD ? 'CONTADO' : 'CRÉDITO'}</span>
            </div>
            <div class="erp-header-sub">
              ORDEN: #${orderId} · <span class="${stop.status === 'completed' ? 'erp-status-completed' : 'erp-status-draft'}">${stop.status === 'completed' ? 'COMPLETADA' : 'BORRADOR'}</span>
            </div>
          </div>
        </div>
        <button class="erp-header-omit" onclick="skipStopConfirm('${stop.stopId}')">
          <span>✖</span> OMITIR
        </button>
      </div>

      <div class="erp-content" id="stop-content">

        ${handoffBanner}

        <div class="erp-panel">
          <div class="erp-panel-header">
            <span class="erp-panel-title">1. Despacho de Producto</span>
            <span class="erp-panel-badge">REQ: ${stop.preOrderKg.toFixed(2)} KG</span>
          </div>
          <div class="erp-panel-body">
            <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:10px">
              <div>
                <div style="font-weight:700;font-size:14px;color:var(--slate-900)">🌽 Tortilla de Maíz</div>
                <div style="font-size:12px;color:var(--slate-500);font-family:monospace">P.U: ${formatCurrency(price)} / KG</div>
              </div>
              <div style="text-align:right;font-family:monospace">
                <div style="font-size:10px;color:var(--slate-400);text-transform:uppercase">Subtotal</div>
                <div style="font-weight:700;font-size:15px;color:var(--slate-900)" id="stop-subtotal">${formatCurrency(subtotal)}</div>
              </div>
            </div>
            <div class="erp-qty-grid">
              <button class="erp-qty-btn" onclick="adjustDelivery(-1)">−</button>
              <div class="erp-qty-display">
                <span class="erp-qty-number" id="delivery-qty" style="cursor:pointer" onclick="editQty('delivery-qty')">${kg}</span>
                <span class="erp-qty-label">KG REAL</span>
              </div>
              <button class="erp-qty-btn" onclick="adjustDelivery(1)">+</button>
            </div>
          </div>
        </div>

        <div class="erp-panel">
          <div class="erp-panel-header" style="cursor:pointer" onclick="toggleInventoryPanel()">
            <span class="erp-panel-title">2. Ajustes de Inventario</span>
            <span id="inventory-badge" style="font-size:10px;font-family:monospace;color:var(--slate-500);font-weight:600">${inventoryExpanded ? '▼' : (dev > 0 || rec > 0 ? '✏️ ' + (dev + rec) + 'kg' : '+ AGREGAR')}</span>
          </div>
          <div id="inventory-body" style="display:${inventoryExpanded ? 'block' : 'none'};overflow:hidden;transition:max-height 0.2s ease">
            <div class="erp-panel-body" style="padding:4px 12px 10px">
              <table class="erp-table">
                <thead>
                  <tr>
                    <th>Concepto</th>
                    <th>Cant (KG)</th>
                    <th>Monto</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      Devolución
                      <span class="erp-concept-detail">−${formatCurrency(price)}/kg</span>
                    </td>
                    <td>
                      <div class="inline-stepper">
                        <button onclick="adjustDevolucion(-1)">−</button>
                        <span id="devolucion-qty" style="cursor:pointer" onclick="editQty('devolucion-qty')">${dev}</span>
                        <button onclick="adjustDevolucion(1)">+</button>
                      </div>
                    </td>
                    <td style="color:var(--amber-400)" id="devolucion-monto">−${formatCurrency(dev * price)}</td>
                  </tr>
                  <tr>
                    <td>
                      Recompra
                      <span class="erp-concept-detail">+${formatCurrency(halfPrice)}/kg</span>
                    </td>
                    <td>
                      <div class="inline-stepper">
                        <button onclick="adjustRecompra(-1)">−</button>
                        <span id="recompra-qty" style="cursor:pointer" onclick="editQty('recompra-qty')">${rec}</span>
                        <button onclick="adjustRecompra(1)">+</button>
                      </div>
                    </td>
                    <td style="color:var(--emerald-600)" id="recompra-monto">${formatCurrency(rec * halfPrice)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div class="erp-panel">
          <div class="erp-panel-header">
            <span class="erp-panel-title">3. Matriz de Cobro</span>
          </div>
          <div class="erp-panel-body">
            <div class="erp-matrix-neto-row">
              <span style="color:var(--slate-600)">Neto Venta:</span>
              <span style="font-weight:700;color:var(--slate-900);font-family:monospace" id="stop-neto-val">${formatCurrency(neto)}</span>
            </div>
            ${yaCobrado > 0 ? `
              <div class="erp-matrix-neto-row">
                <span style="color:var(--slate-500)">Ya cobrado (parciales):</span>
                <span style="font-weight:700;color:var(--emerald-600);font-family:monospace">−${formatCurrency(yaCobrado)}</span>
              </div>
            ` : ''}
            ${chipVisible ? `
              <div class="erp-pending-chip ${collectPending ? 'erp-pending-chip-on' : ''}" id="pending-chip" onclick="toggleCollectPending()">
                <span id="pending-chip-label">Cobrar ${formatCurrency(pending)} pendiente ${pendingDateLabel ? `(<a class="erp-pending-date-link" onclick="event.stopPropagation();openDebtStop('${recentPending.stopId || ''}','${recentPending.orderId || ''}','${recentPending.routeName || ''}')">${pendingDateLabel}</a>)` : ''}</span>
              </div>
            ` : ''}
            <div class="erp-sugerido-row" id="sugerido-row" style="${collectPending ? '' : 'display:none'}">
              <span style="color:var(--slate-600)">TOTAL A COBRAR SUGERIDO:</span>
              <span style="font-weight:800;color:var(--accent-600);font-family:monospace;font-size:14px" id="stop-sugerido">${formatCurrency(sugerido)}</span>
            </div>
            <div style="margin-top:10px">
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
                <div>
                  <label style="font-size:10px;font-weight:700;color:var(--slate-500);text-transform:uppercase;display:block;font-family:monospace;margin-bottom:4px">Efectivo ($)</label>
                  <input type="text" class="erp-input" id="stop-cash" value="${cashDefault.toFixed(2)}" inputmode="decimal" oninput="onCashInput()" onblur="commitCashCredit()" onkeydown="if(event.key==='Enter'){this.blur();}">
                </div>
                <div>
                  <label style="font-size:10px;font-weight:700;color:var(--slate-500);text-transform:uppercase;display:block;font-family:monospace;margin-bottom:4px">Crédito ($)</label>
                  <input type="text" class="erp-input" id="stop-credit" value="${creditDefault.toFixed(2)}" inputmode="decimal" oninput="onCreditInput()" onblur="commitCashCredit()" onkeydown="if(event.key==='Enter'){this.blur();}">
                </div>
              </div>
            </div>
          </div>
        </div>

        <div style="height:85px"></div>

      </div>

      <div class="erp-footer">
        <div class="erp-footer-total">
          <span class="erp-footer-total-label">Total Transacción</span>
          <span class="erp-footer-total-value" id="stop-total-footer">${formatCurrency(sugerido)}</span>
        </div>
        <button class="erp-btn-register" onclick="openSignatureSheet('${stop.stopId}')">
          <span>📝</span> FIRMAR Y REGISTRAR
        </button>
      </div>

      ${renderSkipReasonSheet()}
      ${renderSignatureSheet()}
    `,
    init: () => { updateSummary(); }
  };
}

// ─── STREET SALE ───────────────────────────────────────
function renderStreetSale() {
  return {
    html: `
      <div class="erp-screen">
        <div style="display:flex;align-items:center;gap:8px;padding:10px 10px 4px">
          <button class="erp-btn erp-btn-sm" onclick="App.goBack()">← VOLVER</button>
          <div>
            <div style="font-size:15px;font-weight:700;color:var(--slate-900)">Venta callejera</div>
            <div style="font-size:10px;color:var(--slate-400);font-family:monospace">Venta sin cliente registrado</div>
          </div>
        </div>
        <div style="flex:1;overflow-y:auto;padding:8px 10px 80px">
          <div style="background:white;border:1px solid var(--slate-200);padding:12px;margin-bottom:12px">
            <div class="erp-field">
              <div class="erp-label">Producto</div>
              <select class="erp-select" id="street-product" onchange="onStreetProductChange()">
                ${PRODUCTOS.map(p => `<option value="${p.id}">${p.icon} ${p.name}</option>`).join('')}
              </select>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
              <div class="erp-field">
                <div class="erp-label">Cantidad (kg)</div>
                <div style="display:flex;align-items:center;gap:8px">
                  <button class="erp-btn erp-btn-sm" onclick="adjustStreet(-0.5)">−</button>
                  <span style="font-size:22px;font-weight:700;font-family:monospace;flex:1;text-align:center;color:var(--slate-900);cursor:pointer" id="street-qty" onclick="editQty('street-qty')">1</span>
                  <button class="erp-btn erp-btn-sm" onclick="adjustStreet(0.5)">+</button>
                </div>
              </div>
              <div class="erp-field">
                <div class="erp-label">Precio/kg ($)</div>
                <input class="erp-input" style="height:44px;font-size:18px;font-weight:700;font-family:monospace;text-align:center" type="text" inputmode="decimal" id="street-price" value="${getProductPrice(PRODUCTOS[0].id)}" oninput="onStreetPriceInput()">
              </div>
            </div>
            <div class="erp-field">
              <div class="erp-label">Descripción <span style="color:var(--red-500)">*</span></div>
              <input class="erp-input" type="text" id="street-description" placeholder="¿Qué se vendió y a quién?">
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;margin-top:4px;border-top:1px solid var(--slate-100)">
              <span style="font-size:12px;font-weight:600;color:var(--slate-600);font-family:monospace">Total a cobrar</span>
              <span style="font-size:16px;font-weight:700;color:var(--emerald-600);font-family:monospace" id="street-total">${formatCurrency(getProductPrice(PRODUCTOS[0].id))}</span>
            </div>
            </div>
            <button class="erp-btn erp-btn-primary erp-btn-lg erp-btn-block" onclick="confirmStreetSale()" style="margin-top:12px">💵 Registrar venta</button>
          </div>

          <div style="background:white;border:1px solid var(--slate-200);padding:12px">
            <div style="font-size:11px;font-weight:700;font-family:monospace;text-transform:uppercase;color:var(--slate-500);margin-bottom:8px">📊 Ventas callejeras hoy</div>
            ${AppState.extraSales.length === 0 ? '<div style="font-size:12px;color:var(--slate-400);font-family:monospace">Ninguna aún</div>' :
              AppState.extraSales.map(e => {
                const p = getProduct(e.productId);
                return `<div class="erp-collection-item"><span class="erp-collection-item-name">${p ? p.name : ''} · ${e.kg}kg</span><span class="erp-collection-item-amount">${formatCurrency(e.amount)}</span>${e.description ? `<div style="font-size:10px;color:var(--slate-500);font-family:monospace;margin-top:2px">${e.description}</div>` : ''}</div>`;
              }).join('')}
          </div>
        </div>
      </div>
    `,
    init: () => { AppState.extraSales = DB.Street.byDate(today()); }
  };
}

// ─── SETTLEMENT ────────────────────────────────────────
// ─── CUSTOMERS ───
function renderCustomers() {
  const sheetCustomerId = AppState.sheetCustomerId;
  const sheetC = sheetCustomerId ? getCustomer(sheetCustomerId) : null;
  const sortBy = AppState.customersSortBy;
  const sortDir = AppState.customersSortDir;
  const page = AppState.customersPage;
  const perPage = AppState.customersPerPage;
  const sel = AppState.selectedCustomers || [];
  const isAdmin = Auth.isAdmin();

  const colMap = { name: 'name', contact: 'contact', phone: 'phone', direccion: 'direccion' };

  const sortArrow = (col) => sortBy === col ? (sortDir === 'asc' ? '▲' : '▼') : '';

  const sorted = [...activeCustomers()].sort((a, b) => {
    const va = (a[colMap[sortBy]] || '').toLowerCase();
    const vb = (b[colMap[sortBy]] || '').toLowerCase();
    return sortDir === 'asc' ? va.localeCompare(vb) : vb.localeCompare(va);
  });

  const totalPages = Math.max(1, Math.ceil(sorted.length / perPage));
  const start = (page - 1) * perPage;
  const paged = sorted.slice(start, start + perPage);

  const allSelected = paged.length > 0 && paged.every(c => sel.includes(c.id));

  function sortHeader(label, col) {
    const arrow = sortArrow(col);
    const active = sortBy === col;
    return `<th class="${active ? 'active' : ''}" onclick="App.sortCustomers('${col}')">${label} <span>${arrow}</span></th>`;
  }

  function renderPagination(right) {
    const mr = right ? ' style="margin-left:auto"' : '';
    return `<div class="erp-pages"${mr}>
      ${Array.from({ length: totalPages }, (_, i) => {
        const p = i + 1;
        return `<button class="erp-page${p === page ? ' active' : ''}" onclick="App.setCustomersPage(${p})">${p}</button>`;
      }).join('')}
      <button class="erp-page" onclick="App.setCustomersPage(${totalPages})">Última</button>
    </div>`;
  }

  return {
    html: `
      <div class="erp-screen">
        <div style="display:flex;align-items:center;gap:8px;padding:10px 10px 4px">
          <button class="erp-btn erp-btn-sm" onclick="App.goBack()">← VOLVER</button>
          <div style="flex:1">
            <div style="font-size:15px;font-weight:700;color:var(--slate-900)">Clientes</div>
            <div style="font-size:10px;color:var(--slate-400);font-family:monospace">${activeCustomers().length} registrados</div>
          </div>
          ${isAdmin ? `<button class="erp-btn erp-btn-sm erp-btn-primary" onclick="App.navigate('customerForm')">+ NUEVO</button>` : ''}
        </div>
        <div style="padding:4px 10px 0">
          <input class="erp-input" id="customer-search" placeholder="Buscar por nombre, contacto o teléfono..."
            oninput="filterCustomers()" style="border-radius:0">
        </div>
        <div style="padding:4px 10px;display:flex;justify-content:flex-end">
          ${renderPagination(true)}
        </div>
        <div style="flex:1;overflow-y:auto;padding:0 10px 80px" id="customer-list">
          <table class="erp-customer-table">
            <thead><tr>
              ${isAdmin ? '<th class="check"><input type="checkbox" ' + (allSelected ? 'checked' : '') + ' onchange="App.toggleSelectAllCustomers(this.checked)"></th>' : ''}
              ${sortHeader('Cliente', 'name')}${sortHeader('Contacto', 'contact')}${sortHeader('Teléfono', 'phone')}${sortHeader('Dirección', 'direccion')}
            </tr></thead>
            <tbody>
              ${paged.map(c => {
                const checked = sel.includes(c.id);
                return `
                <tr onclick="App.openCustomerSheet('${c.id}')">
                  ${isAdmin ? '<td class="check" onclick="event.stopPropagation()"><input type="checkbox" ' + (checked ? 'checked' : '') + ' onchange="App.toggleSelectCustomer(\'' + c.id + '\',this.checked)"></td>' : ''}
                  <td class="name">${c.name}</td>
                  <td>${c.contact || '—'}</td>
                  <td class="phone">${c.phone}</td>
                  <td class="dir">${c.direccion || '—'}</td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
          ${isAdmin && sel.length > 0 ? `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 4px">
            <span style="font-size:12px;color:var(--slate-500);font-family:monospace">${sel.length} seleccionados</span>
            <button class="erp-btn erp-btn-sm erp-btn-danger" onclick="bulkDeleteCustomers()">🗑️ Eliminar</button>
          </div>` : ''}
          <div style="display:flex;justify-content:flex-end;padding:4px 0 12px">
            ${renderPagination(true)}
          </div>
        </div>
      </div>
      ${sheetC ? renderCustomerSheet(sheetC) : ''}
      ${AppState.openingDebtModal ? renderOpeningDebtModal(getCustomer(AppState.openingDebtModal.customerId)) : ''}
    `,
    init: () => {}
  };
}

function bulkDeleteCustomers() {
  const sel = AppState.selectedCustomers;
  if (sel.length === 0) return;
  if (!confirm('¿Eliminar ' + sel.length + ' cliente(s)? Esta acción no se puede deshacer.')) return;
  sel.forEach(id => deleteCustomer(id));
  AppState.selectedCustomers = [];
  render();
}

function filterCustomers() {
  const q = document.getElementById('customer-search')?.value.toLowerCase() || '';
  const list = document.getElementById('customer-list');
  if (!list) return;
  const filtered = activeCustomers().filter(c =>
    c.name.toLowerCase().includes(q) ||
    (c.contact || '').toLowerCase().includes(q) ||
    c.phone.includes(q)
  );

  const sb = AppState.customersSortBy;
  const sd = AppState.customersSortDir;
  const cm = { name: 'name', contact: 'contact', phone: 'phone', direccion: 'direccion' };
  const col = cm[sb] || 'name';

  filtered.sort((a, b) => {
    const va = (a[col] || '').toLowerCase();
    const vb = (b[col] || '').toLowerCase();
    return sd === 'asc' ? va.localeCompare(vb) : vb.localeCompare(va);
  });

  const pp = AppState.customersPerPage;
  const tp = Math.max(1, Math.ceil(filtered.length / pp));
  if (AppState.customersPage > tp) AppState.customersPage = tp;
  const pg = AppState.customersPage;
  const start = (pg - 1) * pp;
  const paged = filtered.slice(start, start + pp);
  const sel = AppState.selectedCustomers || [];
  const allSelected = paged.length > 0 && paged.every(c => sel.includes(c.id));

  const sortArrow = (col) => sb === col ? (sd === 'asc' ? '▲' : '▼') : '';
  const sortHeader = (label, col) => {
    const arrow = sortArrow(col);
    return `<th class="${sb === col ? 'active' : ''}" onclick="App.sortCustomers('${col}')">${label} <span>${arrow}</span></th>`;
  };

  list.innerHTML = `
    <table class="erp-customer-table">
      <thead><tr>
        <th class="check"><input type="checkbox" ${allSelected ? 'checked' : ''} onchange="App.toggleSelectAllCustomers(this.checked)"></th>
        ${sortHeader('Cliente', 'name')}${sortHeader('Contacto', 'contact')}${sortHeader('Teléfono', 'phone')}${sortHeader('Dirección', 'direccion')}
      </tr></thead>
      <tbody>
        ${paged.length === 0
          ? '<tr><td colspan="5" style="text-align:center;padding:32px;color:var(--slate-400);font-family:monospace">Ningún cliente coincide</td></tr>'
          : paged.map(c => {
              const checked = sel.includes(c.id);
              return `
            <tr onclick="App.openCustomerSheet('${c.id}')">
              <td class="check" onclick="event.stopPropagation()"><input type="checkbox" ${checked ? 'checked' : ''} onchange="App.toggleSelectCustomer('${c.id}',this.checked)"></td>
              <td class="name">${c.name}</td>
              <td>${c.contact || '—'}</td>
              <td class="phone">${c.phone}</td>
              <td class="dir">${c.direccion || '—'}</td>
            </tr>`;
          }).join('')}
      </tbody>
    </table>
    ${sel.length > 0 ? `
    <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 4px">
      <span style="font-size:12px;color:var(--slate-500);font-family:monospace">${sel.length} seleccionados</span>
      <button class="erp-btn erp-btn-sm erp-btn-danger" onclick="bulkDeleteCustomers()">🗑️ Eliminar</button>
    </div>` : ''}
    <div style="display:flex;justify-content:flex-end;align-items:center;gap:4px;margin-top:8px;padding:0 4px 12px">
      ${Array.from({ length: tp }, (_, i) => {
        const p = i + 1;
        return `<button class="erp-page${p === pg ? ' active' : ''}" onclick="App.setCustomersPage(${p});filterCustomers()">${p}</button>`;
      }).join('')}
      <button class="erp-page" onclick="App.setCustomersPage(${tp});filterCustomers()">Última</button>
    </div>`;
}

// ─── CUSTOMER SHEET ───
function renderCustomerSheet(c) {
  const isAdmin = Auth.isAdmin();
  return `
    <div class="erp-overlay" onclick="App.closeCustomerSheet()"></div>
    <div class="erp-sheet">
      <div class="erp-sheet-handle"></div>
      <div class="erp-customer-sheet-header">
        <div class="erp-customer-sheet-avatar">👤</div>
        <div>
          <div class="erp-customer-sheet-name">${c.name}</div>
          <div class="erp-customer-sheet-phone">${c.phone} · ${capitalize(c.paymentTerm)}</div>
        </div>
      </div>
      <div class="erp-customer-sheet-actions">
        <button class="erp-btn erp-btn-block" onclick="App.closeCustomerSheet();App.navigate('customerStatement',{customerId:'${c.id}'})">
          <span>💰</span> Estado de cuentas <span style="margin-left:auto;color:var(--slate-400)">›</span>
        </button>
        <button class="erp-btn erp-btn-block" onclick="App.closeCustomerSheet();App.navigate('customerInfo',{customerId:'${c.id}'})">
          <span>ℹ️</span> Detalles <span style="margin-left:auto;color:var(--slate-400)">›</span>
        </button>
        ${isAdmin ? `
        <button class="erp-btn erp-btn-block" onclick="App.closeCustomerSheet();openOpeningDebtModal('${c.id}')">
          <span>💾</span> Registrar deuda previa <span style="margin-left:auto;color:var(--slate-400)">›</span>
        </button>
        <hr class="erp-divider">
        <button class="erp-btn erp-btn-block" style="color:var(--danger);border-color:var(--danger)" onclick="App.closeCustomerSheet();deleteCustomerConfirm('${c.id}')">
          <span>🗑️</span> Eliminar cliente <span style="margin-left:auto;color:var(--slate-400)">›</span>
        </button>` : ''}
      </div>
    </div>
  `;
}

// ─── CUSTOMER DETAIL ───
function renderCustomerDetail(customerId) {
  const c = getCustomer(customerId);
  if (!c) return { html: '<div class="erp-empty"><span class="erp-empty-icon">👤</span><div class="erp-empty-text">Cliente no encontrado</div></div>', init: () => {} };
  const balance = getCustomerBalance(c.id);
  const isClear = balance <= 0;
  const totalPaid = getTotalPayments(c.id);
  return {
    html: `
      <div class="erp-screen">
        <div style="display:flex;align-items:center;gap:8px;padding:10px 10px 4px">
          <button class="erp-btn erp-btn-sm" onclick="App.goBack()">← VOLVER</button>
          <div style="flex:1;min-width:0">
            <div style="font-size:15px;font-weight:700;color:var(--slate-900)">${c.name}</div>
            <div style="font-size:10px;color:var(--slate-400);font-family:monospace">${c.phone}</div>
          </div>
          <span class="erp-chip ${c.paymentTerm !== 'COD' ? 'erp-chip-amber' : 'erp-chip-green'}">${c.paymentTerm !== 'COD' ? 'Crédito' : 'Contado'}</span>
        </div>
        <div style="flex:1;overflow-y:auto;padding:8px 10px 80px">
          <div style="padding:16px;text-align:center;border:1px solid ${isClear ? 'var(--green-100)' : 'var(--danger-bg)'};border-radius:8px;margin-bottom:10px;background:white">
            <div style="font-size:10px;font-family:monospace;text-transform:uppercase;color:var(--slate-500)">Saldo</div>
            <div style="font-size:24px;font-weight:700;font-family:monospace;color:${isClear ? 'var(--emerald-600)' : 'var(--danger)'}">${formatCurrency(balance)}</div>
            <div style="font-size:11px;color:var(--slate-400);font-family:monospace;margin-top:2px">${isClear ? 'Al corriente' : 'Adeudo pendiente'}</div>
          </div>
          <button class="erp-btn erp-btn-block" style="justify-content:flex-start;gap:10px" onclick="App.navigate('customerStatement',{customerId:'${c.id}'})">
            <span>💰</span> Estado de cuentas <span style="margin-left:auto;color:var(--slate-400)">›</span>
          </button>
          <button class="erp-btn erp-btn-block" style="justify-content:flex-start;gap:10px" onclick="showToast('Crear orden — proximamente')">
            <span>📝</span> Crear orden <span style="margin-left:auto;color:var(--slate-400)">›</span>
          </button>
          <button class="erp-btn erp-btn-block" style="justify-content:flex-start;gap:10px" onclick="openOpeningDebtModal('${c.id}')">
            <span>💾</span> Registrar deuda previa <span style="margin-left:auto;color:var(--slate-400)">›</span>
          </button>
          <button class="erp-btn erp-btn-block" style="justify-content:flex-start;gap:10px" onclick="setupCustomerRecurrence('${c.id}')">
            <span>🔄</span> Recurrencia de pago <span style="margin-left:auto;color:var(--slate-400)">›</span>
          </button>
          <button class="erp-btn erp-btn-block" style="justify-content:flex-start;gap:10px" onclick="App.navigate('customerInfo',{customerId:'${c.id}'})">
            <span>ℹ️</span> Detalles <span style="margin-left:auto;color:var(--slate-400)">›</span>
          </button>
          ${getCustomerPayments(c.id).length > 0 ? `
            <div style="background:white;border:1px solid var(--slate-200);padding:12px;margin-top:10px">
              <div style="font-size:11px;font-weight:700;font-family:monospace;text-transform:uppercase;color:var(--slate-500);margin-bottom:8px">Historial de pagos</div>
              ${getCustomerPayments(c.id).slice(-5).reverse().map(p => `
                <div class="erp-data-row">
                  <span class="erp-data-label">${formatDate((p.timestamp || '').slice(0, 10))} · ${p.method === 'card' ? 'Tarjeta' : 'Efectivo'}</span>
                  <span class="erp-data-value" style="color:var(--emerald-600)">−${formatCurrency(p.amount)}</span>
                </div>
              `).join('')}
            </div>
          ` : ''}
        </div>
        ${AppState.openingDebtModal ? renderOpeningDebtModal(c) : ''}
      </div>
    `,
    init: () => {}
  };
}

// ─── OPENING DEBT MODAL (deuda previa) ─────────────────
function openOpeningDebtModal(customerId) {
  AppState.openingDebtModal = { customerId, amount: null };
  render();
}

function closeOpeningDebtModal() {
  AppState.openingDebtModal = null;
  render();
}

function renderOpeningDebtModal(c) {
  return `
    <div class="erp-overlay" onclick="closeOpeningDebtModal()"></div>
    <div class="erp-sheet" onclick="event.stopPropagation()">
      <div class="erp-sheet-handle"></div>
      <div class="erp-sheet-title">💾 Registrar Deuda Previa</div>
      <div class="erp-sheet-body">
        <div style="font-size:11px;color:var(--slate-500);font-family:monospace;margin-bottom:12px">Monto que el cliente ya debía antes de usar la app (saldo inicial). Aparecerá en su Estado de cuentas.</div>
        <div class="erp-field">
          <div class="erp-label">Monto ($)</div>
          <input class="erp-input erp-input-lg" id="od-amount" type="number" min="0" step="0.01" value="">
        </div>
        <div class="erp-field">
          <div class="erp-label">Fecha de la deuda</div>
          <input class="erp-input erp-input-lg" id="od-date" type="date" value="${today()}">
        </div>
      </div>
      <div class="erp-sheet-footer">
        <button class="erp-btn erp-btn-block" style="background:var(--emerald-600);border:none;color:white;font-weight:700;min-height:44px"
          onclick="confirmOpeningDebt('${c.id}')">Guardar</button>
      </div>
    </div>`;
}

function confirmOpeningDebt(customerId) {
  const amount = parseFloat(document.getElementById('od-amount')?.value) || 0;
  if (amount <= 0) { showToast('❌ Ingresa un monto válido'); return; }
  const date = document.getElementById('od-date')?.value || today();
  addOpeningDebt(customerId, amount, date);
  showToast('✅ Deuda previa registrada: ' + formatCurrency(amount));
  AppState.openingDebtModal = null;
  render();
}

// ─── CUSTOMER ACCOUNT STATEMENT (estado de cuenta) ─────
function setStatementFilter(f) {
  AppState.statementFilter = f;
  render();
}

function openStatementModal() {
  AppState.statementModal = { amount: null };
  render();
}

function closeStatementModal() {
  AppState.statementModal = null;
  render();
}

function setStatementAmount(v) {
  const el = document.getElementById('stmt-amount');
  if (el) el.value = v;
}

function confirmStatementPayment(customerId) {
  const amount = parseFloat(document.getElementById('stmt-amount')?.value) || 0;
  const balance = getCustomerBalance(customerId);
  if (amount <= 0) { showToast('❌ Ingresa un monto válido'); return; }
  if (amount > balance) { showToast('❌ El pago excede el saldo de ' + formatCurrency(balance)); return; }
  addPayment(customerId, amount, 'cash');
  showToast('✅ Abono registrado: ' + formatCurrency(amount));
  AppState.statementModal = null;
  render();
}

function renderStatementRow(mv) {
  const isCredit = mv.type === 'credit';
  const sign = isCredit ? '+' : '−';
  const color = isCredit ? 'var(--green-700)' : 'var(--emerald-600)';
  const badge = isCredit
    ? '<span class="erp-stmt-badge erp-stmt-badge-cargo">CARGO</span>'
    : '<span class="erp-stmt-badge erp-stmt-badge-abono">ABONO</span>';
  const folio = mv.ref || '—';
  const dateTxt = formatStmtDate(mv.date) + (mv.time ? ' ' + mv.time : '');
  return `
    <tr>
      <td class="erp-stmt-cell-date">${dateTxt}</td>
      <td class="erp-stmt-cell-folio">${folio}</td>
      <td>${badge}</td>
      <td class="erp-stmt-cell-desc">${mv.desc}</td>
      <td class="erp-stmt-cell-num" style="color:${color}">${sign}${formatCurrency(Math.abs(mv.monto))}</td>
      <td class="erp-stmt-cell-num">${formatCurrency(mv.saldo_actual)}</td>
      <td class="erp-stmt-cell-op">${mv.operator}</td>
    </tr>`;
}

function renderStatementModal(c) {
  const balance = getCustomerBalance(c.id);
  const canPay = balance > 0;
  const opts = [
    ['all', 'De Siempre'],
    ['sinceLastPayment', 'Desde último pago'],
    ['week', 'Última semana'],
    ['month', 'Último mes'],
    ['90d', 'Últimos 90 días'],
  ];
  return `
    <div class="erp-overlay" onclick="closeStatementModal()"></div>
    <div class="erp-sheet" onclick="event.stopPropagation()">
      <div class="erp-sheet-handle"></div>
      <div class="erp-sheet-title">💵 Registrar Pago</div>
      <div class="erp-sheet-body">
        <div class="erp-field">
          <div class="erp-label">Monto (efectivo)</div>
          <input class="erp-input erp-input-lg" id="stmt-amount" type="number" min="0" step="0.01"
            value="${canPay ? balance.toFixed(2) : '0.00'}" ${canPay ? '' : 'disabled'}>
        </div>
        ${canPay ? `
          <button class="erp-btn erp-btn-block" style="justify-content:flex-start;gap:10px;min-height:44px"
            onclick="setStatementAmount('${balance.toFixed(2)}')">
            <span>✅</span> Pagar Total (${formatCurrency(balance)})
          </button>
          <div class="erp-field" style="margin-top:12px">
            <div class="erp-label">Método</div>
            <div class="erp-option-card selected" style="border-color:var(--green-700);background:var(--green-100)">
              <div class="erp-option-card-icon">💵</div>
              <div class="erp-option-card-label">Pago en efectivo</div>
            </div>
          </div>
        ` : `
          <div style="padding:16px;text-align:center;color:var(--slate-400);font-size:12px">Sin saldo pendiente</div>
        `}
      </div>
      <div class="erp-sheet-footer">
        <button class="erp-btn erp-btn-block" style="background:var(--emerald-600);border:none;color:white;font-weight:700;min-height:44px"
          onclick="confirmStatementPayment('${c.id}')" ${canPay ? '' : 'disabled'}>Confirmar</button>
      </div>
    </div>`;
}

function renderCustomerStatement(customerId) {
  const c = getCustomer(customerId);
  if (!c) return { html: '<div class="erp-empty"><span class="erp-empty-icon">👤</span><div class="erp-empty-text">Cliente no encontrado</div></div>', init: () => {} };
  const balance = getCustomerBalance(c.id);
  const hasBalance = balance > 0;
  const limit = Number(c.creditLimit) || 0;
  const hasLimit = limit > 0;
  const st = getCustomerStatement(c.id, AppState.statementFilter);
  const shown = st.rows;
  const opts = [
    ['all', 'De Siempre'],
    ['sinceLastPayment', 'Desde último pago'],
    ['week', 'Última semana'],
    ['month', 'Último mes'],
    ['90d', 'Últimos 90 días'],
  ];
  const activeFilter = AppState.statementFilter;
  return {
    html: `
      <div class="erp-screen">
        <div style="background:var(--slate-900);color:white;padding:14px;flex-shrink:0">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
            <button class="erp-btn erp-btn-sm" onclick="App.goBack()" style="background:var(--slate-800);border:1px solid var(--slate-700);color:var(--slate-400)">← VOLVER</button>
            <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:var(--accent-600)">ESTADO DE CUENTA</div>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:flex-end">
            <div style="display:flex;align-items:center;gap:10px;min-width:0">
              <div class="erp-stmt-avatar">${(c.name || '?').trim()[0].toUpperCase()}</div>
              <div style="min-width:0">
                <div style="font-size:20px;font-weight:900;color:white;line-height:1.1">${c.name}</div>
                <div style="font-size:11px;color:var(--slate-400);margin-top:4px">${c.phone || 'Sin teléfono'}${c.direccion ? ' · 📍 ' + c.direccion : ''}</div>
              </div>
            </div>
            <div style="text-align:right;flex-shrink:0;margin-left:10px">
              <div style="font-size:24px;font-weight:900;color:${hasBalance ? 'var(--amber-400)' : 'var(--emerald-400)'};font-family:monospace">${formatCurrency(balance)}</div>
              <div style="font-size:10px;color:var(--slate-400);margin-top:2px;font-family:monospace">Límite: ${hasLimit ? formatCurrency(limit) : 'Sin límite'}</div>
            </div>
          </div>
        </div>

        <div class="erp-stmt-scroll">
          <div class="erp-stmt-toolbar">
            <button class="erp-stmt-btn erp-stmt-btn-primary" style="min-height:44px" onclick="openStatementModal()">💵 Registrar Pago</button>
            <button class="erp-stmt-btn" style="min-height:44px" onclick="printStatement('${c.id}')">🖨️ Imprimir</button>
          </div>
          <div class="erp-stmt-filter">
            <label>Movimientos:</label>
            <select class="erp-stmt-select" onchange="setStatementFilter(this.value)">
              ${opts.map(([v, l]) => `<option value="${v}" ${v === activeFilter ? 'selected' : ''}>${l}</option>`).join('')}
            </select>
          </div>

          <div class="erp-stmt-table-wrap">
            <table class="erp-stmt-table">
              <thead>
                <tr>
                  <th>Fecha/Hora</th>
                  <th>Folio</th>
                  <th>Movimiento</th>
                  <th>Descripción</th>
                  <th class="erp-stmt-cell-r">Monto</th>
                  <th class="erp-stmt-cell-r">Saldo actual</th>
                  <th class="erp-stmt-cell-r">Cajero</th>
                </tr>
              </thead>
              <tbody>
                ${shown.length === 0
                  ? '<tr><td class="erp-stmt-empty" colspan="7">No hay movimientos en el crédito del cliente seleccionado</td></tr>'
                  : shown.map(mv => renderStatementRow(mv)).join('')}
              </tbody>
            </table>
          </div>
        </div>

        ${AppState.statementModal ? renderStatementModal(c) : ''}
      </div>
    `,
    init: () => {}
  };
}

function printStatement(customerId) {
  const c = getCustomer(customerId);
  if (!c) return;
  const st = getCustomerStatement(c.id, 'all');
  const rowsHtml = st.rows.map(mv => {
    const isCredit = mv.type === 'credit';
    const sign = isCredit ? '+' : '−';
    return `
      <tr>
        <td>${formatDate(mv.date)}${mv.time ? ' ' + mv.time : ''}</td>
        <td>${mv.ref || '—'}</td>
        <td>${isCredit ? 'Cargo' : 'Abono'}</td>
        <td>${mv.desc}</td>
        <td>${sign}${formatCurrency(Math.abs(mv.monto))}</td>
        <td>${formatCurrency(mv.saldo_actual)}</td>
        <td>${mv.operator}</td>
      </tr>`;
  }).join('');
  const limit = Number(c.creditLimit) || 0;
  const printWin = window.open('', '_blank', 'width=720,height=900');
  if (!printWin) { showToast('⚠️ Permite ventanas emergentes para imprimir'); return; }
  printWin.document.write(`<!doctype html><html><head><title>Estado de Cuenta — ${c.name}</title>
<style>
body{font-family:'Segoe UI',Arial,sans-serif;margin:24px;color:#111}
h1{color:#006644;font-size:18px;margin:0 0 4px}
.meta{color:#555;font-size:12px;margin-bottom:16px}
table{width:100%;border-collapse:collapse;font-size:11px}
th,td{border:1px solid #E5E7EB;padding:6px 8px;text-align:left}
th{background:#F3F4F6;font-weight:700}
.num{text-align:right;font-family:monospace}
.total{margin-top:12px;font-size:12px;font-weight:700}
</style></head><body>
<h1>ESTADO DE CUENTA</h1>
<div class="meta">${c.name} · ${c.phone || ''} · Límite: ${limit > 0 ? formatCurrency(limit) : 'Sin límite'} · Impreso: ${formatDate(today())} ${new Date().toTimeString().slice(0,5)}</div>
<table>
<thead><tr><th>Fecha/Hora</th><th>Folio</th><th>Movimiento</th><th>Descripción</th><th>Monto</th><th>Saldo actual</th><th>Cajero</th></tr></thead>
<tbody>${rowsHtml}</tbody>
</table>
<div class="total">Saldo actual: ${formatCurrency(getCustomerBalance(c.id))}</div>
</body></html>`);
  printWin.document.close();
  printWin.focus();
  printWin.print();
}

// --- CUSTOMER INFO ---
function renderCustomerInfo(customerId) {
  const c = getCustomer(customerId);
  if (!c) return { html: '<div class="erp-empty"><span class="erp-empty-icon">👤</span><div class="erp-empty-text">Cliente no encontrado</div></div>', init: () => {} };
  const isAdmin = Auth.isAdmin();
  const ro = isAdmin ? '' : ' readonly';
  return {
    html: `
      <div class="erp-screen">
        <div style="display:flex;align-items:center;gap:8px;padding:10px 10px 4px">
          <button class="erp-btn erp-btn-sm" onclick="App.goBack()">← VOLVER</button>
          <div style="flex:1;min-width:0">
            <div style="font-size:15px;font-weight:700;color:var(--slate-900)">${c.name}</div>
            <div style="font-size:10px;color:var(--slate-400);font-family:monospace">${c.phone}</div>
          </div>
        </div>
        <div style="flex:1;overflow-y:auto;padding:8px 10px 80px">
          <div style="background:white;border:1px solid var(--slate-200);padding:12px">
            <div style="font-size:11px;font-weight:700;font-family:monospace;text-transform:uppercase;color:var(--slate-500);margin-bottom:8px">Información</div>
            <div class="erp-field">
              <div class="erp-label">Cliente</div>
              <input class="erp-input" id="ci-name" value="${escHtml(c.name)}"${ro}>
            </div>
            <div class="erp-field">
              <div class="erp-label">Contacto</div>
              <input class="erp-input" id="ci-contact" value="${escHtml(c.contact || '')}" placeholder="Nombre del contacto"${ro}>
            </div>
            <div class="erp-field">
              <div class="erp-label">Teléfono</div>
              <input class="erp-input" id="ci-phone" value="${escHtml(c.phone)}" placeholder="555-0000"${ro}>
            </div>
            <div class="erp-field">
              <div class="erp-label">Dirección</div>
              <input class="erp-input" id="ci-direccion" value="${escHtml(c.direccion || '')}" placeholder="Calle y número"${ro}>
            </div>
            <div class="erp-data-row" style="margin-top:4px"><span class="erp-data-label">Ruta</span><span class="erp-data-value">${c.route}</span></div>

            <div style="border-top:1px solid var(--slate-200);margin-top:8px;padding-top:12px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <span style="font-size:11px;font-weight:700;font-family:monospace;text-transform:uppercase;color:var(--slate-500)">🔄 Recurrencia de pago</span>
                ${isAdmin ? `<button class="erp-btn erp-btn-sm" onclick="setupCustomerRecurrence('${c.id}')">Configurar</button>` : ''}
              </div>
              <div style="font-size:12px;color:var(--slate-500);font-family:monospace;margin-top:4px">${recurrenceSummary(c.recurrence)}</div>
            </div>

            <div class="erp-field" style="margin-top:12px">
              <div class="erp-label">Precio default ($/kg)</div>
              <input class="erp-input" id="ci-default-price" type="number" min="0" step="0.5" value="${c.defaultPrice || ''}" placeholder="Usar precio del producto"${ro}>
            </div>

            <div class="erp-field">
              <div class="erp-label">Límite de crédito ($)</div>
              <input class="erp-input" id="ci-credit-limit" type="number" min="0" step="100" value="${c.creditLimit || ''}" placeholder="0 = solo contado"${ro}>
            </div>
          </div>
          <div style="display:flex;gap:8px;margin-top:12px">
            <button class="erp-btn erp-btn-secondary" style="flex:1" onclick="App.goBack()">Volver</button>
            ${isAdmin ? `<button class="erp-btn erp-btn-primary" style="flex:2" onclick="saveCustomerInfo('${c.id}')">💾 Guardar cambios</button>` : ''}
          </div>
        </div>
      </div>
    `,
    init: () => {}
  };
}

function saveCustomerInfo(customerId) {
  const name = document.getElementById('ci-name').value.trim();
  if (!name) { showToast('El nombre es obligatorio'); return; }
  const defaultPrice = parseFloat(document.getElementById('ci-default-price').value) || 0;
  const creditLimit = parseFloat(document.getElementById('ci-credit-limit').value) || 0;
  updateCustomer(customerId, {
    name,
    contact: document.getElementById('ci-contact').value.trim(),
    phone: document.getElementById('ci-phone').value.trim(),
    direccion: document.getElementById('ci-direccion').value.trim(),
    defaultPrice,
    creditLimit,
  });
  showToast('✓ Cliente actualizado');
  render();
}

function setupCustomerRecurrence(customerId) {
  const c = getCustomer(customerId);
  if (!c) return;
  showRecurrenceSheet({ current: c.recurrence || null }, (result) => {
    if (result) {
      updateCustomer(customerId, {
        recurrence: result.preset === 'none' ? null : { ...result, anchor: (c.recurrence && c.recurrence.anchor) || today() },
      });
      showToast(result.preset === 'none' ? '✓ Recurrencia eliminada' : '✓ Recurrencia guardada');
      render();
    }
  });
}

function recurrenceSummary(r) {
  if (!r || r.preset === 'none') return 'No configurada';
  const days = r.daysOfWeek && r.daysOfWeek.length ? r.daysOfWeek.map(d => ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'][d]).join(', ') : '';
  const freq = `Cada ${r.frequencyValue} ${r.frequencyUnit === 'days' ? 'día(s)' : r.frequencyUnit === 'weeks' ? 'semana(s)' : r.frequencyUnit === 'months' ? 'mes(es)' : 'año(s)'}`;
  const when = days ? ` los ${days}` : '';
  const ends = r.endType === 'date' ? ` hasta ${formatDate(r.endDate)}` : r.endType === 'occurrences' ? `, ${r.endOccurrences} vez/ces` : '';
  return `${freq}${when}${ends}`;
}

// ─── ROUTES ───
function renderRoutes() {
  return {
    html: `
      <div class="erp-screen">
        <div style="display:flex;align-items:center;gap:8px;padding:10px 10px 4px">
          <button class="erp-btn erp-btn-sm" onclick="App.goBack()">← VOLVER</button>
          <div>
            <div style="font-size:15px;font-weight:700;color:var(--slate-900)">Rutas</div>
            <div style="font-size:10px;color:var(--slate-400);font-family:monospace">Programación e historial</div>
          </div>
        </div>
        <div class="erp-empty"><span class="erp-empty-icon">🗺️</span><div class="erp-empty-text">Historial de rutas disponible próximamente</div></div>
      </div>
    `,
    init: () => {}
  };
}

// ─── REPORTS ───
function emptySettlement() {
  return {
    startingInventory: 0, totalDelivered: 0, totalExtraSold: 0, totalStaleReturned: 0,
    totalRecompra: 0, totalRecompraCollected: 0, totalCredited: 0, endingInventory: 0, totalCollected: 0,
    totalCard: 0, totalCash: 0, recompraValue: 0, streetTotal: 0, devValue: 0, brutoValue: 0,
    routeName: '—', driverName: '—', isLive: false, stops: []
  };
}

function reportPeriodDisplay(period, from, to) {
  if (period === 'today') return formatDate(today()).toUpperCase();
  if (period === 'yesterday') return formatDate(shiftDays(today(), -1)).toUpperCase();
  if (period === 'week') return 'SEMANA DEL ' + formatDateShort(from) + ' AL ' + formatDateShort(to);
  if (period === 'month') return 'MES DE ' + (from ? from.slice(0, 7) : today().slice(0, 7));
  if (period === 'year') return 'AÑO ' + (from ? from.slice(0, 4) : today().slice(0, 4));
  if (period === 'custom') return formatDateShort(from) + ' – ' + formatDateShort(to);
  return formatDate(today()).toUpperCase();
}

function renderReports() {
  try {
    const isAdmin = Auth.isAdmin();
    if (!isAdmin) AppState.reportPeriod = 'today';
    const tab = AppState.reportTab || 'settlement';
    const data = getTodaySettlement() || emptySettlement();
    const period = AppState.reportPeriod || 'today';
    const isToday = period === 'today' || !period;
    const aggData = getAggregatedSettlementForPeriod(period, AppState.reportFrom, AppState.reportTo);
    const rng = settlementRange(period, AppState.reportFrom, AppState.reportTo);
    const p1 = getProductPrice('P1');
    const hP1 = p1 / 2;
    const dateDisplay = reportPeriodDisplay(period, rng.from, rng.to);
    const route = AppState.route;
    const driver = AppState.driver;
    const settlementData = isToday ? data : (aggData || emptySettlement());
    const PERIODS = isAdmin ? [
      { k: 'today', lbl: 'Hoy' },
      { k: 'yesterday', lbl: 'Ayer' },
      { k: 'week', lbl: 'Semana' },
      { k: 'month', lbl: 'Mes' },
      { k: 'year', lbl: 'Año' },
      { k: 'custom', lbl: 'Rango' },
    ] : [{ k: 'today', lbl: 'Hoy' }];

    const live = data.isLive && isToday;
    const chipLabel = (() => {
      const f = d => d ? formatDateShort(d).toUpperCase() : '';
      if (period === 'yesterday') return 'Ayer: ' + f(rng.from);
      if (period === 'week') return f(rng.from) + ' – ' + f(rng.to);
      if (period === 'month') {
        const d = new Date((rng.from || today()) + 'T12:00:00');
        return 'Mes: ' + d.toLocaleDateString('es-MX', { month: 'short', year: 'numeric' }).toUpperCase();
      }
      if (period === 'year') return 'Año: ' + (rng.from ? rng.from.slice(0, 4) : today().slice(0, 4));
      if (period === 'custom') return f(rng.from) + ' – ' + f(rng.to);
      return 'Hoy: ' + f(rng.from);
    })();

    return {
      html: `
        <div class="erp-screen">
          <!-- TOP APP BAR -->
          <div style="display:flex;align-items:center;gap:8px;padding:10px 10px 4px;flex-shrink:0">
            <button class="erp-btn erp-btn-sm" onclick="App.goBack()">← VOLVER</button>
            <div style="flex:1;min-width:0">
              <div style="font-size:15px;font-weight:700;color:var(--slate-900)">Reportes</div>
              <div style="font-size:10px;color:var(--slate-400);font-family:monospace">El Comal</div>
            </div>
            <span class="erp-date-chip">📅 ${chipLabel}</span>
            ${live ? '<span class="erp-chip erp-chip-green">● EN VIVO</span>' : '<span class="erp-chip">HISTÓRICO</span>'}
          </div>

          <!-- MODULE TABS -->
          <div class="erp-report-tab-bar">
            <button class="erp-report-tab ${tab === 'settlement' ? 'active' : ''}" data-tab="settlement">📋 Liquidación</button>
            <button class="erp-report-tab ${tab === 'ventas' ? 'active' : ''}" data-tab="ventas">📊 Ventas</button>
            <button class="erp-report-tab ${tab === 'inventory' ? 'active' : ''}" data-tab="inventory">📦 Inventario</button>
          </div>

          <!-- PERIOD TABS -->
          ${isAdmin ? `
          <div class="erp-report-tab-bar">
            ${PERIODS.map(p => `
              <button class="erp-report-tab ${period === p.k ? 'active' : ''}" data-period="${p.k}">${p.lbl}</button>
            `).join('')}
          </div>
          ` : ''}

          ${isAdmin && period === 'custom' ? `
          <div style="display:flex;gap:8px;align-items:flex-end;padding:8px 10px;background:white;border-bottom:1px solid var(--slate-200);flex-shrink:0">
            <div class="erp-field" style="flex:1;margin:0">
              <div class="erp-label">Desde</div>
              <input type="date" class="erp-input" id="report-from" value="${AppState.reportFrom || ''}" style="width:100%">
            </div>
            <div class="erp-field" style="flex:1;margin:0">
              <div class="erp-label">Hasta</div>
              <input type="date" class="erp-input" id="report-to" value="${AppState.reportTo || ''}" style="width:100%">
            </div>
            <button class="erp-btn erp-btn-sm erp-btn-primary" onclick="applyReportRange()" style="white-space:nowrap">Aplicar</button>
          </div>` : ''}

          <div style="flex:1;overflow-y:auto;padding:10px 10px 80px">
            ${tab === 'settlement' ? _renderSettlementTab(settlementData, p1, hP1, dateDisplay, isToday) : ''}
            ${tab === 'ventas' ? _renderVentasTab(aggData, route, driver, period, dateDisplay, p1, hP1) : ''}
            ${tab === 'inventory' ? _renderInventoryTab(aggData, period) : ''}
          </div>
        </div>
    `,
    init: () => {
      document.querySelectorAll('.erp-report-tab[data-tab]').forEach(btn => {
        btn.addEventListener('click', () => {
          AppState.reportTab = btn.dataset.tab;
          render();
        });
      });
      document.querySelectorAll('.erp-report-tab[data-period]').forEach(btn => {
        btn.addEventListener('click', () => {
          AppState.reportPeriod = btn.dataset.period;
          render();
        });
      });
    }
  };
} catch (e) {
  console.error('renderReports error:', e);
  return { html: `<div class="erp-screen" style="padding:20px"><div class="erp-empty"><span class="erp-empty-icon">⚠️</span><div class="erp-empty-text">Error: ${e.message}</div><button class="erp-btn erp-btn-secondary" style="margin-top:12px" onclick="App.goBack()">← VOLVER</button></div></div>`, init: () => {} };
}
}

function applyReportRange() {
  const from = document.getElementById('report-from').value;
  const to = document.getElementById('report-to').value;
  if (!from || !to) { showToast('Selecciona ambas fechas'); return; }
  AppState.reportPeriod = 'custom';
  AppState.reportFrom = from;
  AppState.reportTo = to;
  render();
}

function reportEmpty(icon, title, desc, btnLabel, btnAction) {
  return `
    <div class="erp-empty">
      <span class="erp-empty-icon">${icon}</span>
      <div class="erp-empty-text" style="font-size:13px;font-weight:700;color:var(--slate-700)">${title}</div>
      <div style="font-size:11px;color:var(--slate-400);font-family:monospace;margin-top:4px;max-width:280px;margin-left:auto;margin-right:auto;line-height:1.4">${desc}</div>
      ${btnLabel && btnAction ? `<button class="erp-btn erp-btn-primary" style="margin-top:12px" onclick="${btnAction}">${btnLabel}</button>` : ''}
    </div>`;
}

// ERP posting chip for a settlement (admin visibility only).
function erpPostedChip(data, isToday) {
  if (isToday) return ''; // live day not closed yet
  try {
    if (typeof ErpOutbox === 'undefined' || !Auth.isAdmin()) return '';
    const ev = ErpOutbox.settlementEvent(data.date, data.routeName);
    if (!ev) return '';
    if (ev.status === 'sent') return ` <span class="erp-chip erp-chip-green" style="font-size:8px">ERP ✓ ${escHtml(ev.erpRef || '')}</span>`;
    if (ev.status === 'failed') return ' <span class="erp-chip erp-chip-amber" style="font-size:8px">ERP falló</span>';
    return ' <span class="erp-chip" style="font-size:8px">ERP en cola</span>';
  } catch (e) { return ''; }
}

function _renderSettlementTab(data, p1, hP1, dateDisplay, isToday) {
  const hasData = data.totalDelivered > 0 || data.totalRecompra > 0;  if (!hasData) {
    if (isToday) {
      return reportEmpty('📋', 'No hay liquidaciones hoy', 'Completa las paradas de tu ruta para ver la liquidación del día aquí.', 'Ver rutas pendientes', "App.navigate('route')");
    }
    return reportEmpty('📋', 'Sin liquidación en el período', 'No hay paradas completadas entre estas fechas.', null, null);
  }

  const rn = data.routeName || AppState.routeName || '—';
  const stops = data.stops || [];
  const completedStops = stops.filter(s => s.status === 'completed');

  // Ledger per-stop: only for today's live data or if snapshot has stops
  const showLedger = completedStops.length > 0;

  // Calculate per-stop values for ledger
  const ledgers = completedStops.map(st => {
    const price = getStopPrice(st) || p1;
    const dKg = (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0;
    const devKg = st.devolucionKg || 0;
    const recKg = st.recompraKg || 0;
    const cred = st.creditAmount || 0;
    const bruto = dKg * price;
    const dev$ = devKg * price;
    const rec$ = recKg * RECOMPRA_PRICE;
    const efvo = bruto - dev$ - rec$ - cred;
    return { id: st.stopId, customer: st.customerName, bruto, dev$, rec$, cred, efvo };
  });

  const totalBruto = ledgers.reduce((s, r) => s + r.bruto, 0);
  const totalDev = ledgers.reduce((s, r) => s + r.dev$, 0);
  const totalRec = ledgers.reduce((s, r) => s + r.rec$, 0);
  const totalCred = ledgers.reduce((s, r) => s + r.cred, 0);
  const totalEfvo = ledgers.reduce((s, r) => s + r.efvo, 0);

  const netRevenue = data.brutoValue - data.devValue;
  const cashBank = data.totalCash;
  const isAggregated = data.routeName === 'Todas las rutas';
  const cxcToday = isAggregated ? 0 : getPaymentsTotalForDate(data.date || today());

  return `
    <div style="display:flex;justify-content:space-between;align-items:baseline;padding:0 2px 8px">
      <div style="font-size:15px;font-weight:700;color:var(--slate-900)">📋 Liquidación del día
        ${erpPostedChip(data, isToday)}</div>
      <div style="font-size:9px;color:var(--slate-400);font-family:monospace">${dateDisplay} · ${rn}</div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
      <div class="erp-stat-card">
        <div style="font-size:8px;font-weight:700;text-transform:uppercase;color:var(--slate-400);margin-bottom:4px">Revenue Bruto</div>
        <div style="font-size:18px;font-weight:700;color:var(--emerald-600)">${formatCurrency(data.brutoValue)}</div>
        <div style="font-size:7px;color:var(--slate-400);margin-top:2px">Ventas + Recompra + Calle</div>
      </div>
      <div class="erp-stat-card">
        <div style="font-size:8px;font-weight:700;text-transform:uppercase;color:var(--slate-400);margin-bottom:4px">Ingreso p/ Recompras</div>
        <div style="font-size:18px;font-weight:700;color:var(--amber-400)">${formatCurrency(data.recompraValue)}</div>
        <div style="font-size:7px;color:var(--slate-400);margin-top:2px">${data.totalRecompra.toFixed(2)} kg</div>
      </div>
      <div class="erp-stat-card">
        <div style="font-size:8px;font-weight:700;text-transform:uppercase;color:var(--slate-400);margin-bottom:4px">Nuevo Crédito (CxC)</div>
        <div style="font-size:18px;font-weight:700;color:#1E40AF">${formatCurrency(data.totalCredited)}</div>
        <div style="font-size:7px;color:var(--slate-400);margin-top:2px">Cuentas por cobrar</div>
      </div>
      <div class="erp-stat-card" style="background:var(--slate-900);border-color:var(--slate-800);color:white">
        <div style="font-size:8px;font-weight:700;text-transform:uppercase;color:var(--slate-400);margin-bottom:4px">Total Entrado a Caja</div>
        <div style="font-size:18px;font-weight:700">${formatCurrency(cashBank + data.recompraValue)}</div>
        <div style="font-size:7px;color:var(--slate-400);margin-top:2px">Efectivo + Recompra</div>
      </div>
    </div>

    ${showLedger ? `
    <div class="erp-card">
      <div style="background:var(--slate-50);border-bottom:1px solid var(--slate-200);padding:8px 10px;font-size:9px;font-weight:700;text-transform:uppercase;color:var(--slate-600);letter-spacing:0.3px">Detalle por parada</div>
      <div style="overflow-x:auto">
      <table style="width:100%;border-collapse:collapse;font-size:9px;min-width:500px">
        <thead>
          <tr style="background:var(--slate-100);border-bottom:1px solid var(--slate-200);font-size:7px;text-transform:uppercase;color:var(--slate-500)">
            <th style="padding:4px 4px;text-align:left">ID/Hora</th>
            <th style="padding:4px 4px;text-align:left">Cliente / Ruta</th>
            <th style="padding:4px 4px;text-align:right">Vta Bruta</th>
            <th style="padding:4px 4px;text-align:right">Devolución</th>
            <th style="padding:4px 4px;text-align:right">Recompra</th>
            <th style="padding:4px 4px;text-align:right">Crédito</th>
            <th style="padding:4px 4px;text-align:right">Efectivo</th>
            <th style="padding:4px 4px;text-align:center">Estado</th>
          </tr>
        </thead>
        <tbody style="border-bottom:2px solid var(--slate-200)">
          ${ledgers.map(r => `
            <tr style="border-bottom:1px solid var(--slate-100)">
              <td style="padding:4px 4px;font-family:monospace;color:var(--slate-400);font-size:8px">${r.id}</td>
              <td style="padding:4px 4px;font-weight:600;color:var(--slate-800);white-space:nowrap">${r.customer}</td>
              <td style="padding:4px 4px;text-align:right;font-weight:700;color:var(--emerald-600)">${formatCurrency(r.bruto)}</td>
              <td style="padding:4px 4px;text-align:right;color:var(--red-600)">${r.dev$ > 0 ? '-' + formatCurrency(r.dev$) : '—'}</td>
              <td style="padding:4px 4px;text-align:right;color:var(--amber-500)">${r.rec$ > 0 ? formatCurrency(r.rec$) : '—'}</td>
              <td style="padding:4px 4px;text-align:right;color:#1E40AF">${r.cred > 0 ? formatCurrency(r.cred) : '—'}</td>
              <td style="padding:4px 4px;text-align:right;font-weight:700;color:var(--slate-900)">${formatCurrency(r.efvo)}</td>
              <td style="padding:4px 4px;text-align:center;font-size:8px">✅</td>
            </tr>
          `).join('')}
        </tbody>
        <tfoot>
          <tr style="font-weight:700;border-top:2px solid var(--slate-300);background:var(--slate-50)">
            <td colspan="2" style="padding:4px 4px;font-size:9px;color:var(--slate-700)">Total</td>
            <td style="padding:4px 4px;text-align:right;font-size:9px;color:var(--emerald-600)">${formatCurrency(totalBruto)}</td>
            <td style="padding:4px 4px;text-align:right;font-size:9px;color:var(--red-600)">${totalDev > 0 ? '-' + formatCurrency(totalDev) : '—'}</td>
            <td style="padding:4px 4px;text-align:right;font-size:9px;color:var(--amber-500)">${totalRec > 0 ? formatCurrency(totalRec) : '—'}</td>
            <td style="padding:4px 4px;text-align:right;font-size:9px;color:#1E40AF">${totalCred > 0 ? formatCurrency(totalCred) : '—'}</td>
            <td style="padding:4px 4px;text-align:right;font-size:9px;color:var(--slate-900)">${formatCurrency(totalEfvo)}</td>
            <td></td>
          </tr>
        </tfoot>
      </table>
      </div>
    </div>
    ` : ''}

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
      <div class="erp-stat-card">
        <div style="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--slate-500);margin-bottom:8px">Composición de Ingresos</div>
        <div class="erp-data-row"><span class="erp-data-label">Ventas Directas (Contado + Crédito)</span><span class="erp-data-value" style="color:var(--emerald-600)">${formatCurrency(data.totalDelivered * p1)}</span></div>
        ${data.streetTotal > 0 ? `<div class="erp-data-row"><span class="erp-data-label">+ Ventas Calle (Mostrador)</span><span class="erp-data-value" style="color:var(--emerald-600)">${formatCurrency(data.streetTotal)}</span></div>` : ''}
        <div class="erp-data-row"><span class="erp-data-label">+ Ingresos por Recompra de Merma</span><span class="erp-data-value" style="color:var(--amber-500)">${formatCurrency(data.recompraValue)}</span></div>
        <div class="erp-data-row"><span class="erp-data-label">− Devoluciones / Mermas no Recompradas</span><span class="erp-data-value" style="color:var(--red-600)">−${formatCurrency(data.devValue)}</span></div>
        <div style="padding:8px 0;display:flex;justify-content:space-between;font-weight:700;font-size:12px;border-top:2px solid var(--slate-300);margin-top:4px;color:var(--slate-900)">
          <span>Revenue Neto del Día</span>
          <span>${formatCurrency(netRevenue)}</span>
        </div>
      </div>

      <div class="erp-stat-card">
        <div style="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--slate-500);margin-bottom:8px">Caja y Bancos</div>
        <div class="erp-data-row"><span class="erp-data-label">Cobrado por Ventas de Contado Hoy</span><span class="erp-data-value" style="color:var(--emerald-600)">${formatCurrency(cashBank - data.recompraValue)}</span></div>
        <div class="erp-data-row"><span class="erp-data-label">+ Cobrado en Efectivo por Recompras</span><span class="erp-data-value" style="color:var(--amber-500)">${formatCurrency(data.recompraValue)}</span></div>
        <div class="erp-data-row"><span class="erp-data-label">+ Cobranza CxC (Ventas Viejas)</span><span class="erp-data-value" style="color:var(--slate-400)">${cxcToday > 0 ? formatCurrency(cxcToday) : '$0.00'}</span></div>
        <div style="padding:8px 0;display:flex;justify-content:space-between;font-weight:700;font-size:12px;border-top:2px solid var(--slate-300);margin-top:4px;color:var(--slate-900)">
          <span>Total a Entregar por Choferes</span>
          <span style="color:var(--emerald-600)">${formatCurrency(cashBank)}</span>
        </div>
        <div style="font-size:8px;color:var(--slate-400);margin-top:4px;padding-top:4px;border-top:1px solid var(--slate-200);text-align:center">
          Efectivo cobrado: ${formatCurrency(data.totalCash)}
        </div>
      </div>
    </div>

  `;
}

function _renderVentasTab(data, route, driver, period, dateDisplay, p1, hP1) {
  if (!data || (!data.totalDelivered && !data.totalRecompra)) {
    return reportEmpty('📊', 'Sin datos de ventas', 'No hay ventas registradas en este período.', null, null);
  }

  const netSales = (data.totalDelivered * p1) + data.streetTotal - data.devValue + data.recompraValue;
  const collected = data.totalCash;
  const liquidityPct = netSales > 0 ? (collected / netSales * 100).toFixed(1) : '0.0';
  const totalKg = data.totalDelivered + data.totalExtraSold;
  const periodLabel = period === 'today' ? 'DEL DÍA' : period === 'yesterday' ? 'DE AYER' : period === 'week' ? 'DE LA SEMANA' : period === 'month' ? 'DEL MES' : period === 'year' ? 'DEL AÑO' : 'DEL RANGO';
  const stops = data.stops || [];
  const completedStops = stops.filter(s => s.status === 'completed');
  const routeRows = completedStops.length > 0 ? completedStops.map(st => {
    const price = getStopPrice(st) || p1;
    const kg = (st.deliveredKg !== undefined ? st.deliveredKg : st.preOrderKg) || 0;
    const dev = st.devolucionKg || 0;
    const rec = st.recompraKg || 0;
    const total$ = kg * price - dev * price + rec * RECOMPRA_PRICE;
    return { customer: st.customerName, kg, dev, rec, total$ };
  }) : [];

  return `
    <div style="display:flex;justify-content:space-between;align-items:baseline;padding:0 2px 8px">
      <div style="font-size:9px;font-weight:700;color:var(--slate-500);text-transform:uppercase;letter-spacing:0.5px;font-family:monospace">
        VENTAS ${periodLabel} · ${dateDisplay}
      </div>
      <div style="font-size:9px;font-weight:700;color:var(--slate-700);background:var(--slate-200);padding:3px 8px;border:1px solid var(--slate-300);font-family:monospace">
        VOLUMEN: ${totalKg.toFixed(2)} KG
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
      <div class="erp-stat-card">
        <div style="font-size:8px;font-weight:700;text-transform:uppercase;color:var(--slate-400);margin-bottom:4px">Efectivo</div>
        <div style="font-size:17px;font-weight:700;color:var(--emerald-600)">${formatCurrency(data.totalCash)}</div>
        <div style="font-size:7px;color:var(--slate-400);margin-top:2px">En caja física</div>
      </div>
      <div class="erp-stat-card">
        <div style="font-size:8px;font-weight:700;text-transform:uppercase;color:var(--slate-400);margin-bottom:4px">Venta en Ruta</div>
        <div style="font-size:17px;font-weight:700;color:var(--slate-800)">${formatCurrency(data.streetTotal)}</div>
        <div style="font-size:7px;color:var(--slate-400);margin-top:2px">Sin pedido</div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
      <div class="erp-stat-card">
        <div style="display:flex;justify-content:space-between;align-items:start">
          <div style="font-size:8px;font-weight:700;text-transform:uppercase;color:var(--slate-400)">Nuevo Crédito</div>
          <span style="font-size:7px;font-weight:700;font-family:monospace;background:#FEE2E2;color:#B91C1C;padding:1px 4px;border:1px solid #FCA5A5;border-radius:4px">DEUDA GENERADA</span>
        </div>
        <div style="font-size:17px;font-weight:700;color:#1E40AF">${formatCurrency(data.totalCredited)}</div>
        <div style="font-size:7px;color:var(--slate-400);margin-top:2px">Cuentas por cobrar del día</div>
      </div>
      <div class="erp-stat-card">
        <div style="display:flex;justify-content:space-between;align-items:start">
          <div style="font-size:8px;font-weight:700;text-transform:uppercase;color:var(--slate-400)">Devoluciones</div>
          <span style="font-size:7px;font-weight:700;font-family:monospace;background:var(--slate-100);color:var(--slate-600);padding:1px 4px;border:1px solid var(--slate-300);border-radius:4px">${data.totalStaleReturned.toFixed(2)} KG</span>
        </div>
        <div style="font-size:17px;font-weight:700;color:var(--red-600)">−${formatCurrency(data.devValue)}</div>
        <div style="font-size:7px;color:var(--slate-400);margin-top:2px">Producto devuelto</div>
      </div>
    </div>

    <div class="erp-card" style="background:var(--slate-900);border-color:var(--slate-800);padding:14px;display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:6px">
      <div>
        <div style="font-size:8px;color:var(--slate-400);text-transform:uppercase;font-weight:700">Total Ventas Netas</div>
        <div style="font-size:20px;font-weight:700;color:white">${formatCurrency(netSales)}</div>
      </div>
      <div style="text-align:right;border-top:1px solid var(--slate-700);padding-top:5px;width:100%">
        <div style="font-size:8px;color:var(--emerald-400);text-transform:uppercase;font-weight:700">Cobrado en Caja / Bancos</div>
        <div style="font-size:15px;font-weight:700;color:var(--emerald-400)">${formatCurrency(collected)}</div>
        <div style="font-size:7px;color:var(--slate-400)">(${liquidityPct}% de liquidez inmediata)</div>
      </div>
    </div>

    ${routeRows.length > 0 ? `
    <div class="erp-card">
      <div style="background:var(--slate-50);border-bottom:1px solid var(--slate-200);padding:8px 10px;display:flex;justify-content:space-between;align-items:center">
        <div style="font-size:9px;font-weight:700;text-transform:uppercase;color:var(--slate-700);letter-spacing:0.3px">Desglose por Parada</div>
        <div style="font-size:8px;color:var(--slate-500);font-family:monospace">${(route && route.name) || data.routeName || '—'} · ${driver.name}</div>
      </div>
      <div style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;font-size:10px">
          <thead>
            <tr style="background:var(--slate-100);border-bottom:1px solid var(--slate-200);font-size:8px;text-transform:uppercase;color:var(--slate-500)">
              <th style="padding:5px 6px;text-align:left">Cliente</th>
              <th style="padding:5px 6px;text-align:right">Kg</th>
              <th style="padding:5px 6px;text-align:right">Dev</th>
              <th style="padding:5px 6px;text-align:right">Rec</th>
              <th style="padding:5px 6px;text-align:right">Total $</th>
            </tr>
          </thead>
          <tbody style="border-bottom:2px solid var(--slate-200)">
            ${routeRows.map(r => `
              <tr style="border-bottom:1px solid var(--slate-100)">
                <td style="padding:5px 6px;font-weight:600;color:var(--slate-800)">${r.customer}</td>
                <td style="padding:5px 6px;text-align:right;font-weight:700;color:var(--emerald-600)">${r.kg.toFixed(2)}</td>
                <td style="padding:5px 6px;text-align:right;color:var(--amber-500)">${r.dev > 0 ? r.dev.toFixed(2) : '—'}</td>
                <td style="padding:5px 6px;text-align:right;color:var(--emerald-600)">${r.rec > 0 ? r.rec.toFixed(2) : '—'}</td>
                <td style="padding:5px 6px;text-align:right;font-weight:700;color:var(--slate-900)">${formatCurrency(r.total$)}</td>
              </tr>
            `).join('')}
          </tbody>
          <tfoot>
            <tr style="font-weight:700;border-top:2px solid var(--slate-300)">
              <td style="padding:5px 6px;font-size:9px;color:var(--slate-700)">Total</td>
              <td style="padding:5px 6px;text-align:right;font-size:9px;color:var(--emerald-600)">${routeRows.reduce((s,r)=>s+r.kg,0).toFixed(2)}</td>
              <td style="padding:5px 6px;text-align:right;font-size:9px;color:var(--amber-500)">${routeRows.reduce((s,r)=>s+r.dev,0).toFixed(2)}</td>
              <td style="padding:5px 6px;text-align:right;font-size:9px;color:var(--emerald-600)">${routeRows.reduce((s,r)=>s+r.rec,0).toFixed(2)}</td>
              <td style="padding:5px 6px;text-align:right;font-size:9px;color:var(--slate-900)">${formatCurrency(routeRows.reduce((s,r)=>s+r.total$,0))}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
    ` : ''}

    ${stops.filter(s => s.devolucionKg > 0).length > 0 ? `
    <div class="erp-card" style="padding:10px">
      <div style="font-size:9px;font-weight:700;font-family:monospace;text-transform:uppercase;color:var(--slate-500);margin-bottom:6px">Devoluciones por cliente</div>
      ${stops.filter(s => s.devolucionKg > 0).map(s => {
        const rate = s.preOrderKg > 0 ? (s.devolucionKg / s.preOrderKg * 100).toFixed(1) : 0;
        const rc = rate > 10 ? 'var(--red-600)' : rate > 5 ? 'var(--amber-400)' : 'var(--emerald-600)';
        return `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid var(--slate-100);font-size:10px;font-family:monospace">
            <div>
              <div style="font-weight:600;color:var(--slate-800)">${s.customerName}</div>
              <div style="font-size:8px;color:var(--slate-400)">${s.preOrderKg}kg pedidos · ${s.devolucionKg}kg devueltos</div>
            </div>
            <span style="font-weight:700;color:${rc}">${rate}%</span>
          </div>
        `;
      }).join('')}
    </div>
    ` : ''}

    ${(data.isLive && AppState.collections.length > 0) ? `
    <div class="erp-card" style="padding:10px">
      <div style="font-size:9px;font-weight:700;font-family:monospace;text-transform:uppercase;color:var(--slate-500);margin-bottom:6px">Cobros del día</div>
      ${AppState.collections.map(t => {
        const c = getCustomer(t.customerId);
        const methods = t.paymentType ? (t.paymentType === 'card' ? 'Tarjeta' : 'Efectivo') : 'Efectivo';
        const total$ = t.paymentType ? formatCurrency(t.amount) : formatCurrency(t.cash || 0);
        return `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid var(--slate-100);font-size:10px;font-family:monospace">
            <div>
              <div style="font-weight:600;color:var(--slate-800)">${c ? c.name : 'Desconocido'}</div>
              <div style="font-size:8px;color:var(--slate-400)">
                ${new Date(t.timestamp).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' })} · ${methods}
              </div>
            </div>
            <span style="font-weight:700;color:var(--emerald-600)">${total$}</span>
          </div>
        `;
      }).join('')}
    </div>
    ` : ''}
  `;
}

function _renderInventoryTab(data, period) {
  if (!data || (!data.startingInventory && !data.totalDelivered)) {
    return reportEmpty('📦', 'Sin movimiento de inventario', 'No hay datos de inventario para este período.', null, null);
  }

  const variation = data.startingInventory - data.totalDelivered - data.totalExtraSold + data.totalStaleReturned + data.totalRecompra - data.endingInventory;
  const periodLabel = period === 'today' ? 'DEL DÍA' : period === 'yesterday' ? 'DE AYER' : period === 'week' ? 'DE LA SEMANA' : period === 'month' ? 'DEL MES' : period === 'year' ? 'DEL AÑO' : 'DEL RANGO';
  const rn = data.routeName || '—';

  return `
    <div style="display:flex;justify-content:space-between;align-items:baseline;padding:0 2px 8px">
      <div style="font-size:9px;font-weight:700;color:var(--slate-500);text-transform:uppercase;letter-spacing:0.5px;font-family:monospace">
        INVENTARIO ${periodLabel} · ${rn}
      </div>
      <div style="font-size:9px;font-weight:700;color:var(--slate-700);background:var(--slate-200);padding:3px 8px;border:1px solid var(--slate-300);font-family:monospace">
        ${data.stopsCount || 0} PARADAS
      </div>
    </div>

    <div class="erp-card" style="padding:12px">
      <div style="font-size:11px;font-weight:700;font-family:monospace;text-transform:uppercase;color:var(--slate-500);margin-bottom:10px">📦 Movimiento de Kilos</div>
      <div class="erp-settlement-grid">
        <div class="erp-settlement-item"><span class="erp-stat-value">${data.startingInventory}</span><span class="erp-stat-label">Kg iniciales</span></div>
        <div class="erp-settlement-item green"><span class="erp-stat-value">${data.totalDelivered}</span><span class="erp-stat-label">Kg entregados</span></div>
        <div class="erp-settlement-item amber"><span class="erp-stat-value">${data.totalExtraSold}</span><span class="erp-stat-label">Kg venta calle</span></div>
        <div class="erp-settlement-item"><span class="erp-stat-value">${data.totalStaleReturned}</span><span class="erp-stat-label">Kg devueltos</span></div>
        <div class="erp-settlement-item amber"><span class="erp-stat-value">${data.totalRecompra}</span><span class="erp-stat-label">Kg recompra</span></div>
        <div class="erp-settlement-item green full"><span class="erp-stat-value">${data.endingInventory}</span><span class="erp-stat-label">Kg finales (en camión)</span></div>
      </div>
      <div style="margin-top:10px;padding:8px 12px;background:var(--green-100)">
        <div style="display:flex;justify-content:space-between;font-size:12px;font-family:monospace;font-weight:600;color:var(--slate-900)">
          <span>Variación de inventario</span>
          <span>${variation === 0 ? '✅ 0 kg' : '⚠️ ' + variation + ' kg'}</span>
        </div>
      </div>
    </div>
  `;
}

// ─── MORE ───
function openProductForm(productId) {
  AppState.productEditId = productId || 'new';
  render();
}

function closeProductForm() {
  AppState.productEditId = null;
  render();
}

function saveProductForm() {
  const name = document.getElementById('product-name')?.value.trim() || '';
  const icon = document.getElementById('product-icon')?.value.trim() || '📦';
  const price = parseFloat(document.getElementById('product-price')?.value) || 0;
  if (!name) { showToast('❌ Escribe el nombre del producto'); return; }
  if (price <= 0) { showToast('❌ Indica un precio válido'); return; }
  if (AppState.productEditId === 'new') {
    const next = PRODUCTOS.reduce((max, p) => Math.max(max, parseInt(p.id.slice(1)) || 0), 0) + 1;
    PRODUCTOS.push({ id: 'P' + next, name, price, unit: 'kg', icon });
  } else {
    const product = getProduct(AppState.productEditId);
    if (!product) return;
    product.name = name;
    product.price = price;
    product.icon = icon;
  }
  saveProducts();
  AppState.productEditId = null;
  showToast('✅ Producto guardado');
  render();
}

function mdRow(icon, title, sub, onclick, opts = {}) {
  const danger = opts.danger ? ' md-danger' : '';
  const right = opts.value
    ? `<span class="md-row-value">${opts.value}</span>`
    : (opts.noChevron ? '' : '<span class="md-row-chevron">›</span>');
  return `
    <button class="md-row" onclick="${onclick}">
      <span class="md-row-icon${danger}">${icon}</span>
      <span class="md-row-body">
        <span class="md-row-title${danger}">${title}</span>
        ${sub ? `<span class="md-row-sub">${sub}</span>` : ''}
      </span>
      ${right}
    </button>`;
}

function renderMore() {
  if (Auth.isDriver()) {
    AppState.screen = 'mainMenu';
    AppState.params = {};
    return renderMainMenu();
  }
  const isAdmin = Auth.isAdmin();
  const users = Auth.getUsers();
  const futureCount = AppState.futureOrders.length;
  const productCount = PRODUCTOS.length;
  const driftList = isAdmin ? CLIENTES.filter(c => !c.deleted && balanceDrift(c.id)) : [];
  return {
    html: `
      <div class="erp-screen">
        <div class="md-appbar">
          <button class="md-appbar-back" onclick="App.goBack()">←</button>
          <span class="md-appbar-title">Configuración</span>
        </div>
        <div class="md-settings">

          ${isAdmin ? `
          <div class="md-section-label">Administración</div>
          <div class="md-card">
            ${mdRow('👥', 'Usuarios', users.length + ' registrados', "App.navigate('userManagement')")}
            ${mdRow('📦', 'Productos', productCount + ' productos · precios', "App.navigate('settingsProducts')")}
            ${mdRow('🔗', 'Integración ERP', erpCountsSummary(), "App.navigate('settingsErp')")}
            ${driftList.length > 0 ? mdRow('⚠️', 'Saldo vs ledger', driftList.length + ' cliente(s) con diferencia', "App.navigate('settingsBalances')", { danger: true }) : ''}
          </div>
          ` : ''}

          <div class="md-section-label">Operación</div>
          <div class="md-card">
            ${mdRow('📅', 'Pedidos futuros', futureCount === 0 ? 'Sin pedidos' : futureCount + ' pedido(s)', "App.navigate('settingsFutureOrders')")}
            ${mdRow('🚚', 'Chofer', AppState.driver.name, "App.navigate('settingsDriver')")}
          </div>

          <div class="md-section-label">Aplicación</div>
          <div class="md-card">
            ${mdRow('👁️', 'Accesibilidad visual', 'Tamaño de texto y contraste', "App.navigate('settingsAccessibility')")}
            ${mdRow('💾', 'Copia de seguridad', 'Exportar e importar datos', "App.navigate('settingsBackup')")}
            ${mdRow('🧹', 'Limpieza de datos', 'Borrar rutas y transacciones', "App.navigate('settingsData')")}
          </div>

          <div class="md-section-label">Cuenta</div>
          <div class="md-card">
            ${mdRow('🚪', 'Cerrar sesión', '', 'App.logout()', { danger: true, noChevron: true })}
          </div>

        </div>
      </div>
    `,
    init: () => {}
  };
}

// ─── SETTINGS · INTEGRACIÓN ERP ───
function erpCountsSummary() {
  if (typeof ErpOutbox === 'undefined') return 'No disponible';
  const c = ErpOutbox.counts();
  if (c.failed > 0) return c.failed + ' con error · ' + c.pending + ' pendientes';
  if (c.pending > 0) return c.pending + ' pendientes';
  if (c.sent > 0) return c.sent + ' enviados · al día';
  return 'Sin eventos';
}

function renderSettingsErp() {
  if (!Auth.isAdmin()) { AppState.screen = 'mainMenu'; return renderMainMenu(); }
  const counts = ErpOutbox.counts();
  const events = ErpOutbox._loadOutbox().slice().reverse().slice(0, 30);
  const statusChip = ev => {
    if (ev.status === 'sent') return '<span class="erp-chip erp-chip-green">Enviado</span>';
    if (ev.status === 'failed') return '<span class="erp-chip erp-chip-amber">Falló</span>';
    return '<span class="erp-chip erp-chip-blue">Pendiente</span>';
  };
  return {
    html: `
      <div class="erp-screen">
        <div class="md-appbar">
          <button class="md-appbar-back" onclick="App.goBack()">←</button>
          <span class="md-appbar-title">Integración ERP</span>
        </div>
        <div class="md-settings">
          <div class="md-card" style="padding:12px">
            <div style="display:flex;gap:10px;text-align:center;font-family:monospace">
              <div style="flex:1"><div style="font-size:20px;font-weight:700;color:#2563EB">${countsSafe().pending}</div><div style="font-size:10px;color:var(--slate-400)">PENDIENTES</div></div>
              <div style="flex:1"><div style="font-size:20px;font-weight:700;color:var(--emerald-600)">${countsSafe().sent}</div><div style="font-size:10px;color:var(--slate-400)">ENVIADOS</div></div>
              <div style="flex:1"><div style="font-size:20px;font-weight:700;color:${countsSafe().failed > 0 ? 'var(--danger)' : 'var(--slate-400)'}">${countsSafe().failed}</div><div style="font-size:10px;color:var(--slate-400)">FALLIDOS</div></div>
            </div>
            ${countsSafe().failed > 0 ? `<button class="erp-btn erp-btn-primary erp-btn-block" style="margin-top:10px" onclick="retryErpEvents()">↩️ Reintentar fallidos</button>` : ''}
            <div style="font-size:11px;color:var(--slate-400);font-family:monospace;margin-top:8px">Los eventos se envían a ERPNext al cierre de cada jornada (liquidación) y al crear o editar clientes.</div>
          </div>
          <div class="md-section-label">Eventos recientes</div>
          <div class="md-card">
            ${events.length === 0
              ? '<div style="padding:12px;font-size:12px;color:var(--slate-400)">Sin eventos aún</div>'
              : events.map(ev => `
                <div style="padding:10px 12px;border-bottom:1px solid var(--slate-100);display:flex;justify-content:space-between;align-items:center;gap:8px">
                  <div style="min-width:0">
                    <div style="font-size:12px;font-weight:600;color:var(--slate-900)">${escHtml(ev.type)}</div>
                    <div style="font-size:10px;color:var(--slate-400);font-family:monospace">${escHtml(ev.entityId)}${ev.erpRef ? ' · ' + escHtml(ev.erpRef) : ''}${ev.lastError ? ' · ' + escHtml(ev.lastError) : ''}</div>
                  </div>
                  ${statusChip(ev)}
                </div>`).join('')}
          </div>
        </div>
      </div>
    `,
    init: () => {}
  };
}

function countsSafe() {
  try { return ErpOutbox.counts(); } catch (e) { return { pending: 0, sent: 0, failed: 0, total: 0 }; }
}

function retryErpEvents() {
  const n = ErpOutbox.retryFailed();
  showToast(n > 0 ? '↩️ ' + n + ' evento(s) en cola de reintento' : 'Nada que reintentar');
  render();
}

// ─── SETTINGS · BALANCE CHECK (diagnostic, ledger vs stored) ───
function renderSettingsBalances() {
  if (!Auth.isAdmin()) { AppState.screen = 'mainMenu'; return renderMainMenu(); }
  const rows = CLIENTES.filter(c => !c.deleted && balanceDrift(c.id)).map(c => ({
    c,
    derived: computeBalanceFromLedger(c.id),
    stored: Number(c.balance) || 0,
  }));
  return {
    html: `
      <div class="erp-screen">
        <div class="md-appbar">
          <button class="md-appbar-back" onclick="App.goBack()">←</button>
          <span class="md-appbar-title">Saldo vs ledger</span>
        </div>
        <div class="md-settings">
          <div class="md-card">
            ${rows.length === 0
              ? '<div style="padding:12px;font-size:13px;color:var(--emerald-600)">✓ Todos los saldos coinciden con el ledger</div>'
              : rows.map(r => `
                <div style="padding:10px 12px;border-bottom:1px solid var(--slate-100)">
                  <div style="font-size:13px;font-weight:600;color:var(--slate-900)">${escHtml(r.c.name)}</div>
                  <div style="font-size:11px;font-family:monospace;color:var(--slate-500);margin-top:2px">
                    Guardado: ${formatCurrency(r.stored)} · Derivado: ${formatCurrency(r.derived)} · Diff: ${formatCurrency(r.stored - r.derived)}
                  </div>
                </div>`).join('')}
          </div>
          <div style="font-size:11px;color:var(--slate-400);font-family:monospace;padding:0 4px">Derivado = deudas iniciales + créditos de pedidos completados − abonos. Solo diagnóstico.</div>
        </div>
      </div>
    `,
    init: () => {}
  };
}

// ─── SETTINGS · PRODUCTOS ───
function renderSettingsProducts() {
  if (!Auth.isAdmin()) { AppState.screen = 'mainMenu'; return renderMainMenu(); }
  const editingProduct = AppState.productEditId && AppState.productEditId !== 'new' ? getProduct(AppState.productEditId) : null;
  return {
    html: `
      <div class="erp-screen">
        <div class="md-appbar">
          <button class="md-appbar-back" onclick="App.goBack()">←</button>
          <span class="md-appbar-title">Productos</span>
          <div style="flex:1"></div>
          <button class="erp-btn erp-btn-sm erp-btn-primary" onclick="openProductForm('new')">+ Nuevo</button>
        </div>
        <div class="md-settings">
          ${AppState.productEditId ? `
          <div class="md-card" style="padding:14px 16px;margin-bottom:12px">
            <div style="font-size:12px;font-weight:700;color:var(--green-700);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px">${editingProduct ? 'Editar producto' : 'Nuevo producto'}</div>
            <div style="display:grid;grid-template-columns:1fr 70px;gap:8px">
              <div class="erp-field"><div class="erp-label">Nombre</div><input class="erp-input" id="product-name" value="${escHtml(editingProduct?.name || '')}" placeholder="Nombre"></div>
              <div class="erp-field"><div class="erp-label">Ícono</div><input class="erp-input" id="product-icon" value="${escHtml(editingProduct?.icon || '📦')}" maxlength="4"></div>
            </div>
            <div class="erp-field"><div class="erp-label">Precio por kg</div><input class="erp-input" id="product-price" type="number" min="0.01" step="0.5" value="${editingProduct ? getProductPrice(editingProduct.id) : ''}" placeholder="0.00"></div>
            <div style="display:flex;gap:8px;margin-top:4px"><button class="erp-btn erp-btn-primary erp-btn-block" onclick="saveProductForm()">💾 Guardar</button><button class="erp-btn erp-btn-block" onclick="closeProductForm()">Cancelar</button></div>
          </div>` : ''}
          <div class="md-card">
            ${PRODUCTOS.map(p => {
              const cur = getProductPrice(p.id);
              return `
                <button class="md-row" onclick="openProductForm('${p.id}')">
                  <span class="md-row-icon">${p.icon}</span>
                  <span class="md-row-body">
                    <span class="md-row-title">${p.name}</span>
                    <span class="md-row-sub">${formatCurrency(cur)} / kg</span>
                  </span>
                  <span class="md-row-chevron">›</span>
                </button>`;
            }).join('')}
          </div>
          <div style="margin-top:12px">
            <div class="md-section-label" style="padding-top:4px">Ajuste rápido de precios</div>
            <div class="md-card" style="padding:12px 16px">
              ${PRODUCTOS.map(p => `
                <div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--slate-100)">
                  <span style="font-size:14px;font-weight:600;flex:1;color:var(--slate-900)">${p.icon} ${p.name}</span>
                  <span style="font-size:11px;color:var(--slate-400);font-family:monospace">$</span>
                  <input type="number" class="erp-input" id="price-${p.id}" value="${getProductPrice(p.id)}" min="1" max="999" step="0.5" style="width:72px;text-align:right;font-size:14px;font-weight:700;font-family:monospace;padding:6px">
                  <span style="font-size:11px;color:var(--slate-400);font-family:monospace">/kg</span>
                </div>`).join('')}
              <button class="erp-btn erp-btn-primary erp-btn-block" style="margin-top:12px" onclick="saveProductPrices()">💾 Guardar precios</button>
            </div>
          </div>
        </div>
      </div>
    `,
    init: () => {}
  };
}

// ─── SETTINGS · PEDIDOS FUTUROS ───
function renderSettingsFutureOrders() {
  if (!Auth.isAdmin()) { AppState.screen = 'mainMenu'; return renderMainMenu(); }
  return {
    html: `
      <div class="erp-screen">
        <div class="md-appbar">
          <button class="md-appbar-back" onclick="App.goBack()">←</button>
          <span class="md-appbar-title">Pedidos futuros</span>
          <div style="flex:1"></div>
          <button class="erp-btn erp-btn-sm erp-btn-primary" onclick="App.navigate('futureOrder')">+ Nuevo</button>
        </div>
        <div class="md-settings">
          ${AppState.futureOrders.length === 0
            ? '<div class="erp-empty"><span class="erp-empty-icon">📅</span><div class="erp-empty-text">Sin pedidos futuros</div></div>'
            : `<div class="md-card" style="padding:8px 12px">${AppState.futureOrders.map(o => {
                const p = getProduct(o.productId);
                return `
                  <div class="erp-future-card" style="border:none;border-bottom:1px solid var(--slate-100)">
                    <div class="erp-future-card-header">
                      <div class="erp-future-card-name">${o.customerName}</div>
                      <span class="erp-chip ${o.prepaid ? 'erp-chip-green' : 'erp-chip-amber'}">${o.prepaid ? 'Pagado' : 'Pendiente'}</span>
                    </div>
                    <div class="erp-future-card-product">${p ? p.icon + ' ' + p.name : ''} - ${o.qty}kg</div>
                    <div class="erp-future-card-meta">
                      <span>Fecha: ${formatDate(o.deliveryDate)}</span>
                      <span>Tel: ${o.phone}</span>
                    </div>
                    ${o.notes ? '<div class="erp-future-card-note">Nota: ' + o.notes + '</div>' : ''}
                  </div>`;
              }).join('')}</div>`}
        </div>
      </div>
    `,
    init: () => {}
  };
}

// ─── SETTINGS · CHOFER ───
function renderSettingsDriver() {
  if (!Auth.isAdmin()) { AppState.screen = 'mainMenu'; return renderMainMenu(); }
  return {
    html: `
      <div class="erp-screen">
        <div class="md-appbar">
          <button class="md-appbar-back" onclick="App.goBack()">←</button>
          <span class="md-appbar-title">Chofer</span>
        </div>
        <div class="md-settings">
          <div class="md-card" style="padding:16px">
            <div class="erp-field" style="margin-bottom:12px">
              <label class="erp-label">Nombre</label>
              <input type="text" class="erp-input" id="user-name" value="${AppState.driver.name}" placeholder="Nombre completo">
            </div>
            <div class="erp-field" style="margin-bottom:12px">
              <label class="erp-label">ID</label>
              <input type="text" class="erp-input" id="user-id" value="${AppState.driver.id}" placeholder="Ej. DRV001">
            </div>
            <div class="erp-data-row"><span class="erp-data-label">Ruta asignada</span><span class="erp-data-value">${AppState.route ? AppState.route.name : 'Sin ruta'}</span></div>
            <button class="erp-btn erp-btn-primary erp-btn-block" style="margin-top:12px" onclick="saveUserProfile()">💾 Guardar chofer</button>
          </div>
        </div>
      </div>
    `,
    init: () => {}
  };
}

// ─── SETTINGS · ACCESIBILIDAD ───
function renderSettingsAccessibility() {
  if (!Auth.isAdmin()) { AppState.screen = 'mainMenu'; return renderMainMenu(); }
  return {
    html: `
      <div class="erp-screen">
        <div class="md-appbar">
          <button class="md-appbar-back" onclick="App.goBack()">←</button>
          <span class="md-appbar-title">Accesibilidad visual</span>
        </div>
        <div class="md-settings">
          <div class="md-card" style="padding:16px">
            <div style="font-size:13px;font-weight:600;color:var(--slate-700);margin-bottom:8px">Tamaño del texto</div>
            <div style="display:flex;gap:8px;margin-bottom:16px">
              <button class="erp-option-card ${A11Y.scale <= 1 ? 'selected' : ''}" onclick="setTextScale(1)">
                <span class="erp-option-card-icon">A</span>
                <span class="erp-option-card-label">Normal</span>
              </button>
              <button class="erp-option-card ${A11Y.scale >= 1.2 && A11Y.scale < 1.4 ? 'selected' : ''}" onclick="setTextScale(1.2)">
                <span class="erp-option-card-icon" style="font-size:28px">A</span>
                <span class="erp-option-card-label">Grande</span>
              </button>
              <button class="erp-option-card ${A11Y.scale >= 1.4 ? 'selected' : ''}" onclick="setTextScale(1.4)">
                <span class="erp-option-card-icon" style="font-size:34px">A</span>
                <span class="erp-option-card-label">Muy grande</span>
              </button>
            </div>
            <div style="display:flex;align-items:center;gap:10px">
              <span style="font-size:14px;flex:1;color:var(--slate-900)">Alto contraste</span>
              <button class="erp-btn erp-btn-sm" onclick="toggleHighContrast()" style="background:${A11Y.highContrast ? 'var(--emerald-600)' : 'var(--slate-200)'};border:none;color:${A11Y.highContrast ? 'white' : 'var(--slate-600)'};min-width:64px;font-size:12px;cursor:pointer">${A11Y.highContrast ? 'ON' : 'OFF'}</button>
            </div>
            <div style="font-size:12px;color:var(--slate-400);margin-top:12px;line-height:1.4">Textos más grandes y/o más oscuros para facilitar la lectura.</div>
          </div>
        </div>
      </div>
    `,
    init: () => {}
  };
}

// ─── SETTINGS · COPIA DE SEGURIDAD ───
function renderSettingsBackup() {
  if (!Auth.isAdmin()) { AppState.screen = 'mainMenu'; return renderMainMenu(); }
  return {
    html: `
      <div class="erp-screen">
        <div class="md-appbar">
          <button class="md-appbar-back" onclick="App.goBack()">←</button>
          <span class="md-appbar-title">Copia de seguridad</span>
        </div>
        <div class="md-settings">
          <div class="md-card" style="padding:16px;margin-bottom:12px">
            <div style="font-size:12px;font-weight:700;color:var(--green-700);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px">Exportar</div>
            <button class="erp-btn erp-btn-primary erp-btn-block" onclick="downloadBackup()">⬇️ Exportar datos (.json)</button>
            <div style="font-size:12px;font-weight:600;color:var(--slate-500);margin:12px 0 4px">O copia el contenido del respaldo</div>
            <button class="erp-btn erp-btn-block" onclick="showBackupText()">📋 Generar texto del respaldo</button>
            <textarea id="backup-export" class="erp-input" readonly placeholder="Pulsa 'Generar texto del respaldo' para mostrar aquí el contenido" style="width:100%;height:120px;margin-top:8px;font-size:10px;font-family:monospace;box-sizing:border-box;white-space:pre"></textarea>
            <button class="erp-btn erp-btn-block" style="margin-top:6px" onclick="copyBackupText()">📋 Copiar texto del respaldo</button>
          </div>
          <div class="md-card" style="padding:16px">
            <div style="font-size:12px;font-weight:700;color:var(--green-700);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px">Importar</div>
            <input type="file" id="backup-file" accept=".json,application/json" style="display:none" onchange="handleBackupFile(this)">
            <button class="erp-btn erp-btn-block" onclick="document.getElementById('backup-file').click()">📂 Elegir archivo .json</button>
            <textarea id="backup-text" class="erp-input" placeholder="Pega aquí el texto del respaldo copiado" style="width:100%;height:90px;margin-top:8px;font-size:11px;font-family:monospace;box-sizing:border-box"></textarea>
            <button class="erp-btn erp-btn-primary erp-btn-block" style="margin-top:6px" onclick="importBackupFromText()">⬆️ Importar y reemplazar datos</button>
            <div style="font-size:11px;color:var(--slate-400);margin-top:8px;line-height:1.4">Antes de importar se guarda una copia de tus datos actuales (elcomal_preimport_backup_*).</div>
            <button class="erp-btn erp-btn-block" style="margin-top:6px" onclick="restoreLastPreImportBackup()">↩️ Restaurar respaldo previo</button>
          </div>
        </div>
      </div>
    `,
    init: () => {
      if (AppState.backupExportText) {
        const ta = document.getElementById('backup-export');
        if (ta) {
          ta.value = AppState.backupExportText;
          ta.style.height = Math.max(120, Math.min(400, AppState.backupExportText.split('\n').length * 14)) + 'px';
        }
      }
    }
  };
}

// ─── SETTINGS · LIMPIEZA DE DATOS ───
function renderSettingsData() {
  if (!Auth.isAdmin()) { AppState.screen = 'mainMenu'; return renderMainMenu(); }
  return {
    html: `
      <div class="erp-screen">
        <div class="md-appbar">
          <button class="md-appbar-back" onclick="App.goBack()">←</button>
          <span class="md-appbar-title">Limpieza de datos</span>
        </div>
        <div class="md-settings">
          <div class="md-card" style="padding:16px">
            <button class="erp-btn erp-btn-danger erp-btn-block" onclick="confirmCleanupRouteData()">🧹 Limpiar rutas y transacciones</button>
            <div style="font-size:12px;color:var(--slate-400);margin-top:10px;line-height:1.4">Borra solo datos de rutas: viajes, paradas, sesiones, cortes y venta callejera. Se conservan clientes, precios, recurrencias y pedidos (incluidos los recurrentes).</div>
          </div>
        </div>
      </div>
    `,
    init: () => {}
  };
}


// ─── USER MANAGEMENT (admin only) ───────────────────────
function renderUserManagement() {
  if (Auth.isDriver()) {
    AppState.screen = 'mainMenu';
    AppState.params = {};
    return renderMainMenu();
  }
  const users = Auth.getUsers();
  const me = Auth.currentUser() || {};
  return {
    html: `
      <div class="erp-screen">
        <div style="display:flex;align-items:center;gap:8px;padding:10px 10px 4px">
          <button class="erp-btn erp-btn-sm" onclick="App.goBack()">← VOLVER</button>
          <div style="flex:1">
            <div style="font-size:15px;font-weight:700;color:var(--slate-900)">Usuarios</div>
            <div style="font-size:10px;color:var(--slate-400);font-family:monospace">${users.length} registrados</div>
          </div>
          <button class="erp-btn erp-btn-sm erp-btn-primary" onclick="toggleNewUserForm()">+ NUEVO</button>
        </div>
        <div style="flex:1;overflow-y:auto;padding:8px 10px 80px">
          ${AppState.showNewUserForm ? `
          <div style="background:white;border:1px solid var(--slate-200);padding:12px;margin-bottom:8px">
            <div style="font-size:11px;font-weight:700;font-family:monospace;text-transform:uppercase;color:var(--slate-500);margin-bottom:6px">Nuevo usuario</div>
            <div class="erp-field"><div class="erp-label">Nombre completo</div><input class="erp-input" id="nu-name" placeholder="Nombre completo" value="${escHtml(AppState.nuName)}" oninput="AppState.nuName=this.value"></div>
            <div class="erp-field"><div class="erp-label">Usuario</div><input class="erp-input" id="nu-username" placeholder="usuario" value="${escHtml(AppState.nuUsername)}" oninput="AppState.nuUsername=this.value"></div>
            <div class="erp-field"><div class="erp-label">Contraseña</div><input class="erp-input" id="nu-password" type="password" placeholder="Contraseña" value="${escHtml(AppState.nuPassword)}" oninput="AppState.nuPassword=this.value"></div>
            <div class="erp-field">
              <div class="erp-label">Rol</div>
              <select class="erp-input" id="nu-role" onchange="AppState.nuRole=this.value">
                <option value="driver" ${AppState.nuRole === 'driver' ? 'selected' : ''}>Chofer</option>
                <option value="admin" ${AppState.nuRole === 'admin' ? 'selected' : ''}>Admin</option>
              </select>
            </div>
            <div class="login-error" id="nu-error" style="color:var(--danger);min-height:18px"></div>
            <button class="erp-btn erp-btn-primary erp-btn-block" onclick="createUserSubmit()">Crear usuario</button>
          </div>` : ''}
          ${users.map(u => `
            <div style="background:white;border:1px solid var(--slate-200);padding:12px;margin-bottom:8px">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <div>
                  <div style="font-size:14px;font-weight:700;color:var(--slate-900)">${escHtml(u.name)}</div>
                  <div style="font-size:11px;color:var(--slate-400);font-family:monospace">@${escHtml(u.username)} · ${u.role === 'admin' ? 'Admin' : 'Chofer'}</div>
                </div>
                <span class="erp-chip ${u.active ? 'erp-chip-green' : 'erp-chip-amber'}">${u.active ? 'Activo' : 'Inactivo'}</span>
              </div>
              ${AppState.editUserId === u.id ? `
              <div style="border-top:1px solid var(--slate-100);margin-top:8px;padding-top:10px">
                <div class="erp-field"><div class="erp-label">Nombre completo</div><input class="erp-input" id="eu-name" value="${escHtml(AppState.euName)}" oninput="AppState.euName=this.value"></div>
                <div class="erp-field"><div class="erp-label">Usuario</div><input class="erp-input" id="eu-username" value="${escHtml(AppState.euUsername)}" oninput="AppState.euUsername=this.value"></div>
                <div class="login-error" id="eu-error" style="color:var(--danger);min-height:18px"></div>
                <div style="display:flex;gap:6px;margin-top:4px">
                  <button class="erp-btn erp-btn-sm" style="flex:1" onclick="cancelEditUser()">Cancelar</button>
                  <button class="erp-btn erp-btn-primary erp-btn-sm" style="flex:2" onclick="editUserSubmit('${u.id}')">Guardar</button>
                </div>
              </div>` : ''}
              <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap">
                <button class="erp-btn erp-btn-sm" onclick="startEditUser('${u.id}')">✏️ Editar</button>
                ${u.id !== me.userId ? `<button class="erp-btn erp-btn-sm" onclick="toggleUserActive('${u.id}')">${u.active ? 'Desactivar' : 'Activar'}</button>` : ''}
                <button class="erp-btn erp-btn-sm" onclick="resetUserPassword('${u.id}')">Cambiar contraseña</button>
                ${u.id !== me.userId ? `<button class="erp-btn erp-btn-sm erp-btn-danger" onclick="deleteUserConfirm('${u.id}')">Eliminar</button>` : ''}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `,
    init: () => {}
  };
}

function toggleNewUserForm() {
  AppState.showNewUserForm = !AppState.showNewUserForm;
  render();
}

function startEditUser(userId) {
  const u = Auth.getUsers().find(x => x.id === userId);
  if (!u) return;
  AppState.editUserId = userId;
  AppState.euName = u.name || '';
  AppState.euUsername = u.username || '';
  render();
}

function cancelEditUser() {
  AppState.editUserId = null;
  AppState.euName = '';
  AppState.euUsername = '';
  render();
}

async function editUserSubmit(userId) {
  const err = document.getElementById('eu-error');
  const name = (document.getElementById('eu-name')?.value || '').trim();
  const username = (document.getElementById('eu-username')?.value || '').trim();
  if (!name) { if (err) err.textContent = 'El nombre es obligatorio.'; return; }
  if (!username) { if (err) err.textContent = 'El usuario es obligatorio.'; return; }
  const current = Auth.getUsers().find(x => x.id === userId);
  const existing = Auth.getUsers().find(x => x.username === username && x.id !== userId);
  if (existing) { if (err) err.textContent = 'Ese usuario ya existe.'; return; }
  try {
    await Auth.updateUser(userId, { name, username });
    if (current && current.id === (Auth.currentUser() || {}).userId) {
      Auth.updateSession({ name, username });
      AppState.driver = { name, id: userId, role: current.role };
    }
    AppState.editUserId = null;
    AppState.euName = '';
    AppState.euUsername = '';
    showToast('✓ Usuario actualizado');
    render();
  } catch (e) {
    if (err) err.textContent = e.message;
  }
}

async function createUserSubmit() {
  const err = document.getElementById('nu-error');
  const name = document.getElementById('nu-name').value.trim();
  const username = document.getElementById('nu-username').value.trim();
  const password = document.getElementById('nu-password').value;
  const role = document.getElementById('nu-role').value;
  if (!name || !username || !password) { if (err) err.textContent = 'Completa todos los campos.'; return; }
  if (password.length < 4) { if (err) err.textContent = 'La contraseña debe tener al menos 4 caracteres.'; return; }
  try {
    await Auth.createUser(username, password, role, name);
    AppState.showNewUserForm = false;
    AppState.nuName = '';
    AppState.nuUsername = '';
    AppState.nuPassword = '';
    AppState.nuRole = 'driver';
    showToast('✓ Usuario creado');
    render();
  } catch (e) {
    if (err) err.textContent = e.message;
  }
}

async function resetUserPassword(userId) {
  const np = prompt('Nueva contraseña (mínimo 4 caracteres):');
  if (!np) return;
  if (np.length < 4) { showToast('❌ Mínimo 4 caracteres'); return; }
  try { await Auth.updateUser(userId, { password: np }); showToast('✓ Contraseña actualizada'); }
  catch (e) { showToast('❌ ' + e.message); }
}

function toggleUserActive(userId) {
  const u = Auth.getUsers().find(x => x.id === userId);
  if (!u) return;
  if (u.active && u.role === 'admin') {
    const admins = Auth.getUsers().filter(x => x.role === 'admin' && x.active);
    if (admins.length <= 1) { showToast('❌ No puedes desactivar al último admin'); return; }
  }
  Auth.updateUser(userId, { active: !u.active });
  render();
}

function deleteUserConfirm(userId) {
  const u = Auth.getUsers().find(x => x.id === userId);
  if (!u) return;
  if (u.role === 'admin') {
    const admins = Auth.getUsers().filter(x => x.role === 'admin' && x.active);
    if (admins.length <= 1) { showToast('❌ No puedes eliminar al último admin'); return; }
  }
  if (!confirm('¿Eliminar al usuario ' + u.name + '?')) return;
  Auth.deleteUser(userId);
  render();
}

function downloadBackup() {
  const data = exportBackup();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'elcomal-backup-' + today() + '.json';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 1000);
  showToast('✅ Respaldo exportado: ' + backupSummary(data));
}

function showBackupText() {
  const data = exportBackup();
  AppState.backupExportText = JSON.stringify(data, null, 2);
  render();
  showToast('✅ Texto del respaldo generado: ' + backupSummary(data));
}

function copyBackupText() {
  const ta = document.getElementById('backup-export');
  if (!ta || !ta.value) { showToast('❌ Primero pulsa "Generar texto del respaldo"'); return; }
  ta.select();
  ta.setSelectionRange(0, ta.value.length);
  let copied = false;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(ta.value).then(() => {
      showToast('✅ Copiado al portapapeles. Pégalo en el otro dispositivo.');
    }).catch(() => {
      copied = document.execCommand('copy');
      showToast(copied ? '✅ Copiado. Pégalo en el otro dispositivo.' : '⚠️ Selecciona el texto y copia manualmente');
    });
  } else {
    copied = document.execCommand('copy');
    showToast(copied ? '✅ Copiado. Pégalo en el otro dispositivo.' : '⚠️ Selecciona el texto y copia manualmente');
  }
}

function handleBackupFile(input) {
  const file = input.files && input.files[0];
  if (!file) { showToast('❌ No se seleccionó ningún archivo'); return; }
  const reader = new FileReader();
  reader.onload = () => {
    const res = importBackup(String(reader.result || ''));
    if (!res.ok) { showToast('❌ ' + res.error); return; }
    input.value = '';
    AppState.toast = '✅ Importado: ' + res.summary;
    render();
    setTimeout(() => location.reload(), 1800);
  };
  reader.readAsText(file);
}

function importBackupFromText() {
  const ta = document.getElementById('backup-text');
  const text = ta ? ta.value.trim() : '';
  if (!text) { showToast('❌ Pega el contenido del respaldo primero'); return; }
  const res = importBackup(text);
  if (!res.ok) { showToast('❌ ' + res.error); return; }
  ta.value = '';
  AppState.toast = '✅ Importado: ' + res.summary;
  render();
  setTimeout(() => location.reload(), 1800);
}

function restoreLastPreImportBackup() {
  if (!restorePreImportBackup()) { showToast('⚠️ No hay respaldo previo guardado'); return; }
  AppState.toast = '✅ Datos previos restaurados';
  render();
  setTimeout(() => location.reload(), 1500);
}

// ─── FUTURE ORDER FORM ─────────────────────────────────
function renderFutureOrderForm() {
  return {
    html: `
      <div class="erp-screen">
        <div style="display:flex;align-items:center;gap:8px;padding:10px 10px 4px">
          <button class="erp-btn erp-btn-sm" onclick="App.goBack()">← VOLVER</button>
          <div>
            <div style="font-size:15px;font-weight:700;color:var(--slate-900)">Nuevo pedido futuro</div>
            <div style="font-size:10px;color:var(--slate-400);font-family:monospace">Registra un pedido de mostrador</div>
          </div>
        </div>
        <div style="flex:1;overflow-y:auto;padding:10px 10px 80px">
          <div style="background:white;border:1px solid var(--slate-200);padding:12px">
            <div class="erp-field">
              <div class="erp-label">Nombre del cliente</div>
              <input class="erp-input" id="fo-name" placeholder="Ej: Juan Pérez">
            </div>
            <div class="erp-field">
              <div class="erp-label">Teléfono</div>
              <input class="erp-input" id="fo-phone" placeholder="555-0000" type="tel">
            </div>
            <div class="erp-field">
              <div class="erp-label">Producto</div>
              <select class="erp-select" id="fo-product">
                ${PRODUCTOS.map(p => `<option value="${p.id}">${p.icon} ${p.name}</option>`).join('')}
              </select>
            </div>
            <div class="erp-field">
              <div class="erp-label">Cantidad (kg)</div>
              <input class="erp-input erp-input-lg" id="fo-qty" type="number" value="10" min="1" step="1">
            </div>
            <div class="erp-field">
              <div class="erp-label">Fecha de entrega</div>
              <input class="erp-input" id="fo-date" type="date" value="${today()}">
            </div>
            <div class="erp-field">
              <div class="erp-label">¿Ya pagó?</div>
              <div class="erp-option-group">
                <div class="erp-option-card selected" id="fo-paid-no" onclick="selectFOPaid(false)">
                  <div class="erp-option-card-icon">💳</div>
                  <div class="erp-option-card-label">Paga al entregar</div>
                </div>
                <div class="erp-option-card" id="fo-paid-yes" onclick="selectFOPaid(true)">
                  <div class="erp-option-card-icon">💰</div>
                  <div class="erp-option-card-label">Pagó hoy</div>
                </div>
              </div>
            </div>
            <div class="erp-field" id="fo-amount-section" style="display:none">
              <div class="erp-label">¿Cuánto pagó?</div>
              <input class="erp-input erp-input-lg" id="fo-amount" type="number" value="0" step="10">
            </div>
            <div class="erp-field">
              <div class="erp-label">Notas</div>
              <input class="erp-input" id="fo-notes" placeholder="Ej: Para una fiesta">
            </div>
            <button class="erp-btn erp-btn-primary erp-btn-lg erp-btn-block" onclick="saveFutureOrder()">💾 Guardar pedido</button>
          </div>
        </div>
      </div>
    `,
    init: () => {}
  };
}

// ─── GLOBAL FUNCTIONS (called from onclick) ────────────
let sigCanvas = null;
let isSigDrawn = false;
let _cashTendered = 0;

function setupSignaturePad() {
  const canvas = document.getElementById('sig-canvas');
  if (!canvas) return;
  sigCanvas = canvas;
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  let drawing = false;

  function startDraw(x, y) {
    drawing = true;
    ctx.beginPath();
    ctx.moveTo(x, y);
  }

  function moveDraw(x, y) {
    if (!drawing) return;
    ctx.lineTo(x, y);
    ctx.strokeStyle = '#1A1A2E';
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  function endDraw() {
    if (!drawing) return;
    drawing = false;
    isSigDrawn = true;
    updateSigUI();
  }

  canvas.addEventListener('touchstart', (e) => {
    e.preventDefault();
    const rect = canvas.getBoundingClientRect();
    const touch = e.touches[0];
    startDraw(touch.clientX - rect.left, touch.clientY - rect.top);
  });
  canvas.addEventListener('touchmove', (e) => {
    e.preventDefault();
    const rect = canvas.getBoundingClientRect();
    const touch = e.touches[0];
    moveDraw(touch.clientX - rect.left, touch.clientY - rect.top);
  });
  canvas.addEventListener('touchend', (e) => { e.preventDefault(); endDraw(); });

  canvas.addEventListener('mousedown', (e) => {
    const rect = canvas.getBoundingClientRect();
    startDraw(e.clientX - rect.left, e.clientY - rect.top);
  });
  canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect();
    moveDraw(e.clientX - rect.left, e.clientY - rect.top);
  });
  canvas.addEventListener('mouseup', endDraw);
}

function updateSigUI() {
  const placeholder = document.getElementById('sig-placeholder');
  const area = document.getElementById('sig-area');
  if (placeholder) placeholder.style.display = isSigDrawn ? 'none' : 'block';
  if (area) area.className = `sig-sheet-canvas-wrap${isSigDrawn ? ' signed' : ''}`;
}

function clearSignature() {
  if (!sigCanvas) return;
  const ctx = sigCanvas.getContext('2d');
  ctx.clearRect(0, 0, sigCanvas.width, sigCanvas.height);
  isSigDrawn = false;
  updateSigUI();
}

// ─── SKIP REASON SHEET ──────────────────────────────────
function renderSkipReasonSheet() {
  const modal = AppState.skipReasonModal;
  if (!modal) return '';
  return `
    <div class="erp-overlay" onclick="closeSkipReasonSheet()">
      <div class="erp-sheet" onclick="event.stopPropagation()">
        <div class="erp-sheet-handle"></div>
        <div class="erp-sheet-title">⏭️ ¿Por qué saltas esta parada?</div>
        <div class="erp-sheet-body">
          <div style="display:flex;flex-direction:column;gap:8px">
            <div class="erp-option-card" id="skip-no_salio" onclick="selectSkipReason('no_salio')">
              <div class="erp-option-card-icon">🚪</div>
              <div class="erp-option-card-label">No salió</div>
            </div>
            <div class="erp-option-card" id="skip-estaba_cerrado" onclick="selectSkipReason('estaba_cerrado')">
              <div class="erp-option-card-icon">🔒</div>
              <div class="erp-option-card-label">Estaba cerrado</div>
            </div>
            <div class="erp-option-card" id="skip-otro" onclick="selectSkipReason('otro')">
              <div class="erp-option-card-icon">✏️</div>
              <div class="erp-option-card-label">Otro</div>
            </div>
            <div id="skip-otro-input" style="display:none">
              <textarea class="erp-textarea" id="skip-note" rows="2" placeholder="Especifica el motivo..."></textarea>
            </div>
          </div>
        </div>
        <div class="erp-sheet-footer">
          <button class="erp-btn erp-btn-primary erp-btn-lg erp-btn-block" onclick="confirmSkipOrder()">⏭️ Saltar parada</button>
          <button class="erp-btn erp-btn-secondary erp-btn-block" onclick="closeSkipReasonSheet()">Cancelar</button>
        </div>
      </div>
    </div>
  `;
}

let _selectedSkipReason = null;
function selectSkipReason(reason) {
  _selectedSkipReason = reason;
  document.querySelectorAll('#skip-otro-input, [id^="skip-"]').forEach(el => el.classList.remove('selected'));
  document.getElementById('skip-' + reason)?.classList.add('selected');
  document.getElementById('skip-otro-input').style.display = reason === 'otro' ? 'block' : 'none';
}

function closeSkipReasonSheet() {
  AppState.skipReasonModal = null;
  _selectedSkipReason = null;
  render();
}

function confirmSkipOrder() {
  if (!_selectedSkipReason) { showToast('❌ Selecciona un motivo'); return; }
  const modal = AppState.skipReasonModal;
  if (!modal) return;
  const note = _selectedSkipReason === 'otro' ? (document.getElementById('skip-note')?.value || 'Otro') : '';
  const reason = _selectedSkipReason;

  if (modal.orderId) {
    const o = getAdvanceOrder(modal.orderId);
    if (o) {
      o.status = 'skipped';
      o.skipReason = reason;
      o.skipNote = note;
      o.skippedBy = AppState.driver.id;
      o.skippedByName = AppState.driver.name;
      o.updatedAt = new Date().toISOString();
      saveAdvanceOrders();
      const trip = AppState.trips.find(t => t.orderIds.includes(o.id));
      if (trip) {
        const all = trip.orderIds.every(oid => {
          const ord = advanceOrders.find(x => x.id === oid);
          return ord && (ord.status === 'completed' || ord.status === 'skipped');
        });
        if (all) { trip.status = 'completed'; saveTrips(); showToast('🎉 ¡Ruta completada!'); }
      }
    }
    const stop = AppState.route.stops.find(s => s.stopId === modal.stopId);
    if (stop) { stop.status = 'skipped'; saveStopProgress(AppState.routeName, AppState.route.stops); }
  } else {
    const stop = AppState.route.stops.find(s => s.stopId === modal.stopId);
    if (stop) { stop.status = 'skipped'; saveStopProgress(AppState.routeName, AppState.route.stops); }
  }

  AppState.skipReasonModal = null;
  _selectedSkipReason = null;
  showToast('⏭️ Parada saltada');
  App.goBack();
}

function saveDraftAndGoBack(stopId) {
  saveDeliveryDraft(stopId);
  App.goBack();
}

const QTY_EDIT_CFG = {
  'delivery-qty': { min: 0, max: 200, commit: () => { syncCashToNeto(); updateSummary(); saveDeliveryDraft(); } },
  'devolucion-qty': { min: 0, max: 50, commit: () => { syncCashToNeto(); updateSummary(); saveDeliveryDraft(); } },
  'recompra-qty': { min: 0, max: 50, commit: () => { updateSummary(); saveDeliveryDraft(); } },
  'street-qty': { min: 0.5, max: 20, commit: () => { adjustStreet(0); } },
  'rs-occ-v': { min: 1, max: 999, commit: () => { if (window.onRSOccEdit) window.onRSOccEdit(); } },
};

function editQty(id) {
  const cfg = QTY_EDIT_CFG[id];
  const span = document.getElementById(id);
  if (!cfg || !span || span.dataset.editing) return;
  const input = document.createElement('input');
  input.type = 'number';
  input.min = cfg.min;
  input.max = cfg.max;
  input.step = '0.5';
  input.value = span.textContent;
  Object.assign(input.style, {
    width: '100%', textAlign: 'center', fontFamily: 'monospace', fontWeight: '700',
    fontSize: 'inherit', border: '1px solid var(--slate-300)', borderRadius: '6px',
    padding: '2px 4px', background: 'white', color: 'var(--slate-900)', minWidth: '32px',
  });
  span.dataset.editing = '1';
  span.replaceWith(input);
  input.focus();
  input.select();

  const finish = () => {
    if (input.dataset.done) return;
    input.dataset.done = '1';
    let v = parseFloat(input.value);
    if (isNaN(v)) v = parseFloat(span.textContent) || cfg.min;
    v = Math.max(cfg.min, Math.min(cfg.max, v));
    v = Math.round(v * 2) / 2;
    const fresh = document.createElement('span');
    fresh.id = id;
    fresh.className = span.className;
    fresh.textContent = v;
    fresh.style.cursor = 'pointer';
    fresh.onclick = () => editQty(id);
    input.replaceWith(fresh);
    if (cfg.commit) cfg.commit();
  };

  input.addEventListener('blur', finish);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
    if (e.key === 'Escape') { input.value = span.textContent; input.blur(); }
  });
}

function adjustDelivery(delta) {
  const el = document.getElementById('delivery-qty');
  if (!el) return;
  let v = parseFloat(el.textContent) + delta * 0.5;
  v = Math.max(0, Math.min(200, v));
  v = Math.round(v * 2) / 2;
  el.textContent = v;
  syncCashToNeto();
  updateSummary();
  saveDeliveryDraft();
}

function adjustDevolucion(delta) {
  const el = document.getElementById('devolucion-qty');
  if (!el) return;
  let v = parseFloat(el.textContent) + delta * 0.5;
  v = Math.max(0, Math.min(50, v));
  v = Math.round(v * 2) / 2;
  el.textContent = v;
  syncCashToNeto();
  updateSummary();
  saveDeliveryDraft();
}

function adjustRecompra(delta) {
  const el = document.getElementById('recompra-qty');
  if (!el) return;
  let v = parseFloat(el.textContent) + delta * 0.5;
  v = Math.max(0, Math.min(50, v));
  v = Math.round(v * 2) / 2;
  el.textContent = v;
  updateSummary();
  saveDeliveryDraft();
}

function toggleInventoryPanel() {
  const body = document.getElementById('inventory-body');
  const badge = document.getElementById('inventory-badge');
  if (!body || !badge) return;
  const isHidden = body.style.display === 'none';
  body.style.display = isHidden ? 'block' : 'none';
  const dev = parseFloat(document.getElementById('devolucion-qty')?.textContent) || 0;
  const rec = parseFloat(document.getElementById('recompra-qty')?.textContent) || 0;
  badge.textContent = isHidden ? '▼' : ((dev || rec) ? '✏️ ' + (dev + rec) + 'kg' : '+ AGREGAR');
  const stopId = AppState.params?.stopId;
  if (!stopId) return;
  const stop = AppState.route?.stops.find(s => s.stopId === stopId);
  if (!stop) return;
  stop.deliveryDraft = stop.deliveryDraft || {};
  stop.deliveryDraft.inventoryExpanded = !!isHidden;
  if (stop.orderId) {
    const o = getAdvanceOrder(stop.orderId);
    if (o) { o.deliveryDraft = { ...(o.deliveryDraft || {}), inventoryExpanded: !!isHidden }; saveAdvanceOrders(); }
  }
}

function onCashInput() {
  const total = currentStopSugerido();
  const cashEl = document.getElementById('stop-cash');
  const creditEl = document.getElementById('stop-credit');
  if (!cashEl || !creditEl) return;
  let cash = parseFloat(cashEl.value) || 0;
  cash = Math.max(0, cash);
  creditEl.value = Math.max(0, total - cash).toFixed(2);
  updateSummary();
}

function onCreditInput() {
  const total = currentStopSugerido();
  const cashEl = document.getElementById('stop-cash');
  const creditEl = document.getElementById('stop-credit');
  if (!cashEl || !creditEl) return;
  let credit = parseFloat(creditEl.value) || 0;
  credit = Math.max(0, credit);
  cashEl.value = Math.max(0, total - credit).toFixed(2);
  updateSummary();
}

function commitCashCredit() {
  const total = currentStopSugerido();
  const cashEl = document.getElementById('stop-cash');
  const creditEl = document.getElementById('stop-credit');
  if (!cashEl || !creditEl) return;
  let cash = parseFloat(cashEl.value) || 0;
  cash = Math.max(0, Math.min(total, cash));
  cashEl.value = cash.toFixed(2);
  creditEl.value = Math.max(0, total - cash).toFixed(2);
  updateSummary();
}

function currentStopNeto() {
  const stopId = AppState.params?.stopId;
  const stop = stopId ? AppState.route?.stops.find(s => s.stopId === stopId) : null;
  if (!stop) return 0;
  const draft = stop.deliveryDraft || {};
  const kg = draft.kg || stop.preOrderKg;
  const dev = draft.dev !== undefined ? draft.dev : (stop.devolucionKg || 0);
  const rec = draft.rec !== undefined ? draft.rec : (stop.recompraKg || 0);
  const price = getStopPrice(stop);
  const halfPrice = RECOMPRA_PRICE;
  return kg * price - dev * price + rec * halfPrice;
}

function currentStopObj() {
  const stopId = AppState.params?.stopId;
  return stopId ? AppState.route?.stops.find(s => s.stopId === stopId) : null;
}

// Cash already collected on this order by earlier partial legs (any
// driver, including this driver's own prior partials — that cash is
// already booked in the collections session).
function currentStopYaCobrado() {
  const stop = currentStopObj();
  if (!stop || !stop.orderId) return 0;
  const o = getAdvanceOrder(stop.orderId);
  return o ? sumHandoffCash(o) : 0;
}

function currentStopHasHandoffs() {
  const stop = currentStopObj();
  if (!stop || !stop.orderId) return false;
  const o = getAdvanceOrder(stop.orderId);
  return !!o && orderHandoffs(o).length > 0;
}

// Neto plus outstanding old debt when the "cobrar pendiente" chip is on,
// minus what earlier partial legs already collected.
function currentStopSugerido() {
  const stopId = AppState.params?.stopId;
  const stop = stopId ? AppState.route?.stops.find(s => s.stopId === stopId) : null;
  if (!stop) return 0;
  const neto = currentStopNeto();
  const ya = currentStopYaCobrado();
  const chipOn = !!(document.getElementById('pending-chip') && document.getElementById('pending-chip').classList.contains('erp-pending-chip-on'));
  if (!chipOn) return Math.max(0, neto - ya);
  const pending = getCustomerBalance(stop.customerId);
  return Math.max(0, neto - ya) + (pending > 0.01 ? pending : 0);
}

function toggleCollectPending() {
  const stopId = AppState.params?.stopId;
  const stop = stopId ? AppState.route?.stops.find(s => s.stopId === stopId) : null;
  if (!stop) return;
  const chip = document.getElementById('pending-chip');
  const pending = getCustomerBalance(stop.customerId);
  const neto = currentStopNeto();
  const isOn = chip && chip.classList.contains('erp-pending-chip-on');
  if (chip) chip.classList.toggle('erp-pending-chip-on', !isOn);
  const cashEl = document.getElementById('stop-cash');
  const creditEl = document.getElementById('stop-credit');
  if (!cashEl || !creditEl) return;
  if (!isOn) {
    const total = neto + (pending > 0.01 ? pending : 0);
    cashEl.value = total.toFixed(2);
    creditEl.value = '0.00';
  } else {
    const recKg = parseFloat(document.getElementById('recompra-qty')?.textContent) || 0;
    const cash = recKg > 0 ? recKg * RECOMPRA_PRICE : neto;
    cashEl.value = cash.toFixed(2);
    creditEl.value = Math.max(0, neto - cash).toFixed(2);
  }
  updateSummary();
}

function syncCashToNeto() {
  const stopId = AppState.params?.stopId;
  const stop = stopId ? AppState.route?.stops.find(s => s.stopId === stopId) : null;
  const cashEl = document.getElementById('stop-cash');
  const creditEl = document.getElementById('stop-credit');
  if (!stop || !cashEl || !creditEl) return;
  const kg = parseFloat(document.getElementById('delivery-qty')?.textContent) || 0;
  const dev = parseFloat(document.getElementById('devolucion-qty')?.textContent) || 0;
  const rec = parseFloat(document.getElementById('recompra-qty')?.textContent) || 0;
  const price = getStopPrice(stop);
  const neto = kg * price - dev * price + rec * RECOMPRA_PRICE;
  const recValue = rec * RECOMPRA_PRICE;
  const ya = currentStopYaCobrado();
  if (currentStopHasHandoffs()) {
    // Continuation leg: collect only what earlier legs haven't.
    const total = currentStopSugerido();
    cashEl.value = total.toFixed(2);
    creditEl.value = '0.00';
  } else {
    const netoRemaining = Math.max(0, neto - ya);
    const cash = recValue > 0 ? recValue : netoRemaining;
    cashEl.value = cash.toFixed(2);
    creditEl.value = Math.max(0, netoRemaining - cash).toFixed(2);
  }
}

function saveDeliveryDraft(stopId) {
  const sid = stopId || AppState.params?.stopId;
  if (!sid) return;
  const stop = AppState.route?.stops.find(s => s.stopId === sid);
  if (!stop) return;
  const kg = parseFloat(document.getElementById('delivery-qty')?.textContent) || 0;
  const dev = parseFloat(document.getElementById('devolucion-qty')?.textContent) || 0;
  const rec = parseFloat(document.getElementById('recompra-qty')?.textContent) || 0;
  const cash = parseFloat(document.getElementById('stop-cash')?.value) || 0;
  const credit = parseFloat(document.getElementById('stop-credit')?.value) || 0;
  const prev = stop.deliveryDraft || {};
  const inventoryExpanded = prev.inventoryExpanded || false;
  const collectPending = !!(document.getElementById('pending-chip') && document.getElementById('pending-chip').classList.contains('erp-pending-chip-on'));
  const driver = AppState.driver || {};
  const updatedAt = new Date().toISOString();
  stop.deliveryDraft = { kg, dev, rec, cash, credit, inventoryExpanded, collectPending, driverId: driver.id, driverName: driver.name, updatedAt };
  if (stop.orderId) {
    const o = getAdvanceOrder(stop.orderId);
    if (o) { o.deliveryDraft = { kg, dev, rec, cash, credit, inventoryExpanded, collectPending, driverId: driver.id, driverName: driver.name, updatedAt }; saveAdvanceOrders(); }
  } else {
    saveStopProgress(AppState.routeName, AppState.route.stops);
  }
}

function updateSummary() {
  const qtyEl = document.getElementById('delivery-qty');
  if (!qtyEl) return;
  const kg = parseFloat(qtyEl.textContent) || 0;
  const devKg = parseFloat(document.getElementById('devolucion-qty')?.textContent) || 0;
  const recKg = parseFloat(document.getElementById('recompra-qty')?.textContent) || 0;
  const stopId = AppState.params?.stopId;
  const stop = stopId ? AppState.route?.stops.find(s => s.stopId === stopId) : null;
  const price = stop ? getStopPrice(stop) : getProductPrice('P1');
  const halfPrice = RECOMPRA_PRICE;
  const neto = kg * price - devKg * price + recKg * halfPrice;

  const subEl = document.getElementById('stop-subtotal');
  if (subEl) subEl.textContent = formatCurrency(kg * price);

  const devMonto = document.getElementById('devolucion-monto');
  if (devMonto) devMonto.textContent = devKg > 0 ? '−' + formatCurrency(devKg * price) : '$0';

  const recMonto = document.getElementById('recompra-monto');
  if (recMonto) recMonto.textContent = formatCurrency(recKg * halfPrice);

  const netoValEl = document.getElementById('stop-neto-val');
  if (netoValEl) netoValEl.textContent = formatCurrency(neto);

  const chip = document.getElementById('pending-chip');
  const chipOn = !!(chip && chip.classList.contains('erp-pending-chip-on'));
  const pending = stop ? getCustomerBalance(stop.customerId) : 0;
  const yaCobradoSummary = currentStopYaCobrado();
  const sugerido = Math.max(0, neto - yaCobradoSummary) + (chipOn ? (pending > 0.01 ? pending : 0) : 0);

  const sugeridoEl = document.getElementById('stop-sugerido');
  const sugeridoRow = document.getElementById('sugerido-row');
  if (sugeridoRow) sugeridoRow.style.display = chipOn ? 'flex' : 'none';
  if (sugeridoEl) sugeridoEl.textContent = formatCurrency(sugerido);

  const cash = parseFloat(document.getElementById('stop-cash')?.value) || 0;
  const credit = parseFloat(document.getElementById('stop-credit')?.value) || 0;

  const footerEl = document.getElementById('stop-total-footer');
  if (footerEl) footerEl.textContent = formatCurrency(sugerido);

  saveDeliveryDraft();
}

function onStreetProductChange() {
  const prod = document.getElementById('street-product');
  const priceEl = document.getElementById('street-price');
  if (prod && priceEl) priceEl.value = getProductPrice(prod.value) || '';
  updateStreetTotal();
}

function updateStreetTotal() {
  const qty = parseFloat(document.getElementById('street-qty')?.textContent) || 0;
  const price = parseFloat(document.getElementById('street-price')?.value) || 0;
  const totalEl = document.getElementById('street-total');
  if (totalEl) totalEl.textContent = formatCurrency(qty * price);
}

function onStreetPriceInput() { updateStreetTotal(); }

function adjustStreet(delta) {
  const el = document.getElementById('street-qty');
  if (!el) return;
  let v = parseFloat(el.textContent) + delta;
  v = Math.max(0.5, Math.min(20, v));
  v = Math.round(v * 2) / 2;
  el.textContent = v;
  updateStreetTotal();
}

function confirmStreetSale() {
  const prodId = document.getElementById('street-product')?.value;
  const qty = parseFloat(document.getElementById('street-qty')?.textContent) || 0;
  const price = parseFloat(document.getElementById('street-price')?.value) || 0;
  const total = qty * price;
  const description = document.getElementById('street-description')?.value.trim() || '';

  if (qty <= 0 || price <= 0) { showToast('❌ Cantidad o precio inválidos'); return; }
  if (!description) { showToast('❌ Ingresa una descripción de la venta'); return; }

  addExtraSale(prodId, qty, total, description);
  showToast('✅ Venta registrada: ' + formatCurrency(total));
  App.goBack();
}

// ─── SIGNATURE SHEET ──────────────────────────────────
function renderSignatureSheet() {
  const sheet = AppState.signatureSheet;
  if (!sheet) return '';
  const stopId = sheet.stopId;
  const stop = AppState.route?.stops.find(s => s.stopId === stopId);
  if (!stop) return '';
  const draft = stop.deliveryDraft || {};
  const kg = draft.kg || stop.preOrderKg;
  const dev = draft.dev !== undefined ? draft.dev : (stop.devolucionKg || 0);
  const rec = draft.rec !== undefined ? draft.rec : (stop.recompraKg || 0);
  const cash = draft.cash || 0;
  const price = getStopPrice(stop);
  const halfPrice = RECOMPRA_PRICE;
  const sigOrder = stop.orderId ? getAdvanceOrder(stop.orderId) : null;
  const yaCobradoSig = sigOrder ? sumHandoffCash(sigOrder) : 0;
  const neto = kg * price - dev * price + rec * halfPrice;
  const credit = draft.credit !== undefined ? draft.credit : Math.max(0, neto - yaCobradoSig - cash);
  const orderId = stop.orderId || stop.stopId || '—';

  return `
    <div class="sheet-overlay" onclick="closeSignatureSheet()">
      <div class="sheet-container" onclick="event.stopPropagation()">
        <div class="sheet-header">
          <div class="sheet-handle"></div>
          <div class="sheet-header-row">
            <div class="sheet-header-title">Cierre de Entrega</div>
            <button class="sheet-close" onclick="closeSignatureSheet()">✕</button>
          </div>
          <div class="sheet-header-sub">${stop.customerName} · #${orderId}</div>
        </div>
        <div class="sheet-body">
          <div class="signature-summary-grid">
            <div class="summary-item">
              <span class="summary-label">Despacho</span>
              <span class="summary-value">${kg.toFixed(2)} kg</span>
            </div>
            <div class="summary-item">
              <span class="summary-label">Total Venta</span>
              <span class="summary-value summary-value--green">${formatCurrency(neto)}</span>
            </div>
            ${yaCobradoSig > 0 ? `
            <div class="summary-item">
              <span class="summary-label">Ya cobrado</span>
              <span class="summary-value">−${formatCurrency(yaCobradoSig)}</span>
            </div>
            ` : ''}
            <div class="summary-item">
              <span class="summary-label">A Crédito</span>
              <span class="summary-value summary-value--amber">${formatCurrency(credit)}</span>
            </div>
            <div class="summary-item">
              <span class="summary-label">Efectivo</span>
              <span class="summary-value">${formatCurrency(cash)}</span>
            </div>
          </div>

          <div class="sig-sheet-area">
            <span class="sig-sheet-label">FIRME AQUÍ CON EL DEDO</span>
            <div class="sig-sheet-canvas-wrap" id="sig-area">
              <span id="sig-placeholder" style="font-size:12px;color:var(--slate-400);font-family:monospace;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);pointer-events:none">Firma aquí</span>
              <canvas class="signature-canvas" id="sig-canvas" width="400" height="120"></canvas>
            </div>
          </div>
        </div>
        <div class="sheet-footer">
          <button class="sig-confirm-btn" onclick="confirmSignatureFromSheet('${stopId}')">CONFIRMAR Y FINALIZAR PARADA</button>
          <div class="sig-disclaimer">Al confirmar, se registrará la venta y el cobro correspondiente. Esta acción no se puede deshacer.</div>
        </div>
      </div>
    </div>
  `;
}

function openSignatureSheet(stopId) {
  saveDeliveryDraft(stopId);
  AppState.signatureSheet = { stopId };
  render();
  setTimeout(() => setupSignaturePad(), 50);
}

function closeSignatureSheet() {
  const sheet = AppState.signatureSheet;
  if (sheet) saveDeliveryDraft(sheet.stopId);
  AppState.signatureSheet = null;
  render();
}

function confirmSignatureFromSheet(stopId) {
  if (!isSigDrawn) { showToast('✍️ Pide la firma del cliente'); return; }
  closeSignatureSheet();
  confirmStop(stopId);
}

function confirmStop(stopId) {
  const stop = AppState.route.stops.find(s => s.stopId === stopId);
  if (!stop) return;
  const price = getStopPrice(stop);
  const halfPrice = RECOMPRA_PRICE;

  const qty = parseFloat(document.getElementById('delivery-qty')?.textContent) || 0;
  if (qty <= 0) { showToast('❌ La cantidad debe ser mayor a 0'); return; }

  const devKg = parseFloat(document.getElementById('devolucion-qty')?.textContent) || 0;
  const recKg = parseFloat(document.getElementById('recompra-qty')?.textContent) || 0;
  const cash = parseFloat(document.getElementById('stop-cash')?.value) || 0;
  const creditAmount = parseFloat(document.getElementById('stop-credit')?.value) || 0;
  const neto = qty * price - devKg * price + recKg * halfPrice;

  // Cash already booked by earlier partial legs on this order (any driver).
  const orderRec = stop.orderId ? getAdvanceOrder(stop.orderId) : null;
  const yaCobrado = orderRec ? sumHandoffCash(orderRec) : 0;
  const base = Math.max(0, neto - yaCobrado); // remaining sale value to collect on this leg

  const chipOn = !!(document.getElementById('pending-chip') && document.getElementById('pending-chip').classList.contains('erp-pending-chip-on'));
  const pending = getCustomerBalance(stop.customerId);
  const sugerido = base + (chipOn && pending > 0.01 ? pending : 0);

  const balance = cash + creditAmount;
  if (Math.abs(balance - sugerido) > 0.01) {
    showToast('❌ Efectivo + Crédito debe ser igual al Total a Cobrar');
    return;
  }

  const todayCredit = Math.max(0, base - cash);
  const oldDebtPaid = chipOn && pending > 0.01 ? Math.min(pending, Math.max(0, cash - base)) : 0;

  if (todayCredit > 0) {
    const cust = getCustomer(stop.customerId);
    if (cust && cust.creditLimit > 0 && todayCredit > cust.creditLimit) {
      showToast('❌ El crédito excede el límite de ' + formatCurrency(cust.creditLimit));
      return;
    }
  }

  const recompraValue = recKg * halfPrice;
  const recompraCollected = Math.min(recompraValue, cash);

  stop.devolucionKg = devKg;
  stop.recompraKg = recKg;
  stop.recompraCollected = recompraCollected;
  stop.oldDebtPaid = oldDebtPaid;
  stop.deliveryDraft = null;

  if (stop.orderId) {
    const o = getAdvanceOrder(stop.orderId);
    if (o) {
      o.status = 'completed';
      o.devolucionKg = devKg;
      o.recompraKg = recKg;
      o.recompraCollected = recompraCollected;
      o.deliveredKg = qty;
      o.creditAmount = todayCredit;
      o.creditPaidType = cash > 0 ? 'cash' : null;
      o.creditPaidAmount = yaCobrado + cash; // total cash across all legs
      o.oldDebtPaid = oldDebtPaid;
      o.completedAt = new Date().toISOString();
      o.completedBy = AppState.driver.id;
      o.completedByName = AppState.driver.name;
      o.updatedAt = new Date().toISOString();
      saveAdvanceOrders();

      if (cash > 0) {
        addCollection(stop.customerId, cash); // current leg only — partials booked their own
      }

      const trip = AppState.trips.find(t => t.orderIds.includes(o.id));
      try { if (typeof ErpOutbox !== 'undefined') ErpOutbox.emitOrderCompleted(o, trip); } catch (e) { console.error('erp outbox emit failed', e); }
      if (trip) {
        const all = trip.orderIds.every(oid => {
          const ord = advanceOrders.find(x => x.id === oid);
          return ord && (ord.status === 'completed' || ord.status === 'skipped');
        });
        if (all) {
          trip.status = 'completed';
          trip.completedBy = AppState.driver.id;
          trip.completedByName = AppState.driver.name;
          trip.completedAt = new Date().toISOString();
          trip.updatedAt = trip.completedAt;
          saveTrips();
          showToast('🎉 ¡Ruta completada!');
        }
      }
    }
    stop.status = 'completed';
    stop.deliveredKg = qty;
    stop.creditAmount = todayCredit;
    stop.creditPaidType = cash > 0 ? 'cash' : null;
    stop.creditPaidAmount = yaCobrado + cash;
    saveStopProgress(AppState.routeName, AppState.route.stops);
  } else {
    stop.creditAmount = todayCredit;
    if (cash > 0) {
      stop.creditPaidType = 'cash';
      stop.creditPaidAmount = cash;
      addCollection(stop.customerId, cash);
    }
    completeStop(stopId);

  }

  if (todayCredit > 0) {
    recordCustomerCredit(stop.customerId, todayCredit);
  }

  if (oldDebtPaid > 0.01) {
    recordDebtPayment(stop.customerId, oldDebtPaid);
  }

  showToast('✅ Parada completada');
  App.goBack();
}

// ─── PARTIAL DELIVERY (split handoff) ───────────────────
// Books the cash THIS driver collected immediately (true to who holds
// the cash), logs a cumulative handoff entry on the order, and leaves
// the order pending with its draft for the next driver.
function commitPartialDelivery(stopId) {
  const stop = AppState.route?.stops.find(s => s.stopId === stopId);
  if (!stop) return;
  const o = stop.orderId ? getAdvanceOrder(stop.orderId) : null;
  if (!o) { showToast('❌ Orden no encontrada'); return; }
  if (o.status !== 'pending') { showToast('❌ La orden ya está cerrada'); return; }

  const qty = parseFloat(document.getElementById('delivery-qty')?.textContent) || 0;
  if (qty <= 0) { showToast('❌ La cantidad debe ser mayor a 0'); return; }
  if (qty >= stop.preOrderKg) { showToast('⚠️ Cantidad completa — usa FIRMAR Y REGISTRAR'); return; }

  const devKg = parseFloat(document.getElementById('devolucion-qty')?.textContent) || 0;
  const recKg = parseFloat(document.getElementById('recompra-qty')?.textContent) || 0;
  const cash = parseFloat(document.getElementById('stop-cash')?.value) || 0;
  const me = AppState.driver;
  const now = new Date().toISOString();

  const handoffs = orderHandoffs(o);
  const mine = handoffs.find(h => h.by === me.id);
  if (mine) {
    // Same driver re-committing: adjust the collections delta so cash
    // is never double-booked.
    const delta = cash - (Number(mine.cash) || 0);
    if (delta !== 0) addCollection(stop.customerId, delta);
    mine.cash = cash;
    mine.kg = qty;
    mine.dev = devKg;
    mine.rec = recKg;
    mine.at = now;
  } else {
    if (cash > 0) addCollection(stop.customerId, cash);
    handoffs.push({
      by: me.id, byName: me.name, at: now,
      kg: qty, dev: devKg, rec: recKg, cash,
    });
    o.deliveryHandoffs = handoffs;
  }
  o.updatedAt = now;
  saveDeliveryDraft(stopId);
  saveAdvanceOrders();
  AppState.partialSheet = null;
  showToast('🤝 Parcial guardado — ' + qty + 'kg' + (cash > 0 ? ' · ' + formatCurrency(cash) + ' cobrados' : ''));
  App.goBack();
}

function renderPartialSheet() {
  const sheet = AppState.partialSheet;
  if (!sheet) return '';
  const stop = AppState.route?.stops.find(s => s.stopId === sheet.stopId);
  if (!stop) return '';
  const kg = parseFloat(document.getElementById('delivery-qty')?.textContent) || 0;
  const devKg = parseFloat(document.getElementById('devolucion-qty')?.textContent) || 0;
  const recKg = parseFloat(document.getElementById('recompra-qty')?.textContent) || 0;
  const cash = parseFloat(document.getElementById('stop-cash')?.value) || 0;
  const price = getStopPrice(stop);
  const halfPrice = RECOMPRA_PRICE;
  const neto = kg * price - devKg * price + recKg * halfPrice;
  const yaCobrado = stop.orderId && getAdvanceOrder(stop.orderId) ? sumHandoffCash(getAdvanceOrder(stop.orderId)) : 0;
  const quedan = Math.max(0, stop.preOrderKg - kg);
  const orderId = stop.orderId || stop.stopId || '—';

  return `
    <div class="sheet-overlay" onclick="App.closePartialSheet()">
      <div class="sheet-container" onclick="event.stopPropagation()">
        <div class="sheet-header">
          <div class="sheet-handle"></div>
          <div class="sheet-header-row">
            <div class="sheet-header-title">🤝 Guardar Parcial</div>
            <button class="sheet-close" onclick="App.closePartialSheet()">✕</button>
          </div>
          <div class="sheet-header-sub">${stop.customerName} · #${orderId}</div>
        </div>
        <div class="sheet-body">
          <div class="signature-summary-grid">
            <div class="summary-item">
              <span class="summary-label">Entregado</span>
              <span class="summary-value">${kg.toFixed(2)} kg</span>
            </div>
            <div class="summary-item">
              <span class="summary-label">Quedan</span>
              <span class="summary-value summary-value--amber">${quedan.toFixed(2)} kg</span>
            </div>
            <div class="summary-item">
              <span class="summary-label">Venta parcial</span>
              <span class="summary-value summary-value--green">${formatCurrency(neto)}</span>
            </div>
            <div class="summary-item">
              <span class="summary-label">Cobras tú</span>
              <span class="summary-value">${formatCurrency(cash)}</span>
            </div>
          </div>
          ${yaCobrado > 0 ? `<div style="font-size:11px;color:var(--slate-500);font-family:monospace;padding:4px 12px 0">Ya cobrado antes en esta orden: ${formatCurrency(yaCobrado)}</div>` : ''}
          <div class="sig-disclaimer" style="padding:8px 12px 0">El efectivo se registra a tu nombre ahora. La orden queda pendiente con ${quedan.toFixed(2)} kg por entregar.</div>
        </div>
        <div class="sheet-footer">
          <button class="sig-confirm-btn" onclick="commitPartialDelivery('${stop.stopId}')">CONFIRMAR PARCIAL</button>
          <button class="erp-btn erp-btn-secondary erp-btn-block" style="margin-top:8px" onclick="App.closePartialSheet()">Seguir editando</button>
        </div>
      </div>
    </div>
  `;
}

function skipStopConfirm(stopId) {
  const stop = AppState.route.stops.find(s => s.stopId === stopId);
  if (!stop) return;
  AppState.skipReasonModal = { stopId, orderId: stop.orderId };
  render();
}

let foPaid = false;
function selectFOPaid(paid) {
  foPaid = paid;
  document.getElementById('fo-paid-yes').classList.toggle('selected', paid);
  document.getElementById('fo-paid-no').classList.toggle('selected', !paid);
  document.getElementById('fo-amount-section').style.display = paid ? 'block' : 'none';
}

function saveFutureOrder() {
  const name = document.getElementById('fo-name')?.value.trim();
  const phone = document.getElementById('fo-phone')?.value.trim();
  const prodId = document.getElementById('fo-product')?.value;
  const qty = parseFloat(document.getElementById('fo-qty')?.value) || 0;
  const date = document.getElementById('fo-date')?.value;
  const notes = document.getElementById('fo-notes')?.value.trim() || '';

  if (!name) { showToast('❌ Ingresa el nombre del cliente'); return; }
  if (qty <= 0) { showToast('❌ Cantidad inválida'); return; }
  if (!date) { showToast('❌ Selecciona una fecha'); return; }

  const prepaidAmount = foPaid ? (parseFloat(document.getElementById('fo-amount')?.value) || 0) : 0;

  addFutureOrder({ customerName: name, phone, productId: prodId, qty, deliveryDate: date, prepaid: foPaid, prepaidAmount, notes });
  showToast('✅ Pedido guardado para el ' + formatDate(date));
  App.goBack();
}

function finishDay() {
  const data = getSettlementData();
  const p1 = getProductPrice('P1');
  const route = AppState.route;
  const stops = route ? route.stops.filter(s => s.status === 'completed' || s.status === 'skipped').map(s => ({
    stopId: s.stopId, orderId: s.orderId || null, customerName: s.customerName, customerId: s.customerId,
    productId: s.productId || null,
    price: getStopPrice(s),
    preOrderKg: s.preOrderKg || 0, devolucionKg: s.devolucionKg || 0,
    recompraKg: s.recompraKg || 0, recompraCollected: s.recompraCollected || 0,
    deliveredKg: s.deliveredKg || 0,
    creditAmount: s.creditAmount || 0, extraKg: s.extraKg || 0,
    oldDebtPaid: s.oldDebtPaid || 0,
    status: s.status, completedAt: s.completedAt || null,
  })) : [];
  const snapshot = {
    id: genId(),
    date: AppState.routeDate || today(),
    routeName: AppState.routeName,
    driverName: AppState.driver.name,
    timestamp: new Date().toISOString(),
    // ── ERP integration fields (additive) ──
    currency: 'MXN',
    closedBy: AppState.driver.id,
    closedByName: AppState.driver.name,
    closedAt: new Date().toISOString(),
    posted: false,
    erpRef: null,
    startingInventory: data.startingInventory,
    totalDelivered: data.totalDelivered,
    totalExtraSold: data.totalExtraSold,
    totalStaleReturned: data.totalStaleReturned,
    totalRecompra: data.totalRecompra,
    totalRecompraCollected: data.totalRecompraCollected,
    totalCredited: data.totalCredited,
    totalCash: data.totalCash,
    totalCard: data.totalCard,
    totalCollected: data.totalCollected,
    recompraValue: data.recompraValue,
    streetTotal: data.streetTotal,
    devValue: data.devValue,
    brutoValue: data.brutoValue,
    stopsCount: route ? route.stops.length : 0,
    completedStopsCount: stops.length,
    stops,
  };
  DB.SettlementHistory.addSnapshot(snapshot);
  // ERP outbox: end-of-day settlement is the posting boundary.
  if (typeof ErpOutbox !== 'undefined') {
    try { ErpOutbox.emitSettlementClose(snapshot); } catch (e) { console.error('erp outbox emit failed', e); }
  }
  showToast('🎉 Jornada finalizada. ¡Buen trabajo ' + AppState.driver.name.split(' ')[0] + '!');
  setTimeout(() => {
    AppState.screen = 'mainMenu';
    AppState.params = {};
    AppState.reportTab = 'settlement';
    render();
  }, 1500);
}

// ─── ORDER FORM (Admin: create advance orders) ─────────
function renderOrderForm() {
  const showForm = AppState.showOrderForm;
  return {
    html: `
      <div class="erp-screen">
        <div style="display:flex;align-items:center;gap:8px;padding:10px 10px 4px">
          <button class="erp-btn erp-btn-sm" onclick="App.goBack()">← VOLVER</button>
          <div style="flex:1">
            <div style="font-size:15px;font-weight:700;color:var(--slate-900)">Pedidos</div>
            <div style="font-size:10px;color:var(--slate-400);font-family:monospace">Órdenes activas</div>
          </div>
          <button class="erp-btn erp-btn-sm erp-btn-primary" onclick="App.openOrderForm()">+ NUEVO</button>
        </div>
        <div style="flex:1;overflow-y:auto;padding:8px 10px 80px">

          <div style="background:white;border:1px solid var(--slate-200);margin-bottom:10px">
            <div style="cursor:pointer;display:flex;justify-content:space-between;align-items:center;padding:10px 14px" onclick="App.toggleOrderForm()">
              <span style="font-size:13px;font-weight:700;color:var(--slate-900)">${showForm ? '▼' : '▶'} Nuevo pedido</span>
              ${!showForm ? '<span style="font-size:10px;color:var(--slate-400);font-family:monospace">Tap para crear</span>' : ''}
            </div>
            <div id="order-form-body" style="${showForm ? '' : 'display:none'}">
              <div style="padding:0 14px 14px">
                <div class="erp-field">
                  <div class="erp-label">Cliente</div>
                  <select class="erp-select" id="order-customer" onchange="updateOrderRoute()">
                    <option value="">Seleccionar cliente...</option>
                    ${activeCustomers().map(c => `
                      <option value="${c.id}" data-route="${c.route}">${c.name}</option>
                    `).join('')}
                  </select>
                </div>
                <div class="erp-field">
                  <div class="erp-label">Ruta</div>
                  <select class="erp-select" id="order-route">
                    <option value="">Seleccionar ruta...</option>
                    ${ROUTES.map(r => `
                      <option value="${r}">${r}</option>
                    `).join('')}
                  </select>
                </div>
                <div class="erp-field">
                  <div class="erp-label">Artículo</div>
                  <select class="erp-select" id="order-product">
                    ${PRODUCTOS.map(p => `
                      <option value="${p.id}" data-price="${getProductPrice(p.id)}" ${p.id === 'P1' ? 'selected' : ''}>${p.icon} ${p.name} — ${formatCurrency(getProductPrice(p.id))}/kg</option>
                    `).join('')}
                  </select>
                </div>
                <div style="display:flex;gap:8px">
                  <div class="erp-field" style="flex:1">
                    <div class="erp-label">Cantidad (kg)</div>
                    <input class="erp-input" id="order-qty" type="number" min="0.5" step="0.5" placeholder="0">
                  </div>
                  <div class="erp-field" style="flex:1">
                    <div class="erp-label">Precio</div>
                    <input class="erp-input" id="order-price" type="number" min="0" step="0.5" placeholder="${getProductPrice('P1')}">
                  </div>
                </div>
                <div style="margin-top:4px;font-size:11px;color:var(--slate-500);font-family:monospace" id="order-preview"></div>
                <div style="display:flex;gap:8px">
                  <div class="erp-field" style="flex:1">
                    <div class="erp-label">Fecha de entrega</div>
                    <input class="erp-input" id="order-date" type="date" value="${today()}">
                  </div>
                  <div class="erp-field" style="flex:1">
                    <div class="erp-label">Instrucciones</div>
                    <textarea class="erp-textarea" id="order-instructions" rows="1" placeholder="Ej: antes de las 9am..."></textarea>
                  </div>
                </div>
                <div style="border-top:1px solid var(--slate-200);margin-top:8px;padding-top:12px">
                  <div style="display:flex;justify-content:space-between;align-items:center">
                    <span style="font-size:11px;font-weight:700;font-family:monospace;text-transform:uppercase;color:var(--slate-500)">🔄 Repetir pedido</span>
                    <button class="erp-btn erp-btn-sm" onclick="setupOrderRecurrence()">Configurar</button>
                  </div>
                  <div style="font-size:12px;color:var(--slate-500);font-family:monospace;margin-top:4px" id="order-recurrence-summary">${recurrenceSummary(AppState.orderRecurrence)}</div>
                </div>
                <button class="erp-btn erp-btn-primary erp-btn-block" id="order-submit" onclick="submitOrder()" disabled style="margin-top:8px">
                  ${AppState.editingOrderId ? '✓ Actualizar pedido' : '✓ Crear pedido'}
                </button>
                <div id="order-toast" style="display:none;margin-top:8px;padding:8px;text-align:center;font-size:12px;font-weight:600"></div>
                ${AppState.editingOrderId ? '<div style="text-align:center;margin-top:4px"><button class="erp-btn erp-btn-sm" onclick="cancelEditOrder()">Cancelar edición</button></div>' : ''}
              </div>
            </div>
          </div>

          <div style="display:flex;justify-content:space-between;align-items:center;padding:0 4px 6px">
            <span style="font-size:11px;font-weight:700;font-family:monospace;text-transform:uppercase;color:var(--slate-500)">📋 Órdenes activas</span>
            <span class="erp-chip erp-chip-blue">${getAllAdvanceOrders().filter(o => o.status === 'pending').length}</span>
          </div>
          ${(() => {
            const active = getAllAdvanceOrders().filter(o => o.status === 'pending');
            const sel = AppState.selectedOrders || [];
            const allSelected = active.length > 0 && active.every(o => sel.includes(o.id));
            if (active.length === 0) return '<div style="font-size:12px;color:var(--slate-400);font-family:monospace;padding:12px 4px">Sin órdenes pendientes</div>';
            return `
            <table class="erp-order-table">
              <thead><tr>
                <th class="check"><input type="checkbox" ${allSelected ? 'checked' : ''} onchange="App.toggleSelectAllOrders(this.checked)"></th>
                <th>Cliente</th>
                <th>Fecha</th>
                <th>Artículo</th>
                <th class="num">Cantidad</th>
                <th class="num">Total</th>
                <th>Ruta</th>
              </tr></thead>
              <tbody>
                ${active.map(o => {
                  const checked = sel.includes(o.id);
                  const d = o.date ? formatDateShort(o.date) : '—';
                  const isEditing = AppState.editingOrderId === o.id;
                  return `
                  <tr class="${isEditing ? 'editing' : ''}">
                    <td class="check" onclick="event.stopPropagation()"><input type="checkbox" ${checked ? 'checked' : ''} onchange="App.toggleSelectOrder('${o.id}',this.checked)"></td>
                    <td class="name">${o.recurrence && o.recurrence.preset && o.recurrence.preset !== 'none' ? '<span title="Pedido recurrente (plantilla)">🔁</span> ' : o.source === 'recurring' ? '<span title="Generado automáticamente por pedido recurrente">♻️</span> ' : ''}${o.customerName}</td>
                    <td class="date">${d}</td>
                    <td class="prod">${o.productName}</td>
                    <td class="num">${o.qty} kg</td>
                    <td class="num">${formatCurrency(o.price * o.qty)}</td>
                    <td>${o.route ? `<span class="erp-chip erp-chip-blue">${o.route}</span>` : '<span style="font-size:10px;color:var(--slate-400)">—</span>'}</td>
                  </tr>
                  ${checked && sel.length === 1 ? `
                  <tr>
                    <td colspan="7" style="padding:4px 12px 6px">
                      <div class="erp-order-actions">
                        <button class="erp-btn erp-btn-sm" style="color:var(--green-700);border-color:var(--green-700)" onclick="editOrder('${o.id}');event.stopPropagation()">Editar</button>
                        <button class="erp-btn erp-btn-sm" onclick="cancelOrder('${o.id}');event.stopPropagation()">Cancelar</button>
                        <button class="erp-btn erp-btn-sm erp-btn-danger" onclick="deleteOrder('${o.id}');event.stopPropagation()">Eliminar</button>
                      </div>
                    </td>
                  </tr>` : ''}`;
                }).join('')}
              </tbody>
            </table>
            ${sel.length > 1 ? `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:6px 8px;border-top:1px solid var(--slate-200)">
              <span style="font-size:11px;color:var(--slate-500);font-family:monospace">${sel.length} seleccionados</span>
              <button class="erp-btn erp-btn-sm erp-btn-danger" onclick="bulkDeleteOrders()">🗑️ Eliminar</button>
            </div>` : ''}`;
          })()}

        </div>
      </div>
    `,
    init: () => {
      const customerEl = document.getElementById('order-customer');
      const productEl = document.getElementById('order-product');
      const qtyEl = document.getElementById('order-qty');
      const priceEl = document.getElementById('order-price');
      const submitEl = document.getElementById('order-submit');
      const previewEl = document.getElementById('order-preview');

      function validate() {
        const ok = customerEl.value && productEl.value && parseFloat(qtyEl.value) > 0 && parseFloat(priceEl.value) > 0;
        submitEl.disabled = !ok;
      }

      customerEl.addEventListener('change', () => {
        const cust = customerEl.value ? getCustomer(customerEl.value) : null;
        const prodOpt = productEl.options[productEl.selectedIndex];
        if (!AppState.editingOrderId && cust && cust.defaultPrice > 0) {
          priceEl.value = cust.defaultPrice;
        } else if (!AppState.editingOrderId && prodOpt && prodOpt.dataset.price && productEl.value) {
          priceEl.value = prodOpt.dataset.price;
        }
        validate();
      });
      productEl.addEventListener('change', () => {
        const opt = productEl.options[productEl.selectedIndex];
        const cust = customerEl.value ? getCustomer(customerEl.value) : null;
        if (!AppState.editingOrderId && cust && cust.defaultPrice > 0) {
          priceEl.value = cust.defaultPrice;
        } else if (!AppState.editingOrderId && opt && opt.dataset.price) {
          priceEl.value = opt.dataset.price;
        }
        validate();
      });
      qtyEl.addEventListener('input', () => {
        const q = parseFloat(qtyEl.value) || 0;
        const p = parseFloat(priceEl.value) || 0;
        previewEl.textContent = q > 0 && p > 0 ? 'Total: ' + formatCurrency(q * p) : '';
        validate();
      });
      priceEl.addEventListener('input', () => {
        const q = parseFloat(qtyEl.value) || 0;
        const p = parseFloat(priceEl.value) || 0;
        previewEl.textContent = q > 0 && p > 0 ? 'Total: ' + formatCurrency(q * p) : '';
        validate();
      });

      const editId = AppState.editingOrderId;
      if (editId) {
        const o = getAllAdvanceOrders().find(x => x.id === editId);
        if (o) {
          customerEl.value = o.customerId;
          const routeEl = document.getElementById('order-route');
          const opt = customerEl.options[customerEl.selectedIndex];
          if (opt && opt.dataset.route) routeEl.value = opt.dataset.route;
          else routeEl.value = o.route;
          productEl.value = o.productId;
          qtyEl.value = o.qty;
          priceEl.value = o.price;
          document.getElementById('order-date').value = o.date || today();
          document.getElementById('order-instructions').value = o.instructions || '';
          previewEl.textContent = 'Total: ' + formatCurrency(o.qty * o.price);
          validate();
        }
      } else {
        const opt = productEl.options[productEl.selectedIndex];
        const cust = customerEl.value ? getCustomer(customerEl.value) : null;
        if (cust && cust.defaultPrice > 0) priceEl.value = cust.defaultPrice;
        else if (opt && opt.dataset.price) priceEl.value = opt.dataset.price;
        validate();
      }
    }
  };
}

function resolveCustomerRoute(customerId) {
  const c = getCustomer(customerId);
  if (!c) return null;
  const dir = (c.direccion || '').trim();
  if (dir) {
    const match = ROUTES.find(r => r.toLowerCase() === dir.toLowerCase());
    if (match) return match;
  }
  return c.route || null;
}

function updateOrderRoute() {
  const el = document.getElementById('order-customer');
  const routeEl = document.getElementById('order-route');
  const opt = el.options[el.selectedIndex];
  const resolved = el.value ? resolveCustomerRoute(el.value) : null;
  if (resolved) {
    routeEl.value = resolved;
  } else if (opt && opt.dataset.route) {
    routeEl.value = opt.dataset.route;
  }
}

function setupOrderRecurrence() {
  showRecurrenceSheet({ current: AppState.orderRecurrence || null }, (result) => {
    if (!result) return;
    AppState.orderRecurrence = result.preset === 'none' ? null : result;
    const summaryEl = document.getElementById('order-recurrence-summary');
    if (summaryEl) summaryEl.textContent = recurrenceSummary(AppState.orderRecurrence);
  });
}

function submitOrder() {
  const customerId = document.getElementById('order-customer').value;
  const productId = document.getElementById('order-product').value;
  const qty = document.getElementById('order-qty').value;
  const price = document.getElementById('order-price').value;
  const route = document.getElementById('order-route').value;
  const instructions = document.getElementById('order-instructions').value;
  const orderDate = document.getElementById('order-date').value || today();

  if (!customerId || !productId || !qty || !price) return;

  const editId = AppState.editingOrderId;
  const recurrence = AppState.orderRecurrence;

  if (editId) {
    updateAdvanceOrder(editId, { customerId, productId, qty, price, route, instructions, date: orderDate, recurrence });
    AppState.editingOrderId = null;
  } else {
    addAdvanceOrder(customerId, productId, qty, price, route, instructions, orderDate, recurrence);
  }

  AppState.orderRecurrence = null;
  AppState.showOrderForm = false;

  const toast = document.getElementById('order-toast');
  toast.style.display = 'block';
  toast.style.background = 'rgba(34,197,94,0.15)';
  toast.style.color = 'var(--success)';
  toast.textContent = editId
    ? '✓ Pedido actualizado para ' + getCustomer(customerId).name
    : '✓ Pedido creado para ' + getCustomer(customerId).name;

  document.getElementById('order-customer').value = '';
  document.getElementById('order-product').value = 'P1';
  document.getElementById('order-qty').value = '';
  document.getElementById('order-price').value = getProductPrice('P1');
  document.getElementById('order-route').value = '';
  document.getElementById('order-instructions').value = '';
  document.getElementById('order-preview').textContent = '';
  document.getElementById('order-submit').disabled = true;

  setTimeout(() => { toast.style.display = 'none'; render(); }, 2500);
}

function navigateToStop(stopId, routeName) {
  if (routeName && routeName !== AppState.routeName) {
    AppState._prevRouteFilter = AppState.routeFilter;
    AppState._prevRouteName = AppState.routeName;
    AppState._prevRoute = AppState.route;
    AppState.routeName = routeName;
    AppState.routeFilter = routeName;
    AppState.extraSales = [];
    AppState.collections = [];
    AppState.creditModal = null;
  }
  App.navigate('stop', { stopId });
}

// Opens the submitted stop where a customer's old debt was registered.
// Prefers the live route (same-day debt), then falls back to scanning
// settlement history snapshots for the originating stop.
function openDebtStop(stopId, orderId, routeName) {
  const live = stopId ? findStop(stopId) : null;
  if (live) { App.navigate('stop', { stopId }); return; }
  if (orderId) {
    const o = getAdvanceOrder(orderId);
    if (o) { App.navigate('stop', { stopId: 'S-' + o.id, orderId: o.id }); return; }
  }
  const hist = findHistoricalStop(stopId, orderId, routeName);
  if (hist) {
    AppState.currentStop = hist;
    AppState.historicalStop = true;
    App.navigate('stop', { stopId: hist.stopId, historical: true });
    return;
  }
  showToast('❌ No se encontró la parada original');
}

// Searches settlement snapshots for a completed stop and reconstructs a
// read-only stop object (only fields the read-only view needs).
function findHistoricalStop(stopId, orderId, routeName) {
  const snaps = DB.SettlementHistory.load();
  const snap = snaps.find(s => (!routeName || s.routeName === routeName) &&
    (s.stops || []).some(st =>
      (stopId && (st.stopId === stopId || st.orderId === stopId)) ||
      (orderId && (st.orderId === orderId || st.stopId === 'S-' + orderId))
    ));
  if (!snap) return null;
  const st = (snap.stops || []).find(st =>
    (stopId && (st.stopId === stopId || st.orderId === stopId)) ||
    (orderId && (st.orderId === orderId || st.stopId === 'S-' + orderId))
  );
  if (!st) return null;
  return {
    stopId: st.stopId || 'S-' + st.orderId || stopId,
    orderId: st.orderId || null,
    customerId: st.customerId,
    customerName: st.customerName,
    preOrderKg: st.preOrderKg || 0,
    devolucionKg: st.devolucionKg || 0,
    recompraKg: st.recompraKg || 0,
    deliveredKg: st.deliveredKg !== undefined ? st.deliveredKg : (st.preOrderKg || 0),
    creditAmount: st.creditAmount || 0,
    creditPaidAmount: st.creditPaidAmount || 0,
    creditPaidType: st.creditPaidType || null,
    oldDebtPaid: st.oldDebtPaid || 0,
    completedAt: st.completedAt || null,
    status: 'completed',
    skipReason: null,
    skipNote: null,
  };
}

function buildStopFromOrder(o) {
  const completed = o.status === 'completed' || o.status === 'skipped';
  return {
    stopId: 'S-' + o.id,
    orderId: o.id,
    customerId: o.customerId,
    customerName: o.customerName,
    preOrderKg: o.qty,
    staleKg: 0,
    devolucionKg: o.devolucionKg || 0,
    recompraKg: o.recompraKg || 0,
    extraKg: 0,
    deliveredKg: completed ? (o.deliveredKg || o.qty) : 0,
    creditAmount: o.creditAmount || 0,
    creditPaidType: o.creditPaidType || null,
    creditPaidAmount: o.creditPaidAmount || 0,
    oldDebtPaid: o.oldDebtPaid || 0,
    skipReason: o.skipReason || null,
    skipNote: o.skipNote || null,
    completedAt: o.completedAt || null,
    paymentType: '',
    cashTendered: 0,
    stopPhase: 'pendiente',
    status: completed ? o.status : 'active',
    sequence: 1,
    deliveryDraft: completed ? null : (o.deliveryDraft || null),
  };
}

function navigateToTripOrder(tripId, orderId) {
  AppState.currentTripId = tripId;
  App.navigate('stop', { stopId: 'S-' + orderId, orderId });
}

// ─── CUSTOMER FORM SCREEN ───────────────────────────────
function renderCustomerFormScreen() {
  if (Auth.isDriver()) {
    AppState.screen = 'mainMenu';
    AppState.params = {};
    return renderMainMenu();
  }
  const cId = AppState.params?.customerId || null;
  const c = cId ? getCustomer(cId) : null;
  const isEdit = !!c;
  return {
    html: `
      <div class="erp-screen">
        <div style="display:flex;align-items:center;gap:8px;padding:10px 10px 4px">
          <button class="erp-btn erp-btn-sm" onclick="App.goBack()">← VOLVER</button>
          <div>
            <div style="font-size:15px;font-weight:700;color:var(--slate-900)">${isEdit ? 'Editar cliente' : 'Nuevo cliente'}</div>
          </div>
        </div>
        <div style="flex:1;overflow-y:auto;padding:10px 10px 80px">
          <div style="background:white;border:1px solid var(--slate-200);padding:12px">
            <div class="erp-field">
              <div class="erp-label">Cliente</div>
              <input class="erp-input" id="cf-name" value="${isEdit ? escHtml(c.name) : ''}" placeholder="Nombre del cliente">
            </div>
            <div class="erp-field">
              <div class="erp-label">Contacto</div>
              <input class="erp-input" id="cf-contact" value="${isEdit ? escHtml(c.contact || '') : ''}" placeholder="Nombre del contacto">
            </div>
            <div class="erp-field">
              <div class="erp-label">Teléfono</div>
              <input class="erp-input" id="cf-phone" value="${isEdit ? escHtml(c.phone) : ''}" placeholder="555-0000">
            </div>
            <div class="erp-field">
              <div class="erp-label">Dirección</div>
              <input class="erp-input" id="cf-direccion" value="${isEdit ? escHtml(c.direccion || '') : ''}" placeholder="Calle y número">
            </div>
            ${!isEdit ? `
              <div class="erp-field">
                <div class="erp-label">Adeudo inicial ($)</div>
                <input class="erp-input" id="cf-balance" type="number" min="0" step="0.01" value="" placeholder="0 = sin deuda previa">
                <div style="font-size:10px;color:var(--slate-400);font-family:monospace;margin-top:4px">Deuda que el cliente ya tenía. Aparecerá en su saldo y Estado de cuentas.</div>
              </div>
            ` : ''}
          </div>
          <div style="display:flex;gap:8px;margin-top:12px">
            <button class="erp-btn erp-btn-secondary" style="flex:1" onclick="App.goBack()">Cancelar</button>
            <button class="erp-btn erp-btn-primary" style="flex:2" onclick="saveCustomerFromScreen()">${isEdit ? 'Guardar cambios' : 'Crear cliente'}</button>
          </div>
        </div>
      </div>
    `,
    init: () => {}
  };
}

function saveCustomerFromScreen() {
  const name = document.getElementById('cf-name').value.trim();
  if (!name) { showToast('El nombre es obligatorio'); return; }
  const cId = AppState.params?.customerId || null;
  const direccion = document.getElementById('cf-direccion').value.trim();
  const data = {
    name,
    contact: document.getElementById('cf-contact').value.trim(),
    phone: document.getElementById('cf-phone').value.trim(),
    direccion,
  };
  const routeMatch = direccion ? ROUTES.find(r => r.toLowerCase() === direccion.toLowerCase()) : null;
  if (routeMatch) data.route = routeMatch;
  if (cId) {
    updateCustomer(cId, data);
    showToast('✓ Cliente actualizado');
  } else {
    const c = addCustomer(data);
    const opening = parseFloat(document.getElementById('cf-balance')?.value) || 0;
    if (c && opening > 0) {
      addOpeningDebt(c.id, opening, today());
    }
    showToast('✓ Cliente creado');
  }
  App.goBack();
}

function escHtml(s) {
  const d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
}

// ─── CLEANUP RUTAS CONFIRM ──────────────────────────────
function confirmCleanupRouteData() {
  if (!confirm('¿Limpiar rutas y transacciones?\n\nSe BORRARÁN: viajes, paradas, sesiones (cobros), cortes, venta callejera, abonos CxC, deudas iniciales y saldos de clientes.\n\nSe CONSERVARÁN: clientes, precios, recurrencias y TODOS los pedidos (incluidos recurrentes).\n\nEsta acción no se puede deshacer.')) return;
  cleanupRouteData();
}

// ─── CUSTOMER DELETE ────────────────────────────────────
function deleteCustomerConfirm(id) {
  const c = getCustomer(id);
  if (!c) return;
  if (confirm('¿Eliminar a "' + c.name + '"? Esta acción no se puede deshacer.')) {
    deleteCustomer(id);
    showToast('✓ Cliente eliminado');
    render();
  }
}

// ─── ORDER ACTIONS ──────────────────────────────────────
function cancelOrder(orderId) {
  cancelAdvanceOrder(orderId);
  showToast('✓ Pedido cancelado');
  render();
}

function deleteOrder(orderId) {
  if (confirm('¿Eliminar este pedido permanentemente?')) {
    if (AppState.editingOrderId === orderId) { AppState.editingOrderId = null; AppState.orderRecurrence = null; }
    deleteAdvanceOrder(orderId);
    showToast('✓ Pedido eliminado');
    render();
  }
}

function editOrder(orderId) {
  const o = getAllAdvanceOrders().find(x => x.id === orderId);
  if (!o) return;
  AppState.editingOrderId = orderId;
  AppState.orderRecurrence = o.recurrence || null;
  AppState.showOrderForm = true;
  render();
}

function cancelEditOrder() {
  AppState.editingOrderId = null;
  AppState.orderRecurrence = null;
  AppState.showOrderForm = false;
  render();
}

function bulkDeleteOrders() {
  const sel = AppState.selectedOrders;
  if (!sel || sel.length === 0) return;
  if (!confirm('¿Eliminar ' + sel.length + ' pedido(s) permanentemente?')) return;
  sel.forEach(id => {
    if (AppState.editingOrderId === id) { AppState.editingOrderId = null; AppState.orderRecurrence = null; }
    deleteAdvanceOrder(id);
  });
  AppState.selectedOrders = [];
  render();
}

// ─── PRODUCT PRICE SETTINGS ────────────────────────────

function saveProductPrices() {
  PRODUCTOS.forEach(p => {
    const el = document.getElementById('price-' + p.id);
    if (el) {
      const v = parseFloat(el.value);
      if (v > 0) setProductPrice(p.id, v);
    }
  });
  showToast('✅ Precios guardados');
}

function saveUserProfile() {
  const name = (document.getElementById('user-name')?.value || '').trim();
  const id = (document.getElementById('user-id')?.value || '').trim();
  if (!name) { showToast('❌ Ingresa un nombre'); return; }
  AppState.driver.name = name;
  AppState.driver.id = id || AppState.driver.id;
  DB.User.save({ name: AppState.driver.name, id: AppState.driver.id });
  showToast('✅ Chofer guardado');
  render();
}
